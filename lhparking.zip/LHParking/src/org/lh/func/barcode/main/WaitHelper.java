package org.lh.func.barcode.main;

import org.sendi.parking.wxapi.Util;

/**
 * 
 * @author Administrator
 * 用于阻塞 webview 线程 等待结果
 */
public class WaitHelper {

	private static WaitHelper mHelper;
	
	public static WaitHelper getInstance(){
		if(mHelper == null){
			mHelper = new WaitHelper();
		}
		return mHelper;
	}

	private Object optionLock = new Object();
	private int result = 0;//代表失败  1代表成功
	private String wxresult = "null";
	
	public int getResult(){
		int temp = result;
		result = 0;
		return temp;
	}

	/**
	 * js 端调用 某功能 并阻塞自己
	 * @param runid
	 */
	public void callOption() {
		synchronized (optionLock) {
			try {
				optionLock.wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**
	 * java 功能执行结束
	 * @param runid
	 */
	public void optionEnd(int result){
		synchronized (optionLock) {
			this.result = result;
			optionLock.notify();
		}
	}
	
	public void optionWXPayEnd(String result) {
		synchronized (optionLock) {
			this.wxresult = result;
			optionLock.notify();
		}
	}
	
	private String payResult = new Util().formatPayResult(false, "操作失败", false);
	
	public String getPayResult() {
		String temp = payResult;
		payResult = new Util().formatPayResult(false, "操作失败", false);
		return temp;
	}
	
	public void setPayResutlt(String result) {
		this.payResult = result;
	}
	
}
