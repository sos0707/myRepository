package org.sendi.parking.notify;

import java.io.File;

import org.sendi.parking.global.ParkingIntentDefiner;
import org.sendi.parking.service.DownService;
import org.sendi.parking.utils.LogX;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;

/**
 * 下载 apk 更新操作
 * 
 * @author Administrator
 * 
 */
public class ApkNotifyHolder extends DownNotifyBuilder {

	public ApkNotifyHolder(Context context) {
		super(context);
	}

	@Override
	protected PendingIntent getFailPendingIntent(String info) {
		// TODO Auto-generated method stub
		Intent intent = new Intent(mContext, DownService.class);
		intent.putExtra(ParkingIntentDefiner.EXTRA_DOWN_SERVICE_URL, info);
		PendingIntent pintent = PendingIntent.getService(mContext, 1,
				intent,
				PendingIntent.FLAG_ONE_SHOT);
		return pintent;
	}

	@Override
	protected PendingIntent getSuccessPendingIntent(String info) {
		// TODO Auto-generated method stub
		LogX.i("info : " + info);
		Intent intent = new Intent(Intent.ACTION_VIEW);
		intent.setDataAndType(Uri.fromFile(new File(info)),
				"application/vnd.android.package-archive");
		PendingIntent pintent = PendingIntent.getActivity(mContext, 1, intent,
				PendingIntent.FLAG_ONE_SHOT);
		return pintent;
	}

	@Override
	protected String getSuccessInfo() {
		// TODO Auto-generated method stub
		return "下载成功,点击安装";
	}

	@Override
	protected String getTitleInfo() {
		// TODO Auto-generated method stub
		return "浪花停车版本更新下载";
	}

}
