package org.sendi.parking.notify;

import org.sendi.parking.global.ParkingIntentDefiner;
import org.sendi.parking.im.service.PacketService;
import org.sendi.parking.ui.LHParkingActivity;

import cn.gzsendi.lhparking.R;
import android.annotation.TargetApi;
import android.app.Notification;
import android.app.Notification.Builder;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class SystemMsgNotifyBuilder implements INotifyBuilder {

	private Context mContext;
	private String mText;
	private String mTargetUrl;

	public SystemMsgNotifyBuilder(Context context, String msg, String url) {
		this.mContext = context;
		this.mText = msg;
		this.mTargetUrl = url;
	}

	@Override
	public Notification buildNotify() {
		// TODO Auto-generated method stub
		Notification notification;
		if (Build.VERSION.SDK_INT >= 11) {
			notification = buildNew();
		} else {
			notification = buildOld();
		}
		return notification;
	}

	private Notification buildOld() {
		// TODO Auto-generated method stub
		Notification notification = new Notification();
		notification.icon = R.drawable.icon;
		notification.defaults = Notification.DEFAULT_LIGHTS;
		if (isNeedSound()) {
			notification.defaults |= Notification.DEFAULT_SOUND;
		}
		if (isNeedVibra()) {
			notification.defaults |= Notification.DEFAULT_VIBRATE;
		}
		notification.flags |= Notification.FLAG_AUTO_CANCEL;
		notification.when = System.currentTimeMillis();
		notification.tickerText = mText;
		notification.setLatestEventInfo(mContext, "浪花停车", mText, getIntent());
		return notification;
	}

	@TargetApi(11)
	private Notification buildNew() {
		Builder builder = new Builder(mContext);
		builder.setContentText(mText);
		builder.setContentTitle("浪花停车");
		int defaults = Notification.DEFAULT_LIGHTS;
		if (isNeedSound()) {
			defaults |= Notification.DEFAULT_SOUND;
		}
		if (isNeedVibra()) {
			defaults |= Notification.DEFAULT_VIBRATE;
		}
		builder.setDefaults(defaults);
		builder.setAutoCancel(true);
		builder.setSmallIcon(R.drawable.icon);
		builder.setTicker(mText);
		builder.setWhen(System.currentTimeMillis());
		builder.setContentIntent(getIntent());
		return builder.getNotification();
	}

	private boolean isNeedSound() {
		return true;
	}

	private boolean isNeedVibra() {
		return true;
	}

	private PendingIntent getIntent() {
		Intent intent = new Intent(mContext, PacketService.class);
		intent.putExtra(ParkingIntentDefiner.EXTRA_INTENT_CLICK_SYSMSG, true);
		return PendingIntent.getService(mContext, 0, intent, 0);
	}

}
