package org.sendi.parking.notify;

import android.app.Notification;

public interface INotifyBuilder {
	
	Notification buildNotify();

}
