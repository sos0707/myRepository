package org.sendi.parking.notify;

import java.util.Random;

import cn.gzsendi.lhparking.R;
import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.view.View;
import android.widget.RemoteViews;

/**
 * 
 * @author Administrator
 * 
 */
public abstract class DownNotifyBuilder implements INotifyBuilder {

	protected Context mContext;
	private NotificationManager mManager;
	private Notification mNotification;
	private int mNotifyId = new Random().nextInt(1000);
	private int mCurProgress;
	private long lastUpdateTime;

	public DownNotifyBuilder(Context context) {
		this.mContext = context;
		this.mManager = (NotificationManager) context
				.getSystemService(Context.NOTIFICATION_SERVICE);
		mNotification = buildNotify();
	}

	@SuppressLint("NewApi")
	@Override
	public Notification buildNotify() {
		// TODO Auto-generated method stub
		Notification.Builder builder = new Notification.Builder(mContext);
		builder.setSmallIcon(R.drawable.icon);
		builder.setContent(new RemoteViews("cn.gzsendi.lhparking",
				R.layout.layout_notify_down));
		builder.setDefaults(Notification.DEFAULT_LIGHTS);
		builder.setWhen(System.currentTimeMillis());
		builder.setAutoCancel(true);
		return builder.getNotification();
	}

	public void onStart() {
		RemoteViews views = mNotification.contentView;
		views.setViewVisibility(R.id.layout_notify_down_progress_pb, View.GONE);
		views.setViewVisibility(R.id.layout_notify_down_progress_tv, View.GONE);
		views.setTextViewText(R.id.layout_notify_down_info_tv, "准备下载");
		views.setTextViewText(R.id.layout_notify_down_title_tv, getTitleInfo());
		updateNotify();
	}

	public void onProgress(int progress) {
		RemoteViews views = mNotification.contentView;
		if (mCurProgress == 0) {
			views.setViewVisibility(R.id.layout_notify_down_progress_pb,
					View.VISIBLE);
			views.setViewVisibility(R.id.layout_notify_down_progress_tv,
					View.VISIBLE);
			views.setTextViewText(R.id.layout_notify_down_info_tv, "下载中");
		}
		mCurProgress = progress;
		views.setProgressBar(R.id.layout_notify_down_progress_pb, 100,
				mCurProgress, false);
		views.setTextViewText(R.id.layout_notify_down_progress_tv, progress
				+ "%");
		updateNotify();
	}

	public void onFail(String info) {
		RemoteViews views = mNotification.contentView;
		views.setViewVisibility(R.id.layout_notify_down_progress_pb, View.GONE);
		views.setViewVisibility(R.id.layout_notify_down_progress_tv, View.GONE);
		views.setTextViewText(R.id.layout_notify_down_info_tv, "下载失败，点击重试");
		mNotification.contentIntent = getFailPendingIntent(info);
		updateNotify();
	}

	public void onSuccess(String info/* path or other? */) {

		RemoteViews views = mNotification.contentView;
		views.setViewVisibility(R.id.layout_notify_down_progress_pb, View.GONE);
		views.setViewVisibility(R.id.layout_notify_down_progress_tv, View.GONE);
		views.setTextViewText(R.id.layout_notify_down_info_tv, getSuccessInfo());
		mNotification.contentIntent = getSuccessPendingIntent(info);
		updateNotify();
	}

	public void onCancel() {
		mManager.cancel(mNotifyId);
	}

	public void updateNotify() {
		if(mCurProgress > 0 && mCurProgress < 100){
			long current = System.currentTimeMillis();
			if(current - lastUpdateTime < 2000){
				return;
			}
			lastUpdateTime = current;
		}  
		mManager.notify(mNotifyId, mNotification);
	}
	
	protected abstract String getTitleInfo();

	protected abstract PendingIntent getFailPendingIntent(String info);

	protected abstract PendingIntent getSuccessPendingIntent(String info);

	protected abstract String getSuccessInfo();
}
