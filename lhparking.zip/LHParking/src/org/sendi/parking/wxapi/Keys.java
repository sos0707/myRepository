﻿/*
 * Copyright (C) 2010 The MobileSecurePay Project
 * All right reserved.
 * author: shiqun.shi@alipay.com
 * 
 *  提示：如何获取安全校验码和合作身份者id
 *  1.用您的签约支付宝账号登录支付宝网站(www.alipay.com)
 *  2.点击“商家服务”(https://b.alipay.com/order/myorder.htm)
 *  3.点击“查询合作者身份(pid)”、“查询安全校验码(key)”
 */

package org.sendi.parking.wxapi;

//
// 请参考 Android平台安全支付服务(msp)应用开发接口(4.2 RSA算法签名)部分，并使用压缩包中的openssl RSA密钥生成工具，生成一套RSA公私钥。
// 这里签名时，只需要使用生成的RSA私钥。
// Note: 为安全起见，使用RSA私钥进行签名的操作过程，应该尽量放到商家服务器端去进行。
public final class Keys {

	//合作身份者id，以2088开头的16位纯数字
	public static final String DEFAULT_PARTNER = "2088411405573923";

	//收款支付宝账号
//	public static final String DEFAULT_SELLER = "zfb@gzsendi.cn";
	public static final String DEFAULT_SELLER = "2088411405573923";

	//商户私钥，自助生成
	public static final String PRIVATE = "MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBAL/mn3QSP4EoAvY5svu/Ec23EO1g1pbzVEkjbM+jul4PI9JmOTDUZ2UwpqxKGl8IVgMyLwEYfu2KADAwaij0tNKqRmYpgiBqeF0MnZgzE3t3xj+UzpnsxsUzIFTDwpf0uP3Dhwa4fRZQ3jit8fV9/sTZ/bK8TZKQlOXuYd9bSt1dAgMBAAECgYB53OiRey0cxd3rowSIXfPeYUy8kexz+54gvABTc7PcG10yNXxIB/qJBfYyHvTUOKT2bp3u4jFog2RPNc+UpqFUsrfQW6aRszbReJGMcQ1cO8nGJEJesCIv2QoHls1+An50WMVXgOisqsDKpUwTcRIFYZgAYvMesFk3M7PCdNP6AQJBAPwhqAjDRWbJVOYXRXe3AlffvyixqkVCOLqEuOGSNFeVmY/wYqXof1Cdav6CepeL/NOsY8u6LZCwl5rg96z4SMECQQDC2GM3eX+u1MJNKQDkkCXBtqIxLnk3Y3rlUxtxEwr//CRFV7mTWSW8kZ8VWAb3ySQlrh4X7x+LLgltYb38Dv+dAkB3CPjJMk/oyDLR8ri0XW24yQT6FG8cBbi8rn6O2LTniNSYNViNlafOCpQCFt4EAG5cDS6Md5idkBHzaDTmr83BAkBg7js1jsj5VbivoBVkn11ZKB058E+3QVMTIKwHLZ0MSghVQtX8Op4uWBdXC+qzfCnyYNNxvrDnkWh5NOXJrkB1AkB83irtSe3fCzHQdkKawF1Ckjmj+ZphOUR3jD/Px09nUvzOsNgoKYOYWVU1wbtqdI4XXBejrOA/euns4K9PUYyo";

	public static final String PUBLIC = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCnxj/9qwVfgoUh/y2W89L6BkRAFljhNhgPdyPuBV64bfQNN1PjbCzkIM6qRdKBoLPXmKKMiFYnkd6rAoprih3/PrQEB/VsW8OoM8fxn67UDYuyBTqA23MML9q1+ilIZwBC2AQ2UBVOrFXfFl75p6/B5KsiNG9zpgmLCUYuLkxpLQIDAQAB";

}
