package org.sendi.parking.wxapi;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;

public class DBUtil {
	
	public static void createTable(SQLiteDatabase db, String strTableName) {
		String sql = "CREATE TABLE IF NOT EXISTS "
				+ strTableName
				+ "(uid text not null, outtradeno text primary key not null, errcode text not null, errmsg text not null)";
		db.execSQL(sql);
	}
	
	public static void insertPayInfo(SQLiteDatabase db, String tableName, String outTradeno, String errCode, String errMsg) {
		ContentValues cv = new ContentValues();
		cv.put("uid", tableName);
		cv.put("outtradeno", outTradeno );
		cv.put("errcode", errCode);
		cv.put("errmsg", errMsg);
		db.insert(tableName, null, cv);
		db.close();
	}
	
	public static void updatePayInfo(SQLiteDatabase db, String tableName, String outTradeno, String errCode, String errMsg) {
		ContentValues cv = new ContentValues();
		cv.put("errcode", errCode);
		cv.put("errmsg", errMsg);
		db.update(tableName, cv, "outtradeno=?", new String[]{outTradeno});
		db.close();	
	}
	
}
