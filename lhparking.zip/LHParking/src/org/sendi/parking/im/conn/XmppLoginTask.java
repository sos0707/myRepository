package org.sendi.parking.im.conn;

import org.jivesoftware.smack.Connection;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smack.packet.Presence;
import org.jivesoftware.smack.packet.XMPPError;
import org.sendi.parking.global.ParkingApp;
import org.sendi.parking.im.service.PacketService;
import org.sendi.parking.utils.LogX;

import com.ab.util.AbStrUtil;

import android.content.Intent;

/**
 * 登入 task
 * 
 * @author Administrator
 * 
 */
public class XmppLoginTask implements Runnable {

	private String mName;
	private String mPwd;

	public void setName(String name){
		this.mName = name;
	}
	
	public void setPwd(String pwd){
		this.mPwd = pwd;
	}
	
	public boolean hasLoginInfo(){
		boolean result = !AbStrUtil.isEmpty(mName) && !AbStrUtil.isEmpty(mPwd);
		if(result){
			LogX.i("有注册信息");
		}else{
			LogX.i("未注册");
		}
		return result;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		if(hasLoginInfo()){
			doConn();
		}
	}

	private void doConn() {
		XmppManager xmpp = XmppManager.getXmpp();
		Connection conn = xmpp.getXmppConn();
		if (!conn.isConnected()) {
			LogX.i("qh", "try to conn");
			try {
				conn.connect();
			} catch (XMPPException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else{
			LogX.i("qh", "isConned");
		}
		if (!xmpp.isLogined()) {
			LogX.i("qh", "try to login : name : pwd : "+mName+":"+mPwd);
			try {
				conn.login(mName, mPwd);
				handLoginSuccess(conn);
				xmpp.login(true);
				ParkingApp.mApp.startService(new Intent(ParkingApp.mApp, PacketService.class));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				handLoginFail(e);
				xmpp.login(false);
			}
		}else{
			LogX.i("qh", "isLogined");
		}
	}

	private void handLoginSuccess(Connection conn) {
		conn.sendPacket(new Presence(Presence.Type.available));// 上线
	}

	private void handLoginFail(Exception xmppe) {
		xmppe.printStackTrace();
		XmppManager.getXmpp().login(false);
		if (xmppe instanceof XMPPException) {
			XMPPError error = ((XMPPException) xmppe).getXMPPError();
			int errorcode = error != null ? error.getCode() : 0;
			switch (errorcode) {
			case 407:
				// 未注册
				LogX.i("LOGIN", "未注册");
				break;
			case 401:
			case 403:
				LogX.i("LOGIN", "帐号或密码错误");
				break;
			default:
				// unknow error
				LogX.i("LOGIN", "Xmpp 登入错误  error code : " + errorcode);
				break;
			}
		} else {
			LogX.i("LOGIN", "unknow login exception");
		}
	}

}
