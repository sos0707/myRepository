package org.sendi.parking.im.service;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

import org.sendi.parking.global.ParkingPrefs;
import org.sendi.parking.im.conn.XmppLoginTask;
import org.sendi.parking.im.conn.XmppManager;
import org.sendi.parking.utils.LogX;

import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

/**
 * 
 * @author Administrator
 *
 */
public class ConnService extends Service{
	
	private static final int HEART_TIME = 1000 * 20;
	
	private Executor mBgConnWorker;
	private XmppLoginTask mConnTask = new XmppLoginTask();
	private Runnable mTimerTask = new Runnable() {
		
		@Override
		public void run() {
			// TODO Auto-generated method stub
			LogX.i("qh", "do timer task");
			if(!mConnTask.hasLoginInfo()){
				String uid = ParkingPrefs.getStrValue(ParkingPrefs.PREF_LANGHUA_UID);
				mConnTask.setName(uid);
				mConnTask.setPwd(uid);
			}
			mConnTask.run();
			try {
				Thread.sleep(HEART_TIME);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			doConn();
		}
	};
	
	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		startForeground(0, new Notification());
		mBgConnWorker = Executors.newSingleThreadScheduledExecutor(new ThreadFactory() {
			
			@Override
			public Thread newThread(Runnable r) {
				// TODO Auto-generated method stub
				Thread t = new Thread(r);
				t.setPriority(Thread.MIN_PRIORITY);
				t.setDaemon(true);
				return t;
			}
		});
		doConn();
	}
	
	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		XmppManager.getXmpp().disConn();
	}
	
	private void doConn(){
		mBgConnWorker.execute(mTimerTask);
	}
	
}
