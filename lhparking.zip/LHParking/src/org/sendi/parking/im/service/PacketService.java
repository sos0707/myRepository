package org.sendi.parking.im.service;

import java.util.Random;

import org.jivesoftware.smack.Connection;
import org.jivesoftware.smack.PacketListener;
import org.jivesoftware.smack.filter.MessageTypeFilter;
import org.jivesoftware.smack.filter.PacketFilter;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.Packet;
import org.jivesoftware.smack.packet.Message.Type;
import org.sendi.parking.global.ParkingIntentDefiner;
import org.sendi.parking.im.conn.XmppManager;
import org.sendi.parking.notify.SystemMsgNotifyBuilder;
import org.sendi.parking.notify.INotifyBuilder;
import org.sendi.parking.ui.LHParkingActivity;
import org.sendi.parking.utils.LogX;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;

/**
 * 
 * @author Administrator
 * 
 */
public class PacketService extends Service implements PacketListener {

	private NotificationManager mNotifyService;
	private int notifyId;
	private int sysMsgCount;
	private Notification notification;

	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		mNotifyService = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
		Connection conn = XmppManager.getXmpp().getXmppConn();
		conn.addPacketListener(this, getPacketFilter());
		notifyId = new Random().nextInt(1000);
		// conn.addPacketListener(ACCEPT_CHAT_LISTENER, new
		// MessageTypeFilter(Type.chat));
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		// TODO Auto-generated method stub
		boolean isClickFromNotify = false;
		if (intent != null) {
			isClickFromNotify = intent.getBooleanExtra(
					ParkingIntentDefiner.EXTRA_INTENT_CLICK_SYSMSG, false);
		}
		LogX.i("qh", "is click from notify : "+isClickFromNotify);
		if (isClickFromNotify) {// 重新开始
			notifyId = new Random().nextInt(1000);
			sysMsgCount = 0;
			notification = null;
			Intent intent2main = new Intent(this, LHParkingActivity.class);
			intent2main.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			startActivity(intent2main);
		}
		return START_STICKY;
	}

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		XmppManager.getXmpp().getXmppConn().removePacketListener(this);
		// XmppManager.getXmpp().getXmppConn().removePacketListener(ACCEPT_CHAT_LISTENER);
	}

	private PacketFilter getPacketFilter() {
		// TODO Auto-generated method stub
		return new MessageTypeFilter(Type.chat);
	}

	@Override
	public void processPacket(Packet packet) {
		// TODO Auto-generated method stub
		Message msg = (Message) packet;
		String body = msg.getBody();
		LogX.i("qh", body);
		LogX.i("qh", msg.getFrom());
		if (body != null) {
			String[] datas = body.split("_#_");
			if (datas.length >= 2) {
				String text = datas[0];
				String url = datas[1];
				sysMsgCount++;
				showNotification(text, url);
			}
		}
	}

	@SuppressWarnings("deprecation")
	private void showNotification(String text, String url) {
		if (notification == null) {
			INotifyBuilder builder = new SystemMsgNotifyBuilder(this, text, url);
			notification = builder.buildNotify();
			mNotifyService.notify(notifyId, notification);
		} else {
			notification.setLatestEventInfo(this, "浪花停车", "您有" + sysMsgCount
					+ "条未读消息", notification.contentIntent);
			mNotifyService.notify(notifyId, notification);
		}

	}

}
