package org.sendi.parking.service;

import java.io.File;

import org.sendi.parking.global.ParkingIntentDefiner;
import org.sendi.parking.global.ParkingLocal;
import org.sendi.parking.notify.ApkNotifyHolder;

import com.ab.http.AbFileHttpResponseListener;
import com.ab.http.AbHttpUtil;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

/**
 * 下载  apk
 * @author Administrator
 * 
 */
public class DownService extends Service {

	public static boolean inDown = false;
	private ApkNotifyHolder mNotifyHolder;

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		// TODO Auto-generated method stub
		if(!inDown){
			String url = intent
					.getStringExtra(ParkingIntentDefiner.EXTRA_DOWN_SERVICE_URL);
			doDownFile(url);
		}
		return super.onStartCommand(intent, flags, startId);
	}

	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}

	private void doDownFile(final String url) {
		if(url == null){
			stopSelf();
			return;
		}
		inDown = true;
		if (mNotifyHolder != null) {
			mNotifyHolder.onCancel();
			mNotifyHolder = null;
		}
		mNotifyHolder = new ApkNotifyHolder(this);
		File file = new File(ParkingLocal.getCacheDir(), "1.apk");
		if(file.exists()){
			file.delete();
		}
		AbHttpUtil.getInstance(this).get(url, new AbFileHttpResponseListener(file) {
			@Override
			public void onStart() {
				// TODO Auto-generated method stub
				mNotifyHolder.onStart();
			}

			@Override
			public void onProgress(int bytesWritten, int totalSize) {
				// TODO Auto-generated method stub
				mNotifyHolder.onProgress(bytesWritten * 100 / totalSize);
			}

			@Override
			public void onFailure(int statusCode, String content,
					Throwable error) {
				// TODO Auto-generated method stub
				mNotifyHolder.onFail(url);
				inDown = false;
				stopSelf();
			}

			@Override
			public void onSuccess(int statusCode, File file) {
				// TODO Auto-generated method stub
				mNotifyHolder.onSuccess(file.getAbsolutePath());
				inDown = false;
				stopSelf();
			}
			
			@Override
			public void onFinish() {
				// TODO Auto-generated method stub
				super.onFinish();
				if(inDown){//处理 http请求被意外重置  说明既没有成功 也没有失败
					mNotifyHolder.onFail(url);
					inDown = false;
				}
			}
		});
	}

}
