package org.sendi.parking.ui;

import java.io.ByteArrayInputStream;

import org.lh.func.barcode.main.WaitHelper;
import org.sendi.parking.global.ParkingApp;
import org.sendi.parking.global.ParkingIntentDefiner;
import org.sendi.parking.global.ParkingLocal;
import org.sendi.parking.global.ParkingPrefs;
import org.sendi.parking.global.WeakHandler;
import org.sendi.parking.im.service.ConnService;
import org.sendi.parking.service.DownService;
import org.sendi.parking.ui.base.LHBaseActivity;
import org.sendi.parking.ui.js.JavaScriptInterface;
import org.sendi.parking.utils.LogX;
import org.sendi.parking.wxapi.Constants;
import org.sendi.parking.wxapi.DBUtil;
import org.sendi.parking.wxapi.PayInfoDBHelper;
import org.sendi.parking.wxapi.Result;
import org.sendi.parking.wxapi.Util;
import org.sendi.parking.wxapi.WXPayUtil;

import cn.gzsendi.lhparking.R;

import com.ab.http.AbHttpUtil;
import com.ab.http.AbStringHttpResponseListener;
import com.ab.util.AbDateUtil;
import com.ab.util.AbStrUtil;
import com.tencent.mm.sdk.openapi.IWXAPI;
import com.tencent.mm.sdk.openapi.WXAPIFactory;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnDismissListener;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.GeolocationPermissions.Callback;
import android.widget.EditText;
import android.widget.Toast;

/**
 * 获取服务端页面
 * 
 * @author Administrator
 * 
 */
public class LHParkingActivity extends LHBaseActivity {

	private static final String URL_TAG_REGISTER_SUCCESS = "registerlogin=true&uid=";
	private static final String URL_TAG_WXPAY = "paytype=weixinpay&payparams=";
	
	private static final int DELAY_FREE_MEM_TIME = 10 * 1000;
	
	private WebView mWebView;
	private WXPayUtil wxpay;

	private IWXAPI api;
	private PayInfoDBHelper dbHelper = new PayInfoDBHelper(this);
	final ParkingApp app = ParkingApp.mApp;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_langhua);
		api = WXAPIFactory.createWXAPI(this, Constants.APP_ID, true);
		api.registerApp(Constants.APP_ID);
		initViews();
		app.setContext(this, mHandler);
		mWebView.loadUrl(ParkingApp.mApp.getServerConfig().getDoorURL());
		// mWebView.loadUrl("http://192.168.1.109:8080/lhparking/index.html");
		mWorkHandler.sendEmptyMessageDelayed(WorkHandler.MSG_DO_CLEAR_MEM, DELAY_FREE_MEM_TIME * 2);
		startService(new Intent(this, ConnService.class));
		checkNewVersion();
//		new Thread() {
//
//			@Override
//			public void run() {
//				// TODO Auto-generated method stub
//				JavaScriptInterface js = new JavaScriptInterface();
//				js.waitForPayResult("0.1", "201407041234560", false, "3");
//			}
//
//		}.start(); 
	}
	
		@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		mWebView.onPause();
	}
	
		@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		mWebView.clearView();
		mWebView.destroy();
		mWebView = null;
		mWorkHandler.removeMessages(WorkHandler.MSG_DO_CLEAR_MEM);
		mWorkHandler = null;
	}

	Handler mHandler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			String s[] = String.valueOf(msg.obj).split("\\,");
			Result result = new Result(s[0]);

			switch (msg.what) {
			case 1:
				String rs = result.getResultStatus();
				WaitHelper wait = WaitHelper.getInstance();
//				SQLiteDatabase db = dbHelper.getWritableDatabase();
				Log.i("pullxml", "payresult: "+ rs + "  " + msg.obj);
				if(rs.equals("9000")) {
					String result1 = new Util().formatPayResult(true, "支付成功", false);
//					DBUtil.updatePayInfo(db, ParkingPrefs.getStrValue(ParkingPrefs.PREF_LANGHUA_UID), s[1], "1", "AliPay支付成功");
//					DBUtil.updatePayInfo(db, "defaultpayinfo", s[1], "1", "AliPay支付成功");
					wait.setPayResutlt(result1);
				}else {
					String result1 = new Util().formatPayResult(false, "支付失败", false);
//					DBUtil.updatePayInfo(db, ParkingPrefs.getStrValue(ParkingPrefs.PREF_LANGHUA_UID), s[1], "0", "AliPay支付失败："+result.getResult());
//					DBUtil.updatePayInfo(db, "defaultpayinfo", s[1], "0", "AliPay支付失败："+result.getResult());
					wait.setPayResutlt(result1);
				}
				app.setIsPay(false);
				break;
			}
		};
	};
	
	@SuppressWarnings("deprecation")
	@SuppressLint("SetJavaScriptEnabled")
	private void initViews() {
		// TODO Auto-generated method stub
		mWebView = (WebView) findViewById(R.id.main_webview);
		final WebSettings mSetting = mWebView.getSettings();
		mSetting.setJavaScriptEnabled(true);
		mSetting.setJavaScriptCanOpenWindowsAutomatically(true);

		// 离线缓存
		mSetting.setDomStorageEnabled(true);
		mSetting.setAppCacheMaxSize(1024 * 1024 * 8);// 设置缓冲大小，我设的是8M
		String appCacheDir = this.getApplicationContext()
				.getDir("cache", Context.MODE_PRIVATE).getPath();
		mSetting.setAppCachePath(appCacheDir);
		mSetting.setAllowFileAccess(true);
		mSetting.setAppCacheEnabled(true);
		mSetting.setCacheMode(WebSettings.LOAD_DEFAULT);
		
		//geo
		mSetting.setGeolocationEnabled(true);
		
		mWebView.setWebChromeClient(new WebChromeClient() {
			@Override
			public void onGeolocationPermissionsShowPrompt(String origin,
					Callback callback) {
				// TODO Auto-generated method stub
				callback.invoke(origin, true, false);
			}
		});
		
		//url
		mWebView.setWebViewClient(new WebViewClient() {

			@SuppressLint("NewApi")
			@Override
			public WebResourceResponse shouldInterceptRequest(WebView view,
					String url) {
				// TODO Auto-generated method stub
				if (checkIsSpecialURL(url, URL_TAG_REGISTER_SUCCESS)) {
					saveUinfo(url);
					ByteArrayInputStream is = new ByteArrayInputStream(
							"loginorreg".getBytes());
					return new WebResourceResponse("text/html", "UTF-8", is);
				}
				
				if(checkIsSpecialURL(url, URL_TAG_WXPAY)) {
					doWXPay(url);
//					wxpaytest();
					ByteArrayInputStream is = new ByteArrayInputStream(
							"wxpay".getBytes());
					return new WebResourceResponse("text/html", "UTF-8", is);
				}
				
				return super.shouldInterceptRequest(view, url);
			}
		});
		mWebView.addJavascriptInterface(new JavaScriptInterface(), "langhua");

	}
	
	/**
	 * 尝试减少 webview使用的内存
	 */
	private void tryToFreeMemory(){
		if(mWebView != null){
			Log.i("qh", "try to free memory");
			mWebView.freeMemory();
		}
	}

	/**
	 * 拦截URL进行匹配 完成特定动作
	 * 
	 * @param url
	 * @param tag
	 * @return
	 */
	private boolean checkIsSpecialURL(String url, String tag) {
		if (url.contains(tag)) {
			return true;
		}
		return false;
	}

	// 拦截UID 注册 或者 登录成功
	private void saveUinfo(String url) {/* uinfo = uid,utype */
		LogX.i("get uid " + url);
		int index = url.lastIndexOf('=');
		String uinfo = url.substring(index + 1);
		LogX.i("get uinfo " + uinfo);
		if (!AbStrUtil.isEmpty(uinfo)) {
			LogX.i("save uinfo : " + uinfo);
			String[] uinfos = uinfo.split(",");
			ParkingPrefs.setStrValue(ParkingPrefs.PREF_LANGHUA_UID, uinfos[0]);
			ParkingPrefs
					.setStrValue(ParkingPrefs.PREF_LANGHUA_UTYPE, uinfos[1]);
			Toast.makeText(this,
					"注册成功，uid:" + uinfos[0] + " utype:" + uinfos[1],
					Toast.LENGTH_LONG).show();
		} else {
			LogX.i("error uid : " + uinfo);
			Toast.makeText(this, "注册失败，请重试...", Toast.LENGTH_LONG).show();
		}
	}

	// for check new version
	private int mVersionCode = 1;
	private int mServerVersion;
	private String mServerVersionInfo;

	private WorkHandler mWorkHandler = new WorkHandler(this);

	private static class WorkHandler extends WeakHandler<LHParkingActivity> {

		private static final int MSG_DO_GET_SERVER_VERSION = 0;
		private static final int MSG_DO_CLEAR_MEM = 1;

		public WorkHandler(LHParkingActivity owner) {
			super(owner);
			// TODO Auto-generated constructor stub
		}

		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			switch (msg.what) {
			case MSG_DO_GET_SERVER_VERSION:
				getOwner().doGetServerVersion();
				break;
			case MSG_DO_CLEAR_MEM:
				getOwner().tryToFreeMemory();
				sendEmptyMessageDelayed(MSG_DO_CLEAR_MEM, DELAY_FREE_MEM_TIME);
				break;
			default:
				break;
			}
		}
	}
	
	private void checkNewVersion() {// 貌似要延迟 5000
		// TODO Auto-generated method stub
		if (isNeedCheckVersion()) {
			mVersionCode = ParkingLocal.getVersionCode(this);
			mWorkHandler.sendEmptyMessageDelayed(
					WorkHandler.MSG_DO_GET_SERVER_VERSION, 5000);
		}
	}

	private void doGetServerVersion() {
		AbHttpUtil.getInstance(this).get(
				ParkingApp.mApp.getServerConfig().getCheckVersionURL(),
				new AbStringHttpResponseListener() {
					@Override
					public void onSuccess(int statusCode, String content) {
						// TODO Auto-generated method stub
						super.onSuccess(statusCode, content);
						parseVerson(content);
						if (mVersionCode < mServerVersion) {
							showUpdateDialog(mServerVersion, mServerVersionInfo);
						}
					}
				});
	}

	private void parseVerson(String content) {
		LogX.i("version content : |" + content + "|");
		if (!AbStrUtil.isEmpty(content)) {
			String[] params = content.split("#");
			if (params.length >= 3) {
				LogX.i("params len : " + params.length);
				String v = params[1];
				String vinfo = params[2];
				try {
					int vcode = Integer.parseInt(v);
					mServerVersion = vcode;
					mServerVersionInfo = vinfo;
				} catch (NumberFormatException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					LogX.i("to int error : |" + v+"|");
				}
				return;
			} else {
				LogX.i("params len : " + params.length);
			}
		}
		mServerVersion = mVersionCode;
		mServerVersionInfo = "";
	}

	private Dialog mUpdateDialog;

	private void showUpdateDialog(final int versioncode, String updateinfo) {
		if (mUpdateDialog == null) {
			mUpdateDialog = new AlertDialog.Builder(this).setTitle("发现新版本")
					.setMessage(updateinfo)
					.setPositiveButton("更新", new OnClickListener() {

						@Override
						public void onClick(DialogInterface dialog, int which) {
							// TODO Auto-generated method stub
							Intent intent = new Intent(LHParkingActivity.this,
									DownService.class);
							intent.putExtra(
									ParkingIntentDefiner.EXTRA_DOWN_SERVICE_URL,
									ParkingApp.mApp.getServerConfig()
											.getDownNewApkURL());
							startService(intent);
							mUpdateDialog.dismiss();
						}

					}).setNegativeButton("取消", new OnClickListener() {

						@Override
						public void onClick(DialogInterface dialog, int which) {
							// TODO Auto-generated method stub
							mUpdateDialog.dismiss();
						}
					}).create();
			mUpdateDialog.setCancelable(false);
			mUpdateDialog.setCanceledOnTouchOutside(false);
			mUpdateDialog.setOnDismissListener(new OnDismissListener() {

				@Override
				public void onDismiss(DialogInterface dialog) {
					// TODO Auto-generated method stub
					ParkingPrefs.setLongValue(
							ParkingPrefs.PREF_LANGHUA_UPDATE_LASTTIME,
							System.currentTimeMillis());
				}
			});
		}
		mUpdateDialog.show();
	}

	private boolean isNeedCheckVersion() {
		long now = System.currentTimeMillis();
		long lasttime = ParkingPrefs.getLongValue(
				ParkingPrefs.PREF_LANGHUA_UPDATE_LASTTIME, -1);
		return !AbDateUtil.isSameDayOfMillis(now, lasttime);
	}

	/**
	 * paytype=商品名称&payparams=订单号,金额&_dc=1402543750346
	 * paytype=weixinpay&payparams=2014061211290557280,12&_dc=1402543750346
	 * weixinpay--浪花停车充值
	 */
	private void doWXPay(String url) {
		wxpay = new WXPayUtil(this);
		String[] ss = new String[5];
		Float f;
		ss = url.split("\\=");
		ss = ss[2].split("\\&");
		ss = ss[0].split("\\,");
		f = Float.valueOf(ss[1]);
		int i = (int) (f * 100);
		Log.i("pullxml", String.valueOf(i) + "  "+ ss[0]);
//		wxpay.doWXPay("浪花停车充值", String.valueOf(i), ss[0]);
		//浪花停车充值
	}

	private static final int MENU_EXIT = 0;
	private static final int MENU_TEST_SET_IP = 1;
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// TODO Auto-generated method stub
		menu.add(0, MENU_EXIT, 0, "退出");
		menu.add(0, MENU_TEST_SET_IP, 0, "设置服务器地址");
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		switch (item.getItemId()) {
		case MENU_EXIT:
			mWebView.clearCache(true);
			finish();
			break;
		case MENU_TEST_SET_IP:
			showSetIpDialog();
			break;
		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}

	private Dialog mSetIpDialog;
	private EditText vSetIpEdit;

	private void showSetIpDialog() {
		if (mSetIpDialog == null) {
			vSetIpEdit = new EditText(this);
			vSetIpEdit.setHint("ip+port 或者 完整地址");
			mSetIpDialog = new AlertDialog.Builder(this).setTitle("请输入")
					.setIcon(android.R.drawable.ic_dialog_info)
					.setView(vSetIpEdit)
					.setPositiveButton("确定", new OnClickListener() {

						@Override
						public void onClick(DialogInterface dialog, int which) {
							// TODO Auto-generated method stub
							String text = vSetIpEdit.getText().toString()
									.trim();
							if (text.length() <= 0) {
								return;
							}
							ParkingApp.mApp.getServerConfig().setServerAddress(
									text);
							mWebView.clearCache(false);
							mWebView.loadUrl(ParkingApp.mApp.getServerConfig()
									.getDoorURL());
						}
					}).setNegativeButton("取消", null).create();
		}
		mSetIpDialog.show();
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		if (keyCode == KeyEvent.KEYCODE_BACK && mWebView.canGoBack()) {
			   mWebView.goBack();// 返回前一个页面
			   return true;
			  }
		return super.onKeyDown(keyCode, event);
	}
	
	
}
