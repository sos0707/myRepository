package org.sendi.parking.ui.js;

import org.lh.func.barcode.main.CaptureActivity;
import org.lh.func.barcode.main.WaitHelper;
import org.sendi.parking.global.ParkingApp;
import org.sendi.parking.global.ParkingIntentDefiner;
import org.sendi.parking.global.ParkingPrefs;
import org.sendi.parking.model.ScanTask;
import org.sendi.parking.utils.LogX;
import org.sendi.parking.wxapi.AliPayUtil;
import org.sendi.parking.wxapi.DBUtil;
import org.sendi.parking.wxapi.PayInfoDBHelper;
import org.sendi.parking.wxapi.Util;
import org.sendi.parking.wxapi.WXPayUtil;

import com.ab.util.AbStrUtil;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.webkit.JavascriptInterface;

/**
 * 
 * @author Administrator
 *
 */
public final class JavaScriptInterface {
	
	/**
	 * 
	 * @return
	 */
	@JavascriptInterface
	public String getUID(){
		String uid = ParkingPrefs.getStrValue(ParkingPrefs.PREF_LANGHUA_UID);
		if(uid == null){
			uid = "0";
		}
		LogX.i("req uid from js : "+uid+" from : "+Thread.currentThread());
		return uid;
	}
	
	@JavascriptInterface
	public String getUTYPE(){
		String utype = ParkingPrefs.getStrValue(ParkingPrefs.PREF_LANGHUA_UTYPE);
		LogX.i("req utype from js : "+utype+" from : "+Thread.currentThread());
		return utype;
	}
	
	@JavascriptInterface
	public int waitForScanResult(String taskId, String numOfScan){
		Log.i("qh", "wait for scan : "+Thread.currentThread().getName());
		if(AbStrUtil.isEmpty(taskId) || 
				AbStrUtil.isEmpty(numOfScan)){
			return 0;
		}
		final ParkingApp app = ParkingApp.mApp;
		final ScanTask scanTask = new ScanTask();
		scanTask.setTask_id(taskId);
		scanTask.setNumOfScan(numOfScan);
		app.runOnUIThread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				Intent intent = new Intent(app, CaptureActivity.class);
				intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				intent.putExtra(ParkingIntentDefiner.EXTRA_SCAN_TASK, scanTask);
				app.startActivity(intent);
				Log.i("qh", "start activity : scan");
			}
		});
		WaitHelper scan = WaitHelper.getInstance();
		scan.callOption();
		int result = scan.getResult();
		return result;
	}
	
	@JavascriptInterface
	public String waitForWXPayResult(String fee, final String outtradeno, boolean lock) {
		final ParkingApp app = ParkingApp.mApp;
		WaitHelper wait = WaitHelper.getInstance();
		String result = "";
		if(lock) {
			Float f = Float.valueOf(fee);
			int i = (int) (f * 100);
			final String totalfee = String.valueOf(i);
			Log.i("pullxml", totalfee);
//			PayInfoDBHelper dbHelper = new PayInfoDBHelper(ParkingApp.mContext);
			ParkingApp.setIsPay(true);
//			SQLiteDatabase db = dbHelper.getWritableDatabase();
//			DBUtil.createTable(db, ParkingPrefs.getStrValue(ParkingPrefs.PREF_LANGHUA_UID));
//			DBUtil.createTable(db, "defaultpayinfo");
//			DBUtil.insertPayInfo(db, ParkingPrefs.getStrValue(ParkingPrefs.PREF_LANGHUA_UID), outtradeno, "0", "操作失败");
//			DBUtil.insertPayInfo(db, "defaultpayinfo", outtradeno, "0", "操作失败");
			WXPayUtil wxpay = new WXPayUtil(ParkingApp.mContext);
			wxpay.doWxPay("浪花停车充值", totalfee, outtradeno);
			while(ParkingApp.isPay) {
				
			}
			result = wait.getPayResult();
		}else {
			result = new Util().formatPayResult(false, "操作失败", false);
		}
		
		return result;
	}
	
	public String waitForAliPayResult(String totalfee, String outtradeno) {
//		PayInfoDBHelper dbHelper = new PayInfoDBHelper(ParkingApp.mContext);
		WaitHelper wait = WaitHelper.getInstance();
		ParkingApp.setIsPay(true);
		AliPayUtil alipay = new AliPayUtil();
//		SQLiteDatabase db = dbHelper.getWritableDatabase();
//		DBUtil.createTable(db, ParkingPrefs.getStrValue(ParkingPrefs.PREF_LANGHUA_UID));
//		DBUtil.createTable(db, "defaultpayinfo");
//		DBUtil.insertPayInfo(db, ParkingPrefs.getStrValue(ParkingPrefs.PREF_LANGHUA_UID), outtradeno, "0", "操作失败");
		alipay.doAliPay("浪花停车充值", totalfee, outtradeno);
		
		while(ParkingApp.isPay) {

		}
		String result = wait.getPayResult();
		Log.i("pullxml", result);
		return result;
	}
	
	@JavascriptInterface
	public String waitForPayResult(String totalfee, final String outtradeno, boolean lock, String type) {
		String result = "";
		int paytype = Integer.parseInt(type);
		switch(paytype) { 
		case 1:
			result = waitForAliPayResult(totalfee, outtradeno);
			break;
		case 3:
			Log.i("pullxml", "3 dowxpay");
			result = waitForWXPayResult(totalfee, outtradeno, true);
			break;
		default:
			result = new Util().formatPayResult(false, "操作失败", false);
		}
		Log.i("pullxml", result);
		return result;
	}
	
	@JavascriptInterface
	public String waitForAliPayResult(String fee, final String outtradeno, boolean lock) {
		PayInfoDBHelper dbHelper = new PayInfoDBHelper(ParkingApp.mContext);
		WaitHelper wait = WaitHelper.getInstance();
		String result = new Util().formatPayResult(false, "操作失败", false);;
		if(lock) {
			ParkingApp.setIsPay(true);
			AliPayUtil alipay = new AliPayUtil();
			SQLiteDatabase db = dbHelper.getWritableDatabase();
//			DBUtil.createTable(db, ParkingPrefs.getStrValue(ParkingPrefs.PREF_LANGHUA_UID));
			DBUtil.createTable(db, "defaultpayinfo");
//			DBUtil.insertPayInfo(db, ParkingPrefs.getStrValue(ParkingPrefs.PREF_LANGHUA_UID), outtradeno, "0", "操作失败");
			DBUtil.insertPayInfo(db, "dafultpayinfo", outtradeno, "0", "操作失败");
			alipay.doAliPay("浪花停车充值", fee, outtradeno);
			
			while(ParkingApp.isPay) {
				Log.i("pullxml", "ispay");
			}
			result = wait.getPayResult();
		}else {
			result = new Util().formatPayResult(false, "操作失败", false);
		}
		
		Log.i("pullxml", result);
		return result;
	}
	
	/**
	 * 退出登录
	 * @return
	 */
	@JavascriptInterface
	public int loginOut(){
		return ParkingPrefs.loginOut() ? 1 : 0;
	}
}
