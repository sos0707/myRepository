package org.sendi.parking.ui.base;

import org.sendi.parking.global.ParkingApp;

import android.app.Activity;
import android.os.Bundle;

/**
 * 基本的 activity
 * @author Administrator
 *
 */
public class LHBaseActivity extends Activity{
	
	protected ParkingApp mApp;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		mApp = ParkingApp.mApp;
		mApp.registerActivity(this);
	}
	
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		mApp.onResume();
//		if(ParkingPrefs.getBoolValue(ParkingPrefs.PREF_LANGHUA_GESTURE_GUARD_ONOFF, false)){
//			startActivity(new Intent(this, LHLockActivity.class));
//			return;
//		}
	}
	
	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		mApp.onStop();
	}
	
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		mApp.unregisterActivity(this);
	}

}
