package org.sendi.parking.model;

/**
 * 服务端操作 的状态
 * 
 * @author Administrator
 * 
 */
public class OpInfo {

	private boolean success;//操作是否成功
	private String msg;//相关信息

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	@Override
	public String toString() {
		return "BeforeExecInfo [success=" + success + ", msg=" + msg + "]";
	}

	
}
