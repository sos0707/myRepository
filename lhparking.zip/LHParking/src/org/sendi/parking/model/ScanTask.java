package org.sendi.parking.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * 代表扫描任务
 * 
 * @author Administrator
 * 
 */
public class ScanTask implements Parcelable {

	private String task_id;
	private String numOfScan;
	private String nid;/* 小区id 由二维码扫描结果获得 */

	public String getTask_id() {
		return task_id;
	}

	public void setTask_id(String task_id) {
		this.task_id = task_id;
	}

	public String getNumOfScan() {
		return numOfScan;
	}

	public void setNumOfScan(String numOfScan) {
		this.numOfScan = numOfScan;
	}

	public String getNid() {
		return nid;
	}

	public void setNid(String nid) {
		this.nid = nid;
	}
	
	public ScanTask(){
		
	}

	private ScanTask(Parcel in) {
		task_id = in.readString();
		numOfScan = in.readString();
		nid = in.readString();
	}

	@Override
	public int describeContents() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		// TODO Auto-generated method stub
		dest.writeString(task_id);
		dest.writeString(numOfScan);
		dest.writeString(nid);
	}

	public static final Parcelable.Creator<ScanTask> CREATOR = new Parcelable.Creator<ScanTask>() {

		@Override
		public ScanTask createFromParcel(Parcel source) {
			// TODO Auto-generated method stub
			return new ScanTask(source);
		}

		@Override
		public ScanTask[] newArray(int size) {
			// TODO Auto-generated method stub
			return new ScanTask[size];
		}
	};
}
