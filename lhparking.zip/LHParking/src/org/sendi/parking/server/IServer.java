package org.sendi.parking.server;

import org.sendi.parking.model.ScanTask;

public interface IServer {

	/**
	 * 设置服务地址
	 */
	public void setServerAddress(String address);
	
	/**
	 * 主页
	 * @return
	 */
	public String getDoorURL();
	
	/**
	 * 扫描
	 * @return
	 */
	public String getScanExecResultURL(ScanTask result);
	
	public String getCheckVersionURL();
	
	public String getDownNewApkURL();

}
