package org.sendi.parking.server;

import org.sendi.parking.global.ParkingApp;
import org.sendi.parking.model.ScanTask;
import org.sendi.parking.utils.LogX;

import android.util.SparseArray;

/**
 * 服务器的相关配置
 * 
 * @author Administrator
 * 
 */
public class ServerConfig implements IServer {

	private static final int URL_DOOR = 101;
	private static final int URL_SCAN_EXEC_RESULT = 102;
	private static final int URL_CHECK_VERSION = 103;
	private static final int URL_DOWN_APK = 104;
	
	private static final String IP_REG = "([1-9]|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])(\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])){3}";
	private static final String URL_REG = "[a-zA-Z0-9][-a-zA-Z0-9]{0,62}(\\.[a-zA-Z0-9][-a-zA-Z0-9]{0,62})+\\.?";
	
	private String wapperURLWithUID(String url) {
		if (url.contains("?")) {
			url = url + "&uid=" + ParkingApp.mApp.getUID();
		} else {
			url = url + "?uid=" + ParkingApp.mApp.getUID();
		}
		LogX.i("#### LANGHUA URL : " + url);
		return url;
	}

	private String wapperAddress(String address) {
		if(address.matches(IP_REG)
				||address.matches(IP_REG + "?(:\\d{1,5})")
				||address.matches(URL_REG)){
			return "http://" + address + "/lhparking";
		}
		if(address.contains("http")){
			return address;
		}
		return "http://"+address;
	}

	private SparseArray<String> mURLs = new SparseArray<String>(5);

	private String serverAddress;// ip or lh.cc

	@Override
	public String getDoorURL() {
		// TODO Auto-generated method stub
		String url = mURLs.get(URL_DOOR);
		if (url == null) {
			url = wapperAddress(serverAddress) + "/index.html";
			mURLs.put(URL_DOOR, url);
		}
		return wapperURLWithUID(url);
	}

	@Override
	public String getScanExecResultURL(ScanTask result) {
		// TODO Auto-generated method stub
		StringBuilder sb = new StringBuilder();
		sb.append(getScanExecResultURLPart()).append("task_id=")
				.append(result.getTask_id()).append("&").append("numOfScan=")
				.append(result.getNumOfScan()).append("&").append("nid=")
				.append(result.getNid());
		return wapperURLWithUID(sb.toString());
	}

	private String getScanExecResultURLPart() {
		String url = mURLs.get(URL_SCAN_EXEC_RESULT);
		if (url == null) {
			url = wapperAddress(serverAddress)
					+ "/servlet/SysInterface?method=2020&";
			mURLs.put(URL_SCAN_EXEC_RESULT, url);
		}
		return url;
	}

	@Override
	public void setServerAddress(String address) {
		// TODO Auto-generated method stub
		this.serverAddress = address;
		this.mURLs.clear();
	}

	@Override
	public String getCheckVersionURL() {
		// TODO Auto-generated method stub
		// LANGHUA_HOST + "/v";
		String url = mURLs.get(URL_CHECK_VERSION);
		if (url == null) {
			url = wapperAddress(serverAddress) + "/v";
			mURLs.put(URL_CHECK_VERSION, url);
		}
		return url;
	}

	@Override
	public String getDownNewApkURL() {
		// TODO Auto-generated method stub
		String url = mURLs.get(URL_DOWN_APK);
		if (url == null) {
			url = wapperAddress(serverAddress) + "/lhparking.apk";
			mURLs.put(URL_DOWN_APK, url);
		}
		return url;
	}

}
