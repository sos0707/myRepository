package org.sendi.parking.global;

public class ParkingIntentDefiner {
	
	public static final String EXTRA_SCAN_TASK = "extra_scan_task";
	
	public static final String EXTRA_DOWN_SERVICE_URL = "extra_down_url";
	//是否是点击了  系统消息的通知
	public static final String EXTRA_INTENT_CLICK_SYSMSG = "extra_is_click_sysmsg_notify";
	

}
