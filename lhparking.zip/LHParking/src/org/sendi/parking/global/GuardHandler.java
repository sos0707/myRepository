package org.sendi.parking.global;

import org.sendi.parking.utils.LogX;

import android.os.Handler;
import android.os.Handler.Callback;
import android.os.HandlerThread;
import android.os.Message;

/**
 * 用于记录时间
 * @author Administrator
 *
 */
public class GuardHandler extends HandlerThread implements Callback{
	
	private static final int MSG_CHANGE_GUARD_TIME = 1;
	private static final int DEFAULT_DELAY = 60000;/*one mincute*/
	
	private Handler mHandler;

	public GuardHandler(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean handleMessage(Message msg) {
		// TODO Auto-generated method stub
		LogX.i("超过1分钟了 开启锁屏");
		ParkingPrefs.setBoolValue(ParkingPrefs.PREF_LANGHUA_GESTURE_GUARD_ONOFF, true);
		return false;
	}
	
	public void startGuard(){
		start();
		mHandler = new Handler(getLooper(), this);
		setGuard(0);//说明应用已经被结束了 不管怎样都应该显示 解锁界面
	}
	
	public void resetGuard(){
		if(mHandler != null){
			mHandler.removeMessages(MSG_CHANGE_GUARD_TIME);
			LogX.i("关闭一分钟");
		}
	}
	
	public void setGuard(){
		setGuard(DEFAULT_DELAY);
	}
	
	private void setGuard(long time){
		if(mHandler != null){
			mHandler.sendEmptyMessageDelayed(MSG_CHANGE_GUARD_TIME, time);
			LogX.i("1分钟倒计时");
		}
	}

}
