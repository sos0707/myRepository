package org.sendi.parking.global;

import org.sendi.parking.utils.LogX;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

/**
 * APP 的prefs 数据
 * @author Administrator
 *
 */
public class ParkingPrefs {
	
	private static final String PREF_FILE_DEFAULT = "langhua";
	public static final String PREF_LANGHUA_UID = "langhua_uid";/*string*/
	public static final String PREF_LANGHUA_UTYPE = "langhua_utype";/*string*/
	public static final String PREF_LANGHUA_GESTURE_GUARD_PWD = "langhua_gesture_guard_pwd";/*string*/
	public static final String PREF_LANGHUA_GESTURE_GUARD_ONOFF = "langhua_gesture_guard_onoff";/*bool  是否开启*/
	
	public static final String PREF_LANGHUA_NOTIFY_ENABLE = "langhua_notify_enable";
	public static final String PREF_LANGHUA_NOTIFY_SOUND_ENABLE = "langhua_notify_sound_enable";
	public static final String PREF_LANGHUA_NOTIFY_VIBRA_ENABLE = "langhua_notify_vibra_enable";
	
	public static final String PREF_LANGHUA_UPDATE_LASTTIME = "langhua_update_lasttime";/* long msec*/
	
	private static SharedPreferences getDefaultPreferences(){
		return ParkingApp.mApp.getSharedPreferences(PREF_FILE_DEFAULT, Context.MODE_PRIVATE);
	}
	
	/**
	 * string value
	 * @param key
	 * @return
	 */
	public static String getStrValue(String key){
		return getDefaultPreferences().getString(key, null);
	}

	/**
	 * set value
	 */
	public static void setStrValue(String key, String value){
		SharedPreferences prefs = getDefaultPreferences();
		Editor edit = prefs.edit();
		edit.putString(key, value);
		boolean success = edit.commit();
		LogX.i("设置 key : "+key+"; value : "+value+" 成功?"+success);
	}
	
	/**
	 * 
	 * @param key
	 * @return
	 */
	public static boolean getBoolValue(String key, boolean defvalue){
		return getDefaultPreferences().getBoolean(key, defvalue);
	}
	
	public static void setBoolValue(String key, boolean value){
		SharedPreferences prefs = getDefaultPreferences();
		Editor edit = prefs.edit();
		edit.putBoolean(key, value);
		boolean success = edit.commit();
		LogX.i("设置 key : "+key+"; value : "+value+" 成功?"+success);
	}
	
	public static long getLongValue(String key, long defvalue){
		return getDefaultPreferences().getLong(key, defvalue);
	}
	
	public static void setLongValue(String key, long value){
		SharedPreferences prefs = getDefaultPreferences();
		Editor edit = prefs.edit();
		edit.putLong(key, value);
		boolean success = edit.commit();
		LogX.i("设置 key : "+key+"; value : "+value+" 成功?"+success);
	}
	
	/**
	 * 退出登录
	 */
	public static boolean loginOut(){
		SharedPreferences prefs = getDefaultPreferences();
		Editor edit = prefs.edit();
		edit.remove(PREF_LANGHUA_UID);
		edit.remove(PREF_LANGHUA_UTYPE);
		return edit.commit();
	}
}
