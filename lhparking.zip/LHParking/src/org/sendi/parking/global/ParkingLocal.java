package org.sendi.parking.global;

import java.io.File;

import org.sendi.parking.utils.LogX;

import com.ab.util.AbFileUtil;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Environment;

/**
 * 本地存储
 * 
 * @author Administrator
 * 
 */
public class ParkingLocal {

	private static final String APP_DIR = "parking";
	private static final String APP_CACHE_SD_DIR = "cache";
	private static final String APP_GEO_SD_DIR = "geo";

	public static void init() {
		File cache = getCacheDir();
		if (cache != null)
			AbFileUtil.setDownPathFileDir(cache.getAbsolutePath() + File.separator);
	}

	public static boolean hasSDCard() {
		return Environment.getExternalStorageState().equals(
				Environment.MEDIA_MOUNTED);
	}

	public static File getCacheDir() {
		File cache = null;
		if ((cache = getAppCacheDirOnSD()) != null) {
			return cache;
		}
		if ((cache = Environment.getDownloadCacheDirectory()) != null) {
			return cache;
		}
		LogX.i("no cache download");
		return null;
	}

	public static File getAppDirOnSD() {
		if (hasSDCard()) {
			File sdcard = Environment.getExternalStorageDirectory();
			File app = new File(sdcard, APP_DIR);
			if (!app.exists()) {
				app.mkdir();
			}
			return app;
		}
		return null;
	}

	public static File getAppCacheDirOnSD() {
		if (hasSDCard()) {
			File cache = new File(getAppDirOnSD(), APP_CACHE_SD_DIR);
			if (!cache.exists()) {
				cache.mkdir();
			}
			return cache;
		}
		return null;
	}
	
	public static File getGeoSavedPath(){
		if (hasSDCard()) {
			File cache = new File(getAppDirOnSD(), APP_GEO_SD_DIR);
			if (!cache.exists()) {
				cache.mkdir();
			}
			return cache;
		}
		return null;
	}

	/**
	 * 获取版本号
	 * 
	 * @return 当前应用的版本号
	 */
	public static int getVersionCode(Context context) {
		try {
			PackageManager manager = context.getPackageManager();
			PackageInfo info = manager.getPackageInfo(context.getPackageName(),
					0);
			int version = info.versionCode;
			return version;
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}
	}

}
