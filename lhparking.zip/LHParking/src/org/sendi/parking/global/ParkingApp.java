package org.sendi.parking.global;

import java.util.ArrayList;

import org.sendi.parking.im.conn.XmppManager;
import org.sendi.parking.server.ServerConfig;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Handler;

/**
 * 停车app
 * 
 * @author Administrator
 * 
 */
public class ParkingApp extends Application {

	public static ParkingApp mApp;
	
	public static Activity mContext;
	public static Handler pHandler;
	
	private String mUID;

	private ServerConfig mServerConfig;
	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		mApp = this;
		XmppManager.getXmpp().initXmppConn();
		ParkingLocal.init();
		mServerConfig = new ServerConfig();
		mServerConfig.setServerAddress("lhhl.cc");
//		mGuard = new GuardHandler("guarder");
//		mGuard.startGuard();
	}

	/*
	 * >>>>>>>>>>> setter getter
	 * @return
	 */
	public String getUID() {
		if(mUID == null){
			mUID = ParkingPrefs.getStrValue(ParkingPrefs.PREF_LANGHUA_UID);
		}
		return mUID;
	}
	
	public ServerConfig getServerConfig() {
		return mServerConfig;
	}

	/*
	 * >>>>>>>>>>>>> run on ui
	 */
	private Handler mHandler = new Handler();

	public void runOnUIThread(Runnable r) {
		runOnUIThread(r, 0);
	}

	public void runOnUIThread(Runnable r, long delay) {
		mHandler.postDelayed(r, delay);
	}

	/*
	 * >>>>>>>>>>>>> manager activities
	 */
	private ArrayList<Activity> mActivities = new ArrayList<Activity>();/* 记录所有开启的activity */
//	private GuardHandler mGuard;

	public void registerActivity(Activity activity) {
		if (!mActivities.contains(activity)) {
			mActivities.add(activity);
		}
	}

	public void unregisterActivity(Activity activity) {
		if (mActivities.contains(activity)) {
			mActivities.remove(activity);
		}
	}

	public void existAll() {
		for (Activity activity : mActivities) {
			activity.finish();
		}
		mActivities.clear();
	}

	public void onResume() {
//		mGuard.resetGuard();
	}

	public void onStop() {
//		mGuard.setGuard();
	}
	
	public void setContext(Activity context, Handler handler) {
		this.mContext = context;
		this.pHandler = handler;
	}
	
	public static boolean isPay = false;
	
	public static void setIsPay(boolean pay) {
		isPay = pay;
	}
	
}
