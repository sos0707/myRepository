/** Automatically generated file. DO NOT MODIFY */
package cn.gzsendi.lhparking;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}