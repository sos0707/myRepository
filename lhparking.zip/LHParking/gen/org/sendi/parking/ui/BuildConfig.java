/** Automatically generated file. DO NOT MODIFY */
package org.sendi.parking.ui;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}