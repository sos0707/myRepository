package org.sendi.parking.ui.wxapi;


import org.sendi.parking.ui.R;

import com.sendi.lhparking.ctx.ParkingApp;
import com.tencent.mm.sdk.constants.ConstantsAPI;
import com.tencent.mm.sdk.modelbase.BaseReq;
import com.tencent.mm.sdk.modelbase.BaseResp;
import com.tencent.mm.sdk.openapi.IWXAPI;
import com.tencent.mm.sdk.openapi.IWXAPIEventHandler;
import com.tencent.mm.sdk.openapi.WXAPIFactory;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Message;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

/**
 *  注意: 要接收微信支付的返回结果，该类名必须为WXPayEntryActivity，并且要在 xxx.xxx...wxapi 包中, 配置 android:exported="true"
 *  实现了IWXAPIEventHandler接口，实现onResp函数用于接收支付返回结果。
 *  注意由客户端返回的支付结果不能作为最终支付的可信结果，应以服务器端的支付结果通知为准。
 * @author 4321
 *
 */
public class WXPayEntryActivity extends Activity implements IWXAPIEventHandler{
	private IWXAPI api;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.pay_result);
    	api = WXAPIFactory.createWXAPI(this, Constants.APP_ID);
        api.handleIntent(getIntent(), this);

	}
	
	@Override
	protected void onNewIntent(Intent intent) {
		// TODO Auto-generated method stub
		super.onNewIntent(intent);
		setIntent(intent);
		api.handleIntent(intent, this);
	}

	@Override
	public void onReq(BaseReq arg0) {
		// TODO Auto-generated method stub
		
	}

	/**
	 * ERR_AUTH_DENIED	-4   认证被否决 ; 
	 * ERR_COMM	        -1   一般错误 ;
	 * ERR_OK	         0   正确返回 ;
	 * ERR_SENT_FAILED	-3   发送失败 ;
	 * ERR_UNSUPPORT	-5   不支持错误 ;
	 * ERR_USER_CANCEL	-2   用户取消 。
	 */
	@Override
	public void onResp(BaseResp resp) {
		// TODO Auto-generated method stub
		Log.i("TEST", "onResp");
		Message msg = new Message();
		msg.what = 2;
		if (resp.getType() == ConstantsAPI.COMMAND_PAY_BY_WX) {
			if(String.valueOf(resp.errCode).equals("0")) {
				msg.obj = resp.errCode;
				ParkingApp.payHandler.sendMessage(msg);
//				showTipsDialog("支付成功", this);
			}else {
				msg.obj = resp.errCode;
				ParkingApp.payHandler.sendMessage(msg);
//				showTipsDialog("支付失败", this);
			}
			WXPayEntryActivity.this.finish();
		}
	}
	
	private void showTipsDialog(String msg, Context context){  
        AlertDialog dialog;  
        AlertDialog.Builder builder = new AlertDialog.Builder(context);  
        builder.setTitle("消息").setIcon(android.R.drawable.stat_notify_error);  
        builder.setMessage(msg);  
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener(){  
            @Override 
            public void onClick(DialogInterface dialog, int which) {  
                // TODO Auto-generated method stub  
                WXPayEntryActivity.this.finish();
            }                     
        });  
        dialog = builder.create();  
        dialog.show();  
    }  
}
