package org.sendi.parking.ui.wxapi;

public class Constants {
	/** APP_ID 替换为应用从官方网站申请到的合法appId */
    public static final String APP_ID = "wxb55cabb89e432852";
    /** APP_ID wxd930ea5d5a258f4f 对应的密钥 */
	public static final String APP_SECRET = "5f44e405c69b3439755852171ee25eb8";
	/** 商家向财付通申请的商家id */
    public static final String PARTNER_ID = "1219612701";
    /**
     * 微信开放平台和商户约定的支付密钥
     * 
     * 注意：不能hardcode在客户端，建议genSign这个过程由服务器端完成
     */
	public static final String APP_KEY = "Ry9CBaYgZBu8WdQkKdZzqPOj4nM1hdvqQB6ZYoFdborcvD1qwFLsAbhnnAPpLVnHWbvBKcMUTHoCYSy2vsIDhz54QXFtNM8fu0UukcmJCXyIheDPlg7PdrwwMKFIFQdo"; // wxd930ea5d5a258f4f 对应的支付密钥
	/**
	 * 微信公众平台商户模块和商户约定的密钥
	 * 
	 * 注意：不能hardcode在客户端，建议genPackage这个过程由服务器端完成
	 */
	public static final String PARTNER_KEY = "ba36e4c162eaa4391bca8ee928825ca1";
    
    public static class ShowMsgActivity {
		public static final String STitle = "showmsg_title";
		public static final String SMessage = "showmsg_message";
		public static final String BAThumbData = "showmsg_thumb_data";
	}
}
