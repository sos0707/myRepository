package com.ab.view.myview;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.ScaleGestureDetector.OnScaleGestureListener;
import android.widget.LinearLayout;

/**
 * 
 * @author Administrator
 *
 */
public class ScaleLayout extends LinearLayout implements OnScaleGestureListener{
	
	private ScaleGestureDetector mScale;
	
	private OnScaleGestureListener mClientListener;
	
	public ScaleLayout(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
		mScale = new ScaleGestureDetector(getContext(), this);
	}

	public ScaleLayout(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		mScale = new ScaleGestureDetector(getContext(), this);
	}
	
	public void setClientListener(OnScaleGestureListener mClientListener) {
		this.mClientListener = mClientListener;
	}
	
	@Override
	public boolean onInterceptTouchEvent(MotionEvent ev) {
		// TODO Auto-generated method stub
		if(ifTwoPointMayBeScale(ev)){
			return true;
		}
		return super.onInterceptTouchEvent(ev);
	}
	
	private boolean ifTwoPointMayBeScale(MotionEvent ev){
		if(ev.getPointerCount() >= 2){
			return true;
		}
		return false;
	}
	
	@Override
	public boolean onTouchEvent(MotionEvent event) {
		// TODO Auto-generated method stub
		return mScale.onTouchEvent(event);
	}
	
	@Override
	public boolean onScale(ScaleGestureDetector detector) {
		// TODO Auto-generated method stub
		if(mClientListener != null){
			return mClientListener.onScale(detector);
		}
		return false;
	}

	@Override
	public boolean onScaleBegin(ScaleGestureDetector detector) {
		// TODO Auto-generated method stub
		if(mClientListener != null){
			return mClientListener.onScaleBegin(detector);
		}
		return false;
	}

	@Override
	public void onScaleEnd(ScaleGestureDetector detector) {
		// TODO Auto-generated method stub
		if(mClientListener != null){
			mClientListener.onScaleEnd(detector);
		}
	}

}
