package com.ab.view.myview;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.TextView;

/**
 * 秒表view
 * @author Administrator
 *
 */
public class StopWatchView extends TextView{

	public StopWatchView(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
	}

	//
	protected void getInitData(){
		
	}
}
