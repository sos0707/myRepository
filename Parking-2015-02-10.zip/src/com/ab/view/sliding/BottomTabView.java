/*
 * Copyright (C) 2015 www.amsoft.cn
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.ab.view.sliding;

/*
 * Copyright (C) 2015 www.amsoft.cn
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


import java.util.ArrayList;
import java.util.List;

import org.sendi.parking.ui.R;

import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.util.SysUtils;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.GestureDetector;
import android.view.GestureDetector.OnGestureListener;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

// TODO: Auto-generated Javadoc
/**
 * 使用  select状态， 效果 提供 selector 的  图片 和 颜色
 */
public class BottomTabView extends LinearLayout{
	
	/** The context. */
	private Context mContext;
	//三个列表 要 一一对应
	private List<TextView> mItemViews = null;
	/**tab的文字*/
	private List<String> mItemTexts = null;
	
	/**tab的图标*/
	private List<Drawable> mItemIcons = null;
	
	/**当前选中编号*/
	private int mSelectedTabIndex = 0;
	
	/**tab的文字大小*/
	private int tabTextSize = 16;
	/**text color*/
	private ColorStateList mTextColor;
	
	private int mTextViewPadding = SysUtils.dip2px(ParkingApp.mAppCtx, 5);
	
	private OnSelectListener mClient;
	
	private boolean mHasIcon;
	
	
	public interface OnSelectListener{
		public void onSelected(int index);
	}
	
	private View.OnClickListener mTabClickListener = new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			Integer index = (Integer) v.getTag();
			setCurIndex(index);
		}
	};
	
	
	public BottomTabView(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		init();
	}
	
	private void init(){
		mContext = getContext();
		mItemViews = new ArrayList<TextView>();
		mItemTexts = new ArrayList<String>();
		mItemIcons = new ArrayList<Drawable>();
		mTextColor = getResources().getColorStateList(R.color.door_tab_tv_textcolor_selector);
	}
	
	public void setTabTextColor(int colorid){
		ColorStateList colors = getResources().getColorStateList(colorid);
		if(colors == null){
			throw new IllegalArgumentException("新建color文件夹，color/color_selector，创建类似drawable "
					+ "selector的颜色选择器，这个就是colorstatelist");
		}
		mTextColor = colors;
	}
	
	public void setTabItems(List<String> texts, List<Drawable> icons){
		if(texts == null){
			return;
		}
		if(icons == null || icons.size() != texts.size()){
			mHasIcon = false;
		}else{
			mHasIcon = true;
		}
		mItemTexts.clear();
		mItemIcons.clear();
		mItemTexts.addAll(texts);
		if(mHasIcon){
			mItemIcons.addAll(icons);
		}
	}
	
	public void setTabSelectIndex(int index){
		mSelectedTabIndex = index;
	}
	
	public void setTabListener(OnSelectListener listener){
		this.mClient = listener;
	}
	
	public void manualSelectTab(int index){
		if(index < 0 || index >= mItemTexts.size()){
			return;
		}
		if(index == mSelectedTabIndex){
			return;
		}
		TextView tv = mItemViews.get(mSelectedTabIndex);
		tv.setSelected(false);
		tv = mItemViews.get(index);
		tv.setSelected(true);
		mSelectedTabIndex = index;
	}
	
	public void notifyItemsChanged(){
		removeAllViews();
		mItemViews.clear();
		int size = mItemTexts.size();
		if(size == 0){
			return;
		}
		for(int i=0; i<size; i++){
			addTab(i);
		}
	}
	
	private void addTab(int index){
		TextView tv = new TextView(mContext);
		tv.setText(mItemTexts.get(index));
		tv.setTextColor(mTextColor);
		tv.setBackgroundResource(R.drawable.door_tab_tv_bg_selector);
		tv.setGravity(Gravity.CENTER);
		tv.setTextSize(tabTextSize);
		tv.setTag(Integer.valueOf(index));
		tv.setOnClickListener(mTabClickListener);
		tv.setPadding(mTextViewPadding, mTextViewPadding, mTextViewPadding, mTextViewPadding);
		if(mHasIcon){
			tv.setCompoundDrawables(null, mItemIcons.get(index), null, null);
		}
		if(index == mSelectedTabIndex){
			tv.setSelected(true);
		}
		mItemViews.add(tv);
		addView(tv, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, 1F));
	}
	
	private void setCurIndex(int index){
		if(index < 0 || index >= mItemTexts.size()){
			return;
		}
		if(index == mSelectedTabIndex){
			return;
		}
		TextView tv = mItemViews.get(mSelectedTabIndex);
		tv.setSelected(false);
		tv = mItemViews.get(index);
		tv.setSelected(true);
		mSelectedTabIndex = index;
		
		if(mClient != null){
			mClient.onSelected(index);
		}
		for(int i=0; i<mItemViews.size(); i++){
			tv = mItemViews.get(i);
		}
	}
	
}
