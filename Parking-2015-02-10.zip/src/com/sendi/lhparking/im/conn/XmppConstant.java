package com.sendi.lhparking.im.conn;

/**
 * 
 * @author Administrator
 *
 */
public class XmppConstant {
	
	public static final String XMPP_HOST = "lhhl.cc";
	public static final int XMPP_PORT = 5222;
	
//	//dummy
//	public static final String XMPP_HOST = "192.168.30.119";
//	public static final int XMPP_PORT = 5222;
	//login
	public static final int LOGIN_SUCCESS = 1;
	public static final int LOGIN_FAIL = 2;
	public static final int LOGIN_TIMEOUT = 3;

}
