package com.sendi.lhparking.im.service;

import java.util.Date;


import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.im.conn.XmppLoginTask;

import android.app.AlarmManager;
import android.app.IntentService;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

/**
 * 
 * @author Administrator
 *
 */
public class ConnService extends IntentService{
	
	public ConnService() {
		super("xmpp service");
		// TODO Auto-generated constructor stub
	}

	private static final int HEART_TIME = 1000 * 60 * 2;   //  xmpp 心跳间隔
	
	private XmppLoginTask mConnTask = new XmppLoginTask();
	
	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		makeAlarm();
	}
	
	@Override
	protected void onHandleIntent(Intent intent) {
		// TODO Auto-generated method stub
		Log.i("lh", "检测 xmpp service conn");
		String uid = ParkingApp.mAppCtx.getUID();
		mConnTask.setName(uid);
		mConnTask.setPwd(uid);
		mConnTask.run();
	}
	
	private void makeAlarm() {
		// TODO Auto-generated method stub
		Log.i("qh", "注册alarm to wakeup coreservice : "+(new Date(System.currentTimeMillis())));
		AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
		PendingIntent pi = getKeepAlivePendIntent();
		// 两分钟后再次唤醒ConnService检查xmpp连接
		am.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + getIntervalTime(), pi);
	}

	public PendingIntent getKeepAlivePendIntent() {
		Intent i = new Intent(this, ConnService.class);
		PendingIntent pi = PendingIntent.getService(this, 10086, i,
				PendingIntent.FLAG_UPDATE_CURRENT);
		return pi;
	}

	private long getIntervalTime() {
		return HEART_TIME;//
	}
	
}
