package com.sendi.lhparking.im.service;

import java.util.Random;

import org.jivesoftware.smack.Connection;
import org.jivesoftware.smack.PacketListener;
import org.jivesoftware.smack.filter.MessageTypeFilter;
import org.jivesoftware.smack.filter.PacketFilter;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.Packet;
import org.jivesoftware.smack.packet.Message.Type;
import org.sendi.parking.ui.R;

import com.google.gson.Gson;
import com.lidroid.xutils.DbUtils;
import com.lidroid.xutils.exception.DbException;
import com.sendi.lhparking.ctx.ParkingConstant;
import com.sendi.lhparking.im.conn.XmppManager;
import com.sendi.lhparking.model.SystemMsgModel;
import com.sendi.lhparking.ui.common.SystemMsgListActivity;
import com.sendi.lhparking.util.LogX;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.Log;

/**
 * 
 * @author Administrator
 * 
 * 1.来了系统消息，存入数据库
 * 2，
 * 
 */
public class PacketService extends Service implements PacketListener {
	
	public static final int MSG_CHAT = 1;
	public static final int MSG_NORMAL = 2;//浏览器发送的
	
	private HandlerThread mWorkThread;
	private Handler mWorkHandler;

	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		mNotifyService = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
		mDB = DbUtils.create(this);
		Connection conn = XmppManager.getXmpp().getXmppConn();
		conn.addPacketListener(this, getPacketFilter());
		conn.addPacketListener(new PacketListener() {
			
			@Override
			public void processPacket(Packet packet) {
				// TODO Auto-generated method stub
				Message msg = (Message) packet;
				String body = msg.getBody();
				if (body != null) {
					android.os.Message message = mWorkHandler.obtainMessage();
					message.what = MSG_NORMAL;
					message.obj = body;
					mWorkHandler.sendMessage(message);
				}
			}
		}, new MessageTypeFilter(Type.normal));
		
		mWorkThread = new HandlerThread("listen msg");
		mWorkThread.start();
		mWorkHandler = new Handler(mWorkThread.getLooper(), new Handler.Callback() {
			
			@Override
			public boolean handleMessage(android.os.Message msg) {
				// TODO Auto-generated method stub
				switch (msg.what) {
				case MSG_CHAT:
					parseSystemMsgModel((String)msg.obj);
					break;
				case MSG_NORMAL:
					Log.i("qh", "we have a brower send msg : "+(msg.obj));
					parseSystemMsgModel((String)msg.obj);
					break;
				default:
					break;
				}
				return false;
			}
		});
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		// TODO Auto-generated method stub
		if(intent != null){
			boolean notify = intent.getBooleanExtra(ParkingConstant.INTENT_EXTRA_BOOL_FROM_NOTIFY, false);
			if(notify){
				int type = intent.getIntExtra(ParkingConstant.INTENT_EXTRA_INT_NOTIFY_TYPE, 0);
				handleClick(type, intent);
			}
		}
		return START_STICKY;
	}

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		XmppManager.getXmpp().getXmppConn().removePacketListener(this);
	}

	private PacketFilter getPacketFilter() {
		// TODO Auto-generated method stub
		return new MessageTypeFilter(Type.chat);
	}

	@Override
	public void processPacket(Packet packet) {
		// TODO Auto-generated method stub
		Message msg = (Message) packet;
		String body = msg.getBody();
		if (body != null) {
			android.os.Message message = mWorkHandler.obtainMessage();
			message.what = MSG_CHAT;
			message.obj = body;
			Log.i("lh", "PacketService processPacket body : " + body);
			mWorkHandler.sendMessage(message);
		}
	}
	
	//notify
	private static final int NOTIFY_TYPE_SIMPLE = 1011;
	private static final int NOTIFY_TYPE_MULTI = 2022;
	
	private SystemMsgModel mLastModel;
	private int mLastClickMsgCount;
	private int mNotifyId = new Random().nextInt(1000);
	
	private NotificationManager mNotifyService;
	private Notification notification;
	private DbUtils mDB;
	
	private void handleClick(int type, Intent data){
		if(type <= 0){
			return;
		}
		Log.i("qh", "click notify : "+type);
		if(type == NOTIFY_TYPE_MULTI){
			Intent intent = new Intent(this, SystemMsgListActivity.class);
			intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			startActivity(intent);
		}else if(type == NOTIFY_TYPE_SIMPLE){
			String uuid = data.getStringExtra(ParkingConstant.INTENT_EXTRA_SYSMSG_UUID);
			if(uuid == null){
				return;
			}
			try {
				SystemMsgModel model = mDB.findById(SystemMsgModel.class, uuid);
				Intent intent = ParkingConstant.getIntentBySysMsg(model);
				if(intent == null){
					return;
				}
				intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				startActivity(intent);
				mDB.delete(model);
			} catch (DbException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		notification = null;
		mLastClickMsgCount = 0;
	}
	
	private void parseSystemMsgModel(String json){
		Gson gson = new Gson();
		Log.i("lh", "PacketService parseSystemMsgModel json : "+ json);
		try {
			mLastModel = gson.fromJson(json, SystemMsgModel.class);
		} catch (Exception e) {
			// TODO: handle exception
			Log.i("lh", "im.ParketService parseSystemMsgModel : get mLastModel(SystemMsgModel) json error");
		}
		
		Log.i("lh", "im.ParketService parseSystemMsgModel json : "+ json);
		if(mLastModel == null){
			LogX.i("null system msg ... : "+json);
			return;
		}
		try {
			mDB.save(mLastModel);
		} catch (DbException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		showNotification();
	}
	
	@SuppressWarnings("deprecation")
	private void showNotification() {
		if (notification == null) {//simple
			notification = buildOld();
			mNotifyService.notify(mNotifyId, notification);
			mLastClickMsgCount = 1;
		} else {//
			mLastClickMsgCount++;
			notification.setLatestEventInfo(this, "浪花停车", "您有"+mLastClickMsgCount+"条新消息", null);
			notification.contentIntent = getMultiMsgIntent();
			mNotifyService.notify(mNotifyId, notification);
		}
	}
	
	private PendingIntent getSimpleMsgIntent(){
		Intent intent = new Intent(this, PacketService.class);
		intent.putExtra(ParkingConstant.INTENT_EXTRA_SYSMSG_UUID, mLastModel.getUuid());
		intent.putExtra(ParkingConstant.INTENT_EXTRA_BOOL_FROM_NOTIFY, true);
		intent.putExtra(ParkingConstant.INTENT_EXTRA_INT_NOTIFY_TYPE, NOTIFY_TYPE_SIMPLE);
		return PendingIntent.getService(this, 1010, intent, PendingIntent.FLAG_UPDATE_CURRENT);
	}
	
	private PendingIntent getMultiMsgIntent(){
		Intent intent = new Intent(this, PacketService.class);
		intent.putExtra(ParkingConstant.INTENT_EXTRA_BOOL_FROM_NOTIFY, true);
		intent.putExtra(ParkingConstant.INTENT_EXTRA_INT_NOTIFY_TYPE, NOTIFY_TYPE_MULTI);
		return PendingIntent.getService(this, 1010, intent, PendingIntent.FLAG_UPDATE_CURRENT);
	}
	
	//notify
	@SuppressWarnings("deprecation")
	private Notification buildOld() {
		// TODO Auto-generated method stub
		Notification notification = new Notification();
		notification.icon = R.drawable.ic_launcher;
		notification.defaults = Notification.DEFAULT_LIGHTS;
		if (isNeedSound()) {
			notification.defaults |= Notification.DEFAULT_SOUND;
		}
		if (isNeedVibra()) {
			notification.defaults |= Notification.DEFAULT_VIBRATE;
		}
		notification.flags |= Notification.FLAG_AUTO_CANCEL;
		notification.when = System.currentTimeMillis();
		notification.setLatestEventInfo(this, "浪花停车", mLastModel.getMsg(), getSimpleMsgIntent());
		return notification;
	}

	private boolean isNeedSound() {
		return true;
	}

	private boolean isNeedVibra() {
		return true;
	}

}
