package com.sendi.lhparking.im.receiver;

import com.sendi.lhparking.ctx.ParkingApp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
/**
 * 开机启动service
 * @author Administrator
 *
 */
public class IMBootReceiver extends BroadcastReceiver{

	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stub
		ParkingApp.mAppCtx.startXmppService();
	}

}
