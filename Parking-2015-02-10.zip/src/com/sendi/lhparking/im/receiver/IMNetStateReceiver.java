package com.sendi.lhparking.im.receiver;


import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.im.conn.XmppManager;
import com.sendi.lhparking.util.SysUtils;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class IMNetStateReceiver extends BroadcastReceiver {

	@Override
	public void onReceive(final Context context, Intent intent) {
		// TODO Auto-generated method stub

		if (SysUtils.isNetworkConnected(context)) {
			Log.i("qh", "网络变换了,有网~~。。。" + intent.getAction() + " ... ");
			ParkingApp.mAppCtx.startXmppService();
		} else {
			Log.i("qh", "网络变换了,没网。。。");
			XmppManager.getXmpp().disConn();
		}

	}

}
