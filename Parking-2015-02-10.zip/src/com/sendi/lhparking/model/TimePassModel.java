package com.sendi.lhparking.model;

/**
 * 秒表model
 * 
 * @author Administrator
 * 
 */
public class TimePassModel {

	private String orderid;
	private long timestart;// 启动的手机时间
	
	public String getOrderid() {
		return orderid;
	}

	public void setOrderid(String orderid) {
		this.orderid = orderid;
	}

	public long getTimestart() {
		return timestart;
	}

	public void setTimestart(long timestart) {
		this.timestart = timestart;
	}

}
