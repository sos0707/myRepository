package com.sendi.lhparking.model;

import com.lidroid.xutils.db.annotation.Id;

// 发布 model
public class PublishForm {
//	mSelectQuarter.getId(), mSelectPrice + "",
//	URLEncoder.encode(mSelectNum, "utf-8"), mSelectTimeBegin,
//	mSelectTimeEnd, mSelectRepeat + "", mSelectVaildDayCount
	@Id
	private String id;
//	private Quarter mLastQuarter;
	private String mSelectPrice;
	private String mSelectNum;
	private String mSelectTimeBegin;
	private String mSelectTimeEnd;
	private String mSelectRepeat;
	private String mSelectVaildDayCount;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
//	public Quarter getmLastQuarter() {
//		return mLastQuarter;
//	}
//	public void setmLastQuarter(Quarter mLastQuarter) {
//		this.mLastQuarter = mLastQuarter;
//	}
	public String getmSelectPrice() {
		return mSelectPrice;
	}
	public void setmSelectPrice(String mSelectPrice) {
		this.mSelectPrice = mSelectPrice;
	}
	public String getmSelectNum() {
		return mSelectNum;
	}
	public void setmSelectNum(String mSelectNum) {
		this.mSelectNum = mSelectNum;
	}
	public String getmSelectTimeBegin() {
		return mSelectTimeBegin;
	}
	public void setmSelectTimeBegin(String mSelectTimeBegin) {
		this.mSelectTimeBegin = mSelectTimeBegin;
	}
	public String getmSelectTimeEnd() {
		return mSelectTimeEnd;
	}
	public void setmSelectTimeEnd(String mSelectTimeEnd) {
		this.mSelectTimeEnd = mSelectTimeEnd;
	}
	public String getmSelectRepeat() {
		return mSelectRepeat;
	}
	public void setmSelectRepeat(String mSelectRepeat) {
		this.mSelectRepeat = mSelectRepeat;
	}
	public String getmSelectVaildDayCount() {
		return mSelectVaildDayCount;
	}
	public void setmSelectVaildDayCount(String mSelectVaildDayCount) {
		this.mSelectVaildDayCount = mSelectVaildDayCount;
	}
	
	
}
