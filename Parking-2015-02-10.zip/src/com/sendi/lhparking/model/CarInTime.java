package com.sendi.lhparking.model;

import com.lidroid.xutils.db.annotation.Id;

/**
 * 进场的标准时间
 * @author Administrator
 *
 */
public class CarInTime {

	@Id
	private String oid;
	private long time;

	public String getOid() {
		return oid;
	}

	public void setOid(String oid) {
		this.oid = oid;
	}

	public long getTime() {
		return time;
	}

	public void setTime(long time) {
		this.time = time;
	}

}
