package com.sendi.lhparking.model;

import com.lidroid.xutils.db.annotation.Id;

/**
 * xmpp通知消息
 * 
 * @author Administrator
 * 
 */
public class SystemMsgModel {

	@Id
	private String uuid;
	private String tag;//publish  
	private String task_id;
	private String msg;//
	private long time;

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getTag() {
		return tag;
	}

	public void setTag(String tag) {
		this.tag = tag;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getTask_id() {
		return task_id;
	}

	public void setTask_id(String task_id) {
		this.task_id = task_id;
	}

	public long getTime() {
		return time;
	}

	public void setTime(long time) {
		this.time = time;
	}

	
}
