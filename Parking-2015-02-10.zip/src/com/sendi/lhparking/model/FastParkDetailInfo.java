package com.sendi.lhparking.model;

public class FastParkDetailInfo {
	// parking_no：车位号 price:价格 time_range---可用时间   task_id--停车信息id
	private String parking_no;
	private String price;
	private String time_range;
	private String task_id;

	public String getParking_no() {
		return parking_no;
	}
	public void setParking_no(String parking_no) {
		this.parking_no = parking_no;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getTime_range() {
		return time_range;
	}
	public void setTime_range(String time_range) {
		this.time_range = time_range;
	}
	public String getTask_id() {
		return task_id;
	}
	public void setTask_id(String task_id) {
		this.task_id = task_id;
	}
	
	
}
