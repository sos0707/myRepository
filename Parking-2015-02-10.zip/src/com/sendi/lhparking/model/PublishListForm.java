package com.sendi.lhparking.model;

import com.lidroid.xutils.db.annotation.Id;

/**  列表 model
*/
public class PublishListForm {
	
	@Id
	private String id; 
	private String parking_no; 
	private String price; 
	private String time_hour; 
	private String time_date;
	private String state; 
	private String state_en; 
	private String boss_name;
	private String phone;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getParking_no() {
		return parking_no;
	}
	public void setParking_no(String parking_no) {
		this.parking_no = parking_no;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getTime_hour() {
		return time_hour;
	}
	public void setTime_hour(String time_hour) {
		this.time_hour = time_hour;
	}
	public String getTime_date() {
		return time_date;
	}
	public void setTime_date(String time_date) {
		this.time_date = time_date;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getState_en() {
		return state_en;
	}
	public void setState_en(String state_en) {
		this.state_en = state_en;
	}
	public String getBoss_name() {
		return boss_name;
	}
	public void setBoss_name(String boss_name) {
		this.boss_name = boss_name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	@Override
	public String toString() {
		return "PublishListForm [id=" + id + ", parking_no=" + parking_no
				+ ", state=" + state + ", state_en=" + state_en + "]";
	}
	
	
}
