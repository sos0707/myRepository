package com.sendi.lhparking.model;

/**
 * 评价
 * 
 * @author Administrator
 * 
 */
public class Evaluation {

	private String task_id;//评价的单号
	private String comment;// 评论
	private String point;// 评分
	private String master; // 评价者 master  评价 guest
	private String guest; // 被评价者

	public String getTask_id() {
		return task_id;
	}

	public void setTask_id(String task_id) {
		this.task_id = task_id;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getPoint() {
		return point;
	}

	public void setPoint(String point) {
		this.point = point;
	}

	public String getMaster() {
		return master;
	}

	public void setMaster(String master) {
		this.master = master;
	}

	public String getGuest() {
		return guest;
	}

	public void setGuest(String guest) {
		this.guest = guest;
	}

}
