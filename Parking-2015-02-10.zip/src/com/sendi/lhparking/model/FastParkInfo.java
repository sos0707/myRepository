package com.sendi.lhparking.model;

//{"id":"3","distance":89.0,"num":2,"name":"金羊小区"}
public class FastParkInfo {
	private String id;
	private double distance;
	private int num;
	private String name;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public double getDistance() {
		return distance;
	}
	public void setDistance(double distance) {
		this.distance = distance;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
