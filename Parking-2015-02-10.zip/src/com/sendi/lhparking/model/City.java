package com.sendi.lhparking.model;

public class City {

	private String city_name;
	private String city_code;

	public String getCity_name() {
		return city_name;
	}

	public void setCity_name(String city_name) {
		this.city_name = city_name;
	}

	public String getCity_code() {
		return city_code;
	}

	public void setCity_code(String city_code) {
		this.city_code = city_code;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return this.city_name;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((city_code == null) ? 0 : city_code.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		City other = (City) obj;
		if (city_code == null) {
			if (other.city_code != null)
				return false;
		} else if (!city_code.equals(other.city_code))
			return false;
		return true;
	}

	
}
