package com.sendi.lhparking.model;

/**
 * 评价的总体信息
 * 
 * @author Administrator
 * 
 */
public class EvaluationInfo {

	private String name;// 名字
	private String level;// 用户等级
	private String avg_point;// 评价总体平均分
	private String good_sum;// 好评数
	private String normal_sum;// 中评
	private String bad_sum;// 差评
	private String total_num;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getAvg_point() {
		return avg_point;
	}

	public void setAvg_point(String avg_point) {
		this.avg_point = avg_point;
	}

	public String getGood_sum() {
		return good_sum;
	}

	public void setGood_sum(String good_sum) {
		this.good_sum = good_sum;
	}

	public String getNormal_sum() {
		return normal_sum;
	}

	public void setNormal_sum(String normal_sum) {
		this.normal_sum = normal_sum;
	}

	public String getBad_sum() {
		return bad_sum;
	}

	public void setBad_sum(String bad_sum) {
		this.bad_sum = bad_sum;
	}

	public String getTotal_num() {
		return total_num;
	}

	public void setTotal_num(String total_num) {
		this.total_num = total_num;
	}

}
