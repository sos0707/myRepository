package com.sendi.lhparking.model;

import com.lidroid.xutils.db.annotation.Id;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * 小区
 * 
 * @author Administrator
 *         "data":[{"id":1,"name":"金羊花园","en":"JYHY","pmc_id":20,"price_hour"
 *         :10}]
 */
public class Quarter implements Parcelable {

	@Id
	private String id;
	private String name;
	private String en;
	private String pmc_id;
	private String price_hour;

	public Quarter() {
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEn() {
		return en;
	}

	public void setEn(String en) {
		this.en = en;
	}

	public String getPmc_id() {
		return pmc_id;
	}

	public void setPmc_id(String pmc_id) {
		this.pmc_id = pmc_id;
	}

	public String getPrice_hour() {
		return price_hour;
	}

	public void setPrice_hour(String price_hour) {
		this.price_hour = price_hour;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return name;
	}

	private Quarter(Parcel in) {
		this.id = in.readString();
		this.name = in.readString();
		this.en = in.readString();
		this.pmc_id = in.readString();
		this.price_hour = in.readString();
	}

	@Override
	public int describeContents() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		// TODO Auto-generated method stub
		dest.writeString(this.id);
		dest.writeString(this.name);
		dest.writeString(this.en);
		dest.writeString(this.pmc_id);
		dest.writeString(this.price_hour);
	}

	public static final Parcelable.Creator<Quarter> CREATOR = new Parcelable.Creator<Quarter>() {
		public Quarter createFromParcel(Parcel in) {
			return new Quarter(in);
		}

		public Quarter[] newArray(int size) {
			return new Quarter[size];
		}
	};
}
