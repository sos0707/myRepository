package com.sendi.lhparking.model;

import com.lidroid.xutils.db.annotation.Id;


/**
 * 角色共用 执行中的订单
 * 
 * @author Administrator
 * 
 */
public class ExecutingOrder {
	
	@Id
	private String orderId;

	private String id;//
	private String area_name;
	private String parking_no;
	private String start_hour;
	private String end_hour;
	private String task_date;
	private String price;
	private String state;
	
	private String type; // 最左边
	private String is_boss;
	private String is_run;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getArea_name() {
		return area_name;
	}

	public void setArea_name(String area_name) {
		this.area_name = area_name;
	}

	public String getParking_no() {
		return parking_no;
	}

	public void setParking_no(String parking_no) {
		this.parking_no = parking_no;
	}

	public String getStart_hour() {
		return start_hour;
	}

	public void setStart_hour(String start_hour) {
		this.start_hour = start_hour;
	}

	public String getEnd_hour() {
		return end_hour;
	}

	public void setEnd_hour(String end_hour) {
		this.end_hour = end_hour;
	}

	public String getTask_date() {
		return task_date;
	}

	public void setTask_date(String task_date) {
		this.task_date = task_date;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getIs_boss() {
		return is_boss;
	}

	public void setIs_boss(String is_boss) {
		this.is_boss = is_boss;
	}

	public String getIs_run() {
		return is_run;
	}

	public void setIs_run(String is_run) {
		this.is_run = is_run;
	}

	@Override
	public String toString() {
		return id;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
}
