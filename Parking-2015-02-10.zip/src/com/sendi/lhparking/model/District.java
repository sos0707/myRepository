package com.sendi.lhparking.model;

/**
 * 行政区
 * 
 * @author Administrator
 *         "data":[{"district":"天河",""district_en":"TIANHE","city_code":"020"}]}
 */
public class District {

	private String district;
	private String en_district;
	private String city_code;

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getCity_code() {
		return city_code;
	}

	public void setCity_code(String city_code) {
		this.city_code = city_code;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return district;
	}

	public String getEn_district() {
		return en_district;
	}

	public void setEn_district(String en_district) {
		this.en_district = en_district;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((city_code == null) ? 0 : city_code.hashCode());
		result = prime * result
				+ ((en_district == null) ? 0 : en_district.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		District other = (District) obj;
		if (city_code == null) {
			if (other.city_code != null)
				return false;
		} else if (!city_code.equals(other.city_code))
			return false;
		if (en_district == null) {
			if (other.en_district != null)
				return false;
		} else if (!en_district.equals(other.en_district))
			return false;
		return true;
	}

}
