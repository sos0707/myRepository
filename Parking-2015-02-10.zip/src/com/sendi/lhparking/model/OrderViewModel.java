package com.sendi.lhparking.model;

import android.util.Log;

/**
 * 查看订单情况 model
 * 
 * @author Administrator
 * 
 */
public class OrderViewModel {

	private String id;
	private String price;
	private String state;
	private String state_int;
	private String parking_no; // 车位号
	private String car_no; // 车牌号
	private String start_hour;
	private String end_hour;
	private String accept_time; // 接受任务时间
	private String car_in_time; // 车辆进场时间
	private String car_out_time; // 车辆离场时间
	private String task_date; // 日期

	private String booked_time_range; // 预约时间段

	private String area_name;// 小区名
	private String area_id;
	private String consume; // 消费
	private String desc;

	private String boss_id; // 业主ID
	private String worker_id; // 车主ID
	private String worker_name;// 车主名字
	private String car_rate;//好评率
	private String boss_name;// 业主名字
	
	private String evaParkToCar;//是否评价  业主对车主
	private String evaCarToPark;//车主对业主

	private boolean isShowTextView; // 是否可以进场
	private boolean isShowCancelButton; // 是否可以取消预约
	
	private String order_id;
	
	public String getArea_id() {
		return area_id;
	}

	public void setArea_id(String area_id) {
		this.area_id = area_id;
	}

	public String getOrder_id() {
		return order_id;
	}

	public void setOrder_id(String order_id) {
		this.order_id = order_id;
	}

	public boolean getIsShowCancelButton() {
		return isShowCancelButton;
	}
	
	public void setIsShowCancelButton(boolean isShowCancelButton) {
		this.isShowCancelButton = isShowCancelButton;
	}
	
	public boolean getIsShowTextView() {
		return isShowTextView;
	}

	public void setIsShowTextView(boolean isShowTextView) {
		this.isShowTextView = isShowTextView;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getState_int() {
		return state_int;
	}

	public void setState_int(String state_int) {
		this.state_int = state_int;
	}

	public String getParking_no() {
		return parking_no;
	}

	public void setParking_no(String parking_no) {
		this.parking_no = parking_no;
	}

	public String getCar_no() {
		return car_no;
	}

	public void setCar_no(String car_no) {
		this.car_no = car_no;
	}

	public String getStart_hour() {
		return start_hour;
	}

	public void setStart_hour(String start_hour) {
		this.start_hour = start_hour;
	}

	public String getEnd_hour() {
		return end_hour;
	}

	public void setEnd_hour(String end_hour) {
		this.end_hour = end_hour;
	}

	public String getAccept_time() {
		return accept_time;
	}

	public void setAccept_time(String accept_time) {
		this.accept_time = accept_time;
	}

	public String getCar_in_time() {
		return car_in_time;
	}

	public void setCar_in_time(String car_in_time) {
		this.car_in_time = car_in_time;
	}

	public String getCar_out_time() {
		return car_out_time;
	}

	public void setCar_out_time(String car_out_time) {
		this.car_out_time = car_out_time;
	}

	public String getTask_date() {
		return task_date;
	}

	public void setTask_date(String task_date) {
		this.task_date = task_date;
	}

	public String getBooked_time_range() {
		return booked_time_range;
	}

	public void setBooked_time_range(String booked_time_range) {
		this.booked_time_range = booked_time_range;
	}

	public String getArea_name() {
		return area_name;
	}

	public void setArea_name(String area_name) {
		this.area_name = area_name;
	}

	public String getConsume() {
		return consume;
	}

	public void setConsume(String consume) {
		this.consume = consume;
	}

	public String getBoss_id() {
		return boss_id;
	}

	public void setBoss_id(String boss_id) {
		this.boss_id = boss_id;
	}

	public String getWorker_id() {
		return worker_id;
	}

	public void setWorker_id(String worker_id) {
		this.worker_id = worker_id;
	}

	public String getWorker_name() {
		return worker_name;
	}

	public void setWorker_name(String worker_name) {
		this.worker_name = worker_name;
	}

	public String getBoss_name() {
		return boss_name;
	}

	public void setBoss_name(String boss_name) {
		this.boss_name = boss_name;
	}

	public void setCar_rate(String car_rate) {
		this.car_rate = car_rate;
	}
	
	public String getCar_rate() {
		return car_rate;
	}

	public String getEvaParkToCar() {
		return evaParkToCar;
	}

	public void setEvaParkToCar(String evaParkToCar) {
		this.evaParkToCar = evaParkToCar;
	}

	public String getEvaCarToPark() {
		return evaCarToPark;
	}

	public void setEvaCarToPark(String evaCarToPark) {
		this.evaCarToPark = evaCarToPark;
	}
	
	public boolean hasEvaCarToPark(){
		return this.evaCarToPark != null && this.evaCarToPark.equals("1");
	}
	
	public boolean hasEvaParkToCar(){
		return this.evaParkToCar != null && this.evaParkToCar.equals("1");
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	
}
