package com.sendi.lhparking.model;

public class InUsePark {
//	{"totalCount":1,  "data":[{"is_run":"y","id":"200","start_hour":"09:52","name":"曼曼",
//	"parking_no":"冲突车位","end_hour":"09:59","state":"车辆已进场","task_date":"2014-12-31","is_boss":"n"}]}
	private String is_run;
	private String start_hour;
	private String end_hour;
	private String state;
	private String task_date;
	private String is_boss;
	private String parking_no;
	private String name;
	private String orderId;
	private String id;
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return id;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	public String getParking_no() {
		return parking_no;
	}
	public void setParking_no(String parking_no) {
		this.parking_no = parking_no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getIs_run() {
		return is_run;
	}
	public void setIs_run(String is_run) {
		this.is_run = is_run;
	}
	public String getStart_hour() {
		return start_hour;
	}
	public void setStart_hour(String start_hour) {
		this.start_hour = start_hour;
	}
	public String getEnd_hour() {
		return end_hour;
	}
	public void setEnd_hour(String end_hour) {
		this.end_hour = end_hour;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getTask_date() {
		return task_date;
	}
	public void setTask_date(String task_date) {
		this.task_date = task_date;
	}
	public String getIs_boss() {
		return is_boss;
	}
	public void setIs_boss(String is_boss) {
		this.is_boss = is_boss;
	}
	
}
