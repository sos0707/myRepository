package com.sendi.lhparking.model;

public class UnUsePark {
	//"is_run":"y","id":"1574","start_hour":"00:00","name":"巴巴","parking_no":"double 2车位",
	//"end_hour":"23:00","state":"车位空闲","task_date":"2014-12-30","is_boss":"n"
	private String is_run;
	private String state;
	private String task_date;
	private String is_boos;
	private String parking_no;
	private String id;
	private String name;
	private String start_hour;
	private String end_hour;
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return id;
	}
	public String getParking_no() {
		return parking_no;
	}
	public void setParking_no(String parking_no) {
		this.parking_no = parking_no;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStart_hour() {
		return start_hour;
	}
	public void setStart_hour(String start_hour) {
		this.start_hour = start_hour;
	}
	public String getEnd_hour() {
		return end_hour;
	}
	public void setEnd_hour(String end_hour) {
		this.end_hour = end_hour;
	}
	public String getIs_run() {
		return is_run;
	}
	public void setIs_run(String is_run) {
		this.is_run = is_run;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getTask_date() {
		return task_date;
	}
	public void setTask_date(String task_date) {
		this.task_date = task_date;
	}
	public String getIs_boos() {
		return is_boos;
	}
	public void setIs_boos(String is_boos) {
		this.is_boos = is_boos;
	}
	
}
