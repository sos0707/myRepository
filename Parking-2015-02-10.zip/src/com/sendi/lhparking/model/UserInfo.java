package com.sendi.lhparking.model;

/**
 * 个人信息
 * 
 * @author Administrator
 * 
 */
public class UserInfo {

	private String phone;
	private String name;
	private String level;
	private String total_num;

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getTotal_num() {
		return total_num;
	}

	public void setTotal_num(String total_num) {
		this.total_num = total_num;
	}

}
