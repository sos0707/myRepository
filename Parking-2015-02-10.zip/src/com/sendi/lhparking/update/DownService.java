package com.sendi.lhparking.update;

import java.io.File;
import java.util.Random;

import org.sendi.parking.ui.R;

import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.ctx.ParkingLocal;
import com.sendi.lhparking.ctx.WeakHandler;
import com.sendi.lhparking.server.IServer;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.IBinder;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.RemoteViews;

/**
 * 下载  apk
 * @author Administrator
 * 
 */
public class DownService extends Service {

	public static boolean inDown = false;
	
	private NotificationManager mManager;
	
	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		this.mManager = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		// TODO Auto-generated method stub
		doUpdateApkFile();
		return super.onStartCommand(intent, flags, startId);
	}

	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}
	
	private WorkHandler mHandler = new WorkHandler(this);
	private Notification mNotification;
	private int mNotifyId;
	
	private long lastUpdate = -1;
	
	private void doUpdateApkFile(){
		String url = ParkingApp.mAppCtx.getServerConfig().getURL(IServer.URL_FLAG_GET_APK);
		File file = new File(ParkingLocal.getDownDir(), ParkingLocal.APK_FILE);
		if(file.exists()){
			file.delete();
		}
		HttpUtils http = new HttpUtils();
		http.download(url, 
			file.getAbsolutePath()
			, true, true, new RequestCallBack<File>() {
			
			@Override
			public void onStart() {
				// TODO Auto-generated method stub
				mHandler.sendEmptyMessage(WorkHandler.NOTIFY_START);
			}
			
			@Override
			public void onLoading(long total, long current, boolean isUploading) {
				// TODO Auto-generated method stub
				long now = System.currentTimeMillis();
				if(lastUpdate != -1){
					Log.i("qh", "update : "+(now - lastUpdate));
				}
				lastUpdate = now;
				Message msg = mHandler.obtainMessage();
				msg.what = WorkHandler.NOTIFY_UPDATE;
				msg.obj = (int)(current * 100 / total);//百分比
				mHandler.sendMessage(msg);//
			}
			
			@Override
			public void onSuccess(ResponseInfo<File> responseInfo) {
				// TODO Auto-generated method stub
				Message msg = mHandler.obtainMessage();
				msg.what = WorkHandler.NOTIFY_SUCCESS;
				msg.obj = responseInfo.result;
				mHandler.sendMessageDelayed(msg, 1000);
			}
			
			@Override
			public void onFailure(HttpException error, String text) {
				// TODO Auto-generated method stub
				Message msg = mHandler.obtainMessage();
				msg.what = WorkHandler.NOTIFY_FAIL;
				mHandler.sendMessageDelayed(msg, 1000);
			}
		});
	}
	
	@SuppressWarnings("deprecation")
	private void startNotify(){
		Notification.Builder builder = new Notification.Builder(this);
		builder.setSmallIcon(R.drawable.ic_launcher);
		builder.setContent(new RemoteViews("org.sendi.parking.ui",
				R.layout.layout_notify_down));
		builder.setDefaults(Notification.DEFAULT_LIGHTS);
		builder.setWhen(System.currentTimeMillis());
		builder.setAutoCancel(true);
		mNotification = builder.getNotification();
		mNotifyId = new Random().nextInt(1000);
		
		RemoteViews views = mNotification.contentView;
		views.setViewVisibility(R.id.layout_notify_down_progress_pb, View.GONE);
		views.setViewVisibility(R.id.layout_notify_down_progress_tv, View.GONE);
		views.setTextViewText(R.id.layout_notify_down_info_tv, "开始下载...");
		Log.i("TEST", " DownService starNotity ");
		mManager.notify(mNotifyId, mNotification);
	}
	
	private void updateNotify(int pecent){
		RemoteViews views = mNotification.contentView;
		views.setViewVisibility(R.id.layout_notify_down_progress_pb,
					View.VISIBLE);
		views.setViewVisibility(R.id.layout_notify_down_progress_tv,
					View.VISIBLE);
		views.setTextViewText(R.id.layout_notify_down_info_tv, "下载中");
		views.setProgressBar(R.id.layout_notify_down_progress_pb, 100,
				pecent, false);
		views.setTextViewText(R.id.layout_notify_down_progress_tv, pecent
				+ "%");
		mManager.notify(mNotifyId, mNotification);
	}
	
	private void successNotify(File file){
		RemoteViews views = mNotification.contentView;
		views.setViewVisibility(R.id.layout_notify_down_progress_pb, View.GONE);
		views.setViewVisibility(R.id.layout_notify_down_progress_tv, View.GONE);
		views.setTextViewText(R.id.layout_notify_down_info_tv, "下载成功,点击安装");
		mNotification.contentIntent = getSuccessPendingIntent(file);
		
		mManager.notify(mNotifyId, mNotification);
		stopSelf();
	}
	
	private PendingIntent getSuccessPendingIntent(File file) {
		// TODO Auto-generated method stub
		Intent intent = new Intent(Intent.ACTION_VIEW);
		intent.setDataAndType(Uri.fromFile(file),
				"application/vnd.android.package-archive");
		PendingIntent pintent = PendingIntent.getActivity(this, 1, intent,
				PendingIntent.FLAG_ONE_SHOT);
		return pintent;
	}

	private void failNotify(){
		RemoteViews views = mNotification.contentView;
		views.setViewVisibility(R.id.layout_notify_down_progress_pb, View.GONE);
		views.setViewVisibility(R.id.layout_notify_down_progress_tv, View.GONE);
		views.setTextViewText(R.id.layout_notify_down_info_tv, "下载失败，点击重试");
		mNotification.contentIntent = getFailPendingIntent();
		stopSelf();
	}
	
	private PendingIntent getFailPendingIntent() {
		// TODO Auto-generated method stub
		Intent intent = new Intent(ParkingApp.mAppCtx, DownService.class);
		PendingIntent pintent = PendingIntent.getService(this, 1,
				intent,
				PendingIntent.FLAG_ONE_SHOT);
		return pintent;
	}

	class WorkHandler extends WeakHandler<DownService>{
		
		public static final int NOTIFY_START = 1;
		public static final int NOTIFY_UPDATE = 2;
		public static final int NOTIFY_SUCCESS = 3;
		public static final int NOTIFY_FAIL = 4;

		public WorkHandler(DownService owner) {
			super(owner);
			// TODO Auto-generated constructor stub
		}
		
		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			switch (msg.what) {
			case NOTIFY_START:
				getOwner().startNotify();
				break;
			case NOTIFY_UPDATE:
				getOwner().updateNotify((Integer)msg.obj);
				break;
			case NOTIFY_SUCCESS:
				getOwner().successNotify((File)msg.obj);
				break;
			case NOTIFY_FAIL:
				getOwner().failNotify();
				break;
			default:
				break;
			}
		}
	}

}
