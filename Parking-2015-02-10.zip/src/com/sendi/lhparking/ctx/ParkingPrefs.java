package com.sendi.lhparking.ctx;

public class ParkingPrefs {
	
	public static String getStrValue(String key){
		return null;
	}

}
