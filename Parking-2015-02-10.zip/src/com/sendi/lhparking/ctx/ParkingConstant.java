package com.sendi.lhparking.ctx;


import com.sendi.lhparking.model.SystemMsgModel;
import com.sendi.lhparking.ui.common.ViewOrderActivity;
import com.sendi.lhparking.ui.common.ViewOrderHistoryActivity;
import com.sendi.lhparking.ui.common.ViewPublishInfoActivity;
import com.sendi.lhparking.ui.common.ViewPublishInfoFromSysActivity;

import android.content.Intent;
import android.util.Log;

/**
 * 定义 停车业务信息
 * @author Administrator
 *
 */
public class ParkingConstant {
	//车主  业主
	public static final int ROLE_USER = 0;
	//小区保安
	public static final int ROLE_GUARDER = 3;
	
	public static final int ROLE_YEZHU = 1;
	
	public static final String NO_USER_GUEST = "guest";
	
	public static final int ROLE_WUYE = 4;
	//发布车位的状态
	public static final String PUBLISH_UN_CHECK = "0";//未审核
	public static final String PUBLISH_CHECK_FAIL = "-1";//审核失败
	public static final String PUBLISH_CHECK_SUCCESS = "1";//审核通过
	public static final String PUBLISH_PAUSE = "2";//暂停
	
	//通知类型   publish /  order_runing /  order_completed
	public static final String SYS_MSG_TYPE_PUBLISH = "publish";
	public static final String SYS_MSG_TYPE_ORDER_RUNNING = "order_runing";
	public static final String SYS_MSG_TYPE_ORDER_COMPLETED = "order_completed";
	
	//intent
	public static final String INTENT_EXTRA_BOOL_FROM_SYSMSG = "is_from_system_msg";
	public static final String INTENT_EXTRA_BOOL_FROM_NOTIFY = "is_from_click_notify";
	public static final String INTENT_EXTRA_INT_NOTIFY_TYPE = "int_notify_type";
	
	public static final String INTENT_EXTRA_SYSMSG_UUID = "msg_uuid";
	public static final String INTENT_EXTRA_JSON = "json_data";
	public static final String INTENT_EXTRA_PUBLISH_DB_ID = "publish_db_id";//本地数据库
	public static final String INTENT_EXTRA_PUBLISH_ID = "publish_id";//server
	public static final String INTENT_EXTRA_ORDER_ID = "order_server_id";
	
	public static final String INTENT_EXTRA_EVALUTION_ORDERID = "evalution_orderid";
	public static final String INTENT_EXTRA_EVALUTION_MASTERID = "evalution_masterid";
	public static final String INTENT_EXTRA_EVALUTION_GUESTID = "evalution_guestid";
	//obj
	public static final String INTENT_EXTRA_OBJ_SCANTASK = "obj_scantask";
	
	
	// public
	public static Intent getIntentBySysMsg(SystemMsgModel model){
		if(model == null){
			return null;
		}
		String tag = model.getTag();
		Log.i("qh", "model tag : "+tag);
		Intent intent = null;
		if(ParkingConstant.SYS_MSG_TYPE_PUBLISH.equals(tag)){   // 订单发布
			Log.i("qh", "go to view publish");
			intent = new Intent(ParkingApp.mAppCtx, ViewPublishInfoFromSysActivity.class);
			intent.putExtra(ParkingConstant.INTENT_EXTRA_BOOL_FROM_SYSMSG, true);
			intent.putExtra(ParkingConstant.INTENT_EXTRA_PUBLISH_ID, model.getTask_id());
		}else if(ParkingConstant.SYS_MSG_TYPE_ORDER_RUNNING.equals(tag)){   // 订单进行中
			Log.i("qh", "go to view order");
			intent = new Intent(ParkingApp.mAppCtx, ViewOrderActivity.class);
			intent.putExtra(ParkingConstant.INTENT_EXTRA_BOOL_FROM_SYSMSG, true);
			intent.putExtra(ParkingConstant.INTENT_EXTRA_ORDER_ID, model.getTask_id());
		}else if(ParkingConstant.SYS_MSG_TYPE_ORDER_COMPLETED.equals(tag)){  // 订单完成
			//empty
			Log.i("qh", "go to view order history");
			intent = new Intent(ParkingApp.mAppCtx, ViewOrderHistoryActivity.class);
			intent.putExtra(ParkingConstant.INTENT_EXTRA_BOOL_FROM_SYSMSG, true);
			intent.putExtra(ParkingConstant.INTENT_EXTRA_ORDER_ID, model.getTask_id());
		}
		return intent;
	}

}
