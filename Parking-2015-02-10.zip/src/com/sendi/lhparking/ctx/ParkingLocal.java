package com.sendi.lhparking.ctx;

import java.io.File;

import android.os.Environment;

/**
 * 管理文件目录
 * @author Administrator
 *
 */
public class ParkingLocal {

	public static final String APP_DIR = "parking_app";
	public static final String DOWN_DIR = APP_DIR+"/down";
	
	public static final String APK_FILE = "lhparking.apk";
	
	public static boolean hasSDCard(){
		return Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState());
	}
	
	public static File getDownDir(){
		File sd = Environment.getExternalStorageDirectory();
		File dir = new File(sd, DOWN_DIR);
		if(!dir.exists()){
			dir.mkdirs();
		}
		return dir;
	}
}
