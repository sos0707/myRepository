package com.sendi.lhparking.ctx;


import com.baidu.lbsapi.BMapManager;
import com.baidu.lbsapi.MKGeneralListener;
import com.baidu.mapapi.SDKInitializer;
import com.sendi.lhparking.im.conn.XmppManager;
import com.sendi.lhparking.im.service.ConnService;
import com.sendi.lhparking.server.IServer;
import com.sendi.lhparking.server.ParkingServer;
import com.sendi.lhparking.ui.common.AppActivity;
import com.sendi.lhparking.ui.common.LoginActivity;
import com.sendi.lhparking.util.ParkingPrefs;
import com.sendi.lhparking.util.SysUtils;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

public class ParkingApp extends Application{
	
	public static ParkingApp mAppCtx;
	
	private final static String mAppType = "CHEZHU";
	private static int mAppTypeCode = 2;   // 1=业主    2=车主    3=保安     4=物业    0=原版
	private IServer mServer;
	
	private boolean mHasSysMsgListActivity;
	
	private AppActivity mDoor;
	
	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		mAppCtx = this;
		myversion = SysUtils.getVersionCode(ParkingApp.mAppCtx);
//		mServer = new ParkingServer("www.lhhl.cc", "8080");
		mServer = new ParkingServer("121.33.214.30", "8443");
//		mServer = new ParkingServer("www.lhhl.cc", "443");//http://192.168.60.207:8080/www.lhhl.cc
		XmppManager.getXmpp().initXmppConn();
		startXmppService();
		SDKInitializer.initialize(mAppCtx);
		initEngineManager(this);
	}
	
	public void setHasMainActivity(AppActivity door) {
		this.mDoor = door;
	}
	
	public void setHasSysMsgListActivity(boolean mHasSysMsgListActivity) {
		this.mHasSysMsgListActivity = mHasSysMsgListActivity;
	}
	
	public boolean isNeedLoadMainActivity() {
		return !(mDoor != null || mHasSysMsgListActivity);
	}
	
	public boolean isHasMainActivity() {
		return mDoor != null;
	}
	
	public void startMainActivity(){
		Intent intent = new Intent(this, AppActivity.class);
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		startActivity(intent);
	}
	
	public void finishMainActivity(){
		if(mDoor == null)return;
		mDoor.finish();
	}
	
	public void startXmppService(){
		startService(new Intent(this, ConnService.class));
	}
	
	public IServer getServerConfig() {
		return mServer;
	}
	
	public boolean isGuest(){
		return getUID().equals(ParkingConstant.NO_USER_GUEST);
	}
	
	public boolean isAutoLogin(){
		return ParkingPrefs.getBoolValue(LoginActivity.AUTO_LOGIN, false);
	}
	
	public boolean isNeedLogin(){
		return isGuest();
	}

	public String getUID(){
//		return "771793760658";
		String uid = ParkingPrefs.getStrValue(LoginActivity.PREF_LANGHUA_UID);
		Log.i("qh", mAppType + " uid : "+uid);
		return uid == null ? ParkingConstant.NO_USER_GUEST : uid;
//		return "628199577581";
		//628199577581   Guard / 
		//499840940619  user  
		// car_owner  301716303221
	}
	
	public int getUType(){
//		String utype = ParkingPrefs.getStrValue("langhua_utype");
		String utype = String.valueOf(this.getAppTypeCode());
		return utype == null ? 0 : Integer.valueOf(utype);
	}
	
	public static Handler payHandler;
	
	public void setPayHandler(Handler handler) {
		payHandler = handler;
	}
	
	//是否当前用户是物业
	public boolean isRoleGuard(){
		return getUType() == ParkingConstant.ROLE_WUYE;
	}
	//当前用户是该订单的 业主
	public boolean isRoleParkingOwner(String orderparkid){//相对id
		return getUID().equals(orderparkid);
	}
	//当前用户是该订单的 车主
	public boolean isRoleCarOwner(String ordercarid){
		return getUID().equals(ordercarid);
	}
	
	public static Handler addHandler;
	
	public void setAddHandler(Handler handler) {
		addHandler = handler;
	}
	
	public static int myversion = -1;
	public static int serverversion = -1;
	public static String updateInfo = null;
	
	public static void setMyversion(int myversion) {
		ParkingApp.myversion = myversion;
	}

	public static void setServerversion(int serverversion) {
		ParkingApp.serverversion = serverversion;
	}
	
	public static void setUpdateInfo(String info) {
		ParkingApp.updateInfo = info;
	}
	
	public static Handler appHandler;
	public static Handler orderHandler;
	public static Handler orderTabHandler;
	public static Handler mapHandler;
	
	public void setAppHandler(Handler handler) {
		ParkingApp.appHandler = handler;
	}
	
	public void setOrderHandler(Handler handler) {
		ParkingApp.orderHandler = handler;
	}
	
	public void setOrderTabHandler(Handler handler) {
		ParkingApp.orderTabHandler = handler;
	}
	
	public void setMapHandler(Handler handler) {
		ParkingApp.mapHandler = handler;
	}
	
	public static String versionName = "1.0";
	
	public static void setVersionName(String name) {
		ParkingApp.versionName = name;
	}
	
    public BMapManager mBMapManager = null;

    public void initEngineManager(Context context) {
        if (mBMapManager == null) {
            mBMapManager = new BMapManager(context);
        }

        if (!mBMapManager.init(new MyGeneralListener())) {
            Toast.makeText(mAppCtx.getApplicationContext(), 
                    "BMapManager  初始化错误!", Toast.LENGTH_LONG).show();
        }
	}
    
 // 常用事件监听，用来处理通常的网络错误，授权验证错误等
    public static class MyGeneralListener implements MKGeneralListener {
        
        @Override
        public void onGetPermissionState(int iError) {
        	//非零值表示key验证未通过
            if (iError != 0) {
                //授权Key错误：
            	Log.i("TEST", "请在AndoridManifest.xml中输入正确的授权Key,并检查您的网络连接是否正常！error: "+iError);
//                Toast.makeText(mAppCtx.getApplicationContext(), 
//                        "请在AndoridManifest.xml中输入正确的授权Key,并检查您的网络连接是否正常！error: "+iError, Toast.LENGTH_SHORT).show();
            }
            else{
            	Log.i("TEST", "key认证成功");
//            	Toast.makeText(mAppCtx.getApplicationContext(), 
//                        "key认证成功", Toast.LENGTH_SHORT).show();
            }
        }
    }
    
    public String getAppType() {
    	return mAppType;
    }
    
    public int getAppTypeCode() {
    	return mAppTypeCode;
    }
    
    public void setAppTypeCod(int type) {
    	mAppTypeCode = type;
    }
}
