package com.sendi.lhparking.adapter;

import org.sendi.parking.ui.R;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.sendi.lhparking.adapter.UnUseParkAdapter.ViewHolder;
import com.sendi.lhparking.model.ExecutingOrder;
import com.sendi.lhparking.model.InUsePark;
import com.sendi.lhparking.model.UnUsePark;

public class InUseParkAdapter extends PullListAdapter<InUsePark> {

	public InUseParkAdapter(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHolder vh = null;
		if (convertView == null) {
			convertView = LayoutInflater.from(mCtx).inflate(R.layout.item_order_list, null);
			vh = new ViewHolder();
			vh.llayout = (LinearLayout)convertView.findViewById(R.id.llayout_order);
			vh.vParkingInfo = (TextView) convertView.findViewById(R.id.item_order_list_parking_info);
			vh.vDateTime = (TextView) convertView.findViewById(R.id.item_order_list_parking_time_and_date);
			vh.vPrice = (TextView) convertView.findViewById(R.id.item_order_list_parking_price);
			vh.vState = (TextView) convertView.findViewById(R.id.item_order_list_state);
			vh.ivState = (ImageView) convertView.findViewById(R.id.img_icon);
			convertView.setTag(vh);
		} else {
			vh = (ViewHolder) convertView.getTag();
		}
		getData(convertView.getTag(), position);
		
		return convertView;
	}

	private void getData(Object vtag, int position) {
		ViewHolder vh = (ViewHolder) vtag;
		InUsePark info = mModels.get(position);
		vh.vParkingInfo.setText(info.getParking_no() + "   业主： " + info.getName());
		vh.vDateTime.setText("发布日期："+info.getTask_date());
		vh.vPrice.setText("停车时段："+info.getStart_hour()+" ~ "+info.getEnd_hour());
		vh.vState.setText(info.getState());
		vh.ivState.setImageResource(R.drawable.icon_ok);
		setState(vh.vState, vh.ivState, vh.llayout, info);
	}
	
	/*
	 * 物业处理中
	 * 预约成功
	 * 预约待确认
	 * 车辆已进场
	 */
	@SuppressLint("ResourceAsColor")
	private void setState(TextView tv, ImageView iv, LinearLayout ll ,InUsePark info) {
		tv.setText(info.getState());
		if(info.getState().equals("物业处理中")) {
			ll.setBackgroundResource(R.color.ordercolor);
		}else {
			ll.setBackgroundResource(R.color.color_write);
		} 
		
		if(info.getState().equals("物业处理中")) {
			iv.setImageResource(R.drawable.icon_deal);
		}else if(info.getState().equals("预约成功")) {
			iv.setImageResource(R.drawable.icon_ok);
		}else if(info.getState().equals("预约待确认")) {
			iv.setImageResource(R.drawable.icon_wait);
		}else if(info.getState().equals("车辆已进场")) {
			iv.setImageResource(R.drawable.icon_car_in);
		}else {
		}
	}
	
	class ViewHolder {
		TextView vParkingInfo;
		TextView vPrice;
		TextView vDateTime;
		TextView vState;
		ImageView ivState;
		LinearLayout llayout;
	}
	
}
