package com.sendi.lhparking.adapter;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.widget.BaseAdapter;

/**
 * 下拉列表的抽象adapter
 * @author Administrator
 *
 * @param <T>
 */
public abstract class PullListAdapter<T> extends BaseAdapter{
	
	protected List<T> mModels;
	protected Context mCtx;
	
	public PullListAdapter(Context context){
		this.mCtx = context;
		this.mModels = new ArrayList<T>();
	}
	
	public void setNewData(List<T> models){
		if(models == null){
			return;
		}
		mModels.clear();
		mModels = null;
		mModels = models;
		notifyDataSetChanged();
	}
	
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return mModels.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return mModels.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

}
