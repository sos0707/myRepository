package com.sendi.lhparking.adapter;

import java.text.DecimalFormat;
import java.util.List;

import org.sendi.parking.ui.R;

import com.sendi.lhparking.adapter.FastParkInfoListAdapter.ViewHolder;
import com.sendi.lhparking.model.FastParkDetailInfo;
import com.sendi.lhparking.model.FastParkInfo;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class FastParkDetaiListAdapter extends BaseAdapter {



	private List<FastParkDetailInfo> mData;
	private LayoutInflater inflater;
	
	public FastParkDetaiListAdapter(Context context, List<FastParkDetailInfo> infos) {
		this.mData = infos;
		this.inflater = LayoutInflater.from(context);
	}
	
	public void updateListView(List<FastParkDetailInfo> infos) {
		if(infos == null || infos.size() == 0) {
			return;
		}
		this.mData = infos;
		notifyDataSetChanged();
	}
	
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		if(mData == null) {
			return 0;
		}
		return mData.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return mData.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		final int p = position;
		View v = null;
		if(convertView == null){
			v = initView();
		}else {
			v = convertView;
		}
		getData(v.getTag(), p);
		return v;
	}

	private View initView() {
		View v = inflater.inflate(R.layout.list_findinfo_item, null);
		ViewHolder vh = new ViewHolder();
		vh.tvName = (TextView) v.findViewById(R.id.tv_name);
		vh.tvNum = (TextView) v.findViewById(R.id.tv_num);
		vh.tvDistance = (TextView) v.findViewById(R.id.tv_dictance);
		vh.tvDist = (TextView) v.findViewById(R.id.tv_dist);
		v.setTag(vh);
		return v;
	}
	
	private void getData(Object vtag, int position) {
		ViewHolder vh = (ViewHolder) vtag;
		FastParkDetailInfo info = mData.get(position);
		vh.tvName.setText(info.getParking_no());
		vh.tvNum.setText("可用时间 ： "+info.getTime_range());
		vh.tvDistance.setText(info.getPrice()+" 元/小时");
		vh.tvDist.setVisibility(View.GONE);
	}
	
	class ViewHolder {
		TextView tvName;
		TextView tvNum;
		TextView tvDistance;
		TextView tvDist;
	}


}
