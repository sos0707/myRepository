/*
 * Copyright (C) 2015 www.amsoft.cn
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.sendi.lhparking.adapter;

import java.util.List;

import com.ab.view.wheel.AbWheelAdapter;

// TODO: Auto-generated Javadoc
/**
 * The simple Array wheel adapter.
 *
 * @param <T> the element type
 */
public class AbListObjectWheelAdapter<T> implements AbWheelAdapter {
	
	private static final int DEFAULT_MAX_LEN = 20;
	

	private int length;
	private List<T> mData;
	/**
	 * Constructor.
	 *
	 * @param items the items
	 * @param length the max items length
	 */
	public AbListObjectWheelAdapter(List<T> data) {
		this.mData = data;
		this.length = data.size();
	}
	
	/**
	 * 描述：TODO.
	 *
	 * @param index the index
	 * @return the item
	 * @see com.ab.view.wheel.AbWheelAdapter#getItem(int)
	 * @author: amsoft.cn
	 * @date：2013-6-17 上午9:04:48
	 * @version v1.0
	 */
	@Override
	public String getItem(int index) {
		if (index >= 0 && index < length) {
			return mData.get(index).toString();
		}
		return null;
	}

	/**
	 * 描述：TODO.
	 *
	 * @return the items count
	 * @see com.ab.view.wheel.AbWheelAdapter#getItemsCount()
	 * @author: amsoft.cn
	 * @date：2013-6-17 上午9:04:48
	 * @version v1.0
	 */
	@Override
	public int getItemsCount() {
		return length;
	}

	/**
	 * 描述：TODO.
	 *
	 * @return the maximum length
	 * @see com.ab.view.wheel.AbWheelAdapter#getMaximumLength()
	 * @author: amsoft.cn
	 * @date：2013-6-17 上午9:04:48
	 * @version v1.0
	 */
	@Override
	public int getMaximumLength() {
		return DEFAULT_MAX_LEN;
	}

}
