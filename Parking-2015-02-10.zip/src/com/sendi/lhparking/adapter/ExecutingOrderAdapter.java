package com.sendi.lhparking.adapter;

import org.sendi.parking.ui.R;

import com.sendi.lhparking.model.ExecutingOrder;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * 进行中的 model adapter
 * @author Administrator
 *
 */
public class ExecutingOrderAdapter extends PullListAdapter<ExecutingOrder> {

	public ExecutingOrderAdapter(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHolder vh = null;
		if (convertView == null) {
			convertView = LayoutInflater.from(mCtx).inflate(R.layout.item_order_list, null);
			vh = new ViewHolder();
			vh.llayout = (LinearLayout)convertView.findViewById(R.id.llayout_order);
			vh.vParkingInfo = (TextView) convertView.findViewById(R.id.item_order_list_parking_info);
			vh.vDateTime = (TextView) convertView.findViewById(R.id.item_order_list_parking_time_and_date);
			vh.vPrice = (TextView) convertView.findViewById(R.id.item_order_list_parking_price);
			vh.vState = (TextView) convertView.findViewById(R.id.item_order_list_state);
			vh.ivState = (ImageView) convertView.findViewById(R.id.img_icon);
			convertView.setTag(vh);
		} else {
			vh = (ViewHolder) convertView.getTag();
		}
		ExecutingOrder order = mModels.get(position);
//		setType(vh.vType, order);
		setParkingInfo(vh.vParkingInfo, order);
		setDateTime(vh.vDateTime, order);
		if(order.getIs_boss().equals("y")) {
			setPrice(vh.vPrice, order, "我的车位");
		}else {
			setPrice(vh.vPrice, order);
		}
		setState(vh.vState, vh.ivState, vh.llayout, order);
		return convertView;
	}

//	private void setType(TextView tv, ExecutingOrder order) {
//
//	}

	private void setParkingInfo(TextView tv, ExecutingOrder order) {
		tv.setText(order.getParking_no());
	}

	private void setPrice(TextView tv, ExecutingOrder order) {
		tv.setText(order.getPrice());
	}

	private void setPrice(TextView tv, ExecutingOrder order, String state) {
		tv.setText(order.getPrice() + "      " + state);
	}
	
	private void setDateTime(TextView tv, ExecutingOrder order) {
		tv.setText(order.getTask_date() + " " + order.getStart_hour() + "-" + order.getEnd_hour());
	}

	/*
	 * 物业处理中
	 * 预约成功
	 * 预约待确认
	 * 车辆已进场
	 */
	@SuppressLint("ResourceAsColor")
	private void setState(TextView tv, ImageView iv, LinearLayout ll ,ExecutingOrder order) {
		tv.setText(order.getState());
		if(order.getType().equals("物业") && order.getState().equals("物业处理中")) {
			ll.setBackgroundResource(R.color.ordercolor);
		}else {
			ll.setBackgroundResource(R.color.color_write);
		} 
		
		if(order.getState().equals("物业处理中")) {
			iv.setImageResource(R.drawable.icon_deal);
		}else if(order.getState().equals("预约成功")) {
			iv.setImageResource(R.drawable.icon_ok);
		}else if(order.getState().equals("预约待确认")) {
			iv.setImageResource(R.drawable.icon_wait);
		}else if(order.getState().equals("车辆已进场")) {
			iv.setImageResource(R.drawable.icon_car_in);
		}else {
		}
	}

	class ViewHolder {
//		TextView vType;
		TextView vParkingInfo;
		TextView vPrice;
		TextView vDateTime;
		TextView vState;
		ImageView ivState;
		LinearLayout llayout;
	}

}
