package com.sendi.lhparking.adapter;

import org.sendi.parking.ui.R;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.sendi.lhparking.adapter.CompletedOrderAdapter.ViewHolder;
import com.sendi.lhparking.model.CompletedOrder;
import com.sendi.lhparking.model.UnUsePark;

public class UnUseParkAdapter extends PullListAdapter<UnUsePark> {

	public UnUseParkAdapter(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHolder vh = null;
		if (convertView == null) {
			convertView = LayoutInflater.from(mCtx).inflate(R.layout.item_order_list, null);
			vh = new ViewHolder();
			vh.vParkingInfo = (TextView) convertView.findViewById(R.id.item_order_list_parking_info);
			vh.vDateTime = (TextView) convertView.findViewById(R.id.item_order_list_parking_time_and_date);
			vh.vPrice = (TextView) convertView.findViewById(R.id.item_order_list_parking_price);
			vh.vState = (TextView) convertView.findViewById(R.id.item_order_list_state);
			vh.ivState = (ImageView) convertView.findViewById(R.id.img_icon);
			convertView.setTag(vh);
		} else {
			vh = (ViewHolder) convertView.getTag();
		}
		getData(convertView.getTag(), position);
		return convertView;
	}

	//"is_run":"y","id":"1574","start_hour":"00:00","name":"巴巴","parking_no":"double 2车位",
	//"end_hour":"23:00","state":"车位空闲","task_date":"2014-12-30","is_boss":"n"
	private void getData(Object vtag, int position) {
		ViewHolder vh = (ViewHolder) vtag;
		UnUsePark info = mModels.get(position);
		vh.vParkingInfo.setText(info.getParking_no() + "   业主： " + info.getName());
		vh.vDateTime.setText("发布日期："+info.getTask_date());
		vh.vPrice.setText("停车时段："+info.getStart_hour()+" ~ "+info.getEnd_hour());
		vh.vState.setText(info.getState());
		vh.ivState.setImageResource(R.drawable.icon_ok);
	}
	
	class ViewHolder {
		TextView vParkingInfo;
		TextView vPrice;
		TextView vDateTime;
		TextView vState;
		ImageView ivState;
	}
}
