package com.sendi.lhparking.adapter;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import org.sendi.parking.ui.R;

import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.sendi.lhparking.util.AccountDetailInfo;
import com.sendi.lhparking.view.StickyListHeadersAdapter;

public class AccountDetailStickyListAdapter extends BaseAdapter implements StickyListHeadersAdapter {

	private List<AccountDetailInfo> mData;	
	private LayoutInflater inflater;
	private Context mContext;
	private HashMap<String, Double> hmapIncome = new HashMap<String, Double>();
	private HashMap<String, Double> hmapOutcome = new HashMap<String, Double>();
	private HashMap<String, Integer> hmapCount = new HashMap<String, Integer>();
	private HashMap<String, Integer> hmapTotalCount = new HashMap<String, Integer>();

	public AccountDetailStickyListAdapter(Context context, List<AccountDetailInfo> infos) {
		this.mData = infos;
		this.mContext = context;
		this.inflater = LayoutInflater.from(context);
		getTotal();
	}
	
	public void updateListView(List<AccountDetailInfo> infos) {
		if(infos == null || infos.size() == 0) {
			return;
		}
//		this.mData.clear();
//		this.mData.addAll(infos);
		this.mData = infos;
		getTotal();
		this.notifyDataSetChanged();
	}
	
	@Override
	public int getCount() {
		if(mData == null) {
			return 0;
		}
		Log.i("TEST", "list size : " + mData.size());
		return mData.size();
	}

	@Override
	public Object getItem(int position) {
		return mData.get(position);
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		final int p = position;
		View v = null;
		if(convertView == null){
			v = initView();
		}else {
			v = convertView;
		}
		getData(v.getTag(), p);
		return v;
	}
	
	@Override
	public View getHeaderView(int position, View convertView, ViewGroup parent) {
		View v = inflater.inflate(R.layout.list_accountdetail_top_item, null);
		TextView tvCurMon = (TextView) v.findViewById(R.id.tvCurMon);
		TextView tvIncome = (TextView) v.findViewById(R.id.tvIncome);
		TextView tvOutcome = (TextView) v.findViewById(R.id.tvOutcome);
		String[] date = this.mData.get(position).getTime().split("\\-");
		String curDate = date[0]+"-"+date[1];
		tvCurMon.setText(date[1] +" 月");
		DecimalFormat df=new DecimalFormat(".##");
		double din = hmapIncome.get(curDate);
		double dout = hmapOutcome.get(curDate);
		if(din == 0) {
			tvIncome.setText("+"+String.valueOf(hmapIncome.get(curDate)));
		}else {
			tvIncome.setText("+"+ df.format(din));
		}
		
		if(dout == 0 ) {
			tvOutcome.setText(""+String.valueOf(hmapOutcome.get(curDate)));
		}else {
			tvOutcome.setText(""+ df.format(dout));
		}
//		tvIncome.setText("+"+String.valueOf(hmapIncome.get(curDate)));
//		tvOutcome.setText(""+String.valueOf(hmapOutcome.get(curDate)));
		return v;
	}

	/**
	 * 决定header出现的时机，如果当前的headerid和前一个headerid不同时，就会显示
	 */
	@Override
	public long getHeaderId(int position) {
		if(position == 0) {
			return position;
		}
		String[] date = this.mData.get(position).getTime().split("\\-");
		String curDate = date[0]+"-"+date[1];
		return hmapTotalCount.get(curDate);
	}
	
	private View initView() {
		View v = inflater.inflate(R.layout.list_accountdetail_item, null);
		ViewHolder vh = new ViewHolder();
//		vh.tvUname = (TextView) v.findViewById(R.id.tvUname);
		vh.tvType = (TextView) v.findViewById(R.id.tvType);
		vh.tvDate = (TextView) v.findViewById(R.id.tvDate);
		vh.tvNum = (TextView) v.findViewById(R.id.tvNum);
		vh.tvState = (TextView) v.findViewById(R.id.tvState);
		vh.ivState = (ImageView) v.findViewById(R.id.ivUIcon);
		v.setTag(vh);
		return v;
		
	}
	
	private void getData(Object vtag, int position) {
		ViewHolder vh = (ViewHolder) vtag;
		AccountDetailInfo info = mData.get(position);
//		vh.tvUname.setText(info.getUserName());
		vh.tvType.setText(info.getTaskName());
		vh.tvDate.setText(info.getTime());
		
		if(info.getMoney() <= 0) {
			if(info.getTaskName().equals("支出")) {
				vh.ivState.setImageResource(R.drawable.icon_outcome);
			}else {
				vh.ivState.setImageResource(R.drawable.icon_withdraw);
			}
			if(info.getMoney() == 0 && info.getTaskName().equals("收益")) {
				vh.tvNum.setTextColor(mContext.getResources().getColor(R.color.showcolor));
				vh.tvNum.setText("+"+String.valueOf(info.getMoney()));
			}else {
				vh.tvNum.setTextColor(Color.RED);
				vh.tvNum.setText(String.valueOf(info.getMoney()));
			}
		}else {
			if(info.getTaskName().equals("充值")) {
				vh.ivState.setImageResource(R.drawable.icon_recharge);
			}else {
				vh.ivState.setImageResource(R.drawable.icon_income);
			}
			vh.tvNum.setTextColor(mContext.getResources().getColor(R.color.showcolor));
			vh.tvNum.setText("+"+String.valueOf(info.getMoney()));
		}
		if(info.getTaskName().equals("提现")) {
			vh.tvState.setText(info.getState());
		}else {
			vh.tvState.setText("交易成功");
		}
	}
	
	class ViewHolder {
//		TextView tvUname;
		TextView tvType;
		TextView tvDate;
		TextView tvNum;
		TextView tvState;
		ImageView ivState;
	}
	
	public void getTotal() {
		hmapCount.clear();
		hmapIncome.clear();
		hmapOutcome.clear();
		hmapTotalCount.clear();
		int totalcount = 0;
		for(AccountDetailInfo info : this.mData){
			String[] ss = info.getTime().split("\\-");
			String curDate = ss[0]+"-"+ss[1];
			if( !hmapCount.containsKey(curDate)) {
				int count = 0;
				double income = 0, outcome = 0;
				for(AccountDetailInfo info1 : this.mData) {
					String[] ss1 = info1.getTime().split("\\-");
					String tDate = ss1[0]+"-"+ss1[1];
					if(curDate.equals(tDate)) {
						count++;
						if(info1.getMoney()>0) {
							income = income+info1.getMoney();
						}else {
							if( !info1.getTaskName().equals("提现")) {
								outcome = outcome+info1.getMoney();
							}
//							outcome = outcome+info1.getMoney();
						}
					}
				}
				hmapTotalCount.put(curDate, totalcount);
				totalcount = totalcount + count;
				Log.i("TEST", curDate+"   "+String.valueOf(totalcount));
//				hmapTotalCount.put(curDate, totalcount);
				hmapCount.put(curDate, count);
				hmapIncome.put(curDate, income);
				hmapOutcome.put(curDate, outcome);
			}
		}
	}
	
}
