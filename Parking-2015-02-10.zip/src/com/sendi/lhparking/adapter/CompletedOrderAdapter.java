package com.sendi.lhparking.adapter;

import org.sendi.parking.ui.R;

import com.sendi.lhparking.model.CompletedOrder;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * 完成订单的 model adapter
 * @author Administrator
 * 
 */
public class CompletedOrderAdapter extends PullListAdapter<CompletedOrder> {

	public CompletedOrderAdapter(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHolder vh = null;
		if (convertView == null) {
			convertView = LayoutInflater.from(mCtx).inflate(R.layout.item_order_list, null);
			vh = new ViewHolder();
			vh.vParkingInfo = (TextView) convertView.findViewById(R.id.item_order_list_parking_info);
			vh.vDateTime = (TextView) convertView.findViewById(R.id.item_order_list_parking_time_and_date);
			vh.vPrice = (TextView) convertView.findViewById(R.id.item_order_list_parking_price);
			vh.vState = (TextView) convertView.findViewById(R.id.item_order_list_state);
			vh.ivState = (ImageView) convertView.findViewById(R.id.img_icon);
			convertView.setTag(vh);
		} else {
			vh = (ViewHolder) convertView.getTag();
		}
		CompletedOrder order = mModels.get(position);
//		setType(vh.vType, order);
		setParkingInfo(vh.vParkingInfo, order);
		setDateTime(vh.vDateTime, order);
		setPrice(vh.vPrice, order);
		setState(vh.vState, vh.ivState, order);
		return convertView;
	}

//	private void setType(TextView tv, CompletedOrder order) {
//
//	}

	private void setParkingInfo(TextView tv, CompletedOrder order) {
		tv.setText(order.getParking_no());
	}

	private void setPrice(TextView tv, CompletedOrder order) {
		tv.setText(order.getPrice());
	}

	private void setDateTime(TextView tv, CompletedOrder order) {
		tv.setText(order.getTask_date() + " " + order.getStart_hour() + "-" + order.getEnd_hour());
	}

	/*
	 * 预约已取消
	 * 预约已拒绝
	 * 订单超时结束
	 * 车辆已离场
	 */
	private void setState(TextView tv, ImageView iv, CompletedOrder order) {
		tv.setText(order.getState());
		
		if(order.getState() == null) {
			iv.setImageResource(R.drawable.icon_timeout);
			return;
		}
		if(order.getState().equals("预约已取消")) {
			iv.setImageResource(R.drawable.icon_cancel);
		}else if(order.getState().equals("预约已拒绝")) {
			iv.setImageResource(R.drawable.icon_rej);
		}else if(order.getState().equals("订单超时结束")) {
			iv.setImageResource(R.drawable.icon_timeout);
		}else if(order.getState().equals("车辆已离场")) {
			iv.setImageResource(R.drawable.icon_car_out);
		}else {
			
		}
	}

	class ViewHolder {
//		TextView vType;
		
		TextView vParkingInfo;
		TextView vPrice;
		TextView vDateTime;
		TextView vState;
		ImageView ivState;
	}
}
