package com.sendi.lhparking.adapter;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

/**
 * 
 * @author Administrator
 *
 */
public abstract class ListDataCanRefreshAdapter<T> extends BaseAdapter{
	
	private List<T> mDatas;
	private Context mContext;
	
	public ListDataCanRefreshAdapter(Context mContext){
		this.mDatas = new ArrayList<T>();
		this.mContext = mContext;
	}
	/**
	 * 再原有数据的基础上，添加新数据到队尾
	 * @param datas
	 */
	public void addNewData(List<T> datas){
		if(datas != null){
			this.mDatas.addAll(datas);
			notifyDataSetChanged();
		}
	}
	
	/**
	 * 重置所有数据
	 * @param datas
	 */
	public void resetNewData(List<T> datas){
		this.mDatas.clear();
		if(datas != null){
			this.mDatas.addAll(datas);
		}
		notifyDataSetChanged();
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return mDatas.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return mDatas.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		T t = mDatas.get(position);
		Object obj = null;
		if(convertView == null){
			convertView = LayoutInflater.from(mContext).inflate(getItemLayoutId(), null);
			obj = initObjTag(convertView);
			convertView.setTag(obj);
		}else{
			obj = convertView.getTag();
		}
		bindView(obj, t);
		return convertView;
	}
	
	/**
	 * 子类提供布局id
	 * @return
	 */
	protected abstract int getItemLayoutId();
	
	/**
	 * 子类处理view与tagobj的对话
	 * @param converView
	 * @return
	 */
	protected abstract Object initObjTag(View converView);
	
	/**
	 * 子类处理tag obj与数据的绑定(tag obj 一般是自定义viewholder)
	 * @param tag
	 * @param t
	 */
	protected abstract void bindView(Object tag, T t);

}
