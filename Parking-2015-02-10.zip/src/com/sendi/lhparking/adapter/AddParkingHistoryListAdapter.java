package com.sendi.lhparking.adapter;

import java.util.List;

import org.sendi.parking.ui.R;

import com.sendi.lhparking.adapter.ParkingDetailListAdapter.ViewHolder;
import com.sendi.lhparking.util.AddParkingHistoryInfo;
import com.sendi.lhparking.util.ParkingDetailInfo;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class AddParkingHistoryListAdapter extends BaseAdapter {
	private List<AddParkingHistoryInfo> mData;
	private LayoutInflater inflater;
	
	public AddParkingHistoryListAdapter(Context context, List<AddParkingHistoryInfo> infos) {
		this.mData = infos;
		this.inflater = LayoutInflater.from(context);
	}
	
	public void updateListView(List<AddParkingHistoryInfo> infos) {
		if(infos == null || infos.size() == 0) {
			return;
		}
		this.mData = infos;
		notifyDataSetChanged();
	}
	
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		if(mData == null) {
			return 0;
		}
		return mData.size();
	}

	@Override
	public Object getItem(int arg0) {
		// TODO Auto-generated method stub
		return mData.get(arg0);
	}

	@Override
	public long getItemId(int arg0) {
		// TODO Auto-generated method stub
		return arg0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup arg2) {
		// TODO Auto-generated method stub
		final int p = position;
		View v = null;
		if(convertView == null){
			v = initView();
		}else {
			v = convertView;
		}
		getData(v.getTag(), p);
		return v;
	}

	private View initView() {
		View v = inflater.inflate(R.layout.list_addparkinghistory_item, null);
		ViewHolder vh = new ViewHolder();
		vh.tvParkingname = (TextView) v.findViewById(R.id.tvParkingname);
		vh.tvChargeunit = (TextView) v.findViewById(R.id.tvChargeunit);
		vh.tvState = (TextView) v.findViewById(R.id.tvState);
		v.setTag(vh);
		return v;
	}
	
	private void getData(Object vtag, int position) {
		ViewHolder vh = (ViewHolder) vtag;
		AddParkingHistoryInfo info = mData.get(position);
		vh.tvParkingname.setText("小区名称："+info.getParkingName());
		vh.tvChargeunit.setText("物业公司："+info.getChargeUnit());
		vh.tvState.setText("状态 ："+info.getState());
	}
	
	class ViewHolder {
		TextView tvParkingname;
		TextView tvChargeunit;
		TextView tvState;
		TextView tvParkRate;
	}
	
}
