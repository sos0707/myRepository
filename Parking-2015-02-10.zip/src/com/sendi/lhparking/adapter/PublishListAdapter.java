package com.sendi.lhparking.adapter;


import org.sendi.parking.ui.R;

import com.sendi.lhparking.model.PublishListForm;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * 发布车位页面  已发布车位 adapter
 * @author Administrator
 *
 */
public class PublishListAdapter extends PullListAdapter<PublishListForm>{
	

	public PublishListAdapter(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHolder vholder;
		if(convertView == null){
			convertView = LayoutInflater.from(mCtx).inflate(R.layout.item_publish_view_list, null);
			vholder = new ViewHolder();
			vholder.vQuarterInfo = (TextView) convertView.findViewById(R.id.item_publishview_quarter_and_num_tv);
			vholder.vTimeInfo = (TextView) convertView.findViewById(R.id.item_publishview_time_tv);
			vholder.vPriceInfo = (TextView) convertView.findViewById(R.id.item_publishview_price_tv);
			vholder.vCheckState = (TextView) convertView.findViewById(R.id.item_publishview_checkstate_tv);
			vholder.ivState = (ImageView) convertView.findViewById(R.id.img_icon);
			convertView.setTag(vholder);
		}else{
			vholder = (ViewHolder) convertView.getTag();
		}
		
		PublishListForm model = mModels.get(position);
		setQuarterInfo(vholder.vQuarterInfo, model);
		setTime(vholder.vTimeInfo, model);
		setPrice(vholder.vPriceInfo, model);
		setCheck(vholder.vCheckState, vholder.ivState, model);
		return convertView;
	}
	
	private void setQuarterInfo(TextView tv, PublishListForm model){
		tv.setText(model.getParking_no());
	}
	
	private void setTime(TextView tv, PublishListForm model){
		tv.setText(model.getTime_hour());
	}
	
	private void setPrice(TextView tv, PublishListForm model){
		tv.setText(model.getPrice());
	}
	
	private void setCheck(TextView tv, ImageView iv,  PublishListForm model){
		tv.setText(model.getState());
		switch (Integer.valueOf(model.getState_en())) {
		case -1: //拒绝
			iv.setImageResource(R.drawable.icon_cancel);
			break;
		case 0:  //审核中
			iv.setImageResource(R.drawable.icon_wait);
			break;
		case 1:  //通过
			iv.setImageResource(R.drawable.icon_ok);
			break;
		case 2:  //暂停
			iv.setImageResource(R.drawable.icon_pause);
			break;
		default: //
			break;
		}
	}

	class ViewHolder{
		TextView vQuarterInfo;
		TextView vTimeInfo;
		TextView vPriceInfo;
		TextView vCheckState;
		ImageView ivState;
	}
}
