package com.sendi.lhparking.adapter;

import java.util.List;

import org.sendi.parking.ui.R;

import com.sendi.lhparking.adapter.ParkingDetailListAdapter.ViewHolder;
import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.ui.chezhu.MapLocationActivity;
import com.sendi.lhparking.util.ParkingDetailInfo;
import com.sendi.lhparking.util.TrustListInfo;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class TrustListAdapter extends BaseAdapter {
	private List<TrustListInfo> mData;
	private LayoutInflater inflater;
	private Handler mHandler;
	private Context mContext;
	public TrustListAdapter(Context context, List<TrustListInfo> infos, Handler handler) {
		this.mData = infos;
		this.mContext = context;
		this.inflater = LayoutInflater.from(context);
		this.mHandler = handler;
	}
	
	public void updateListView(List<TrustListInfo> infos) {
		if(infos == null || infos.size() == 0) {
			return;
		}
		this.mData.clear();
		this.mData.addAll(infos);
		notifyDataSetChanged();
	}
	
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		if(mData == null) {
			return 0;
		}
		return mData.size();
	}

	@Override
	public Object getItem(int arg0) {
		// TODO Auto-generated method stub
		return mData.get(arg0);
	}

	@Override
	public long getItemId(int arg0) {
		// TODO Auto-generated method stub
		return arg0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup arg2) {
		// TODO Auto-generated method stub
		final int p = position;
		View v = null;
		if(convertView == null){
			v = initView();
		}else {
			v = convertView;
		}
		getData(v.getTag(), p);
		return v;
	}

	private View initView() {
		View v = inflater.inflate(R.layout.list_trust_item, null);
		ViewHolder vh = new ViewHolder();
		vh.tvParkName = (TextView) v.findViewById(R.id.tvParkName);
		vh.tvParkingNo = (TextView) v.findViewById(R.id.tvParkingNo);
		vh.tvRelateTime = (TextView) v.findViewById(R.id.tvRelateTime);
		vh.imgCancel = (Button) v.findViewById(R.id.imgCancel);
				
		v.setTag(vh);
		return v;
	}
	
	private void getData(Object vtag, int position) {
		ViewHolder vh = (ViewHolder) vtag;
		final TrustListInfo info = mData.get(position);
		vh.tvParkName.setText("小区名称："+info.getParkName());
		vh.tvParkingNo.setText("车位号："+info.getParkingNo());
		if(ParkingApp.mAppCtx.getUType() == 1) {
			vh.tvRelateTime.setText("自动审核该车位的发布");
		}else {
			vh.tvRelateTime.setText("自动审核所有人的预约");
		}
		
		vh.imgCancel.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				showDialog(info.getParkId());
			}
		});
	}
	
	private void showDialog(final String id) {  
        AlertDialog dialog;  
        AlertDialog.Builder builder = new AlertDialog.Builder(mContext);  
        builder.setTitle("提示").setIcon(android.R.drawable.stat_notify_error);  
        builder.setMessage("是否确认取消该设置"); 
        builder.setCancelable(true);
        builder.setNegativeButton("取消",
				new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						return;
					}
				});
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener(){  
            @Override 
            public void onClick(DialogInterface dialog, int which) {  
                // TODO Auto-generated method stub  
            	Message msg = new Message();
				msg.what = 1;
				msg.obj = id;
				mHandler.sendMessage(msg);
            }                     
        });
        dialog = builder.create();  
        dialog.show();  
    }
	
	class ViewHolder {
		TextView tvParkName;
		TextView tvParkingNo;
		TextView tvRelateTime;
		Button imgCancel;
	}
	
}
