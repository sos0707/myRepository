package com.sendi.lhparking.adapter;

import java.util.ArrayList;
import java.util.List;

import org.sendi.parking.ui.R;

import com.sendi.lhparking.util.ParkingDetailInfo;
import com.sendi.lhparking.view.TimeView;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class ParkingDetailListAdapter extends BaseAdapter {
	private List<ParkingDetailInfo> mData;
	private LayoutInflater inflater;
	
	public ParkingDetailListAdapter(Context context, List<ParkingDetailInfo> infos) {
		this.mData = infos;
		this.inflater = LayoutInflater.from(context);
	}
	
	public void updateListView(List<ParkingDetailInfo> infos) {
		if(infos == null || infos.size() == 0) {
			return;
		}
//		this.mData.clear();
//		this.mData.addAll(infos);
		this.mData = infos;
		this.notifyDataSetChanged();
	}
	
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		if(mData == null) {
			return 0;
		}
		return mData.size();
	}

	@Override
	public Object getItem(int arg0) {
		// TODO Auto-generated method stub
		return mData.get(arg0);
	}

	@Override
	public long getItemId(int arg0) {
		// TODO Auto-generated method stub
		return arg0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup arg2) {
		// TODO Auto-generated method stub
		final int p = position;
		View v = null;
		if(convertView == null){
			v = initView();
		}else {
			v = convertView;
		}
		getData(v.getTag(), p);
		return v;
	}

	private View initView() {
		View v = inflater.inflate(R.layout.list_parkingdetail_item, null);
		ViewHolder vh = new ViewHolder();
		vh.tvParkNum = (TextView) v.findViewById(R.id.tvParknum);
		vh.tvPrice = (TextView) v.findViewById(R.id.tvPrice);
		vh.tvParkTime = (TextView) v.findViewById(R.id.tvParkTime);
		vh.tvParkRate = (TextView) v.findViewById(R.id.tvParkrate);
		vh.tvTime = (TimeView)v.findViewById(R.id.tv_time);
		v.setTag(vh);
		return v;
	}
	
	private void getData(Object vtag, int position) {
		ViewHolder vh = (ViewHolder) vtag;
		ParkingDetailInfo info = mData.get(position);
		String time = info.getTimeHour();
		String ss[] = time.split("\\-");
		vh.tvParkNum.setText("车位号："+info.getPno());
		vh.tvPrice.setText(""+info.getPrice());        // 价钱
		vh.tvParkTime.setText(""+info.getTimeHour());  // 停车时段
		vh.tvParkRate.setText(""+info.getPrate());     //好评率
		vh.tvTime.setTime(ss[0], ss[3], info.getTimeHour());
	}
	
	class ViewHolder {
		TextView tvParkNum;
		TextView tvPrice;
		TextView tvParkTime;
		TextView tvParkRate;
		TimeView tvTime;
	}
	
}
