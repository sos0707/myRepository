package com.sendi.lhparking.ui.yezhu;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;
import org.sendi.parking.ui.R;
import org.sendi.parking.ui.R.array;
import org.sendi.parking.ui.R.drawable;
import org.sendi.parking.ui.R.id;
import org.sendi.parking.ui.R.layout;

import com.ab.util.AbStrUtil;
import com.ab.view.wheel.AbNumericWheelAdapter;
import com.ab.view.wheel.AbObjectWheelAdapter;
import com.ab.view.wheel.AbWheelView;
import com.lidroid.xutils.exception.DbException;
import com.lidroid.xutils.view.ResType;
import com.lidroid.xutils.view.annotation.ResInject;
import com.lidroid.xutils.view.annotation.ViewInject;
import com.lidroid.xutils.view.annotation.event.OnClick;
import com.sendi.lhparking.model.PublishForm;
import com.sendi.lhparking.model.PublishListForm;
import com.sendi.lhparking.model.Quarter;
import com.sendi.lhparking.server.IServer;
import com.sendi.lhparking.ui.common.base.BaseActivityWithDialog;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;

/**
 * 生成新的车位
 * 
 * @author Administrator
 * 
 */
public class NewPublishActivity extends BaseActivityWithDialog {

	public static final int REQ_SELECT_QUARTER = 1001;

	// for top bar
	@ViewInject(R.id.topbar_left_btn)
	private TextView vTopLeft;
	@ViewInject(R.id.topbar_center_btn)
	private TextView vTopCenter;
	@ViewInject(R.id.topbar_right_btn)
	private TextView vTopRight;

	@OnClick(value = { R.id.new_publish_do_publish })
	private void doPublish(View view) {
		// empty
		if (tipsUserOption()) {
			return;
		}
		showConfirmDialog();
	}

	@OnClick(value = { R.id.topbar_left_btn })
	private void topLeftDoCancel(View view) {
		finish();
	}

	// my views
	@ViewInject(R.id.new_publish_parking_position)
	private TextView vQuarter;// 小区
	@ViewInject(R.id.new_publish_parking_num)
	private EditText vParkingNum;// 车位
	@ViewInject(R.id.new_publish_time_begin)
	private TextView vTimeBegin;
	@ViewInject(R.id.new_publish_time_end)
	private TextView vTimeEnd;
	@ViewInject(R.id.new_publish_price)
	private TextView vParkingPrice;
	@ViewInject(R.id.new_publish_repeat)
	private TextView vRepeat;
	@ViewInject(R.id.new_publish_validity)
	private EditText vVaildCount;
	@ViewInject(R.id.new_publish_do_publish)
	private Button vDoPublish;
	@ViewInject(R.id.layout_repeat_day)
	private LinearLayout llayoutRepeat;
	
	private Quarter mSelectQuarter;
	private String mSelectNum;
	private String mSelectTimeBegin;
	private String mSelectTimeEnd;
	private int mSelectPrice;
	private int mSelectRepeat = -1;
	private String mSelectVaildDayCount;

	@OnClick(value = { R.id.new_publish_parking_position })   //  选择小区
	private void doSelectQuarter(View v) {
		Intent intent = new Intent(this, SelectQuarterActivity.class);
		startActivityForResult(intent, REQ_SELECT_QUARTER);
	}

	@OnClick(value = { R.id.new_publish_price })
	private void doSelectPrice(View view) {
		if (mSelectQuarter == null) {
			tipsUserOption();
			return;
		}
		showChooserPriceDialog();
	}

	@OnClick(value = { R.id.new_publish_repeat })
	private void doSelectRepeat(View view) {
		showChooserRepeatDialog();
	}

	@OnClick(value = { R.id.new_publish_time_begin })
	private void doSelectTimeBegin(View view) {
		mSelectTimeType = SELECT_TIME_BEGIN;
		showChooseTimeDialog();
	}

	@OnClick(value = { R.id.new_publish_time_end })
	private void doSelectTimeEnd(View view) {
		mSelectTimeType = SELECT_TIME_END;
		showChooseTimeDialog();
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_new_publish);
		
		initViews();
		checkLastForm();
	}

	private void initViews() {
		vTopCenter.setText("车位信息");
		vTopLeft.setText("  返回");
		vTopLeft.setVisibility(View.VISIBLE);
		vVaildCount.setOnEditorActionListener(new OnEditorActionListener() {

			@Override
			public boolean onEditorAction(TextView v, int actionId,
					KeyEvent event) {
				// TODO Auto-generated method stub
				switch (actionId) {
				case EditorInfo.IME_ACTION_DONE:
					vDoPublish.performClick();
					return true;
				default:
					break;
				}
				return false;
			}
		});
	}

	private void checkLastForm() {
		try {
			PublishForm model = mDB.findFirst(PublishForm.class);
			mSelectQuarter = mDB.findFirst(Quarter.class);
			if (model == null || mSelectQuarter == null) {
				return;
			}else {
//				mSelectQuarter = model.getmLastQuarter();
				mSelectNum = model.getmSelectNum();
				mSelectTimeBegin = model.getmSelectTimeBegin();
				mSelectTimeEnd = model.getmSelectTimeEnd();
				mSelectPrice = Integer.valueOf(model.getmSelectPrice());
				mSelectRepeat = Integer.valueOf(model.getmSelectRepeat());
				mSelectVaildDayCount = model.getmSelectVaildDayCount();

				vQuarter.setText(mSelectQuarter.getName());
				vParkingNum.setText(model.getmSelectNum());
				vTimeBegin.setText(mSelectTimeBegin);
				vTimeEnd.setText(mSelectTimeEnd);
				vParkingPrice.setText(mSelectPrice + " 元/小时");
				vRepeat.setText(REPEAT_ARR[mSelectRepeat]);
				if(mSelectRepeat == 0) {
					llayoutRepeat.setVisibility(View.GONE);
				}else {
					llayoutRepeat.setVisibility(View.VISIBLE);
					vVaildCount.setText(model.getmSelectVaildDayCount());
				}
				
			}
		} catch (DbException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		Log.i("qh", "activity result");
		if (requestCode == REQ_SELECT_QUARTER) {
			Log.i("qh", "activity result : select quarter");
			if (resultCode == RESULT_OK && data != null) {
				mSelectQuarter = data
						.getParcelableExtra(SelectQuarterActivity.KEY_RESULT);
				if (mSelectQuarter == null) {
					showToastTips("选择小区失败");
					return;
				}
				vQuarter.setText(mSelectQuarter.getName());
				// 换了小区 价格要清空
				vParkingPrice.setHint("不高于小区限价("
						+ mSelectQuarter.getPrice_hour() + "元/小时)");
				vParkingPrice.setText("");
				mSelectPrice = 0;

				// 换了小区 车位要清空
				vParkingNum.setText("");
				mSelectNum = null;
			}else {
				showToastTips("未选择小区");
			}
		}
	}

	private boolean tipsUserOption() {
		if (mSelectQuarter == null) {
			showToastTips("请选择小区");
			return true;
		}
		mSelectNum = vParkingNum.getText().toString();
		if (AbStrUtil.isEmpty(mSelectNum)) {
			showToastTips("请填写车位");
			return true;
		}
		if (mSelectTimeBegin == null || mSelectTimeEnd == null) {
			showToastTips("请选择正确的时间段");
			return true;
		}
		try {
			if (mSelectPrice <= 0
					|| mSelectPrice > Integer.valueOf(mSelectQuarter
							.getPrice_hour())) {
				showToastTips("请选择正确的价格");
				return true;
			}
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (mSelectRepeat < 0) {
			showToastTips("请设置重复模式");
			return true;
		}
		mSelectVaildDayCount = vVaildCount.getText().toString();
		if(mSelectRepeat == 0) {
			mSelectVaildDayCount = "1";
		}
		if (AbStrUtil.isEmpty(mSelectVaildDayCount) ) {
			showToastTips("请填写有效时间");
			return true;
		}
		return false;
	}

	private boolean checkTimeVaild() {
		if (mSelectTimeBegin == null || mSelectTimeEnd == null) {
			return true;
		}
		String[] begin = mSelectTimeBegin.split(":");
		String[] end = mSelectTimeEnd.split(":");

		int beginHH = Integer.valueOf(begin[0]);
		int beginMM = Integer.valueOf(begin[1]);

		int endHH = Integer.valueOf(end[0]);
		int endMM = Integer.valueOf(end[1]);

		if (endHH <= beginHH || ((endHH - beginHH == 1) && endMM < beginMM)) {
			showToastTips("时间段必须大于一个小时");
			clearTime();
			return false;
		}
		return true;
	}

	private void clearTime() {
		mSelectTimeBegin = null;
		mSelectTimeEnd = null;
		vTimeBegin.setText("");
		vTimeEnd.setText("");
	}

	// set wheel params
	private void setWheel(AbWheelView wheel) {
		wheel.setCyclic(false);
		wheel.setCurrentItem(0);
		wheel.setValueTextSize(32);
		wheel.setLabelTextSize(30);
		wheel.setLabelTextColor(0x80000000);
		wheel.setCenterSelectDrawable(this.getResources().getDrawable(
				R.drawable.wheel_select));
	}

	// price select
	private View vWheelPricePanel;
	private AbWheelView vWheelPrice;
	private Button vPriceCancel;
	private Button vPriceOk;

	private void showChooserPriceDialog() {
		if (vWheelPricePanel == null) {
			vWheelPricePanel = LayoutInflater.from(this).inflate(
					R.layout.layout_wheel_chooser_one, null);
			vWheelPrice = (AbWheelView) vWheelPricePanel
					.findViewById(R.id.wheel_panel_wheel);
			vPriceOk = (Button) vWheelPricePanel
					.findViewById(R.id.wheel_panel_okBtn);
			vPriceCancel = (Button) vWheelPricePanel
					.findViewById(R.id.wheel_panel_cancelBtn);

			vPriceCancel.setOnClickListener(new OnClickListener() {

				@SuppressWarnings("deprecation")
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					dismissDialog(DIALOG_BOTTOM);
				}
			});

			vPriceOk.setOnClickListener(new OnClickListener() {

				@SuppressWarnings("deprecation")
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					int curindex = vWheelPrice.getCurrentItem();
					mSelectPrice = curindex + 1;
					vParkingPrice.setText(mSelectPrice + " 元/小时");
					dismissDialog(DIALOG_BOTTOM);
				}
			});
			setWheel(vWheelPrice);
			vWheelPrice.setLabel("元/小时");
		}

		try {
			AbNumericWheelAdapter adapter = new AbNumericWheelAdapter(1,
					Integer.valueOf(mSelectQuarter.getPrice_hour()));
			vWheelPrice.setAdapter(adapter);
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return;
		}

		showDialog(DIALOG_BOTTOM, vWheelPricePanel);
	}

	// repeat select

	public static final String[] REPEAT_ARR = new String[] { "不重复", "每日", "工作日", "节假日" };

	private View vWheelRepeatPanel;
	private AbWheelView vWheelRepeat;
	private Button vRepeatCancel;
	private Button vRepeatOk;

	private void showChooserRepeatDialog() {
		if (vWheelRepeatPanel == null) {
			vWheelRepeatPanel = LayoutInflater.from(this).inflate(
					R.layout.layout_wheel_chooser_one, null);
			vWheelRepeat = (AbWheelView) vWheelRepeatPanel
					.findViewById(R.id.wheel_panel_wheel);
			vRepeatOk = (Button) vWheelRepeatPanel
					.findViewById(R.id.wheel_panel_okBtn);
			vRepeatCancel = (Button) vWheelRepeatPanel
					.findViewById(R.id.wheel_panel_cancelBtn);

			vRepeatCancel.setOnClickListener(new OnClickListener() {

				@SuppressWarnings("deprecation")
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					dismissDialog(DIALOG_BOTTOM);
				}
			});

			vRepeatOk.setOnClickListener(new OnClickListener() {

				@SuppressWarnings("deprecation")
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					mSelectRepeat = vWheelRepeat.getCurrentItem();
					vRepeat.setText(REPEAT_ARR[mSelectRepeat]);
					dismissDialog(DIALOG_BOTTOM);
					if(0 == mSelectRepeat) {
						llayoutRepeat.setVisibility(View.GONE);
						mSelectVaildDayCount = "1";
					}else{
						llayoutRepeat.setVisibility(View.VISIBLE);
					}
				}
			});
			setWheel(vWheelRepeat);
		}

		try {
			AbObjectWheelAdapter<String> adapter = new AbObjectWheelAdapter<String>(
					REPEAT_ARR, 5);
			vWheelRepeat.setAdapter(adapter);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return;
		}
		showDialog(DIALOG_BOTTOM, vWheelRepeatPanel);
	}

	// time select
	public static final int SELECT_TIME_BEGIN = 1;
	public static final int SELECT_TIME_END = 2;

	@ResInject(id = R.array.time_minutes, type = ResType.StringArray)
	private String[] mMinutes;
	@ResInject(id = R.array.time_hours, type = ResType.StringArray)
	private String[] mHours;
	private int mSelectTimeType;

	private View vWheelTimePanel;
	private AbWheelView vWheelHour;
	private AbWheelView vWheelMinute;
	private Button vTimeCancel;
	private Button vTimeOk;

	private void showChooseTimeDialog() {
		if (vWheelTimePanel == null) {
			vWheelTimePanel = LayoutInflater.from(this).inflate(
					R.layout.layout_wheel_chooser_two, null);
			vWheelHour = (AbWheelView) vWheelTimePanel
					.findViewById(R.id.wheel_panel_wheel_1);
			vWheelMinute = (AbWheelView) vWheelTimePanel
					.findViewById(R.id.wheel_panel_wheel_2);
			vTimeCancel = (Button) vWheelTimePanel
					.findViewById(R.id.wheel_panel_cancelBtn);
			vTimeOk = (Button) vWheelTimePanel
					.findViewById(R.id.wheel_panel_okBtn);

			vTimeCancel.setOnClickListener(new OnClickListener() {

				@SuppressWarnings("deprecation")
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					dismissDialog(DIALOG_BOTTOM);
				}
			});

			vTimeOk.setOnClickListener(new OnClickListener() {

				@SuppressWarnings("deprecation")
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					int hour = vWheelHour.getCurrentItem();
					int minute = vWheelMinute.getCurrentItem();
					switch (mSelectTimeType) {
					case SELECT_TIME_BEGIN:
						mSelectTimeBegin = mHours[hour] + ":"
								+ mMinutes[minute];
						if (checkTimeVaild()) {
							vTimeBegin.setText(mSelectTimeBegin);
						}
						break;
					case SELECT_TIME_END:
						mSelectTimeEnd = mHours[hour] + ":" + mMinutes[minute];
						if (checkTimeVaild()) {
							vTimeEnd.setText(mSelectTimeEnd);
						}
						break;
					default:
						break;
					}
					dismissDialog(DIALOG_BOTTOM);
				}
			});

			setWheel(vWheelHour);
			vWheelHour.setCyclic(true);
			setWheel(vWheelMinute);

			AbObjectWheelAdapter<String> adapterhours = new AbObjectWheelAdapter<String>(
					mHours, 2);
			vWheelHour.setAdapter(adapterhours);
			AbObjectWheelAdapter<String> adapterminutes = new AbObjectWheelAdapter<String>(
					mMinutes, 2);
			vWheelMinute.setAdapter(adapterminutes);
		}

		showDialog(DIALOG_BOTTOM, vWheelTimePanel);
	}

	// confirm dialog

	private AlertDialog mConfirmDialog;

	private void showConfirmDialog() {
		if (mConfirmDialog == null) {
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setTitle("车位信息确认")
					.setCancelable(false)
					.setPositiveButton("确定",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int id) {
									postNewPublish();
								}
							})
					.setNegativeButton("取消",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int id) {
									mConfirmDialog.dismiss();
								}
							});
			mConfirmDialog = builder.create();
		}
		mConfirmDialog.setMessage(getNewPublishInfo());
		mConfirmDialog.show();
	}

	private String getNewPublishInfo() {
		StringBuilder builder = new StringBuilder();
		builder.append("停车位置:  ").append(mSelectQuarter.getName()).append('\n')
				.append("车位号码:  ").append(mSelectNum).append('\n')
				.append("车位时间:  ")
				.append(mSelectTimeBegin + " ~ " + mSelectTimeEnd).append('\n')
				.append("车位单价:  ").append(mSelectPrice + "元/小时").append('\n')
				.append("重复模式:  ").append(REPEAT_ARR[mSelectRepeat]).append('\n')
				.append("有效期限:  ").append(mSelectVaildDayCount + " 天")
				.append('\n');
		return builder.toString();
	}

	/**
	 * .append("&area_id").append(params[0]) .append("&price").append(params[1])
	 * .append("&parking_no").append(params[2])
	 * .append("&start_hour").append(params[3])
	 * .append("&end_hour").append(params[4])
	 * .append("&cycle").append(params[5])
	 * .append("&validitydate").append(params[6]);
	 */
	private void postNewPublish() {
		String url = null;
		int repeat = 0;
		if(mSelectRepeat == 0) {
			mSelectVaildDayCount = "1";
		}else {
			repeat = mSelectRepeat - 1;
		}
		try {
			url = mServer.getURL(IServer.URL_FLAG_POST_NEW_PUBLISH,
					mSelectQuarter.getId(), mSelectPrice + "",
					URLEncoder.encode(mSelectNum, "utf-8"), mSelectTimeBegin,
					mSelectTimeEnd, repeat + "", mSelectVaildDayCount);
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			showToastTips("发布失败，车位号字符解析错误");
			return;
		}
		showProgressDialog("正在发布车位信息...");
		getJsonFromServer(url);
		
		PublishForm publishForm = new PublishForm();
		publishForm.setmSelectNum(mSelectNum);
		publishForm.setmSelectPrice(mSelectPrice+"");
		publishForm.setmSelectRepeat(mSelectRepeat+"");
		publishForm.setmSelectTimeBegin(mSelectTimeBegin);
		publishForm.setmSelectTimeEnd(mSelectTimeEnd);
		publishForm.setmSelectVaildDayCount(mSelectVaildDayCount);
		try {
			mDB.deleteAll(PublishForm.class);
			mDB.save(publishForm);
			mDB.deleteAll(Quarter.class);
			mDB.save(mSelectQuarter);
		} catch (DbException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	protected void callbackFromGetJsonFail(int failcode, String msg) {
		// TODO Auto-generated method stub
		dismissDialog(DIALOG_PROGRESS);
		showToastTips("发布车位信息失败:" + msg);
	}

	@Override
	protected void callbackFromGetJsonSuccess(String json) {
		// TODO Auto-generated method stub
		dismissDialog(DIALOG_PROGRESS);
		boolean issuccess = false;
		String msg = "发布车位信息成功";
		try {
			JSONObject jobj = new JSONObject(json);
			issuccess = jobj.getBoolean("success");
			if (!issuccess) {
				msg = jobj.getString("msg");
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		showToastTips(msg);
		if (issuccess) {
			setResult(RESULT_OK);
			finish();
		}
	}

}
