package com.sendi.lhparking.ui.yezhu;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.sendi.parking.ui.R;
import org.sendi.parking.ui.R.drawable;
import org.sendi.parking.ui.R.id;
import org.sendi.parking.ui.R.layout;
import org.sendi.parking.ui.R.string;

import com.ab.view.pullview.AbPullToRefreshView;
import com.ab.view.pullview.AbPullToRefreshView.OnHeaderRefreshListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.lidroid.xutils.exception.DbException;
import com.lidroid.xutils.view.ResType;
import com.lidroid.xutils.view.annotation.ResInject;
import com.lidroid.xutils.view.annotation.ViewInject;
import com.lidroid.xutils.view.annotation.event.OnClick;
import com.lidroid.xutils.view.annotation.event.OnItemClick;
import com.sendi.lhparking.adapter.PublishListAdapter;
import com.sendi.lhparking.adapter.PullListAdapter;
import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.ctx.ParkingConstant;
import com.sendi.lhparking.model.PublishListForm;
import com.sendi.lhparking.server.IServer;
import com.sendi.lhparking.ui.common.ViewPublishInfoActivity;
import com.sendi.lhparking.ui.common.base.BaseActivity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 车位发布列表 浏览主页
 * 
 * @author Administrator
 * 
 */
public class PublishListActivity extends BaseActivity implements
		OnHeaderRefreshListener {

	public static final int REQ_ADD = 1001;
	public static final int REQ_VIEW = 1002;

	// for top bar
	@ViewInject(R.id.topbar_left_btn)
	protected TextView vTopLeft;
	@ViewInject(R.id.topbar_center_btn)
	protected TextView vTopCenter;
	@ViewInject(R.id.topbar_right_btn)
	protected TextView vTopRight;

	@ViewInject(R.id.empty)
	private TextView vEmpty;

	@ViewInject(R.id.publish_view_pull_view)
	private AbPullToRefreshView vPullView;

	@ViewInject(R.id.publish_view_list)
	private ListView vList;

	@ResInject(id = R.drawable.progress_circular, type = ResType.Drawable)
	private Drawable rPullDrawable;
	@ResInject(id = R.string.publish_view_topbar_title, type = ResType.String)
	private String rTitle;

	@OnClick(value = { R.id.topbar_right_btn })      //  添加车位
	public void topRightAddPublish(View v) {
		Intent intent = new Intent(this, NewPublishActivity.class);
		startActivityForResult(intent, REQ_ADD);
	}

	/**
	 * 发布列表点击时执行事件
	 * */
	@OnItemClick(value = { R.id.publish_view_list })
	public void clickPublishList(AdapterView<?> parent, View view,
			int position, long id) {
		// TODO Auto-generated method stub
		PublishListForm model = (PublishListForm) mAdapter.getItem(position);
		Intent intent = new Intent(this, ViewPublishInfoActivity.class);
		intent.putExtra(ParkingConstant.INTENT_EXTRA_PUBLISH_DB_ID,
				model.getId());
		startActivityForResult(intent, REQ_VIEW);
	}

	/**
	 * 下拉刷新时执行的方法 
	 * */
	@Override
	public void onHeaderRefresh(AbPullToRefreshView view) {
		// TODO Auto-generated method stub
		refreshModelFromServer();
	}

	private PullListAdapter<PublishListForm> mAdapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_publish_list);
		mServer = ParkingApp.mAppCtx.getServerConfig();
		initViews();
		refreshModelFromLocal();
		if(ParkingApp.mAppCtx.isAutoLogin()){
			refreshModelFromServer();
		}
	}

	private void initViews() {
		// handler topbar views
		if (ParkingApp.mAppCtx.getUType() == ParkingConstant.ROLE_YEZHU && ParkingApp.mAppCtx.getAppTypeCode() != 4) {
			vTopRight.setText("添 加  ");
			vTopRight.setVisibility(View.VISIBLE);
		} else {
			vTopRight.setVisibility(View.GONE);
		}
		vTopCenter.setText(rTitle);
		if(ParkingApp.mAppCtx.getAppTypeCode() == 4) {
			vTopCenter.setText("发布/审核");
		}
		// handler my views
		vPullView.setOnHeaderRefreshListener(this);
		vPullView.getHeaderView().setHeaderProgressBarDrawable(rPullDrawable);
		vPullView.setPullRefreshEnable(true);
		vPullView.setLoadMoreEnable(false);
		mAdapter = new PublishListAdapter(this);
		vList.setAdapter(mAdapter);
		vList.setEmptyView(vEmpty);
		vEmpty.setMovementMethod(ScrollingMovementMethod.getInstance());// 让empty
																		// view可以接受滑动事件
	}

	private void refreshModelFromLocal() {
		try {
			List<PublishListForm> models = mDB.findAll(PublishListForm.class);
			if (models == null) {
				return;
			}
			refreshListView(models);
		} catch (DbException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 上个activity返回值时在这里处理
	 * */
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		Log.i("qh", "on activity result : " + requestCode + " resultCode : "
				+ resultCode);
		if (requestCode == REQ_ADD) {
			handleReqAdd(resultCode, data);
		} else if (requestCode == REQ_VIEW) {
			handleReqView(resultCode, data);
		}
	}

	private void handleReqAdd(int resultCode, Intent data) {
		if (Activity.RESULT_OK == resultCode) {
			refreshModelFromServer();
		}
	}

	private void handleReqView(int resultCode, Intent data) {
		if (Activity.RESULT_OK == resultCode) {
			refreshModelFromServer();
		}
	}

	/**
	 * 请求服务器，刷新数据
	 * */
	private void refreshModelFromServer() {
		getJsonFromServer(mServer.getURL(IServer.URL_FLAG_GET_PUBLISH_VIEW));
	}

	private void refreshListView(List<PublishListForm> models) {
		mAdapter.setNewData(models);
	}

	@Override
	protected void callbackFromGetJsonFail(int failcode, String msg) {
		// TODO Auto-generated method stub
		vPullView.onHeaderRefreshFinish();
		if (failcode == 0) {
			showToastTips("加载失败:无法连接服务器");
		} else {
			showToastTips("加载失败[" + failcode + "]: " + msg);
		}
	}

	@Override
	protected void callbackFromGetJsonSuccess(String json) {
		// TODO Auto-generated method stub
		Log.i("qh", "json : " + json);
		vPullView.onHeaderRefreshFinish();
		String jsonlist = null;
		try {
			JSONObject jobj = new JSONObject(json);
			JSONArray jarr = jobj.getJSONArray("data");
			jsonlist = jarr.toString();
		} catch (JSONException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		if (jsonlist == null) {
			Log.i("qh", "no data or fail...");
			return;
		}
		Gson gson = new Gson();
		TypeToken<List<PublishListForm>> token = new TypeToken<List<PublishListForm>>() {
		};
		List<PublishListForm> models = gson.fromJson(jsonlist, token.getType());
		try {
			mDB.deleteAll(PublishListForm.class);
			mDB.saveAll(models);
			refreshModelFromLocal();
		} catch (DbException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private long exitTime = 0;
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
//		Log.i("TEST", "appActivity onKeyDown ");
//		if(keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN){   
//	        if((System.currentTimeMillis()-exitTime) > 2000){  
//	            Toast.makeText(getApplicationContext(), "再按一次返回键退出程序", Toast.LENGTH_SHORT).show();                                
//	            exitTime = System.currentTimeMillis();   
//	        } else {
//	            finish();
//	            System.exit(0);
//	        }
//	        return true;   
//	    }
		return super.onKeyDown(keyCode, event);
	}

	@Override
	protected void onRestart() {
		// TODO Auto-generated method stub
		super.onRestart();
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		if(ParkingApp.mAppCtx.isAutoLogin()){
			refreshModelFromServer();
		}
		super.onResume();
	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		if((System.currentTimeMillis()-exitTime) > 2000){  
            Toast.makeText(getApplicationContext(), "再按一次返回键退出程序", Toast.LENGTH_SHORT).show();                                
            exitTime = System.currentTimeMillis();   
        } else {
            finish();
            System.exit(0);
        }
	}
	
	
}
