package com.sendi.lhparking.ui.yezhu;

import org.json.JSONException;
import org.json.JSONObject;
import org.sendi.parking.ui.R;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnDismissListener;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.payutil.Result;
import com.sendi.lhparking.ui.chezhu.TransferAccountActivity;
import com.sendi.lhparking.ui.common.AccountActivity;
import com.sendi.lhparking.ui.common.AccountDetailActivity;
import com.sendi.lhparking.ui.common.BaseActivity;
import com.sendi.lhparking.ui.common.LoginActivity;
import com.sendi.lhparking.util.AccountBaseInfo;

public class YezhuMainActivity extends BaseActivity {

	private AccountBaseInfo bInfo;
	private TextView tvBalance, tvDayIncome, tvWeekIncome, tvWeekOutcome, tvTotalIncome, tvTotalOutcome;
	private TextView tvRank;
	private LinearLayout llayout;
	private ProgressDialog mDialog;
	private String curShowView = "0";
	private int dialogDismiss = 0;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_yezhumain);
		
		ParkingApp.mAppCtx.setPayHandler(mHandler);
		
		init();
		
		if(ParkingApp.mAppCtx.isAutoLogin()){
			boolean bo = isNetConnected();
			if(bo) {
				switch(ParkingApp.mAppCtx.getAppTypeCode()) {
				case 1:
					getCountInfo();
					break;
				case 4:
//					getCount();
					getCountInfo();
					break;
				}
			}else {
				Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
			}
		}
	}
	
	private void init() {	
		tvBalance = (TextView) this.findViewById(R.id.tvBalance);
		tvDayIncome = (TextView) this.findViewById(R.id.tvDayIncome);
		tvWeekIncome = (TextView) this.findViewById(R.id.tvWeekIncome);
		tvWeekOutcome = (TextView) this.findViewById(R.id.tvWeekOutcome);
		tvTotalIncome = (TextView) this.findViewById(R.id.tvTotalIncome);
		tvTotalOutcome = (TextView) this.findViewById(R.id.tvTotalOutcome);
		tvRank = (TextView) this.findViewById(R.id.tv_rank);
		llayout = (LinearLayout) this.findViewById(R.id.llayout5);
	}
	
	/** 
	 * 服务器查询账本基本信息
	 * */
	private void getCountInfo() {
		curShowView = "CountInfo";
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("method", "2014");
		HttpUtils http = new HttpUtils(6000);
		showProgDialog("正在进行账本查询 . . .", http);
		http.send(HttpMethod.POST, 
				ServerURL,
				params,
				new RequestCallBack< String >() {

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// TODO Auto-generated method stub
//						{balance,total_income,day_income,week_income,week_outcome,total_outcome} 
//						分别代表 金额 ，总收益，昨日收益，一周收益，一周支出，总支出
						Log.i(TAG, "getCountInfo result : "+responseInfo.result);
						if(curShowView.equals("CountInfo")) {
							try {
								JSONObject jsob = new JSONObject(responseInfo.result);
								bInfo = new AccountBaseInfo();
								bInfo.setBalance(jsob.getString("balance"));
								bInfo.setTotalIncome(jsob.getString("total_income"));
								bInfo.setDayIncome(jsob.getString("day_income"));
								if(jsob.getString("day_income").equals("0.0")) {
									bInfo.setDayIncome("暂无收益");
								}
								bInfo.setWeekIncome(jsob.getString("week_income"));
								bInfo.setWeekOutcome(jsob.getString("week_outcome"));
								bInfo.setTotalOutcome(jsob.getString("total_outcome"));
								bInfo.setRanking(jsob.getString("ranking"));
								
								tvBalance.setText(bInfo.getBalance());
								tvDayIncome.setText(bInfo.getDayIncome());
								tvWeekIncome.setText(bInfo.getWeekIncome());
								tvWeekOutcome.setText(bInfo.getWeekOutcome());
								tvTotalIncome.setText(bInfo.getTotalIncome());
								tvTotalOutcome.setText(bInfo.getTotalOutcome());
								tvRank.setText(bInfo.getRanking());
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								Toast.makeText(getApplicationContext(), "获取数据错误", Toast.LENGTH_SHORT).show();
								e.printStackTrace();
							}
							
							if(ParkingApp.mAppCtx.getUType() == 1) {
								llayout.setVisibility(View.GONE);
							}else {
								llayout.setVisibility(View.VISIBLE);
							}
							if(mDialog != null) {
								dialogDismiss = 1;
								mDialog.dismiss();
							}
						}
						
						
					}

					@Override
					public void onFailure(HttpException error, String msg) {
						// TODO Auto-generated method stub
						if(curShowView.equals("CountInfo")) {
							showTipsDialog("查询失败，请检查网络连接，稍后再试 ", YezhuMainActivity.this);
						}
						if(mDialog != null) {
							dialogDismiss = 1;
							mDialog.dismiss();
						}
					}
				});
		
	}
	
	public void onPay(View v) {
		Intent intent = new Intent(YezhuMainActivity.this, com.sendi.lhparking.ui.chezhu.PayActivity.class);
		startActivity(intent);
	}
	
	public void onCheckCountDetail(View v) {
		Intent intent = new Intent(YezhuMainActivity.this, AccountDetailActivity.class);
		startActivity(intent);
	}
	
	
	Handler mHandler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			String s[] = String.valueOf(msg.obj).split("\\,");
			Result result = new Result(s[0]);

			switch (msg.what) {
			case 1:
				String rs = result.getResultStatus();
				Log.i("TEST", "payresult: "+ rs + "  " + msg.obj);
				if(rs.equals("9000")) {
//					showTipsDialog("支付成功 ！ ", AccountActivity.this);
		            Toast.makeText(getApplicationContext(), "支付成功 ！", Toast.LENGTH_SHORT).show(); 

				}else {
//					showTipsDialog("支付失败 : "+result.getResult(), AccountActivity.this);
					Toast.makeText(getApplicationContext(), "支付失败 : "+result.getResult(), Toast.LENGTH_SHORT).show();
				}
				break;
			case 2:
				int flag = (Integer) msg.obj;
				if( flag == 0) {
					Toast.makeText(getApplicationContext(), "支付成功 ！", Toast.LENGTH_SHORT).show();
				}else {
//					showTipsDialog("支付失败,errCode: "+flag, AccountActivity.this);
					Toast.makeText(getApplicationContext(), "支付失败 : "+flag, Toast.LENGTH_SHORT).show();
				}
				break;
			}
			init();
			boolean bo = isNetConnected();
			if(bo) {
				getCountInfo();
			}else {
				Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
			}
		};
	};

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		if(requestCode == LoginActivity.REQUEST_LOGIN){
			if(resultCode == LoginActivity.RESULT_CODE_LOGIN_SUCCESS){
				boolean bo = isNetConnected();
				if(bo) {
					getCountInfo();
				}else {
					Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
				}
			}
		}
	}
	
	private void showProgDialog(final String msg, final HttpUtils httpUtils) {
		mDialog = new ProgressDialog(this);
		mDialog.setCanceledOnTouchOutside(false);
		mDialog.setOnDismissListener(new OnDismissListener() {
			
			@Override
			public void onDismiss(DialogInterface dialog) {
				// TODO Auto-generated method stub
				if(dialogDismiss == 0 ) {
					httpUtils.getHttpClient().getConnectionManager().closeExpiredConnections();
//					httpUtils.getHttpClient().getConnectionManager().shutdown();
				}
				dialogDismiss = 0;
				curShowView = "0";
				Log.i(TAG, "dialog dismiss : "+msg);
			}
		});
		mDialog.setMessage(msg);
		mDialog.show();
	}
	
	public void onCheckIncome(View v) {
		Intent intent = new Intent(YezhuMainActivity.this, AccountDetailActivity.class);
		intent.putExtra("showview", 1);
		startActivity(intent);
	}
	
	public void onCheckOutcome(View v) {
		Intent intent = new Intent(YezhuMainActivity.this, AccountDetailActivity.class);
		intent.putExtra("showview", 2);
		startActivity(intent);
	}
	
	public void onTransfer(View v) {
		boolean bo = isNetConnected();
		if(bo) {
			if(bInfo == null) {
				Toast.makeText(getApplicationContext(), "无法查询账户余额，请点击 余额 刷新后再试", Toast.LENGTH_SHORT).show();
				return;
			}
			if(Double.valueOf(bInfo.getBalance()) < 0) {
				Toast.makeText(getApplicationContext(), "账户余额错误，请点击 余额 刷新后再试", Toast.LENGTH_SHORT).show();
				return;
			}
			Intent intent = new Intent(YezhuMainActivity.this, TransferAccountActivity.class);
			intent.putExtra("maxMoney", bInfo.getBalance());
			startActivity(intent);
		}else {
			Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
		}
		
	}
	
	public void onCheckCount(View v) {
		boolean bo = isNetConnected();
		if(bo) {
			getCountInfo();
		}else {
			Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
		}
	}
	
	private void getCount() {
		curShowView = "getCount";
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("method", "2001");
		HttpUtils http = new HttpUtils(6000);
		showProgDialog("正在进行账本查询 . . .", http);
		http.send(HttpMethod.POST, 
				ServerURL,
				params,
				new RequestCallBack< String >() {

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// TODO Auto-generated method stub
//						{balance,total_income,day_income,week_income,week_outcome,total_outcome} 
//						分别代表 金额 ，总收益，昨日收益，一周收益，一周支出，总支出
						Log.i(TAG, "getCount result : "+responseInfo.result);
//						if(curShowView.equals("CountInfo")) {
//							try {
//								JSONObject jsob = new JSONObject(responseInfo.result);
//								bInfo = new AccountBaseInfo();
//								bInfo.setBalance(jsob.getString("balance"));
//								bInfo.setTotalIncome(jsob.getString("total_income"));
//								bInfo.setDayIncome(jsob.getString("day_income"));
//								if(jsob.getString("day_income").equals("0.0")) {
//									bInfo.setDayIncome("暂无收益");
//								}
//								bInfo.setWeekIncome(jsob.getString("week_income"));
//								bInfo.setWeekOutcome(jsob.getString("week_outcome"));
//								bInfo.setTotalOutcome(jsob.getString("total_outcome"));
//								bInfo.setRanking(jsob.getString("ranking"));
//								
//								tvBalance.setText(bInfo.getBalance());
//								tvDayIncome.setText(bInfo.getDayIncome());
//								tvWeekIncome.setText(bInfo.getWeekIncome());
//								tvWeekOutcome.setText(bInfo.getWeekOutcome());
//								tvTotalIncome.setText(bInfo.getTotalIncome());
//								tvTotalOutcome.setText(bInfo.getTotalOutcome());
//								tvRank.setText(bInfo.getRanking());
//							} catch (JSONException e) {
//								// TODO Auto-generated catch block
//								Toast.makeText(getApplicationContext(), "获取数据错误", Toast.LENGTH_SHORT).show();
//								e.printStackTrace();
//							}
//							
//							
//							if(ParkingApp.mAppCtx.getUType() == 1) {
//								llayout.setVisibility(View.GONE);
//							}else {
//								llayout.setVisibility(View.VISIBLE);
//							}
//							if(mDialog != null) {
//								dialogDismiss = 1;
//								mDialog.dismiss();
//							}
//						}
						if(mDialog != null) {
							dialogDismiss = 1;
							mDialog.dismiss();
						}						
					}

					@Override
					public void onFailure(HttpException error, String msg) {
						// TODO Auto-generated method stub
						if(curShowView.equals("getCount")) {
							showTipsDialog("查询失败，请检查网络连接，稍后再试 ", YezhuMainActivity.this);
						}
						if(mDialog != null) {
							dialogDismiss = 1;
							mDialog.dismiss();
						}
					}
				});
		
	
	}
}
