package com.sendi.lhparking.ui.yezhu;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.sendi.parking.ui.R;
import org.sendi.parking.ui.R.id;
import org.sendi.parking.ui.R.layout;

import com.ab.view.wheel.AbWheelView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.lidroid.xutils.view.annotation.ViewInject;
import com.lidroid.xutils.view.annotation.event.OnClick;
import com.sendi.lhparking.adapter.AbListObjectWheelAdapter;
import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.model.City;
import com.sendi.lhparking.model.District;
import com.sendi.lhparking.model.Quarter;
import com.sendi.lhparking.server.IServer;
import com.sendi.lhparking.ui.common.base.BaseActivityWithDialog;
import com.sendi.lhparking.ui.wuye.AddParkingHistoryActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

/**
 * 选择小区页面
 * @author Administrator
 *
 */
public class SelectQuarterActivity extends BaseActivityWithDialog{
	
	public static final String KEY_RESULT = "quarter_result";
	
	//for top bar
	@ViewInject(R.id.topbar_left_btn)
	protected TextView vTopLeft;
	@ViewInject(R.id.topbar_center_btn)
	protected TextView vTopCenter;
	@ViewInject(R.id.topbar_right_btn)
	protected TextView vTopRight;
	
	//my views
	@ViewInject(R.id.select_city_tv)
	private TextView vCityChooser;
	@ViewInject(R.id.select_district_tv)
	private TextView vDistrictChooser;
	@ViewInject(R.id.select_quarter_tv)
	private TextView vQuarterChooser;
	@ViewInject(R.id.btnaddparking)
	private Button btnAddparking;
	
	private State mState;
	
	private List<City> mCityList;
	private List<District> mDistrictList;
	private List<Quarter> mQuarterList;
	
	private City chooseCity;
	private District chooseDistrict;
	private Quarter chooseQuarter;
	
	enum State{
		NONE,
		CHOOSE_CITY,
		CHOOSE_DISTRICT,
		CHOOSE_QUARTER
	}
	
	@OnClick(value={R.id.btnaddparking})  // 小区加盟
	public void addParking(View v) {
		Intent intent = new Intent(SelectQuarterActivity.this, AddParkingHistoryActivity.class);
		startActivity(intent);
		finish();
	}
	
	@OnClick(value={R.id.topbar_left_btn})
	public void topLeftBack(View v) {
//		finish();
		if(tipsUserOption()){
			return;
		}
		Intent intent = new Intent();
		intent.putExtra(KEY_RESULT, chooseQuarter);
		setResult(RESULT_OK, intent);
		finish();
	}
	
	@OnClick(value={R.id.topbar_right_btn})
	public void topRightDone(View v) {
		if(tipsUserOption()){
			return;
		}
		Intent intent = new Intent();
		intent.putExtra(KEY_RESULT, chooseQuarter);
		setResult(RESULT_OK, intent);
		finish();
	}
	
	@OnClick(value={R.id.select_city_tv})
	public void chooseCity(View v){
		mState = State.CHOOSE_CITY;
		if(mCityList == null){
			requestCityList();
			return;
		}
		showChooserDialog();
	}
	@OnClick(value={R.id.select_district_tv})
	public void chooseDistrict(View v){
		if(chooseCity == null){
			tipsUserOption();
			return;
		}
		mState = State.CHOOSE_DISTRICT;
		if(mDistrictList == null){
			requestDistrictList();
			return;
		}
		showChooserDialog();
	}
	@OnClick(value={R.id.select_quarter_tv})
	public void chooseQuarter(View v){
		if(chooseDistrict == null){
			tipsUserOption();
			return;
		}
		mState = State.CHOOSE_QUARTER;
		if(mQuarterList == null){
			requestQuarterList();
			return;
		}
		showChooserDialog();
	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_select_quarter);
		mServer = ParkingApp.mAppCtx.getServerConfig();
		initViews();
		mState = State.NONE;
	}
	
	private void initViews(){
		vTopLeft.setText("  确 定");
		vTopCenter.setText("选择小区");
		vTopRight.setText("完 成  ");
		vTopLeft.setVisibility(View.VISIBLE);
		vTopRight.setVisibility(View.GONE);
	}

	private void requestCityList(){
		requestListFromServer(mServer.getURL(IServer.URL_FLAG_GET_CITIES));
	}
	
	private void requestDistrictList(){
		requestListFromServer(mServer.getURL(IServer.URL_FLAG_GET_DISTRICT, chooseCity.getCity_code()));
	}
	
	private void requestQuarterList(){
		requestListFromServer(mServer.getURL(IServer.URL_FLAG_GET_QUARTER, chooseCity.getCity_code(), chooseDistrict.getEn_district()));
	}
	
	private void requestListFromServer(String url){
		showProgressDialog("加载城市列表...");
		getJsonFromServer(url);
	}
	
	@SuppressWarnings("deprecation")
	@Override
	protected void callbackFromGetJsonFail(int failcode, String msg) {
		// TODO Auto-generated method stub
		dismissDialog(DIALOG_PROGRESS);
		showToastTips("加载列表失败:"+msg);
	}
	
	@SuppressWarnings("deprecation")
	@Override
	protected void callbackFromGetJsonSuccess(String json) {
		// TODO Auto-generated method stub
		dismissDialog(DIALOG_PROGRESS);
		Log.i("qh", "json : "+json);
		String jsonlist = null;
		try {
			JSONObject jobj = new JSONObject(json);
			JSONArray jarr = jobj.getJSONArray("data");
			jsonlist = jarr.toString();
		} catch (JSONException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		if(jsonlist == null){
			Log.i("qh", "no data or fail...");
			showToastTips("无列表");
			return;
		}
		switch (mState) {
		case CHOOSE_CITY:
			getCityList(jsonlist);
			break;
		case CHOOSE_DISTRICT:
			getDistrictList(jsonlist);
			break;
		case CHOOSE_QUARTER:
			getQuarterList(jsonlist);
			break;
		default:
			return;
		}
		showChooserDialog();
	}
	
	private void getCityList(String json){
		Gson gson = new Gson();
		TypeToken<List<City>> token = new TypeToken<List<City>>(){};
		mCityList = gson.fromJson(json, token.getType());
	}
	
	private void getDistrictList(String json){
		Gson gson = new Gson();
		TypeToken<List<District>> token = new TypeToken<List<District>>(){};
		mDistrictList = gson.fromJson(json, token.getType());
	}
	
	private void getQuarterList(String json){
		Gson gson = new Gson();
		TypeToken<List<Quarter>> token = new TypeToken<List<Quarter>>(){};
		mQuarterList = gson.fromJson(json, token.getType());
	}
	
	private View vWheelPanel;
	private AbWheelView vWheelChooser;
	private Button vWheelCancel;
	private Button vWheelOk;
	
	private void showChooserDialog(){
		if(vWheelPanel == null){
			vWheelPanel = LayoutInflater.from(this).inflate(R.layout.layout_wheel_chooser_one, null);
			vWheelChooser = (AbWheelView) vWheelPanel.findViewById(R.id.wheel_panel_wheel);
			vWheelOk = (Button) vWheelPanel.findViewById(R.id.wheel_panel_okBtn);
			vWheelCancel = (Button) vWheelPanel.findViewById(R.id.wheel_panel_cancelBtn);
			
			vWheelCancel.setOnClickListener(new OnClickListener() {
				
				@SuppressWarnings("deprecation")
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					dismissDialog(DIALOG_BOTTOM);
				}
			});
			
			vWheelOk.setOnClickListener(new OnClickListener() {
				
				@SuppressWarnings("deprecation")
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					int curindex = vWheelChooser.getCurrentItem();
					chooseResult(curindex);
					dismissDialog(DIALOG_BOTTOM);
				}
			});
			
			vWheelChooser.setCyclic(false);
			vWheelChooser.setCurrentItem(0);
			vWheelChooser.setValueTextSize(32);
			vWheelChooser.setLabelTextSize(30);
			vWheelChooser.setLabelTextColor(0x80000000);
		}
		setWheel();
		showDialog(DIALOG_BOTTOM, vWheelPanel);
	}
	
	private void setWheel(){
		AbListObjectWheelAdapter adapter = null;
		switch (mState) {
		case CHOOSE_CITY:
			adapter = new AbListObjectWheelAdapter<City>(mCityList);
			break;
		case CHOOSE_DISTRICT:
			adapter = new AbListObjectWheelAdapter<District>(mDistrictList);
			break;
		case CHOOSE_QUARTER:
			adapter = new AbListObjectWheelAdapter<Quarter>(mQuarterList);
			break;
		default:
			break;
		}
		vWheelChooser.setAdapter(adapter);
	}
	
	private void chooseResult(int curindex){
		switch (mState) {
		case CHOOSE_CITY:
			chooseCityResult(curindex);
			break;
		case CHOOSE_DISTRICT:
			chooseDistrictResult(curindex);
			break;
		case CHOOSE_QUARTER:
			chooseQuarterResult(curindex);
			break;
		default:
			break;
		}
	}
	
	private void chooseCityResult(int index){
		if(mCityList == null || mCityList.size() == 0){
			return;
		}
		if(index < 0 || index >= mCityList.size()){
			return;
		}
		City city = mCityList.get(index);
		if(city.equals(chooseCity)){
			return;
		}
		clearDistrict();
		clearQuarter();
		chooseCity = city;
		vCityChooser.setText(chooseCity.getCity_name());
	}
	
	private void chooseDistrictResult(int index){
		Log.i("qh", "result choose district : "+index);
		if(mDistrictList == null || mDistrictList.size() == 0){
			return;
		}
		if(index < 0 || index >= mDistrictList.size()){
			return;
		}
		District dis = mDistrictList.get(index);
		Log.i("qh", "choose district : "+ dis.getDistrict()+" en : "+dis.getEn_district());
		if(dis.equals(chooseDistrict)){
			return;
		}
		clearQuarter();
		chooseDistrict = dis;
		vDistrictChooser.setText(chooseDistrict.getDistrict());
	}
	
	private void chooseQuarterResult(int index){
		if(mQuarterList == null || mQuarterList.size() == 0){
			return;
		}
		if(index < 0 || index >= mQuarterList.size()){
			return;
		}
		Quarter dis = mQuarterList.get(index);
		if(dis.equals(chooseQuarter)){
			return;
		}
		chooseQuarter = dis;
		vQuarterChooser.setText(chooseQuarter.getName());
	}
	
	private void clearDistrict(){
		chooseDistrict = null;
		if(mDistrictList != null){
			mDistrictList.clear();
			mDistrictList = null;
		}
		vDistrictChooser.setText("");
	}
	
	private void clearQuarter(){
		chooseQuarter = null;
		if(mQuarterList != null){
			mQuarterList.clear();
			mQuarterList = null;
		}
		vQuarterChooser.setText("");
	}
	
	private boolean tipsUserOption(){
		if(chooseCity == null){
			showToastTips("请先选择城市");
			return true;
		}
		if(chooseDistrict == null){
			showToastTips("请先选择区县");
			return true;
		}
		if(chooseQuarter == null){
			showToastTips("请选择小区");
			return true;
		}
		return false;
	}
}
