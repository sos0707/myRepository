package com.sendi.lhparking.ui.common;

import java.util.ArrayList;

import org.sendi.parking.ui.R;

import com.sendi.lhparking.adapter.SplashViewAdapter;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;

public class SplashActivity extends BaseActivity {

	private ViewPager viewPager;
	private SplashViewAdapter adapter;
	private ImageView page0;
	private ImageView page1;
	private ImageView page2;
//	private ImageView page3;
	private Button btnEnter;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_splash);
		
		initView();
	}
	
	private void initView() {
		viewPager = (ViewPager) this.findViewById(R.id.viewPager_splash);
		viewPager.setOnPageChangeListener(new MyOnPageChangeListener());
		
		page0 = (ImageView) this.findViewById(R.id.page0);
		page1 = (ImageView) this.findViewById(R.id.page1);
		page2 = (ImageView) this.findViewById(R.id.page2);
//		page3 = (ImageView) this.findViewById(R.id.page3);
		
		LayoutInflater mLin = LayoutInflater.from(this);
		View view0 = mLin.inflate(R.layout.view_page0, null);
		View view1 = mLin.inflate(R.layout.view_page1, null);
		View view2 = mLin.inflate(R.layout.view_page2, null);
//		View view3 = mLin.inflate(R.layout.view_page3, null);
		
		btnEnter = (Button) view2.findViewById(R.id.btn_enter);
		btnEnter.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent();
				intent.setClass(SplashActivity.this, AppActivity.class);
				startActivity(intent);
				SplashActivity.this.finish();
			}
		});
		
		ArrayList<View> views = new ArrayList<View>();
		views.add(view0);
		views.add(view1);
		views.add(view2);
//		views.add(view3);
		
		adapter = new SplashViewAdapter(views);
		viewPager.setAdapter(adapter);
	}
	
	public class MyOnPageChangeListener implements OnPageChangeListener {

		@Override
		public void onPageScrollStateChanged(int arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onPageScrolled(int arg0, float arg1, int arg2) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onPageSelected(int page) {
			// TODO Auto-generated method stub
			switch(page) {
			case 0:
				page0.setImageDrawable(getResources().getDrawable(R.drawable.page_now));
				page1.setImageDrawable(getResources().getDrawable(R.drawable.page));
				break;
			case 1:
				page1.setImageDrawable(getResources().getDrawable(R.drawable.page_now));
				page0.setImageDrawable(getResources().getDrawable(R.drawable.page));
				page2.setImageDrawable(getResources().getDrawable(R.drawable.page));
				break;
			case 2:
				page2.setImageDrawable(getResources().getDrawable(R.drawable.page_now));
				page1.setImageDrawable(getResources().getDrawable(R.drawable.page));
//				page3.setImageDrawable(getResources().getDrawable(R.drawable.page));
				break;
//			case 3:
//				page3.setImageDrawable(getResources().getDrawable(R.drawable.page_now));
//				page2.setImageDrawable(getResources().getDrawable(R.drawable.page));
//				break;
			}
		}
	}
	
}
