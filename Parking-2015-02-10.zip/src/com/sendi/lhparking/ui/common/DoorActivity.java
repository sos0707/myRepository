package com.sendi.lhparking.ui.common;

import org.sendi.parking.ui.R;

import com.sendi.lhparking.ctx.ParkingApp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class DoorActivity extends BaseActivity {

	private Button btnChezhu, btnYezhu, btnBaoan, btnWuye, btnLast;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_door);
		initView();
	}
	
	private void initView() {
		btnChezhu = (Button) this.findViewById(R.id.btn_chezhu);
		btnYezhu = (Button) this.findViewById(R.id.btn_yezhu);
		btnBaoan = (Button) this.findViewById(R.id.btn_baoan);
		btnWuye = (Button) this.findViewById(R.id.btn_wuye);
		btnLast = (Button) this.findViewById(R.id.btn_last);
		
		btnChezhu.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				ParkingApp.mAppCtx.setAppTypeCod(2);
				Intent intent = new Intent(DoorActivity.this, AppActivity.class);
				startActivity(intent);
			}
		});
		
		btnYezhu.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				ParkingApp.mAppCtx.setAppTypeCod(1);
				Intent intent = new Intent(DoorActivity.this, AppActivity.class);
				startActivity(intent);
			}
		});
		
		btnBaoan.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				ParkingApp.mAppCtx.setAppTypeCod(3);
				Intent intent = new Intent(DoorActivity.this, AppActivity.class);
				startActivity(intent);
			}
		});
		
		btnWuye.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				ParkingApp.mAppCtx.setAppTypeCod(4);
				Intent intent = new Intent(DoorActivity.this, AppActivity.class);
				startActivity(intent);
			}
		});
		
		btnLast.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				ParkingApp.mAppCtx.setAppTypeCod(0);
				Intent intent = new Intent(DoorActivity.this, AppActivity.class);
				startActivity(intent);
			}
		});
	}
	
}
