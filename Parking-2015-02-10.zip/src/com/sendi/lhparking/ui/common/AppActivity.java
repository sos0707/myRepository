package com.sendi.lhparking.ui.common;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.sendi.parking.ui.R;
import org.sendi.parking.ui.R.drawable;
import org.sendi.parking.ui.R.id;
import org.sendi.parking.ui.R.layout;


import com.ab.util.AbStrUtil;
import com.ab.view.sliding.BottomTabView;
import com.ab.view.sliding.BottomTabView.OnSelectListener;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.server.IServer;
import com.sendi.lhparking.ui.baoan.BaoanMainActivity;
import com.sendi.lhparking.ui.chezhu.MapLocationActivity;
import com.sendi.lhparking.ui.yezhu.PublishListActivity;
import com.sendi.lhparking.ui.yezhu.YezhuMainActivity;
import com.sendi.lhparking.update.DownService;
import com.sendi.lhparking.util.ParkingPrefs;
import com.sendi.lhparking.util.SysUtils;

import android.app.Activity;
import android.app.ActivityGroup;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.LocalActivityManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.FrameLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.Toast;

/**
 * 主界面
 * 
 * @author Administrator
 * 
 */
@SuppressWarnings("deprecation")
public class AppActivity extends ActivityGroup {

	private BottomTabView vTabs;
	private FrameLayout vContent;

	private List<Class<? extends Activity>> mActivityCls;
	private List<String> mTabTexts;
	private List<Drawable> mTabIcons;

	private int mDefaultActivityIndex;
	private int mCurActivityIndex = -1;

	private LocalActivityManager mLocal;

	private int mAppTypeCode = 0;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		ParkingApp.mAppCtx.setHasMainActivity(this);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_app);
		ParkingApp.mAppCtx.setAppHandler(appHandler);
		ParkingPrefs.setBoolValue("is_first_login", false);  // 是否显示splash页面
		mAppTypeCode = ParkingApp.mAppCtx.getAppTypeCode();   // app客户端版本  1=业主    2=车主    3=保安     4=物业    0=原版
		mLocal = getLocalActivityManager();
		
//		ParkingPrefs.setStrValue("langhua_utype", "0");
//		ParkingPrefs.setStrValue("langhua_uid", "427756511429");
//		ParkingPrefs.setBoolValue(LoginActivity.AUTO_LOGIN, true);
		
		mLocal.dispatchCreate(savedInstanceState);
		switch(mAppTypeCode) {
		case 3:
			Intent intent = new Intent(AppActivity.this, BaoanMainActivity.class);
			startActivity(intent);
			AppActivity.this.finish();
			break;
		default:
			initData();
			initViews();
			break;
		}
		checkVersion();
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		Log.i("qh", "resume ...");
		mLocal.dispatchResume();
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		Log.i("qh", "pause ...");
		mLocal.dispatchPause(isFinishing());
	}

	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		Log.i("qh", "stop ...");
		mLocal.dispatchStop();
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		mLocal.dispatchDestroy(isFinishing());
		ParkingApp.mAppCtx.setHasMainActivity(null);
	}

	private void initData() {
		mActivityCls = new ArrayList<Class<? extends Activity>>();
		mTabTexts = new ArrayList<String>();
		mTabIcons = new ArrayList<Drawable>();

		switch(mAppTypeCode) {
		case 0:
			// cls
			mActivityCls.add(MapLocationActivity.class);
			mActivityCls.add(PublishListActivity.class);
			mActivityCls.add(OrderListActivity.class);
			mActivityCls.add(AccountActivity.class);
			mActivityCls.add(SettingActivity.class);
			// texts
			mTabTexts.add("主页");
			mTabTexts.add("发布");
			mTabTexts.add("订单");
			mTabTexts.add("账本");
			mTabTexts.add("设置");
			// icons
			mTabIcons.add(getTabDrawableById(R.drawable.door_tab_sms_tv_selector));
			mTabIcons.add(getTabDrawableById(R.drawable.door_tab_contact_tv_selector));
			mTabIcons.add(getTabDrawableById(R.drawable.door_tab_dial_tv_selector));
			mTabIcons.add(getTabDrawableById(R.drawable.door_tab_account_selector));
			mTabIcons.add(getTabDrawableById(R.drawable.door_tab_setting_selector));
			break;
		case 2:
			mActivityCls.add(MapLocationActivity.class);
			mActivityCls.add(AccountDetailActivity.class);
			mActivityCls.add(SettingActivity.class);
			mTabTexts.add("停车");
			mTabTexts.add("账本");
			mTabTexts.add("设置");
			mTabIcons.add(getTabDrawableById(R.drawable.door_tab_sms_tv_selector));
			mTabIcons.add(getTabDrawableById(R.drawable.door_tab_account_selector));
			mTabIcons.add(getTabDrawableById(R.drawable.door_tab_setting_selector));
			break;
		case 1:
			mActivityCls.add(YezhuMainActivity.class);
			mActivityCls.add(PublishListActivity.class);
			mActivityCls.add(AccountDetailActivity.class);
			mActivityCls.add(SettingActivity.class);
			mTabTexts.add("主页");
			mTabTexts.add("发布");
			mTabTexts.add("账本");
			mTabTexts.add("设置");
			mTabIcons.add(getTabDrawableById(R.drawable.door_tab_sms_tv_selector));
			mTabIcons.add(getTabDrawableById(R.drawable.door_tab_contact_tv_selector));
			mTabIcons.add(getTabDrawableById(R.drawable.door_tab_account_selector));
			mTabIcons.add(getTabDrawableById(R.drawable.door_tab_setting_selector));
			break;
		case 3:
			break;
		case 4:
			mActivityCls.add(YezhuMainActivity.class);
			mActivityCls.add(PublishListActivity.class);
			mActivityCls.add(AccountDetailActivity.class);
			mActivityCls.add(SettingActivity.class);
			mTabTexts.add("主页");
			mTabTexts.add("发布");
			mTabTexts.add("账本");
			mTabTexts.add("设置");
			mTabIcons.add(getTabDrawableById(R.drawable.door_tab_sms_tv_selector));
			mTabIcons.add(getTabDrawableById(R.drawable.door_tab_contact_tv_selector));
			mTabIcons.add(getTabDrawableById(R.drawable.door_tab_account_selector));
			mTabIcons.add(getTabDrawableById(R.drawable.door_tab_setting_selector));
			break;
		}
//		// cls
//		mActivityCls.add(MapLocationActivity.class);
//		mActivityCls.add(PublishListActivity.class);
//		mActivityCls.add(OrderListActivity.class);
//		mActivityCls.add(AccountActivity.class);
//		mActivityCls.add(SettingActivity.class);
//
//		// texts
//		mTabTexts = new ArrayList<String>();
//		mTabTexts.add("主页");
//		mTabTexts.add("发布");
//		mTabTexts.add("订单");
//		mTabTexts.add("账本");
//		mTabTexts.add("设置");
//
//		// icons
//		mTabIcons = new ArrayList<Drawable>();
//		mTabIcons.add(getTabDrawableById(R.drawable.door_tab_sms_tv_selector));
//		mTabIcons.add(getTabDrawableById(R.drawable.door_tab_contact_tv_selector));
//		mTabIcons.add(getTabDrawableById(R.drawable.door_tab_dial_tv_selector));
//		mTabIcons.add(getTabDrawableById(R.drawable.door_tab_account_selector));
//		mTabIcons.add(getTabDrawableById(R.drawable.door_tab_setting_selector));

		initDefaultActivity();
	}

	private Drawable getTabDrawableById(int rid) {
		Drawable d = getResources().getDrawable(rid);
		d.setBounds(0, 0, d.getMinimumWidth(), d.getMinimumHeight());
		return d;
	}

	private void initDefaultActivity() {
		this.mDefaultActivityIndex = 0;
	}

	private void initViews() {
		// TODO Auto-generated method stub
		vTabs = (BottomTabView) findViewById(R.id.app_tab);
		vTabs.setTabItems(mTabTexts, mTabIcons);
		vTabs.setTabSelectIndex(mDefaultActivityIndex);
		vTabs.notifyItemsChanged();

		vTabs.setTabListener(new OnSelectListener() {

			@Override
			public void onSelected(int index) {
				// TODO Auto-generated method stub
				mCurActivityIndex = index;
				if (mCurActivityIndex != mDefaultActivityIndex
						&& ParkingApp.mAppCtx.isNeedLogin()) {
					showLoginDialog();
					return;
				}
				selectActivity();
			}
		});

		vContent = (FrameLayout) findViewById(R.id.app_content);
		mCurActivityIndex = mDefaultActivityIndex;
		selectActivity();
	}

	private void selectActivity() {
		hideKeyborad();
		View view = mLocal.startActivity("page_" + mCurActivityIndex,
				new Intent(this, mActivityCls.get(mCurActivityIndex)))
				.getDecorView();
		vContent.removeAllViews();
		vContent.addView(view, new ViewGroup.LayoutParams(
				LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		Log.i("qh", "activity result ...");
		if (requestCode == LoginActivity.REQUEST_LOGIN) {
			if (resultCode != LoginActivity.RESULT_CODE_LOGIN_SUCCESS) {// 登录失败
				vTabs.manualSelectTab(mDefaultActivityIndex);
			} else {// 登录成功
				vTabs.manualSelectTab(mCurActivityIndex);
				selectActivity();
			}
		}
	}

	private Dialog mLoginConfirmDialog;

	private void showLoginDialog() {
		if (mLoginConfirmDialog == null) {
			mLoginConfirmDialog = new AlertDialog.Builder(this)
					.setTitle("提示")
					.setMessage("需要登录，才能使用该功能")
					.setPositiveButton("确定",
							new DialogInterface.OnClickListener() {

								@Override
								public void onClick(DialogInterface dialog,
										int which) {
									// TODO Auto-generated method stub
									Intent intent = new Intent(
											AppActivity.this,
											LoginActivity.class);
									startActivityForResult(intent,
											LoginActivity.REQUEST_LOGIN);
								}
							})
					.setNegativeButton("取消",
							new DialogInterface.OnClickListener() {

								@Override
								public void onClick(DialogInterface dialog,
										int which) {
									// TODO Auto-generated method stub
									vTabs.manualSelectTab(mDefaultActivityIndex);
								}
							}).create();
		}
		mLoginConfirmDialog.setCancelable(false);
		mLoginConfirmDialog.setCanceledOnTouchOutside(false);
		mLoginConfirmDialog.show();
	}

	// check update
	private void checkVersion() {
		// TODO Auto-generated method stub
		HttpUtils http = new HttpUtils();
		http.send(
				HttpMethod.GET,
				ParkingApp.mAppCtx.getServerConfig().getURL(
						IServer.URL_FLAG_GET_APK_VERSION),
				new RequestCallBack<String>() {

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// TODO Auto-generated method stub
						String msg = responseInfo.result;
						if (AbStrUtil.isEmpty(msg)) {
							return;
						}
						String[] infos = msg.split(IServer.V_SPLIT);
						if (infos.length < 3) {
							return;
						}
						String versionName = SysUtils.getVersionName(ParkingApp.mAppCtx);
						int myversion = SysUtils
								.getVersionCode(ParkingApp.mAppCtx);
						int serverversion = myversion;
						try {
							serverversion = Integer.valueOf(infos[1]);
						} catch (NumberFormatException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						Log.i("qh", "当前版本："+myversion+", 发现新版本:"+serverversion);
						ParkingApp.mAppCtx.setVersionName(versionName);
						ParkingApp.mAppCtx.setMyversion(myversion);
						ParkingApp.mAppCtx.setServerversion(serverversion);
						ParkingApp.mAppCtx.setUpdateInfo(infos[2]);
						long sevDay = 604800;
						long lLastUpdate = ParkingPrefs.getLongValue("last_update", 0);
						long lCurDate = System.currentTimeMillis()/1000;
						int iLastCode = ParkingPrefs.getIntValue("last_update_code", 0);
						if(myversion == serverversion) {
							return;
						}
						if(iLastCode != serverversion) {
							showUpdateDialog(infos[2]);
							ParkingPrefs.setIntValue("last_update_code", serverversion);
							ParkingPrefs.setLongValue("last_update", lCurDate);
							return;
						}
						if( (lCurDate - lLastUpdate) >= sevDay) {
							if(myversion < serverversion) {
								showUpdateDialog(infos[2]);
							}
							ParkingPrefs.setLongValue("last_update", lCurDate);
						}
					}

					@Override
					public void onFailure(HttpException error, String msg) {
						// TODO Auto-generated method stub
					}
				});
	}
	
	private void showUpdateDialog(String updateinfo){
		Dialog dialog = new AlertDialog.Builder(this)
			.setTitle("发现新版本")
			.setMessage(updateinfo)
			.setNegativeButton("取消", null)
			.setPositiveButton("确定", new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					// TODO Auto-generated method stub
					startService(new Intent(AppActivity.this, DownService.class));
				}
			})
			.create();
		dialog.show();
	}

	private long exitTime = 0;
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
//		Log.i("TEST", "appActivity onKeyDown ");
//		if(keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP){   
//	        if((System.currentTimeMillis()-exitTime) > 2000){  
//	            Toast.makeText(getApplicationContext(), "再按一次返回键退出程序", Toast.LENGTH_SHORT).show();                                
//	            exitTime = System.currentTimeMillis();   
//	        } else {
//	            finish();
//	            System.exit(0);
//	        }
//	        return true;   
//	    }
		return super.onKeyDown(keyCode, event);
	}
	
	Handler appHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			mCurActivityIndex = msg.what;
			vTabs.manualSelectTab(msg.what);
			selectActivity();
		}
		
	};
	
	public void hideKeyborad() {
		InputMethodManager imm =  (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE); 
		if(imm != null) { 
			imm.hideSoftInputFromWindow(getWindow().getDecorView().getWindowToken(),  
		    		   0); 
			}
	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		if((System.currentTimeMillis()-exitTime) > 2000){  
            Toast.makeText(getApplicationContext(), "再按一次返回键退出程序", Toast.LENGTH_SHORT).show();                                
            exitTime = System.currentTimeMillis();   
        } else {
            finish();
            System.exit(0);
        }
//		super.onBackPressed();
	}
	
	
}
