package com.sendi.lhparking.ui.common;

import java.util.ArrayList;
import java.util.List;

import org.sendi.parking.ui.R;
import org.sendi.parking.ui.R.id;
import org.sendi.parking.ui.R.layout;


import com.ab.util.AbStrUtil;
import com.ab.view.pullview.AbPullToRefreshView;
import com.ab.view.pullview.AbPullToRefreshView.OnHeaderRefreshListener;
import com.lidroid.xutils.db.sqlite.Selector;
import com.lidroid.xutils.exception.DbException;
import com.lidroid.xutils.view.annotation.ViewInject;
import com.lidroid.xutils.view.annotation.event.OnClick;
import com.lidroid.xutils.view.annotation.event.OnItemClick;
import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.ctx.ParkingConstant;
import com.sendi.lhparking.model.SystemMsgModel;
import com.sendi.lhparking.ui.common.base.BaseActivityWithDialog;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

/**
 * 多个系统消息调用此界面
 * 
 * @author Administrator
 * 
 */
public class SystemMsgListActivity extends BaseActivityWithDialog implements
		OnHeaderRefreshListener {

	// for top bar
	@ViewInject(R.id.topbar_left_btn)
	private TextView vTopLeft;
	@ViewInject(R.id.topbar_center_btn)
	private TextView vTopCenter;
	@ViewInject(R.id.topbar_right_btn)
	private TextView vTopRight;
	
	@OnClick(value = { R.id.topbar_left_btn })
	public void topLeftClick(View v) {
		finish();
	}

	@ViewInject(R.id.system_msg_list_pull_view)
	private AbPullToRefreshView vPull;
	@ViewInject(R.id.system_msg_list_list)
	private ListView vList;
	@ViewInject(R.id.system_msg_list_empty)
	private TextView vEmpty;

	private SystemMsgAdapter mAdapter;

	@OnItemClick(value = { R.id.system_msg_list_list })
	public void clickSystemList(AdapterView<?> parent, View view, int position,
			long id) {
		// TODO Auto-generated method stub
		SystemMsgModel model = (SystemMsgModel) mAdapter.getItem(position);
		Intent intent = ParkingConstant.getIntentBySysMsg(model);
		startActivity(intent);
		try {
			mDB.delete(model);
		} catch (DbException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_system_msg_list);
		vTopLeft.setText("  返 回");
		vTopLeft.setVisibility(View.VISIBLE);
		vTopCenter.setText("我的消息");
		mAdapter = new SystemMsgAdapter();
		vList.setAdapter(mAdapter);
		ParkingApp.mAppCtx.setHasSysMsgListActivity(true);
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		initList();
	}
	
	@Override
	protected void onNewIntent(Intent intent) {
		// TODO Auto-generated method stub
		super.onNewIntent(intent);
		initList();
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		ParkingApp.mAppCtx.setHasSysMsgListActivity(false);
		if (ParkingApp.mAppCtx.isNeedLoadMainActivity()) {
			startActivity(new Intent(this, AppActivity.class));
		}
	}

	private void initList() {
		try {
			List<SystemMsgModel> models = mDB.findAll(Selector.from(
					SystemMsgModel.class).orderBy("time", true));
			mAdapter.refreshData(models);
		} catch (DbException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	class SystemMsgAdapter extends BaseAdapter {

		private List<SystemMsgModel> mDatas;

		public SystemMsgAdapter() {
			mDatas = new ArrayList<SystemMsgModel>();
		}

		public void refreshData(List<SystemMsgModel> model) {
			mDatas.clear();
			mDatas.addAll(model);
			notifyDataSetChanged();
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return mDatas.size();
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return mDatas.get(position);
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
			ViewHolder vh = null;
			if(convertView == null){
				convertView = LayoutInflater.from(SystemMsgListActivity.this).inflate(R.layout.item_sys_mes_list, null);
				vh = new ViewHolder();
				vh.vMsg = (TextView) convertView.findViewById(R.id.item_sys_msg_text);
				vh.vTime = (TextView) convertView.findViewById(R.id.item_sys_msg_time);
				convertView.setTag(vh);
			}else{
				vh = (ViewHolder) convertView.getTag();
			}
			SystemMsgModel model = mDatas.get(position);
			vh.vMsg.setText(model.getMsg());
			vh.vTime.setText(AbStrUtil.timeToDate(model.getTime()));
			return convertView;
		}
		
		class ViewHolder{
			TextView vMsg;
			TextView vTime;
		}

	}

	@Override
	public void onHeaderRefresh(AbPullToRefreshView view) {
		// TODO Auto-generated method stub
		initList();
		vPull.onHeaderRefreshFinish();
	}
}
