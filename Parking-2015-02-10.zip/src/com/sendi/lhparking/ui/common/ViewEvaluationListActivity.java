package com.sendi.lhparking.ui.common;


import org.sendi.parking.ui.R;
import org.sendi.parking.ui.R.id;
import org.sendi.parking.ui.R.layout;

import com.lidroid.xutils.view.annotation.ViewInject;
import com.sendi.lhparking.ui.common.base.BaseFragmentActivity;
import com.sendi.lhparking.ui.common.frag.EvaluationListFragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.TextView;

/**
 * 查看评价界面
 * @author Administrator
 * 
 */
public class ViewEvaluationListActivity extends BaseFragmentActivity {

	public static final int TYPE_SEE_CAR = 1;   // 车主信用
	public static final int TYPE_SEE_PARK = 2;  // 业主信用
	public static final int TYPE_MY_INFO = 3;   // 我的信用
	
	public static final String KEY_UID = "key_uid";
	public static final String KEY_TYPE = "key_type";
	
	/**
	 * 根据 type 获取对应的intent，调用查看信用信息activity
	 * 1   车主信用
	 * 2   业主信用
	 * 3   我的信用
	 * */
	public static Intent getLaunchIntent(Context context, String uid, int type){
		Intent intent = new Intent(context, ViewEvaluationListActivity.class);
		intent.putExtra(KEY_TYPE, type);
		intent.putExtra(KEY_UID, uid);
		return intent;
	}

	// for top bar
	@ViewInject(R.id.topbar_left_btn)
	protected TextView vTopLeft;
	@ViewInject(R.id.topbar_center_btn)
	protected TextView vTopCenter;
	@ViewInject(R.id.topbar_right_btn)
	protected TextView vTopRight;

//	private String testID = "383832788687";
	private String mUID;
	private int mType;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		if(!parseIntent()){
			finish();
			return;
		}
		setContentView(R.layout.activity_fragment_default_layout);
		if (savedInstanceState == null) {
			getSupportFragmentManager()
					.beginTransaction()
					.add(R.id.activity_frag_default_content,
							EvaluationListFragment.newInstance(mUID))
					.commit();
		}

		initViews();
	}

	private boolean parseIntent() {
		// TODO Auto-generated method stub
		Intent intent = getIntent();
		if(intent == null){
			return false;
		}
		if((mUID = intent.getStringExtra(KEY_UID)) == null){
			return false;
		}
		mType = intent.getIntExtra(KEY_TYPE, TYPE_MY_INFO);
		return true;
	}

	private String getTitleStr() {
		if (mType == TYPE_MY_INFO) {
			return "我的信用";
		} else if (mType == TYPE_SEE_CAR) {
			return "车主信用";
		} else {
			return "业主信用";
		}
	}

	private void initViews() {
		// TODO Auto-generated method stub
		vTopCenter.setText(getTitleStr());
		vTopLeft.setText("  返回");
		vTopLeft.setVisibility(View.VISIBLE);
		vTopLeft.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();
			}
		});
	}
}
