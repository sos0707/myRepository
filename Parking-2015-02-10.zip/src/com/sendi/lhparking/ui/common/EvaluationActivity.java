package com.sendi.lhparking.ui.common;

import org.sendi.parking.ui.R;
import org.sendi.parking.ui.R.id;
import org.sendi.parking.ui.R.layout;
import org.xbill.DNS.Master;

import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.view.annotation.ViewInject;
import com.lidroid.xutils.view.annotation.event.OnClick;
import com.sendi.lhparking.ctx.ParkingConstant;
import com.sendi.lhparking.ui.common.frag.EvaluationOrderFragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 评价页面
 * 
 * @author Administrator
 * 
 */
public class EvaluationActivity extends FragmentActivity {
	
	// for top bar
	@ViewInject(R.id.topbar_left_btn)
	protected TextView vTopLeft;
	@ViewInject(R.id.topbar_center_btn)
	protected TextView vTopCenter;
	@ViewInject(R.id.topbar_right_btn)
	protected TextView vTopRight;
	
	@OnClick(value={R.id.topbar_left_btn})
	private void topLeftDoCancel(View view){
		finish();
	}

	private String mOrderId;
	private String mMasterId;
	private String mGuestId;

	@Override
	protected void onCreate(Bundle bundle) {
		// TODO Auto-generated method stub
		super.onCreate(bundle);
		if (!parseIntent()) {
			Toast.makeText(this, "数据错误", Toast.LENGTH_LONG).show();
			finish();
			return;
		}
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_fragment_default_layout);
		ViewUtils.inject(this);
		
		vTopCenter.setText("添加评价");
		vTopLeft.setText("  返 回");
		vTopLeft.setVisibility(View.VISIBLE);
		
		FragmentManager mgr = getSupportFragmentManager();
		FragmentTransaction trans = mgr.beginTransaction();
		trans.add(R.id.activity_frag_default_content, EvaluationOrderFragment.newInstance(mOrderId, mMasterId, mGuestId));
		trans.commit();
	}

	private boolean parseIntent() {
		Intent intent = getIntent();
		if (intent == null) {
			return false;
		}
		mOrderId = intent
				.getStringExtra(ParkingConstant.INTENT_EXTRA_EVALUTION_ORDERID);
		mMasterId = intent
				.getStringExtra(ParkingConstant.INTENT_EXTRA_EVALUTION_MASTERID);
		mGuestId = intent
				.getStringExtra(ParkingConstant.INTENT_EXTRA_EVALUTION_GUESTID);
		if (mOrderId == null || mMasterId == null || mGuestId == null) {
			return false;
		}
		Log.i("qh", "master : "+mMasterId);
		Log.i("qh", "guest : "+mGuestId);
		return true;
	}

}
