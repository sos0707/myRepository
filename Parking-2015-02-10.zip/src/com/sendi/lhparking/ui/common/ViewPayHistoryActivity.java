package com.sendi.lhparking.ui.common;

import org.sendi.parking.ui.R;

import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.util.AccountDetailInfo;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

/**
 * 充值提现详细界面
 * @author Administrator
 *
 */
public class ViewPayHistoryActivity extends BaseActivity {

	private AccountDetailInfo info;
	private TextView tv1, tv2, tv3, tv4, tv5, tvType, tvMoney, tvUser;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.view_account_detailinfo);
		
		Intent intent = getIntent();
		info = intent.getParcelableExtra("accountDetailInfo");
		showAccountDetailinfo();
	}
	
	private void showAccountDetailinfo() {
		setContentView(R.layout.view_account_detailinfo);
		TextView tvUser = (TextView) this.findViewById(R.id.tvUser);
		TextView tvMoney = (TextView) this.findViewById(R.id.tvMoney);
		TextView tvDate = (TextView) this.findViewById(R.id.tvDate);
		TextView tvType = (TextView) this.findViewById(R.id.tvType);

		TextView tvReturn = (TextView) this.findViewById(R.id.topbar_left_btn);
		TextView tvTitle = (TextView)this.findViewById(R.id.topbar_center_btn);
		
		tvReturn.setText("  返 回");
		tvReturn.setVisibility(View.VISIBLE);
		tvTitle.setText("账 单 详 情");
		tvReturn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				hideKeyborad();
				ViewPayHistoryActivity.this.finish();
			}
		});
		
		tv1 = (TextView) this.findViewById(R.id.tv1);
		tv2 = (TextView) this.findViewById(R.id.tv2);
		tv3 = (TextView) this.findViewById(R.id.tv3);
		tv4 = (TextView) this.findViewById(R.id.tv4);
		tv5 = (TextView) this.findViewById(R.id.tv5);
		tvType = (TextView) this.findViewById(R.id.tvType);
		tvMoney = (TextView) this.findViewById(R.id.tvMoney);
		tvUser = (TextView) this.findViewById(R.id.tvUser);
		tvType.setText(info.getTaskName());
		tvMoney.setText(String.valueOf(info.getMoney()));
		tvUser.setText(info.getUserName());
		if(info.getTaskName().equals("充值")) {
			tv1.setText("充值方式        "+info.getPayType());
			tv2.setText("创建时间        "+info.getTime());
			tv3.setText("交易流水号     "+info.getAmountId());
		}else {
			tv1.setText("提现方式        "+info.getPayType());
			tv2.setText("创建时间        "+info.getTime());
			if(info.getPayTypeEn() == 3) {
				tv3.setText("银        行        "+info.getBank() );
				tv4.setText("银行卡卡号     "+info.getAccount());
			}else if(info.getPayTypeEn() == 1){
				tv3.setText("支付宝账号          "+info.getAccount() );
				tv2.setText("创建时间        "+info.getTime());
			}else {
				tv3.setText("财付通账号          "+info.getAccount() );
				tv2.setText("创建时间        "+info.getTime());
			}
		} 
	}
}
