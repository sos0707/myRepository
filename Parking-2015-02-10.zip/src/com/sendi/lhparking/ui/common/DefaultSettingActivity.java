package com.sendi.lhparking.ui.common;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.sendi.parking.ui.R;

import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.sendi.lhparking.adapter.AddParkingHistoryListAdapter;
import com.sendi.lhparking.adapter.TrustListAdapter;
import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.update.DownService;
import com.sendi.lhparking.util.AddParkingHistoryInfo;
import com.sendi.lhparking.util.TrustListInfo;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnDismissListener;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
/**
 * 默认设置
 * @author Administrator
 *
 */
public class DefaultSettingActivity extends BaseActivity {

	private TextView tvTitle;
	private TextView tvReturn;
	private ListView lvTrust;
	private LinearLayout llayoutShownull;
	
	private ProgressDialog mDialog;
	private String curShowView = "0";
	private int dialogDismiss = 0;
	private List<TrustListInfo> mTrustListInfos = null;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_defaultsetting);
		
		init();
		initView();
	}
	
	private void init() {

		tvTitle = (TextView) this.findViewById(R.id.topbar_center_btn);
		tvReturn = (TextView) this.findViewById(R.id.topbar_left_btn);
		
		tvTitle.setText("默 认 设 置");
		tvReturn.setVisibility(View.VISIBLE);
		tvReturn.setText("  返 回");
		tvReturn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				hideKeyborad();
				DefaultSettingActivity.this.finish();
			}
		});
	}
	
	private void initView() {
		lvTrust = (ListView) this.findViewById(R.id.lvTrust);
		llayoutShownull = (LinearLayout) this.findViewById(R.id.layoutShownull);
		boolean bo = isNetConnected();
		if(bo) {
			doGetTrustList();
		}else {
			Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
		}
	}
	
	private void doGetTrustList() {
		curShowView = "GetTrustList";
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("method", "2027");

		HttpUtils http = new HttpUtils(6000);
		showProgDialog("正在查询默认列表 . . . ", http);
		http.send(HttpMethod.POST, 
				ServerURL, 
				params,
				new RequestCallBack<String>() {

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// TODO Auto-generated method stub
						if(curShowView.equals("GetTrustList")) {
							Log.i(TAG, "DefaultSetting : "+ responseInfo.result);
							try {
								JSONObject jsob = new JSONObject(responseInfo.result);
								int count = jsob.getInt("totalCount");
								JSONArray jsoa = jsob.getJSONArray("data");
								mTrustListInfos = new ArrayList<TrustListInfo>();
								for(int i=0; i< count; i++) {	
//									{id，  name， parking_no， relate_date}  //分别代表id ,小区名称，车位号 ，操作时间
									TrustListInfo info = new TrustListInfo();
									JSONObject jso = jsoa.getJSONObject(i);
									info.setParkId(jso.getString("id"));
									info.setParkName(jso.getString("name"));
									info.setParkingNo(jso.getString("parking_no"));
									info.setRelateTime(jso.getString("relate_date"));
									mTrustListInfos.add(info);
								}
								if(mTrustListInfos != null && mTrustListInfos.size() != 0 ) {
									showTrustList();
								}else {
									llayoutShownull.setVisibility(View.VISIBLE);
									lvTrust.setVisibility(View.GONE);
								}
								if(mDialog != null) {
									dialogDismiss = 1;
									mDialog.dismiss();
								}							
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					}

					@Override
					public void onFailure(HttpException error, String msg) {
						// TODO Auto-generated method stub
						if(curShowView.equals("GetTrustList")) {
							showTipsDialog("查询失败，请检查网络，稍后再试 ", DefaultSettingActivity.this);
						}
						if(mDialog != null) {
							dialogDismiss = 1;
							mDialog.dismiss();
						}	
					}
		});
	
	}
	
	private void showTrustList() {
		llayoutShownull.setVisibility(View.GONE);
		lvTrust.setVisibility(View.VISIBLE);
		TrustListAdapter adapter = new TrustListAdapter(this, mTrustListInfos, trustHandler);
		lvTrust.setAdapter(adapter);
	}
	
	private void showProgDialog(final String msg, final HttpUtils httpUtils) {
		mDialog = new ProgressDialog(this);
		mDialog.setCanceledOnTouchOutside(false);
		mDialog.setOnDismissListener(new OnDismissListener() {
			
			@Override
			public void onDismiss(DialogInterface dialog) {
				// TODO Auto-generated method stub
				if(dialogDismiss == 0 ) {
						httpUtils.getHttpClient().getConnectionManager().closeExpiredConnections();
//						httpUtils.getHttpClient().getConnectionManager().shutdown();
				}
				dialogDismiss = 0;
//				if(curShowView.equals("doCancel")) {
//					curShowView = "GetTrustList";
//				}else {
					curShowView = "0";
//				}
				Log.i(TAG, "dialog dismiss : "+msg);
			}
		});
		mDialog.setMessage(msg);
		mDialog.show();
	}
	
	Handler trustHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			switch(msg.what) {
			case 1:
				String id = (String) msg.obj;
				doCancel(id);
				break;
			case 3:
				doGetTrustList();
				break;
			}
		}
		
	};
	
	private void doCancel(String id) {
		curShowView = "doCancel";
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("id", id);
		params.addBodyParameter("method", "2028");
Log.i(TAG, "do cancel id : " + id);
		HttpUtils http = new HttpUtils(6000);
		showProgDialog("正在取消该设置 . . . ", http);
		http.send(HttpMethod.POST, 
				ServerURL, 
				params,
				new RequestCallBack<String>() {

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// TODO Auto-generated method stub
						if(curShowView.equals("doCancel")) {
							Log.i(TAG, "DefaultSetting docancel : "+ responseInfo.result);
							try {
								JSONObject jsob = new JSONObject(responseInfo.result);
								boolean bo = jsob.getBoolean("success");
								String msg = jsob.getString("msg");
								Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
								if(mDialog != null) {
									dialogDismiss = 1;
									mDialog.dismiss();
								}
								if(bo) {
									Message sendmsg = new Message();
									sendmsg.what = 3;
									trustHandler.sendMessage(sendmsg);
								}
															
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					}

					@Override
					public void onFailure(HttpException error, String msg) {
						// TODO Auto-generated method stub
						if(curShowView.equals("doCancel")) {
							showTipsDialog("设置失败，请检查网络，稍后再试 ", DefaultSettingActivity.this);
						}
						if(mDialog != null) {
							dialogDismiss = 1;
							mDialog.dismiss();
						}	
					}
		});
	
	
	}
	
}
