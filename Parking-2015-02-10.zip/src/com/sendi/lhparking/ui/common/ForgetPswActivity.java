package com.sendi.lhparking.ui.common;

import org.json.JSONException;
import org.json.JSONObject;
import org.sendi.parking.ui.R;

import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.sendi.lhparking.util.MD5Crypter;
import com.sendi.lhparking.util.ParkingPrefs;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnDismissListener;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
/**
 * 忘记密码
 * @author Administrator
 *
 */
public class ForgetPswActivity extends BaseActivity {
	
	private Button btnOK;
	private EditText edUserid;
	private ProgressDialog mDialog;
	private String curShowView = "0";
	private int dialogDismiss = 0;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_forgetpsw);
		initView();
	}
	
	private void initView() {
		setContentView(R.layout.activity_forgetpsw);

		TextView tvTitle = (TextView) this.findViewById(R.id.topbar_center_btn);
		TextView tvReturn = (TextView) this.findViewById(R.id.topbar_left_btn);
		btnOK = (Button) this.findViewById(R.id.btnOK);
		edUserid = (EditText) this.findViewById(R.id.edUserid);
		
		tvTitle.setText("密 码 找 回");
		tvReturn.setVisibility(View.VISIBLE);
		tvReturn.setText("  返 回");
		
		btnOK.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(edUserid.getText().length() == 0) {
					showTipsDialog("请输入注册账号！", ForgetPswActivity.this);
					return;
				}
				hideKeyborad();
				doCheckSecret(edUserid.getText().toString());
			}
		});
		
		tvReturn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				hideKeyborad();
				ForgetPswActivity.this.finish();
			}
		});
		
		edUserid.setOnEditorActionListener(new OnEditorActionListener() {
			
			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				// TODO Auto-generated method stub
				switch(actionId) {
				case EditorInfo.IME_ACTION_DONE:
					btnOK.performClick();
					break;
				}
				return false;
			}
		});
	}
	
	/** 
	 * 验证密保界面
	 * */
	private void initSecretInfo(final String phone, final String quest) {
		Log.i(TAG, "initSecretInfo : ");
		setContentView(R.layout.view_chekcsecret);
		TextView tvTitle = (TextView) this.findViewById(R.id.topbar_center_btn);
		TextView tvReturn = (TextView) this.findViewById(R.id.topbar_left_btn);	
		TextView tvUserid = (TextView) this.findViewById(R.id.tvUserid);	
		TextView tvQuest = (TextView) this.findViewById(R.id.tvQuest);	
		final Button btnOK = (Button) this.findViewById(R.id.btnOK);
		Button btnCancel = (Button) this.findViewById(R.id.btnCancel);
		final EditText edAnswer = (EditText) this.findViewById(R.id.edtAnswer);
		tvTitle.setText("密  保");
		tvReturn.setVisibility(View.VISIBLE);
		tvReturn.setText("  返 回");
		tvUserid.setText(phone);
		tvQuest.setText(quest);
		
		btnOK.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(edAnswer.getText().length() == 0) {
					showTipsDialog("请输入密保答案！", ForgetPswActivity.this);
					return;
				}
				hideKeyborad();
				doGetPsw(phone, quest, edAnswer.getText().toString());
			}
		});
		
		btnCancel.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				hideKeyborad();
//				Intent intent = new Intent(ForgetPswActivity.this, LoginActivity.class);
//				startActivity(intent);
				ForgetPswActivity.this.finish();
			}
		});
		
		tvReturn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				hideKeyborad();
				initView();
			}
		});
		
		edAnswer.setOnEditorActionListener(new OnEditorActionListener() {
			
			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				// TODO Auto-generated method stub
				switch(actionId) {
				case EditorInfo.IME_ACTION_DONE:
					btnOK.performClick();
					break;
				}
				return false;
			}
		});
	}
	
	/** 
	 * 重置密码界面
	 * */
	private void initResetPsw(final String phone) {
		setContentView(R.layout.view_resetpsw);
		TextView tvTitle = (TextView) this.findViewById(R.id.topbar_center_btn);	
		final Button btnOK = (Button) this.findViewById(R.id.btnOK);
		Button btnCancel = (Button) this.findViewById(R.id.btnCancel);
		final EditText edNewpsw = (EditText) this.findViewById(R.id.edNewpsw);
		final EditText edRnewpsw = (EditText) this.findViewById(R.id.edReNewpsw);
		tvTitle.setText("设 置 新 密 码");
		
		btnOK.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(edNewpsw.getText().length() == 0 || edRnewpsw.getText().length() == 0) {
					showTipsDialog("请输入完整密码信息！", ForgetPswActivity.this);
					return;
				}
				if(edNewpsw.getText().length() < 6 || edNewpsw.getText().length()>12) {
					showTipsDialog("密码长度错误 (长度: 6 - 12)", ForgetPswActivity.this);
					return;
				}
				if( !edNewpsw.getText().toString().equals( edRnewpsw.getText().toString() )) {
					showTipsDialog("两次输入密码不同，请重新输入！", ForgetPswActivity.this);
					return;
				}
				hideKeyborad();
				doResetPsw(phone, edNewpsw.getText().toString());
			}
		});
		
		btnCancel.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				hideKeyborad();
//				Intent intent = new Intent(ForgetPswActivity.this, LoginActivity.class);
//				startActivity(intent);
				ForgetPswActivity.this.finish();
			}
		});
		
		edRnewpsw.setOnEditorActionListener(new OnEditorActionListener() {
			
			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				// TODO Auto-generated method stub
				switch(actionId) {
				case EditorInfo.IME_ACTION_DONE:
					btnOK.performClick();
					break;
				}
				return false;
			}
		});
	}
	
	/** 
	 * 服务器根据账号查找密保问题
	 * */
	private void doCheckSecret(final String phone) {
		curShowView = "CheckSecret";
//		参数：method：config_2004 userid：账号 
//		返回：返回值： {success:true,num:’问题编号’,quest:’问题内容’}
		RequestParams params = new RequestParams();
		params.addBodyParameter("phone", phone);
		params.addBodyParameter("method", "config_2004");

		HttpUtils http = new HttpUtils(6000);
		showProgDialog("正在查询密保...", http);
		http.send(HttpMethod.POST, 
				ServerURL, 
				params,
				new RequestCallBack<String>() {

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// TODO Auto-generated method stub
						if(curShowView.equals("CheckSecret")) {
							try {
								JSONObject jsob = new JSONObject(responseInfo.result);
								boolean bo = jsob.getBoolean("success");
								String quest = jsob.getString("question");
								if(bo && !quest.equals("你未设置密保!")) {
									Log.i(TAG, "doCheckSecret : "+responseInfo.result);
									hideKeyborad();
									initSecretInfo(phone, quest);
								}else {
									showTipsDialog("查询失败，"+quest, ForgetPswActivity.this);
								}
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							if(mDialog != null) {
								dialogDismiss = 1;
								mDialog.dismiss();
							}
						}
					}

					@Override
					public void onFailure(HttpException error, String msg) {
						// TODO Auto-generated method stub
						if(curShowView.equals("CheckSecret")) {
							showTipsDialog("查询失败 ", ForgetPswActivity.this);
						}
						if(mDialog != null) {
							dialogDismiss = 1;
							mDialog.dismiss();
						}
					}});
	}
	
	/** 
	 * 服务器验证密保
	 * */
	private void doGetPsw(String phone, String quest, String answer) {
		curShowView = "GetPsw";
//		参数：method：config_2006 userid：账号 num:问题编号 answer:问题答案
//		返回：返回值： {success:true,msg:’账号’}   success为判断标准，treu跳转密码重置页面
		RequestParams params = new RequestParams();
		params.addBodyParameter("phone", phone);
		params.addBodyParameter("question", quest);
		params.addBodyParameter("answer", answer);
		params.addBodyParameter("method", "config_2006");

		HttpUtils http = new HttpUtils(6000);
		showProgDialog("正在找回密码...", http);
		http.send(HttpMethod.POST, 
				ServerURL, 
				params,
				new RequestCallBack<String>() {

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// TODO Auto-generated method stub
						if(curShowView.equals("GetPsw")) {
							try {
								JSONObject jsob = new JSONObject(responseInfo.result);
								boolean bo = jsob.getBoolean("success");
								String msg = jsob.getString("msg");
								if(bo) {
									initResetPsw(msg);
								}else {
									showTipsDialog("找回密码失败，"+msg, ForgetPswActivity.this);
								}
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							if(mDialog != null) {
								dialogDismiss = 1;
								mDialog.dismiss();
							}
						}
						Log.i(TAG, responseInfo.result);
					}

					@Override
					public void onFailure(HttpException error, String msg) {
						// TODO Auto-generated method stub
						if(curShowView.equals("GetPsw")) {
							showTipsDialog("找回密码失败，请检查网络，稍后再试 ", ForgetPswActivity.this);
						}
						if(mDialog != null) {
							dialogDismiss = 1;
							mDialog.dismiss();
						}
					}});
	
	}
	
	/** 
	 * 服务器重置密码
	 * */
	private void doResetPsw(String userid, String password) {
		curShowView = "ResetPsw";
		String psw = MD5Crypter.MD5Encode(password);
//		重置密码
//		参数：method：config_2020 uid：账号   repwd：新密码 recon：确认密码 
//		返回：返回值： {success:true,msg:’修改成功’}
		RequestParams params = new RequestParams();
		params.addBodyParameter("phone", userid);
		params.addBodyParameter("newpwd", psw);
		params.addBodyParameter("method", "config_2020");
		HttpUtils http = new HttpUtils(6000);
		showProgDialog("正在重置密码...", http);
		http.send(HttpMethod.POST, 
				ServerURL, 
				params,
				new RequestCallBack<String>() {
					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// TODO Auto-generated method stub
						if(curShowView.equals("ResetPsw")) {
							try {
								JSONObject jsob = new JSONObject(responseInfo.result);
								boolean bo = jsob.getBoolean("success");
								String msg = jsob.getString("msg");
								if(bo) {
									showTipsDialog(msg+"，请重新登录");
									initView();
								}else {
									showTipsDialog("重置密码失败，"+msg, ForgetPswActivity.this);
								}
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							if(mDialog != null) {
								dialogDismiss = 1;
								mDialog.dismiss();
							}
						}
						
						Log.i(TAG, responseInfo.result);
					}

					@Override
					public void onFailure(HttpException error, String msg) {
						// TODO Auto-generated method stub
						if(curShowView.equals("ResetPsw")) {
							showTipsDialog("重置密码失败，请检查网络，稍后再试 ", ForgetPswActivity.this);
						}
						if(mDialog != null) {
							dialogDismiss = 1;
							mDialog.dismiss();
						}
					}});
		}
	
	private void showTipsDialog(String msg){  
        AlertDialog dialog;  
        AlertDialog.Builder builder = new AlertDialog.Builder(this);  
        builder.setTitle("消息").setIcon(android.R.drawable.stat_notify_error);  
        builder.setMessage(msg);  
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener(){  
            @Override 
            public void onClick(DialogInterface dialog, int which) {  
                // TODO Auto-generated method stub  
//            	Intent intent = new Intent(ForgetPswActivity.this, LoginActivity.class);
//				startActivity(intent);
				ForgetPswActivity.this.finish();
            } 
        });
        dialog = builder.create(); 
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();  
    } 
	
	private void showProgDialog(final String msg, final HttpUtils httpUtils) {
		mDialog = new ProgressDialog(this);
		mDialog.setCanceledOnTouchOutside(false);
		mDialog.setOnDismissListener(new OnDismissListener() {
			
			@Override
			public void onDismiss(DialogInterface dialog) {
				// TODO Auto-generated method stub
				if(dialogDismiss == 0 ) {
					httpUtils.getHttpClient().getConnectionManager().closeExpiredConnections();
//					httpUtils.getHttpClient().getConnectionManager().shutdown();
				}
				dialogDismiss = 0;
				curShowView = "0";
				Log.i(TAG, "dialog dismiss : "+msg);
			}
		});
		mDialog.setMessage(msg);
		mDialog.show();
	}
}
