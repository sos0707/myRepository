package com.sendi.lhparking.ui.common;

import org.json.JSONException;
import org.json.JSONObject;
import org.sendi.parking.ui.R;

import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.util.MD5Crypter;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.TextView.OnEditorActionListener;
/**
 * 修改密码
 * @author Administrator
 *
 */
public class ChangePswActivity extends BaseActivity {

	private ProgressDialog mDialog;
	private String curShowView = "0";
	private int dialogDismiss = 0;
	private Button btnOK;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);

		setContentView(R.layout.view_changepsw);
		TextView tvTitle = (TextView) this.findViewById(R.id.topbar_center_btn);
		TextView tvReturn = (TextView) this.findViewById(R.id.topbar_left_btn);
		final EditText edOldpsw = (EditText) this.findViewById(R.id.edOldpsw);
		final EditText edNewpsw = (EditText) this.findViewById(R.id.edNewpsw);
		final EditText edRenewpsw = (EditText) this.findViewById(R.id.edReNewpsw);
		btnOK = (Button) this.findViewById(R.id.btnOK);
		Button btnCancel = (Button) this.findViewById(R.id.btnCancel);
		
		tvTitle.setText("修 改 密 码");
		tvReturn.setVisibility(View.VISIBLE);
		tvReturn.setText("  返 回");
		
		tvReturn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				ChangePswActivity.this.finish();
			}
		});
		
		btnOK.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(edOldpsw.getText().length() == 0 || edNewpsw.getText().length() == 0 || edRenewpsw.getText().length() == 0) {
					showTipsDialog("请输入完整密码信息", ChangePswActivity.this);
					return;
				}
				
				if(edNewpsw.getText().length() < 6 || edRenewpsw.getText().length()>12) {
					showTipsDialog("密码长度错误 (长度: 6 - 12)", ChangePswActivity.this);
					return;
				}
				if( !edNewpsw.getText().toString().equals(edRenewpsw.getText().toString() )) {
					showTipsDialog("两次输入密码不同，请重新输入！", ChangePswActivity.this);
					return;
				}
				boolean bo = isNetConnected();
				if(bo) {
					btnOK.setClickable(false);
					doChangePsw(edOldpsw.getText().toString(), edNewpsw.getText().toString());
				}else {
					Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
				}
			}
		});
		
		btnCancel.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				ChangePswActivity.this.finish();
			}
		});
		
		edRenewpsw.setOnEditorActionListener(new OnEditorActionListener() {
			
			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				// TODO Auto-generated method stub
				switch(actionId) {
				case EditorInfo.IME_ACTION_DONE:
					btnOK.performClick();
					break;
				}
				return false;
			}
		});
	
	}
	
	/** 
	 * 服务器修改密码
	 * */
	private void doChangePsw(String oldpsw, String newpsw) {
		curShowView = "ChangePsw";		
		String oldPsw = MD5Crypter.MD5Encode(oldpsw);
		String newPsw = MD5Crypter.MD5Encode(newpsw);
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("oldpwd", oldPsw);
		params.addBodyParameter("newpwd", newPsw);
		params.addBodyParameter("method", "config_2000");

		HttpUtils http = new HttpUtils(6000);
		showProgDialog("正在修改密码...", http);
		http.send(HttpMethod.POST, 
				ServerURL, 
				params,
				new RequestCallBack<String>() {

			@Override
	        public void onLoading(long total, long current, boolean isUploading) {
	            if (isUploading) {
	            	Log.i(TAG, "upload: " + current + "/" + total);
	            } else {
	            	Log.i(TAG, "reply: " + current + "/" + total);
	            }
	        }
					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// TODO Auto-generated method stub
						if(curShowView.equals("ChangePsw")) {
							try {
								JSONObject jsob = new JSONObject(responseInfo.result);
								boolean bo = jsob.getBoolean("success");
								if(bo) {
//									showTipsDialog("修改密码成功！", ChangePswActivity.this);
									Toast.makeText(getApplicationContext(), "修改密码成功！", Toast.LENGTH_SHORT).show();
									ChangePswActivity.this.finish();
								}else {
									showTipsDialog("原密码错误，请重新输入！", ChangePswActivity.this);
								}
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							if(mDialog != null) {
								dialogDismiss  = 1;
								mDialog.dismiss();
							}
						}
						Log.i(TAG, responseInfo.result);
					}

					@Override
					public void onFailure(HttpException error, String msg) {
						// TODO Auto-generated method stub
						if(curShowView.equals("ChangePsw")) {
							showTipsDialog("修改密码失败，请检查网络，稍后再试 ", ChangePswActivity.this);
						}
						if(mDialog != null) {
							dialogDismiss = 1;
							mDialog.dismiss();
						}
					}});
	}
	
	private void showProgDialog(final String msg, final HttpUtils httpUtils) {
		mDialog = new ProgressDialog(this);
		mDialog.setCanceledOnTouchOutside(false);
		mDialog.setOnDismissListener(new OnDismissListener() {
			
			@Override
			public void onDismiss(DialogInterface dialog) {
				// TODO Auto-generated method stub
				btnOK.setClickable(true);
				if(dialogDismiss == 0 ) {
					try {
						httpUtils.getHttpClient().getConnectionManager().closeExpiredConnections();
//						httpUtils.getHttpClient().getConnectionManager().shutdown();
					} catch (Exception e) {
						// TODO: handle exception
						e.printStackTrace();
					}
				}
				dialogDismiss = 0;
				curShowView = "0";
				Log.i(TAG, "dialog dismiss : "+msg);
			}
		});
		mDialog.setMessage(msg);
		mDialog.show();
	}
}
