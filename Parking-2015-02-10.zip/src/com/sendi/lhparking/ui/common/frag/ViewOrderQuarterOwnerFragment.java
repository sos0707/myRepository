package com.sendi.lhparking.ui.common.frag;

import org.json.JSONException;
import org.json.JSONObject;
import org.sendi.parking.ui.R;

import com.sendi.lhparking.server.IServer;
import com.sendi.lhparking.ui.common.ViewOrderActivity;
import com.sendi.lhparking.ui.common.base.BaseActivity;
import com.sendi.lhparking.ui.common.base.BaseFragment;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

/**
 * 代表物业
 * @author Administrator
 *
 */
public class ViewOrderQuarterOwnerFragment extends BaseFragment<ViewOrderActivity>{
	
	private TextView vBaseQuarter;
	private TextView vBaseState;
	private TextView vBasePrice;
	private TextView vBaseTime;
	private TextView vBaseParkingOwner;
	
	private TextView vCarOwner;
	private TextView vCarNum;
	
	private View vOptPanel;
	private TextView vOptBtn;
	private boolean isInstead = false;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		View view = inflater.inflate(R.layout.frag_view_order_quarter_owner, null);
		findBasePanel(view);
		findAndInitCarPanel(view);
		findOptPanel(view);
		return view;
	}
	
	private void findBasePanel(View root){
		vBaseQuarter = (TextView) root.findViewById(R.id.layout_view_order_parking_quarter);
		vBaseState = (TextView) root.findViewById(R.id.layout_view_order_parking_state);
		vBasePrice = (TextView) root.findViewById(R.id.layout_view_order_parking_price);
		vBaseTime = (TextView) root.findViewById(R.id.layout_view_order_parking_time);
		vBaseParkingOwner = (TextView) root.findViewById(R.id.layout_view_order_parking_owner);
		root.findViewById(R.id.layout_view_order_parking_owner_panel).setVisibility(View.VISIBLE);
	}
	
	private void findAndInitCarPanel(View view) {
		// TODO Auto-generated method stub
		vCarOwner = (TextView) view.findViewById(R.id.layout_view_order_car_owner);
		vCarNum = (TextView) view.findViewById(R.id.layout_view_order_car_num);
	}
	
	private void findOptPanel(View view){
		vOptPanel = view.findViewById(R.id.frag_vorder_qo_option_panel);
		vOptBtn = (TextView) view.findViewById(R.id.frag_vorder_qo_opt_btn);
		vOptBtn.setText("确认放行");
		vOptBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(isInstead) {
					InputDialogFragment dialog = new InputDialogFragment().newInstance("请输入操作码");
					dialog.setFragment(ViewOrderQuarterOwnerFragment.this);
					dialog.show(getChildFragmentManager(), "提示");
					return;
				}
				doOk();
			}
		});
	}
	
	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onActivityCreated(savedInstanceState);
		initViews();
	}

	private void initViews() {
		// TODO Auto-generated method stub
		vBaseQuarter.setText(mOwner.getOrderViewModel().getParking_no());
		vBaseState.setText(mOwner.getOrderViewModel().getState());
		vBasePrice.setText(mOwner.getOrderViewModel().getPrice());
		vBaseTime.setText(mOwner.getOrderViewModel().getBooked_time_range());
		vBaseParkingOwner.setText(mOwner.getOrderViewModel().getBoss_name());
		
		String worker = mOwner.getOrderViewModel().getWorker_name();
		vCarOwner.setText(worker == null ? "无" : worker);
		String num = mOwner.getOrderViewModel().getCar_no();
		vCarNum.setText(num == null ? "无" : num);
		isInstead = false;
		if(mOwner.getState() == IServer.PARKING_STATE_WAIT_QUARTER){
			vOptPanel.setVisibility(View.GONE);
			vOptPanel.startAnimation(AnimationUtils.loadAnimation(mOwner, R.anim.visible_from_bottom));
			vOptPanel.setVisibility(View.VISIBLE);
		}else if(mOwner.getState() == IServer.PARKING_STATE_CAR_IN) {
			vOptBtn.setText("代 操 作");
			isInstead = true;
			vOptPanel.setVisibility(View.GONE);
			vOptPanel.startAnimation(AnimationUtils.loadAnimation(mOwner, R.anim.visible_from_bottom));
			vOptPanel.setVisibility(View.VISIBLE);
		}else{
			vOptPanel.setVisibility(View.GONE);
		}
	}
	
	private boolean mDoOkAction;
	
	private void doOk(){
		if(mDoOkAction){
			return;
		}
		mOwner.showProgressDialog();
		getJsonFromServer(mOwner.getServer().getURL(IServer.URL_FLAG_POST_QUARTER_ANSWER, 
				mOwner.getOrderViewModel().getId(),mOwner.getOrderViewModel().getOrder_id(),
				mOwner.getOrderViewModel().getCar_in_time() == null ? "1" : "2"));
	}
	
	public void doOk(String orderid){
		if(mDoOkAction){
			return;
		}
		mOwner.showProgressDialog();
		getJsonFromServer(mOwner.getServer().getURL(IServer.URL_FLAG_POST_QUARTER_ANSWER, 
				mOwner.getOrderViewModel().getId(), orderid,
				mOwner.getOrderViewModel().getCar_in_time() == null ? "1" : "2"));
	}
	
	@Override
	protected void callbackFromGetJsonFail(int failcode, String msg) {
		// TODO Auto-generated method stub
		mOwner.dismissDialog(BaseActivity.DIALOG_PROGRESS);
		Log.i("qh", "物业放行 fail result : " + msg);
		handleFail();
	}
	
	@Override
	protected void callbackFromGetJsonSuccess(String json) {
		// TODO Auto-generated method stub
		mOwner.dismissDialog(BaseActivity.DIALOG_PROGRESS);
		boolean success = false;
		Log.i("qh", "物业放行 success result : " + json);
		try {
			JSONObject jobj = new JSONObject(json);
			success = jobj.getBoolean("success");
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(success){
			mOwner.showToastTips("操作成功");
			mOwner.setResult(-2);
			mOwner.finish();
//			mOwner.reqRefreshFromFragUI();
			mDoOkAction = false;
		}else{
			handleFail();
		}
	}
	
	private void handleFail(){
		mOwner.showToastTips("操作失败，请稍后再试");
		mDoOkAction = false;
	}
	
	public void refresh(){
		initViews();
	}
}
