package com.sendi.lhparking.ui.common.frag;

import java.util.List;


import android.content.Intent;

import com.google.gson.reflect.TypeToken;
import com.sendi.lhparking.adapter.CompletedOrderAdapter;
import com.sendi.lhparking.ctx.ParkingConstant;
import com.sendi.lhparking.model.CompletedOrder;
import com.sendi.lhparking.server.IServer;
import com.sendi.lhparking.ui.baoan.BaoanMainActivity;
import com.sendi.lhparking.ui.common.OrderListActivity;
import com.sendi.lhparking.ui.common.ViewOrderActivity;
import com.sendi.lhparking.ui.common.ViewOrderHistoryActivity;

/**
 * 已完成订单列表
 * @author Administrator
 *
 */
public class CompletedOrderListFragment extends RefreshListFragment<CompletedOrder, OrderListActivity>{

	@Override
	protected void initListAdapter() {
		// TODO Auto-generated method stub
		mListAdapter = new CompletedOrderAdapter(mOwner);
	}

	@Override
	protected String getRefreshURL() {
		// TODO Auto-generated method stub
		return mOwner.getServer().getURL(IServer.URL_FLAG_GET_ORDER_LIST_COMPLETED);
	}

	@Override
	protected void viewModelByItemClick(CompletedOrder m) {
		// TODO Auto-generated method stub
		Intent intent = new Intent(mOwner, ViewOrderHistoryActivity.class);
		intent.putExtra(ParkingConstant.INTENT_EXTRA_ORDER_ID, m.getId());
		startActivity(intent);
	}

	@Override
	protected CharSequence getEmptyText() {
		// TODO Auto-generated method stub
		return "在这里查看车位预约的情况\n下拉可以刷新";
	}

	@SuppressWarnings("rawtypes")
	@Override
	protected TypeToken getListModelTypeToken() {
		// TODO Auto-generated method stub
		return new TypeToken<List<CompletedOrder>>(){};
	}

	@Override
	protected void handleModels(List<CompletedOrder> models) {
		// TODO Auto-generated method stub
		for(CompletedOrder order : models){
			order.setOrderId(order.getId()+"_"+order.getType());
		}
	}
}
