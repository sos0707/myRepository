package com.sendi.lhparking.ui.common.frag;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;

public class WaitingDialogFragment extends DialogFragment{
	
	public static WaitingDialogFragment newInstance(String msg){
		WaitingDialogFragment dialog = new WaitingDialogFragment();
		
		Bundle d = new Bundle();
		d.putString("message", msg);
		
		dialog.setArguments(d);
		
		return dialog;
	}
	
	@Override
	public Dialog onCreateDialog(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		ProgressDialog dialog = new ProgressDialog(getActivity());
		dialog.setMessage(getArguments().getString("message"));
		return dialog;
	}

}
