package com.sendi.lhparking.ui.common.frag;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.text.InputType;
import android.util.Log;
import android.widget.EditText;
import android.widget.Toast;

public class InputDialogFragment extends DialogFragment {
	
	private ViewOrderQuarterOwnerFragment fragment;
	static InputDialogFragment newInstance(String title) {
		InputDialogFragment dialog = new InputDialogFragment();
		Bundle bundle = new Bundle();
		bundle.putString("title", title);
		dialog.setArguments(bundle);
		return dialog;
	}

	@Override
	public Dialog onCreateDialog(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		final String title = getArguments().getString("title");

		AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
		final EditText edPsw = new EditText(getActivity());
		edPsw.setInputType(InputType.TYPE_CLASS_NUMBER);
		builder.setTitle("提醒");
		builder.setMessage(title);
		builder.setCancelable(false);
		builder.setView(edPsw);
		builder.setCancelable(true);
		builder.setNegativeButton("取消",
				new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						return;
					}
				});
		builder.setPositiveButton("确定",
				new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub\
						String strInput = edPsw.getText().toString();
						if( 0 == edPsw.getText().length()) {
//							loginPsw = "null";
							Toast.makeText(getActivity(), title, Toast.LENGTH_SHORT).show();
							return;
						}
						Toast.makeText(getActivity(), title+strInput, Toast.LENGTH_SHORT).show();
						fragment.doOk(strInput);
					}
				});	
		return builder.create();
	}
	
	public void setFragment(ViewOrderQuarterOwnerFragment frag) {
		this.fragment = frag;
	}
}
