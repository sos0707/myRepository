package com.sendi.lhparking.ui.common.frag;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.sendi.parking.ui.R;

import com.ab.view.pullview.AbPullToRefreshView;
import com.ab.view.pullview.AbPullToRefreshView.OnHeaderRefreshListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.lidroid.xutils.DbUtils;
import com.lidroid.xutils.exception.DbException;
import com.sendi.lhparking.adapter.PullListAdapter;
import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.ui.common.base.BaseFragment;
import com.sendi.lhparking.ui.common.base.BaseFragmentActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.TextView;

/**
 * 订单列表的抽象类
 * @author Administrator
 * 
 * @param <T>
 */
public abstract class RefreshListFragment<M/* Model */, A extends BaseFragmentActivity/* Activity */>
		extends BaseFragment<A> implements OnHeaderRefreshListener {

	private Class<M> mModelCls;// 获取 M 的class类型 用于操作 DB

	protected AbPullToRefreshView vPull;
	protected ListView vList;
	protected TextView vEmpty;

	protected PullListAdapter<M> mListAdapter;

	@SuppressWarnings("unchecked")
	public RefreshListFragment() {
		Type genType = getClass().getGenericSuperclass();
		Type[] params = ((ParameterizedType) genType).getActualTypeArguments();
		mModelCls = (Class<M>) params[0];
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		Log.i("qh", "fragment : on create view");
		View view = inflater    // 订单列表的layout
				.inflate(R.layout.layout_pull_to_refresh_list, null);
		vPull = (AbPullToRefreshView) view    // 下拉刷新顶部显示
				.findViewById(R.id.layout_pull_list_pull);
		vList = (ListView) view.findViewById(R.id.layout_pull_list_list);   // 订单list
		vEmpty = (TextView) view.findViewById(R.id.layout_pull_list_empty);
		
		return view;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onActivityCreated(savedInstanceState);
		Log.i("qh", "fragment : on activity create");
		initViews();
//		refreshListViewFromLocal();
		if(ParkingApp.mAppCtx.isAutoLogin()){
			refreshListViewFromServer();
		}
		ParkingApp.mAppCtx.setOrderHandler(orderHandler);
	}
	
	private void initViews(){
		vPull.setOnHeaderRefreshListener(this);
		vPull.getHeaderView().setHeaderProgressBarDrawable(
				getResources().getDrawable(R.drawable.progress_circular));
		vPull.setPullRefreshEnable(true);
		vPull.setLoadMoreEnable(false);

		initListAdapter();//
		vList.setAdapter(mListAdapter);
		vList.setEmptyView(vEmpty);
		vEmpty.setMovementMethod(ScrollingMovementMethod.getInstance());// 让empty接受滑动事件
		vEmpty.setText(getEmptyText());

		vList.setOnItemClickListener(new OnItemClickListener() {

			@SuppressWarnings("unchecked")
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				M m = (M) mListAdapter.getItem(position);
				viewModelByItemClick(m);
			}
		});
	}

	@Override
	public void onHeaderRefresh(AbPullToRefreshView view) {
		// TODO Auto-generated method stub
		refreshListViewFromServer();
	}

	/**
	 * 通过查询获取本地DB数据，刷新订单列表
	 * */
	protected void refreshListViewFromLocal() {
		DbUtils db = mOwner.getDB();
		try {
			List<M> models = db.findAll(mModelCls);
			if (models == null) {
				return;
			}
			Log.i("qh", "refreshListViewFromLocal");
			mListAdapter.setNewData(models);
		} catch (DbException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * 请求服务器， 刷新数据
	 * */
	protected void refreshListViewFromServer() {
		getJsonFromServer(getRefreshURL());
	}

	// call back
	protected void callbackFromGetJsonSuccess(String json) {
		Log.i("qh", "json : "+json);
		vPull.onHeaderRefreshFinish();
		String jsonlist = null;
		try {
			JSONObject jobj = new JSONObject(json);
			JSONArray jarr = jobj.getJSONArray("data");
			jsonlist = jarr.toString();
		} catch (JSONException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
//		Log.i("qh", "json : "+json);
		if (jsonlist == null) {
			Log.i("qh", "no data or fail...");
			return;
		}
		Gson gson = new Gson();
		List<M> models = gson.fromJson(jsonlist, getListModelTypeToken().getType());
		Log.i("qh", "models.size : "+models.size());
		handleModels(models);
		try {
			mOwner.getDB().deleteAll(mModelCls);
			mOwner.getDB().saveAll(models);
			refreshListViewFromLocal();
		} catch (DbException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			mListAdapter.setNewData(models);
		}
	}

	protected void callbackFromGetJsonFail(int failcode, String msg) {
		// empty
		vPull.onHeaderRefreshFinish();
		if (failcode == 0) {
			mOwner.showToastTips("加载失败:无法连接服务器");
		} else {
			mOwner.showToastTips("加载失败[" + failcode + "]: " + msg);
		}
	}

	Handler orderHandler = new Handler(){

		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			refreshListViewFromServer();
		}
		
	};
	
	
	@Override
	public void onResume() {
		// TODO Auto-generated method stub
		if(ParkingApp.mAppCtx.isAutoLogin()){
			refreshListViewFromServer();
		}
		super.onResume();
	}

	/**
	 * 子类只管4件事情: 
	 * 1.listview显示成神马样子 因此要提供adapter 
	 * 2.数据在服务器的哪里 因此要提供URL 
	 * 3.数据该给谁去显示因此要提供如何响应item click 
	 * 4.Empty view要如何提示用户 因此要提供empty显示的文本
	 */

	// init mListAdapter
	protected abstract void initListAdapter();

	protected abstract CharSequence getEmptyText();

	protected abstract String getRefreshURL();

	protected abstract void viewModelByItemClick(M m);
	//TypeToken<List<M>> token = new TypeToken<List<M>>(){};
	@SuppressWarnings("rawtypes")
	protected abstract TypeToken getListModelTypeToken();
	
	protected void handleModels(List<M> models){
		
	}
}
