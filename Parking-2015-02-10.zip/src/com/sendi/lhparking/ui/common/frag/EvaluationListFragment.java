package com.sendi.lhparking.ui.common.frag;

import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;
import org.sendi.parking.ui.R;

import com.ab.util.AbStrUtil;
import com.ab.view.pullview.AbPullToRefreshView;
import com.ab.view.pullview.AbPullToRefreshView.OnFooterLoadListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.sendi.lhparking.adapter.ListDataCanRefreshAdapter;
import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.model.EvaluationInfo;
import com.sendi.lhparking.model.EvaluationItem;
import com.sendi.lhparking.server.IServer;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;
/**
 * 评价list
 * @author Administrator
 *
 */
public class EvaluationListFragment extends Fragment implements OnFooterLoadListener{
	
	private static final String DATA_KEY_UID = "key_uid";
	
	private TextView vUserName;//帐号 
//	private TextView vNickName;//昵称
	
	private RatingBar vAvgRating;
	private TextView vAvgScore;
	
	private TextView vEvaTotal;//总数
	private TextView vEvaGood;//好评
	private TextView vEvaAvg;//中评
	private TextView vEvaBad;//差评
	
	private ListView vList;
	private AbPullToRefreshView vPull;
	
	private WaitingDialogFragment mDialogFrag;
	private IServer mServer;
	
	private EvaluationInfo mInfo;
	
	private String mEvaUID;
	private int mTotalItems = 5;
	
	private EvaItemAdapter mAdapter;
	
	public static EvaluationListFragment newInstance(String evauid){
		EvaluationListFragment frag = new EvaluationListFragment();
		Bundle d = new Bundle();
		d.putString(DATA_KEY_UID, evauid);
		frag.setArguments(d);
		return frag;
	}
	
	@Override
	public void onAttach(Activity activity) {
		// TODO Auto-generated method stub
		super.onAttach(activity);
		mServer = ParkingApp.mAppCtx.getServerConfig();
		Bundle d = getArguments();
		mEvaUID = d.getString(DATA_KEY_UID);
		mAdapter = new EvaItemAdapter(activity);
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		return LayoutInflater.from(getActivity()).inflate(R.layout.frag_evaluation_list, null);
	}
	
	@Override
	public void onViewCreated(View view, Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		findViews(view);
	}
	
	private void findViews(View root){
		vUserName = (TextView) root.findViewById(R.id.frag_evaluation_list_name);
		vAvgRating = (RatingBar) root.findViewById(R.id.frag_evaluation_list_rating_bar);
		vAvgScore = (TextView) root.findViewById(R.id.frag_evaluation_list_score);
		
		vEvaTotal = (TextView) root.findViewById(R.id.frag_evaluation_list_count);
		vEvaAvg = (TextView) root.findViewById(R.id.frag_evaluation_list_avg);
		vEvaBad = (TextView) root.findViewById(R.id.frag_evaluation_list_bad);
		vEvaGood = (TextView) root.findViewById(R.id.frag_evaluation_list_good);
		
		vList = (ListView) root.findViewById(R.id.frag_evaluation_list_list);
		vList.setAdapter(mAdapter);
		vPull = (AbPullToRefreshView) root.findViewById(R.id.frag_evaluation_list_pull);
		vPull.setPullRefreshEnable(false);
		vPull.setOnFooterLoadListener(this);
		
	}
	
	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onActivityCreated(savedInstanceState);
		loadInfoFromServer();
		loadItemList();
	}
	
	private void loadInfoFromServer(){
		if(mDialogFrag == null){
			mDialogFrag = WaitingDialogFragment.newInstance("正在载入信息...");
		}
		mDialogFrag.show(getFragmentManager(), "wait");
		loadJsonDataFromServer(mServer.getURL(IServer.URL_FLAG_GET_EVALUATION_TOTAL_INFO, mEvaUID), new InfoCallBack());
	}
	
	// startindex 数据起始编号 分段加载
	private void loadItemList(){
		int startindex = mAdapter.getCount();
		loadJsonDataFromServer(mServer.getURL(IServer.URL_FLAG_GET_EVALUATION_ITEMS, mEvaUID, String.valueOf(startindex)), new ItemCallBack());
	}
	
	private void loadJsonDataFromServer(String url, RequestCallBack<String> callback){
		Log.i("qh", "url : "+url);
		HttpUtils http = new HttpUtils();
		http.send(HttpMethod.GET, url, callback);
	}
	
	private void showToast(String msg){
		Toast.makeText(getActivity(), msg, Toast.LENGTH_LONG).show();
	}
	/**
	 * 
	 * @author Administrator
	 *
	 */
	class InfoCallBack extends RequestCallBack<String>{

		@Override
		public void onSuccess(ResponseInfo<String> responseInfo) {
			// TODO Auto-generated method stub
			mDialogFrag.dismiss();
			String json = responseInfo.result;
			Log.i("qh", "json : "+json);
			if(AbStrUtil.isEmpty(json)){
				showToast("数据出错");
				return ;
			}
			Gson g = new Gson();
			mInfo = g.fromJson(json, EvaluationInfo.class);
			if(mInfo == null){
				showToast("数据出错");
				return ;
			}
			refreshUI();
		}

		@Override
		public void onFailure(HttpException error, String msg) {
			// TODO Auto-generated method stub
			mDialogFrag.dismiss();
			showToast("数据出错");
		}
		
	}
	
	private void refreshUI(){
		vUserName.setText(mInfo.getName());
		vAvgScore.setText(mInfo.getAvg_point());
		vAvgRating.setRating(Float.valueOf(mInfo.getAvg_point()));
		vEvaTotal.setText(mInfo.getTotal_num());
		vEvaAvg.setText(mInfo.getNormal_sum());
		vEvaGood.setText(mInfo.getGood_sum());
		vEvaBad.setText(mInfo.getBad_sum());
		
		mTotalItems = Integer.valueOf(mInfo.getTotal_num());
	}
	
	/**
	 * 
	 * @author Administrator
	 *
	 */
	class ItemCallBack extends RequestCallBack<String>{

		@Override
		public void onSuccess(ResponseInfo<String> responseInfo) {
			// TODO Auto-generated method stub
			vPull.onFooterLoadFinish();
			String json = responseInfo.result;
			Log.i("qh", "json : "+json);
			if(AbStrUtil.isEmpty(json)){
				showToast("评价列表获取失败");
				return;
			}
			String data = null;
			try {
				JSONObject jobj = new JSONObject(json);
				if(jobj.getInt("totalCount") <= 0){
					return ;
				}
				data = jobj.getJSONArray("data").toString();
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Log.i("qh", "data : "+data);
			TypeToken<List<EvaluationItem>> token = new TypeToken<List<EvaluationItem>>(){};
			Gson g = new Gson();
			List<EvaluationItem> list = g.fromJson(data, token.getType());
			Log.i("qh", list == null ? "list is null " : "list size "+list.size()); 
			mAdapter.addNewData(list);
		}

		@Override
		public void onFailure(HttpException error, String msg) {
			// TODO Auto-generated method stub
			vPull.onFooterLoadFinish();
			showToast("加载数据失败");
		}
		
	}
	
	class EvaItemAdapter extends ListDataCanRefreshAdapter<EvaluationItem>{

		public EvaItemAdapter(Context mContext) {
			super(mContext);
			// TODO Auto-generated constructor stub
		}

		@Override
		protected int getItemLayoutId() {
			// TODO Auto-generated method stub
			return R.layout.item_frag_eva_list;
		}

		@Override
		protected Object initObjTag(View converView) {
			// TODO Auto-generated method stub
			ViewHolder vh = new ViewHolder();
			vh.vEvaComment = (TextView) converView.findViewById(R.id.item_eva_list_eva_info);
			vh.vEvaId = (TextView) converView.findViewById(R.id.item_eva_list_uid);
			vh.vEvaTime = (TextView) converView.findViewById(R.id.item_eva_list_date);
			vh.vEvaRating = (RatingBar) converView.findViewById(R.id.item_eva_list_ratingbar);
			return vh;
		}

		@Override
		protected void bindView(Object tag, EvaluationItem evaitem) {
			// TODO Auto-generated method stub
			ViewHolder vh = (ViewHolder) tag;
			vh.vEvaComment.setText(evaitem.getComment());
			vh.vEvaId.setText(hideName(evaitem.getMaster()));
			vh.vEvaTime.setText(evaitem.getReview_time());
			vh.vEvaRating.setRating(Float.valueOf(evaitem.getPoint()));
		}
		
		private String hideName(String name){
			StringBuilder sb = new StringBuilder();
			sb.append(name.charAt(0));
			sb.append("***");
			sb.append(name.charAt(name.length() - 1));
			return sb.toString();
		}
		
		class ViewHolder{
			TextView vEvaId;
			TextView vEvaTime;
			TextView vEvaComment;
			RatingBar vEvaRating;
		}
		
	}

	@Override
	public void onFooterLoad(AbPullToRefreshView view) {
		// TODO Auto-generated method stub
		if(mTotalItems == mAdapter.getCount()){
			showToast("没有更多评价");
			view.onFooterLoadFinish();
			return;
		}
		loadItemList();
	}
}
