package com.sendi.lhparking.ui.common.frag;

import org.json.JSONException;
import org.json.JSONObject;
import org.sendi.parking.ui.R;

import com.ab.util.AbStrUtil;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.model.Evaluation;
import com.sendi.lhparking.server.IServer;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;

/**
 * 订单评价
 * 
 * @author Administrator
 * 
 */
public class EvaluationOrderFragment extends Fragment {

	public static EvaluationOrderFragment newInstance(String orderid,
			String masterid, String guestid) {
		EvaluationOrderFragment eva = new EvaluationOrderFragment();

		Bundle d = new Bundle();
		d.putString(ARGUS_ORDER_ID, orderid);
		d.putString(ARGUS_MASTER_ID, masterid);
		d.putString(ARGUS_GUEST_ID, guestid);

		eva.setArguments(d);
		return eva;
	}

	public static final String ARGUS_ORDER_ID = "orderid";
	public static final String ARGUS_MASTER_ID = "master";
	public static final String ARGUS_GUEST_ID = "guest";

	private RatingBar vRatingBar;
	private EditText vEvaluationEdit;
	private Button vSubmit;

	private Evaluation mEvaluation;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		return inflater.inflate(R.layout.frag_evaluation_order, null);
	}

	@Override
	public void onViewCreated(View view, Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onViewCreated(view, savedInstanceState);
		findViews(view);
	}

	private void findViews(View view) {
		// TODO Auto-generated method stub
		vRatingBar = (RatingBar) view
				.findViewById(R.id.evalution_order_ratingbar);
		vEvaluationEdit = (EditText) view
				.findViewById(R.id.evalution_order_edit);
		vEvaluationEdit.setOnEditorActionListener(new OnEditorActionListener() {
			
			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				// TODO Auto-generated method stub
				switch(actionId) {
				case EditorInfo.IME_ACTION_DONE:
					vSubmit.performClick();
					break;
				}
				return false;
			}
		});
		vSubmit = (Button) view.findViewById(R.id.evalution_order_submit);

		vSubmit.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Evaluation eva = getEvaluation();
				if (checkEvaluation(eva)) {
					submitEvaluation(eva);
				}
			}
		});
	}

	private boolean checkEvaluation(Evaluation eva) {
		// TODO Auto-generated method stub
		if (eva.getMaster() == null || eva.getTask_id() == null
				|| eva.getGuest() == null) {
			return false;
		}
		if (AbStrUtil.isEmpty(eva.getComment())
				|| eva.getComment().length() < 5) {
			showToast("请输入评价信息");
			return false;
		}
		return true;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onActivityCreated(savedInstanceState);
		mEvaluation = new Evaluation();
		Bundle data = getArguments();
		mEvaluation.setTask_id(data.getString(ARGUS_ORDER_ID));
		mEvaluation.setMaster(data.getString(ARGUS_MASTER_ID));
		mEvaluation.setGuest(data.getString(ARGUS_GUEST_ID));
	}

	public Evaluation getEvaluation() {
		mEvaluation.setPoint(String.valueOf(vRatingBar.getRating()));
		mEvaluation.setComment(vEvaluationEdit.getText().toString());
		return mEvaluation;
	}

	private void submitEvaluation(Evaluation eva) {
		IServer server = ParkingApp.mAppCtx.getServerConfig();
		String url = server.getURL(
				IServer.URL_FLAG_POST_EVALUATION_TO_PARKING_OWNER,
				eva.getTask_id(), eva.getMaster(), eva.getGuest(),
				eva.getPoint(), eva.getComment());
		final WaitingDialogFragment dialog = WaitingDialogFragment
				.newInstance("正在提交评论...");
		dialog.show(getFragmentManager(), "dialog");
		HttpUtils http = new HttpUtils();
		http.configDefaultHttpCacheExpiry(0);// 1秒内请求 使用缓存
		Log.i("qh", "url : " + url);
		http.send(HttpMethod.GET, url, new RequestCallBack<String>() {

			@Override
			public void onSuccess(ResponseInfo<String> responseInfo) {
				// TODO Auto-generated method stub
				dialog.dismiss();
				String json = responseInfo.result;
				boolean success = false;
				String msg = null;
				try {
					JSONObject jobj = new JSONObject(json);
					success = jobj.getBoolean("success");
					if (success) {
						showToast("评论成功");
						getActivity().setResult(Activity.RESULT_OK);
						getActivity().finish();
					} else {
						msg = jobj.getString("msg");
						showToast(msg == null ? "提交评价失败" : msg);
					}
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			@Override
			public void onFailure(HttpException error, String msg) {
				// TODO Auto-generated method stub
				dialog.dismiss();
				showToast("提交评价失败");
			}
		});
	}

	private void showToast(String msg) {
		Toast.makeText(getActivity(), msg, Toast.LENGTH_LONG).show();
	}
}
