package com.sendi.lhparking.ui.common.frag;

import org.json.JSONException;
import org.json.JSONObject;
import org.sendi.parking.ui.R;

import com.ab.util.AbStrUtil;
import com.sendi.lhparking.server.IServer;
import com.sendi.lhparking.ui.common.ViewEvaluationListActivity;
import com.sendi.lhparking.ui.common.ViewOrderActivity;
import com.sendi.lhparking.ui.common.base.BaseActivity;
import com.sendi.lhparking.ui.common.base.BaseFragment;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

/**
 * 代表业主
 * 
 * @author Administrator
 * 
 */
public class ViewOrderParkingOwnerFragment extends
		BaseFragment<ViewOrderActivity> {

	private TextView vBaseQuarter;
	private TextView vBaseState;
	private TextView vBasePrice;
	private TextView vBaseTime;

	private View vCarPanel;
	private TextView vCarOwner;
	private TextView vCarNum;

	private View vOptPanel;
	private TextView vOptLeft;
	private TextView vOptRight;

	@Override
	public void onAttach(Activity activity) {
		// TODO Auto-generated method stub
		super.onAttach(activity);
		Log.i("qh", "业主 fragment on attach");
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		View view = inflater.inflate(R.layout.frag_view_order_parking_owner,
				null);
		findBasePanel(view);
		// if(mOwner.getState() != IServer.PARKING_STATE_EMPTY){
		findAndInitCarPanel(view);
		// }
		// if(mOwner.getState() == IServer.PARKING_STATE_WAIT_CONFIRM){
		findOptionPanel(view);
		// }
		return view;
	}

	private void findBasePanel(View root) {
		vBaseQuarter = (TextView) root
				.findViewById(R.id.layout_view_order_parking_quarter);
		vBaseState = (TextView) root
				.findViewById(R.id.layout_view_order_parking_state);
		vBasePrice = (TextView) root
				.findViewById(R.id.layout_view_order_parking_price);
		vBaseTime = (TextView) root
				.findViewById(R.id.layout_view_order_parking_time);
	}

	private void findAndInitCarPanel(View view) {
		// TODO Auto-generated method stub
		vCarPanel = view.findViewById(R.id.layout_view_order_car_panel);
		vCarOwner = (TextView) view
				.findViewById(R.id.layout_view_order_car_owner);
		vCarOwner.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				startActivity(ViewEvaluationListActivity.getLaunchIntent(mOwner, mOwner.getOrderViewModel().getWorker_id(), 
						ViewEvaluationListActivity.TYPE_SEE_CAR));
			}
		});
		vCarNum = (TextView) view.findViewById(R.id.layout_view_order_car_num);
	}

	private void findOptionPanel(View root) {
		vOptPanel = root.findViewById(R.id.frag_vorder_po_option_panel);
		vOptLeft = (TextView) root
				.findViewById(R.id.frag_vorder_po_opt_left_btn);
		vOptRight = (TextView) root
				.findViewById(R.id.frag_vorder_po_opt_right_btn);

		vOptLeft.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				doRefuse();
			}
		});

		vOptRight.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				doAccept();
			}
		});
		if(mOwner.getState() == IServer.PARKING_STATE_CONFIRM) {
			vOptPanel.setVisibility(View.GONE);
			return;
		}
		vOptLeft.setText("拒绝");
		vOptLeft.setTextColor(getResources().getColor(R.color.text_color_red));
		vOptRight.setText("通过");
		vOptRight.setTextColor(getResources().getColor(
				R.color.text_color_light_blue));
	}

	private void initViews() {
		vBaseQuarter.setText(mOwner.getOrderViewModel().getParking_no());
		vBaseState.setText(mOwner.getOrderViewModel().getState());
		vBasePrice.setText(mOwner.getOrderViewModel().getPrice());
		vBaseTime.setText(mOwner.getOrderViewModel().getBooked_time_range());

		if (mOwner.getState() != IServer.PARKING_STATE_EMPTY) {
			vCarPanel.setVisibility(View.VISIBLE);
			vCarOwner.setText(mOwner.getOrderViewModel().getWorker_name());
			vCarOwner.setPadding(0, 0, 10, 0);
			vCarOwner.setCompoundDrawables(null, null, getResources().getDrawable(R.drawable.right_tri), null);
			vCarNum.setText(mOwner.getOrderViewModel().getCar_no());
		} else {
			vCarPanel.setVisibility(View.GONE);
		}

		if (mOwner.getState() == IServer.PARKING_STATE_WAIT_CONFIRM) {
			vOptPanel.setVisibility(View.GONE);
			vOptPanel.startAnimation(AnimationUtils.loadAnimation(mOwner,
					R.anim.visible_from_bottom));
			vOptPanel.setVisibility(View.VISIBLE);
		} else {
			vOptPanel.setVisibility(View.GONE);
		}
	}

//	private SpannableString getCarOwner() {
//		String carrate = "(点击查看信用)";
//		String carownername = mOwner.getOrderViewModel().getWorker_name();
//
//		SpannableString span = new SpannableString(carrate + carownername);
//		span.setSpan(
//				new ForegroundColorSpan(getResources().getColor(
//						R.color.text_color_orange)), 0, carrate.length(),
//				SpannableString.SPAN_EXCLUSIVE_EXCLUSIVE);
//
//		return span;
//	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onActivityCreated(savedInstanceState);
		initViews();
	}

	// accept refuse dialog
	private static final int OPT_ACCEPT = 1;
	private static final int OPT_REFUSE = 2;

	private int mOptType;
	private boolean ifTrust;
	private AlertDialog mOptDialog;

	private void doRefuse() {
		mOptType = OPT_REFUSE;
		showOptConfirmDialog();
	}

	private void doAccept() {
		mOptType = OPT_ACCEPT;
		showOptConfirmDialog();
	}

	private void showOptConfirmDialog() {
		if (mOptDialog != null) {
			mOptDialog = null;
		}
		mOptDialog = new AlertDialog.Builder(mOwner)
				.setMultiChoiceItems(new String[] { "自动审核所有人的预约" },
						new boolean[] { false },
						new DialogInterface.OnMultiChoiceClickListener() {

							@Override
							public void onClick(DialogInterface dialog,
									int which, boolean isChecked) {
								// TODO Auto-generated method stub
								ifTrust = isChecked;
							}
						})
				.setNegativeButton("取消", new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						mOptType = -1;
						ifTrust = false;
					}
				})
				.setPositiveButton("确定", new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						String url = null;
						if (mOptType == OPT_ACCEPT) {    // 通过
							url = mOwner
									.getServer()
									.getURL(IServer.URL_FLAG_POST_ANSWER_TO_PARKING_REQ,
											mOwner.getOrderViewModel().getId(),
											String.valueOf(IServer.PARKING_OWNER_ACCEPT),
											String.valueOf(ifTrust));
						} else if (mOptType == OPT_REFUSE) {   // 拒绝
							url = mOwner
									.getServer()
									.getURL(IServer.URL_FLAG_POST_ANSWER_TO_PARKING_REQ,
											mOwner.getOrderViewModel().getId(),
											String.valueOf(IServer.PARKING_OWNER_REFUSE),
											String.valueOf(ifTrust));
						}
						reqOpt(url);
						mOptType = -1;
						ifTrust = false;
					}
				}).create();
		mOptDialog.setTitle((mOptType == OPT_ACCEPT ? "通过" : "拒绝") + "对该停车请求");
		mOptDialog.show();
	}

	private void reqOpt(String url) {
		if (AbStrUtil.isEmpty(url)) {
			return;
		}
		mOwner.showProgressDialog();
		getJsonFromServer(url);
	}

	@Override
	protected void callbackFromGetJsonFail(int failcode, String msg) {
		// TODO Auto-generated method stub
		mOwner.dismissDialog(BaseActivity.DIALOG_PROGRESS);
		mOwner.showToastTips("操作失败，请稍后再试");
	}

	@Override
	protected void callbackFromGetJsonSuccess(String json) {
		// TODO Auto-generated method stub
		mOwner.dismissDialog(BaseActivity.DIALOG_PROGRESS);
		boolean success = false;
		try {
			JSONObject jobj = new JSONObject(json);
			success = jobj.getBoolean("success");
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (success) {
			mOwner.showToastTips("操作成功");
			vOptPanel.setVisibility(View.GONE);
			Message msg = mHandler.obtainMessage();
			msg.what = 1;
			mHandler.sendMessage(msg);
			mOwner.finish();
//			mOwner.reqRefreshFromFragUI();
		} else {
			mOwner.showToastTips("操作失败，请稍后再试");
		}

	}

	public void refresh() {
		initViews();
	}
	
	Handler mHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			mOwner.reqRefreshFromFragUI();
		}
		
	};
}
