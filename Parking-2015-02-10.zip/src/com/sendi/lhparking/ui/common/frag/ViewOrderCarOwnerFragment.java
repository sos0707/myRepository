package com.sendi.lhparking.ui.common.frag;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.json.JSONException;
import org.json.JSONObject;
import org.sendi.parking.ui.R;

import com.baidu.navisdk.BNaviPoint;
import com.baidu.navisdk.BaiduNaviManager;
import com.baidu.navisdk.BaiduNaviManager.OnStartNavigationListener;
import com.baidu.navisdk.comapi.routeplan.RoutePlanParams.NE_RoutePlan_Mode;
import com.lidroid.xutils.DbUtils;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.DbException;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.ctx.ParkingConstant;
import com.sendi.lhparking.func.barcode.main.CaptureActivity;
import com.sendi.lhparking.model.CarInTime;
import com.sendi.lhparking.model.ScanTask;
import com.sendi.lhparking.server.IServer;
import com.sendi.lhparking.ui.chezhu.MapLocationActivity;
import com.sendi.lhparking.ui.chezhu.NavigatorActivity;
import com.sendi.lhparking.ui.common.AccountActivity;
import com.sendi.lhparking.ui.common.ViewOrderActivity;
import com.sendi.lhparking.ui.common.ViewOrderHistoryActivity;
import com.sendi.lhparking.ui.common.base.BaseFragment;
import com.sendi.lhparking.util.AccountBaseInfo;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnDismissListener;
import android.net.Uri;
import android.os.Bundle;
import android.os.Message;
import android.os.SystemClock;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 代表车主
 * @author Administrator
 *
 */
public class ViewOrderCarOwnerFragment extends BaseFragment<ViewOrderActivity> implements OnClickListener{
	
	public static final int REQ_CODE_CAPTURE = 111;//请求二维码扫描
	
	private TextView vBaseQuarter;
	private TextView vBaseState;
	private TextView vBasePrice;
	private TextView vBaseTime;
	private TextView vBaseParkingOwner;
	
	private View vTimePanel;
	private Chronometer vTime;
	
	private View vOptPanel;
	private TextView vOptBtn;
	private TextView vOptBtn2;
	private LinearLayout layout;
	private TextView vCallTel;
	private CarInTime mInTime;
	private ProgressDialog mDialog;
	private String curShowView = "0";
	private int dialogDismiss = 0;
	private Button btnNavigator;
	private Button btnPhone;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		View view = inflater.inflate(R.layout.frag_view_order_car_owner, null);
		findBasePanel(view);
		findOptPanel(view);
		findTimePanel(view);
		return view;
	}

	private void findBasePanel(View root){
		vBaseQuarter = (TextView) root.findViewById(R.id.layout_view_order_parking_quarter);
		vBaseState = (TextView) root.findViewById(R.id.layout_view_order_parking_state);
		vBasePrice = (TextView) root.findViewById(R.id.layout_view_order_parking_price);
		vBaseTime = (TextView) root.findViewById(R.id.layout_view_order_parking_time);
		vBaseParkingOwner = (TextView) root.findViewById(R.id.layout_view_order_parking_owner);
		root.findViewById(R.id.layout_view_order_parking_owner_panel).setVisibility(View.VISIBLE);
	}
	
	private void findOptPanel(View view){
		vOptPanel = view.findViewById(R.id.frag_vorder_co_option_panel);
		layout = (LinearLayout) view.findViewById(R.id.layout_toast);
		vCallTel = (TextView) view.findViewById(R.id.tv_call_tel);
		btnPhone = (Button)view.findViewById(R.id.btn_call_tel);
		vOptBtn = (TextView) view.findViewById(R.id.frag_vorder_co_opt_btn);
		vOptBtn2 = (TextView) view.findViewById(R.id.frag_vorder_co_opt);
		btnNavigator = (Button) view.findViewById(R.id.btn_navigator);
		
		btnNavigator.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				launchNavigator();
			}
		});
		
		vOptBtn2.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				doCancelOrder();
			}
		});
		
		btnPhone.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
//				Toast.makeText(mOwner, "打电话通知物业", Toast.LENGTH_SHORT).show();
				makeCall(mOwner, vCallTel.getText().toString());
			}
		});
	}
	
	private void findTimePanel(View view){
		vTime = (Chronometer) view.findViewById(R.id.layout_time_timer);
		vTimePanel = view.findViewById(R.id.frag_vorder_co_carintime_panel);
	}
	
	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onActivityCreated(savedInstanceState);
		initViews();
	}
	
	@Override
	public void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		vTime.start();
	}
	
	@Override
	public void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		vTime.stop();
	}
	
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		Log.i("qh", "car frag : on activity result : req_ "+requestCode +" , res_ "+resultCode);
		if(requestCode == REQ_CODE_CAPTURE){
			if(resultCode == Activity.RESULT_OK){
				if(mOwner.getState() == IServer.PARKING_STATE_CONFIRM){//进场成功
//					CarInTime time = new CarInTime();
//					time.setOid(mOwner.getOrderViewModel().getId());
//					time.setTime(System.currentTimeMillis());
//					try {
//						mOwner.getDB().save(time);
//					} catch (DbException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
				}else{//离场成功
					Intent intent = new Intent(mOwner, ViewOrderHistoryActivity.class);
					intent.putExtra(ParkingConstant.INTENT_EXTRA_ORDER_ID, mOwner.getOrderViewModel().getId());
					startActivity(intent);
//					Message msg = new Message();
//					msg.what = 1;
//					ParkingApp.orderTabHandler.sendMessage(msg);
//					ParkingApp.orderHandler.sendMessage(msg);
					mOwner.finish();
//					try {
//						mOwner.getDB().delete(mInTime);
//					} catch (DbException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
				}
			}else {
				showConfirmDialog();
			}
		}
	}
	
	private void initViews(){
		vBaseQuarter.setText(mOwner.getOrderViewModel().getParking_no());
		vBaseState.setText(mOwner.getOrderViewModel().getState());
		vBasePrice.setText(mOwner.getOrderViewModel().getPrice());
		vBaseTime.setText(mOwner.getOrderViewModel().getBooked_time_range());
		vBaseParkingOwner.setText(mOwner.getOrderViewModel().getBoss_name());
		
		if(mOwner.getState() == IServer.PARKING_STATE_CONFIRM) {
			btnNavigator.setVisibility(View.VISIBLE);
		}else {
			btnNavigator.setVisibility(View.GONE);
		}
		Log.i("qh", "mState : "+mOwner.getState());
		vTimePanel.setVisibility(View.GONE);
		if(mOwner.getState() == IServer.PARKING_STATE_CONFIRM
				|| mOwner.getState() == IServer.PARKING_STATE_CAR_IN){
			initOptAndTimeViews();
		}else if(mOwner.getState() == IServer.PARKING_STATE_WAIT_CONFIRM) {
			vOptBtn2.setVisibility(View.GONE);
			vOptBtn.setText("取消预约");
			vOptBtn.setOnClickListener(this);
			vOptPanel.startAnimation(AnimationUtils.loadAnimation(mOwner, R.anim.visible_from_bottom));
			vOptPanel.setVisibility(View.VISIBLE);
		}else if(mOwner.getState() == IServer.PARKING_STATE_WAIT_QUARTER) {
			vCallTel.setText("12345678911");
			btnPhone.setText("18923456789");
			layout.setVisibility(View.VISIBLE);
			vOptPanel.setVisibility(View.GONE);
			return;
		}else {
			vOptPanel.setVisibility(View.GONE);
		}
	}
	
	private void initOptAndTimeViews(){
//		if(!mOwner.getOrderViewModel().getIsShowTextView()) {
//			vOptBtn2.setText("取消预约");
//			vOptBtn2.setVisibility(View.VISIBLE);
//			vOptBtn.setVisibility(View.GONE);
//			vOptPanel.startAnimation(AnimationUtils.loadAnimation(mOwner, R.anim.visible_from_bottom));
//			vOptPanel.setVisibility(View.VISIBLE);
//			return;
//		}
		
		if(mOwner.getState() == IServer.PARKING_STATE_CONFIRM){
			int check1 = 0;
			int check2 = 0;
			vOptBtn2.setVisibility(View.GONE);
//			if(checkTime(mOwner.getOrderViewModel().getStart_hour(), mOwner.getOrderViewModel().getBooked_time_range())) {   // 判断是否可取消，进场时间前1个小时不允许取消预约
//				vOptBtn2.setText("取消预约");
//				vOptBtn2.setVisibility(View.VISIBLE);
//				Log.i("TEST 取消预约  : ", mOwner.getOrderViewModel().getStart_hour());
//				check1 = 1;
//			}
			if(mOwner.getOrderViewModel().getIsShowCancelButton()) {   // 判断是否可取消，进场时间前1个小时不允许取消预约
				vOptBtn2.setText("取消预约");
				vOptBtn2.setVisibility(View.VISIBLE);
				Log.i("TEST 取消预约  : ", mOwner.getOrderViewModel().getStart_hour());
				check1 = 1;
			}
			if(mOwner.getOrderViewModel().getIsShowTextView()) {  // 判断是否可进场，只允许提前30分钟
				vOptBtn.setText("进场扫描");
				vOptBtn.setVisibility(View.VISIBLE);
				Log.i("TEST 进场扫描  : ", mOwner.getOrderViewModel().getStart_hour());         
				check2 = 1;
			}else {
				vOptBtn.setVisibility(View.GONE);
			} 
			if(check1 == 0 && check2 == 0) {
				vOptPanel.setVisibility(View.GONE);
				return;
			}
		}else{
			vTimePanel.setVisibility(View.VISIBLE);
			vOptBtn2.setVisibility(View.GONE);
//			DbUtils db = mOwner.getDB();
//			try {
//				mInTime = db.findById(CarInTime.class, mOwner.getOrderViewModel().getId());
//			} catch (DbException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
			long lastescape = 0;
			if(mInTime != null){
				long now = System.currentTimeMillis();
				lastescape = now - mInTime.getTime();
				Log.i("qh", "car_in_time getTime : "+ mInTime.getTime());
			}
			long now = System.currentTimeMillis();
			lastescape = now - getTime(mOwner.getOrderViewModel().getCar_in_time());
			if(lastescape < 0){
				lastescape = 0;
			}
			vTime.setBase(SystemClock.elapsedRealtime() - lastescape);
			vOptBtn.setText("离场扫描");
		}
		vOptBtn.setOnClickListener(this);
		vOptPanel.startAnimation(AnimationUtils.loadAnimation(mOwner, R.anim.visible_from_bottom));
		vOptPanel.setVisibility(View.VISIBLE);
		
	}
	
	public void refresh(){
		initViews();
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
//		scan();
		if(mOwner.getState() == IServer.PARKING_STATE_CONFIRM
				|| mOwner.getState() == IServer.PARKING_STATE_CAR_IN){

			scan();
		}else{
			doCancelOrder();
		}
	}
	
	private void scan(){
		ScanTask task = new ScanTask();
		task.setTask_id(mOwner.getOrderViewModel().getId());
		task.setNumOfScan(mOwner.getState() == IServer.PARKING_STATE_CONFIRM ? "1" : "2");
		Intent intent = new Intent(mOwner, CaptureActivity.class);
		intent.putExtra(ParkingConstant.INTENT_EXTRA_OBJ_SCANTASK, task);
		mOwner.startActivityForResult(intent, REQ_CODE_CAPTURE);
	}
	
	private AlertDialog mConfirmDialog;
	
	private void showConfirmDialog(){
		Log.i("qh", "show dialog confirm");
		if (mConfirmDialog == null) {
			AlertDialog.Builder builder = new AlertDialog.Builder(mOwner);
			builder
				.setTitle("扫描操作信息")
				.setCancelable(true)
					.setPositiveButton("联系物业",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int id) {
									mConfirmDialog.dismiss();
									mOwner.requestQuartOwner();
								}
							})
					.setNegativeButton("重新扫描",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int id) {
									mConfirmDialog.dismiss();
									scan();
								}
							});
			mConfirmDialog = builder.create();
		}
		mConfirmDialog.setMessage("扫描失败");
		mConfirmDialog.show();
	}
	
	@Override
	public void onDetach() {
		// TODO Auto-generated method stub
		super.onDetach();
		if(mConfirmDialog != null && mConfirmDialog.isShowing()){
			mConfirmDialog.dismiss();
		}
	}
	
	private long getTime(String time) {
		SimpleDateFormat format= new SimpleDateFormat("yyyy-MM-dd kk:mm:ss");
		long timeStart = System.currentTimeMillis();
		try {
			timeStart=format.parse(time).getTime();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return timeStart;
	}
	
	private String ServerURL = "https://121.33.214.30:8443/lhparking/servlet/SysInterface";
	private String TAG = "TEST";
	
	private void doCancelOrder() {
		curShowView = "doCancelOrder";
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("method", "cancel_2005");
		params.addBodyParameter("task_id",mOwner.getOrderViewModel().getId());
		Log.i(TAG, "ServerURL:"+ServerURL +"  method:cancel_2005"+ " task_id:"+mOwner.getOrderViewModel().getId());
		HttpUtils http = new HttpUtils(6000);
		showProgDialog("正在取消预约 . . .", http);
		http.send(HttpMethod.POST, 
				ServerURL,
				params,
				new RequestCallBack< String >() {

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// TODO Auto-generated method stub
						Log.i(TAG, responseInfo.result);
						if(curShowView.equals("doCancelOrder")) {
							try {
								JSONObject jsob = new JSONObject(responseInfo.result);
								boolean bo = jsob.getBoolean("success");
								String msg = jsob.getString("msg");
								Toast.makeText(mOwner, msg, Toast.LENGTH_SHORT).show();
								if(bo) {
//									Intent intent = new Intent(mOwner, ViewOrderHistoryActivity.class);
//									intent.putExtra(ParkingConstant.INTENT_EXTRA_ORDER_ID, mOwner.getOrderViewModel().getId());
//									startActivity(intent);
									mOwner.finish();
								}
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							if(mDialog != null) {
								dialogDismiss = 1;
								mDialog.dismiss();
							}
						}
					}

					@Override
					public void onFailure(HttpException error, String msg) {
						// TODO Auto-generated method stub
						if(curShowView.equals("doCancelOrder")) {
							Toast.makeText(mOwner, "取消预约失败，请稍后再试", Toast.LENGTH_SHORT);
						}
						if(mDialog != null) {
							dialogDismiss = 1;
							mDialog.dismiss();
						}
					}
				});
	}
	
	private void showProgDialog(final String msg, final HttpUtils httpUtils) {
		mDialog = new ProgressDialog(mOwner);
		mDialog.setCanceledOnTouchOutside(false);
		mDialog.setOnDismissListener(new OnDismissListener() {
			
			@Override
			public void onDismiss(DialogInterface dialog) {
				// TODO Auto-generated method stub
				if(dialogDismiss == 0 ) {
					httpUtils.getHttpClient().getConnectionManager().closeExpiredConnections();
//					httpUtils.getHttpClient().getConnectionManager().shutdown();
				}
				dialogDismiss = 0;
				curShowView = "0";
				Log.i(TAG, "dialog dismiss : "+msg);
			}
		});
		mDialog.setMessage(msg);
		mDialog.show();
	}
	
	//09-21 21:14~23:00
	private boolean checkTime(String time, String booktime) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String str1[] = time.split("\\-");
		String str2[] = booktime.split("\\~");
		String checktime = str1[0]+"-"+str2[0]+":00";
		Log.i("TEST checkTime : ", checktime);
		long oneHour = 3600;
		long lCurDate = System.currentTimeMillis()/1000;
		try {
			long orderTime = sdf.parse(checktime).getTime()/1000;
			if((orderTime - lCurDate) >= oneHour) {
				return true;
			}
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//毫秒
		return false;
	}
	
	private boolean checkTime2In(String time, String booktime) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String str1[] = time.split("\\-");
		String str2[] = booktime.split("\\~");
		String checktime = str1[0]+"-"+str2[0]+":00";
		long lCurDate = System.currentTimeMillis()/1000;
		try {
			long orderTime = sdf.parse(checktime).getTime()/1000;
			if( (lCurDate + 1800) >= orderTime) {
				return true;
			}
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//毫秒
		return false;
	}
	
	/**
	 * 启动GPS导航. 前置条件：导航引擎初始化成功
	 */
	private void launchNavigator(){
		//可以通过POI检索、外部POI来源等方式获取起终点坐标
		BNaviPoint startPoint = new BNaviPoint( MapLocationActivity.mCurrentLongitude, MapLocationActivity.mCurrentLantitude,  
		        "起始位置", BNaviPoint.CoordinateType.BD09_MC);  
		BNaviPoint endPoint = new BNaviPoint(113.315807, 23.133144, 
		        "金羊花园", BNaviPoint.CoordinateType.BD09_MC);
		BaiduNaviManager.getInstance().launchNavigator(mOwner,
//				MapLocationActivity.mCurrentLantitude, MapLocationActivity.mCurrentLongitude,"起始位置", 
//		        23.133144, 113.315807,"金羊花园",
				startPoint,
				endPoint,
				NE_RoutePlan_Mode.ROUTE_PLAN_MOD_MIN_TIME, 		 //算路方式
				true, 									   		 //真实导航
				BaiduNaviManager.STRATEGY_FORCE_ONLINE_PRIORITY, //在离线策略
				new OnStartNavigationListener() {				 //跳转监听
					
					@Override
					public void onJumpToNavigator(Bundle configParams) {
						Intent intent = new Intent(mOwner, NavigatorActivity.class);
						intent.putExtras(configParams);
				        startActivity(intent);
					}
					
					@Override
					public void onJumpToDownloader() {
					}
				});
	}
	
	/**
	 * 打电话
	 * @param context
	 * @param phone
	 */
	public static void makeCall(Context context, String phone) {
		Uri uri = Uri.parse("tel:" + phone);
		Intent it = new Intent(Intent.ACTION_CALL, uri);
		context.startActivity(it);
	}
}
