package com.sendi.lhparking.ui.common.frag;

import org.sendi.parking.ui.R;

import com.ab.util.AbStrUtil;
import com.google.gson.Gson;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.model.UserInfo;
import com.sendi.lhparking.server.IServer;
import com.sendi.lhparking.ui.common.ViewEvaluationListActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
/**
 * 个人信息
 * @author Administrator
 *
 */
public class PersonInfoFragment extends Fragment{
	
	public static PersonInfoFragment newInstance(){
		return new PersonInfoFragment();
	}
	
	private TextView vPhone;
	private TextView vName;
	private TextView vLevel;
	private TextView vEvaluation;
	
	private IServer mServer;
	
	@Override
	public void onAttach(Activity activity) {
		// TODO Auto-generated method stub
		super.onAttach(activity);
		mServer = ParkingApp.mAppCtx.getServerConfig();
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		View view = inflater.inflate(R.layout.frag_person_info, null);
		vPhone = (TextView) view.findViewById(R.id.frag_person_info_phone);
		vName = (TextView) view.findViewById(R.id.frag_person_info_name);
		vLevel = (TextView) view.findViewById(R.id.frag_person_info_level);
		vEvaluation = (TextView) view.findViewById(R.id.frag_person_info_evas);
		return view;
	}
	
	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onActivityCreated(savedInstanceState);
		vEvaluation.setClickable(true);
		vEvaluation.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent =ViewEvaluationListActivity.getLaunchIntent(getActivity(), ParkingApp.mAppCtx.getUID(), 
						ViewEvaluationListActivity.TYPE_MY_INFO);
				startActivity(intent);
			}
		});
		loadPersonInfo();
	}
	
	private void refreshUI(){
		vPhone.setText(mInfo.getPhone());
		vName.setText(mInfo.getName());
		vLevel.setText(mInfo.getLevel());
		vEvaluation.setText(mInfo.getTotal_num());
	}
	
	private WaitingDialogFragment mWaitDialog;
	private UserInfo mInfo;
	
	private void loadPersonInfo(){
		if(mWaitDialog == null){
			mWaitDialog = WaitingDialogFragment.newInstance("正在载入信息...");
		}
		mWaitDialog.show(getFragmentManager(), getTag());
		String url = mServer.getURL(IServer.URL_FLAG_GET_PERSON_INFO);
		Log.i("qh", "person url : "+url);
		HttpUtils http = new HttpUtils();
		http.send(HttpMethod.GET, url, new InfoCallBack());
	}
	
	private void showToast(String msg){
		Toast.makeText(getActivity(), msg, Toast.LENGTH_LONG).show();
	}
	
	
	class InfoCallBack extends RequestCallBack<String>{

		@Override
		public void onSuccess(ResponseInfo<String> responseInfo) {
			// TODO Auto-generated method stub
			mWaitDialog.dismiss();
			String json = responseInfo.result;
			Log.i("qh", "json : "+json);
			if(AbStrUtil.isEmpty(json)){
				showToast("数据出错");
				return ;
			}
			Gson g = new Gson();
			mInfo = g.fromJson(json, UserInfo.class);
			if(mInfo == null){
				showToast("数据出错");
				return ;
			}
			refreshUI();
		}

		@Override
		public void onFailure(HttpException error, String msg) {
			// TODO Auto-generated method stub
			mWaitDialog.dismiss();
			showToast("加载数据出错,请检查网络连接！");
		}
		
	}
	
	
}
