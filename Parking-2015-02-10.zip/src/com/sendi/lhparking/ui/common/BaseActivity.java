package com.sendi.lhparking.ui.common;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.FragmentManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;

public class BaseActivity extends FragmentActivity {
	public String TAG = "TEST";
	public ProgressDialog dialog = null;
//	public String ServerURL = "http://192.168.60.207:8080/lhparking/servlet/SysInterface"; https://121.33.214.30:8443/
//	public String ServerURL = "http://www.lhhl.cc/lhparking/servlet/SysInterface";
	public String ServerURL = "https://121.33.214.30:8443/lhparking/servlet/SysInterface";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
	}
	
	public void showTipsDialog(String msg, Context context){  
        AlertDialog dialog;  
        AlertDialog.Builder builder = new AlertDialog.Builder(context);  
        builder.setTitle("消息").setIcon(android.R.drawable.stat_notify_error);  
        builder.setMessage(msg);  
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener(){  
            @Override 
            public void onClick(DialogInterface dialog, int which) {  
                // TODO Auto-generated method stub  
                  
            }                     
        });  
        dialog = builder.create();  
        dialog.show();  
    }  
	
	public void showProgDialog(String msg, Context context) {
		dialog = ProgressDialog.show(context, "消息", msg );
	}
	
	public void hideKeyborad() {
		InputMethodManager imm =  (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE); 
		if(imm != null) { 
			imm.hideSoftInputFromWindow(getWindow().getDecorView().getWindowToken(),  
		    		   0); 
			}
	}
	
	public void checkPasword() {
		
	}
	
	public String getNextDate() {
		SimpleDateFormat format= new SimpleDateFormat("yyyy年MM月dd日 kk:mm");
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		cal.add(Calendar.DAY_OF_YEAR, 1);
		cal.set(Calendar.HOUR_OF_DAY, 23);
		cal.set(Calendar.MINUTE, 59);
		cal.set(Calendar.SECOND, 0);
		format.format(cal.getTime());
		Log.i(TAG, "getNextDate : " + format.format(cal.getTime()));
		return format.format(cal.getTime());
	}
	
	public long genTimeStamp() {
		return System.currentTimeMillis() / 1000;
	}
	
	public String getCurDate() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");  // 日期格式
		Calendar cal = Calendar.getInstance();
		Date date = cal.getTime();
		String curDate = dateFormat.format(date);
		return curDate;
	}
	
	public String getCurTime() {
		DateFormat dateFormat = new SimpleDateFormat("kk:mm");  // 时间格式
		Date date = Calendar.getInstance().getTime();
		String curTime = dateFormat.format(date);
		return curTime;
	}
	
	/** 
     * 检测网络是否连接 
     *  
     * @return 
     */ 
    public boolean isNetConnected() {  
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);  
        if (cm != null) {  
            NetworkInfo[] infos = cm.getAllNetworkInfo();  
            if (infos != null) {  
                for (NetworkInfo ni : infos) {  
                    if (ni.isConnected()) {  
                        return true;  
                    }  
                }  
            }  
        }  
        return false;  
    }
    
    public void tryVibra() {
    	
    }
    
}
