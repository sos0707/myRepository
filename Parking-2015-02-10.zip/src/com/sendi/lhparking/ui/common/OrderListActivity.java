package com.sendi.lhparking.ui.common;

import java.util.ArrayList;
import java.util.List;

import org.sendi.parking.ui.R;
import org.sendi.parking.ui.R.drawable;
import org.sendi.parking.ui.R.id;
import org.sendi.parking.ui.R.layout;


import com.ab.view.sliding.AbSlidingTabView;
import com.lidroid.xutils.view.annotation.ViewInject;
import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.ui.common.base.BaseFragmentActivity;
import com.sendi.lhparking.ui.common.frag.CompletedOrderListFragment;
import com.sendi.lhparking.ui.common.frag.ExecutingOrderListFragment;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.KeyEvent;
import android.widget.Toast;

/**
 * 订单列表
 * @author Administrator
 *
 */
public class OrderListActivity extends BaseFragmentActivity{
	
	//myviews
	@ViewInject(R.id.order_list_tabview)
	private AbSlidingTabView vTapView;
	
	private List<Fragment> mFragments;
	private List<String> mTabTexts;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_order_list);
		ParkingApp.mAppCtx.setOrderTabHandler(orderTabHandler);
		initData();
		initViews();
	}
	
	private void initData() {
		// TODO Auto-generated method stub
		mFragments = new ArrayList<Fragment>();
		mFragments.add(new ExecutingOrderListFragment());   // 进行中订单列表
		mFragments.add(new CompletedOrderListFragment());   // 已完成订单列表

		mTabTexts = new ArrayList<String>();
		mTabTexts.add("进行中");
		mTabTexts.add("已完成");
	}
	
	private void initViews() {
		// TODO Auto-generated method stub
		//设置样式
		vTapView.setTabTextColor(Color.BLACK);
		vTapView.setTabSelectColor(Color.rgb(30, 168, 131));
		vTapView.setTabBackgroundResource(R.drawable.tab_bg);
		vTapView.setTabLayoutBackgroundResource(R.drawable.slide_top);
		//演示增加一组
		vTapView.addItemViews(mTabTexts, mFragments);
		vTapView.setTabPadding(20, 8, 20, 8);
	}
	
	private void setSelectItem(int item) {
		vTapView.setCurrentItem(item);
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		int index = vTapView.getViewPager().getCurrentItem();
		mFragments.get(index).onActivityResult(requestCode, resultCode, data);
	}
	
	private long exitTime = 0;
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		return super.onKeyDown(keyCode, event);
	}
	
	Handler orderTabHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			setSelectItem(msg.what);
		}
		
	};


	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		if((System.currentTimeMillis()-exitTime) > 2000){  
            Toast.makeText(getApplicationContext(), "再按一次返回键退出程序", Toast.LENGTH_SHORT).show();                                
            exitTime = System.currentTimeMillis();   
        } else {
            finish();
            System.exit(0);
        }
	}
	
}
