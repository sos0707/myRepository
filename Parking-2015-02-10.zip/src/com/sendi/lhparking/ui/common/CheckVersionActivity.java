package com.sendi.lhparking.ui.common;

import org.sendi.parking.ui.R;

import com.ab.util.AbStrUtil;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.server.IServer;
import com.sendi.lhparking.update.DownService;
import com.sendi.lhparking.util.ParkingPrefs;
import com.sendi.lhparking.util.SysUtils;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
/**
 * 版本更新
 * @author Administrator
 *
 */
public class CheckVersionActivity extends BaseActivity {

	private static final int CHECK_UPDATE = 0;
	private static final int DO_UPDATE = 1;
	private TextView tvTitle;
	private TextView tvReturn;
	private TextView tvVersion, tvUpdate, tvUpdateinfo;
	private Button btnUpdate;
	private int myversion;
	private int serverversion;
	private String versionName;
	private String updateInfo = null;
	private int flag = 0;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_check_version);
		
		init();
		initView();
	}
	
	private void init() {
		tvTitle = (TextView) this.findViewById(R.id.topbar_center_btn);
		tvReturn = (TextView) this.findViewById(R.id.topbar_left_btn);
		
		tvTitle.setText("版 本 更 新");
		tvReturn.setVisibility(View.VISIBLE);
		tvReturn.setText("  返 回");
		tvReturn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				hideKeyborad();
				CheckVersionActivity.this.finish();
			}
		});
		
		btnUpdate = (Button) this.findViewById(R.id.btn_Update);
		tvVersion = (TextView) this.findViewById(R.id.tv_version);
		tvUpdate = (TextView) this.findViewById(R.id.tv_update);
		tvUpdateinfo = (TextView) this.findViewById(R.id.tv_updateinfo);
		
		btnUpdate.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				switch(flag) {
				case CHECK_UPDATE:
					btnUpdate.setClickable(false);
					checkVersion();
					break;
				case DO_UPDATE:
					startService(new Intent(CheckVersionActivity.this, DownService.class));
		            Toast.makeText(getApplicationContext(), "已开始下载更新包", Toast.LENGTH_SHORT).show();
					break;
				}
			}
		});
	}
	
	private void initView() {
		versionName = SysUtils.getVersionName(ParkingApp.mAppCtx);
		myversion = ParkingApp.myversion;
		serverversion = ParkingApp.serverversion;
		updateInfo = ParkingApp.updateInfo;
		Log.i("TEST CheckVersion : ", String.valueOf(myversion) + " : " + String.valueOf(serverversion) );
		btnUpdate.setClickable(false);
		
		if(myversion >= serverversion) {
			tvVersion.setText("浪花停车"+versionName+"\n \n" + "当前版本已是最新");
			tvUpdate.setText(" ");
			tvUpdateinfo.setText(" ");
			flag = this.CHECK_UPDATE;
			btnUpdate.setText("检查更新");
			btnUpdate.setClickable(true);
		}else {
			tvVersion.setText("发现新版本：浪花停车 (版本"+serverversion+".0)");
			tvUpdate.setText("浪花停车 (版本"+serverversion+".0) 主要更新：");
			tvUpdateinfo.setText(updateInfo);
			flag = this.DO_UPDATE;
			btnUpdate.setText("立即更新");
			btnUpdate.setClickable(true);
		}
		
	}
	
	private void checkVersion() {
		// TODO Auto-generated method stub
//		Toast.makeText(getApplicationContext(), "检查更新", Toast.LENGTH_SHORT).show();
		HttpUtils http = new HttpUtils(5000);
		http.send(
				HttpMethod.GET,
				ParkingApp.mAppCtx.getServerConfig().getURL(
						IServer.URL_FLAG_GET_APK_VERSION),
				new RequestCallBack<String>() {

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// TODO Auto-generated method stub
						String msg = responseInfo.result;
						if (AbStrUtil.isEmpty(msg)) {
							return;
						}
						String[] infos = msg.split(IServer.V_SPLIT);
						if (infos.length < 3) {
							return;
						}
						int myversion = SysUtils
								.getVersionCode(ParkingApp.mAppCtx);
						int serverversion = myversion;
						try {
							serverversion = Integer.valueOf(infos[1]);
						} catch (NumberFormatException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						Log.i("qh", "当前版本："+myversion+", 发现新版本:"+serverversion);
						if(myversion >= serverversion) {
							Toast.makeText(getApplicationContext(), "当前版本已是最新", Toast.LENGTH_SHORT).show();
						}
						ParkingApp.mAppCtx.setMyversion(myversion);
						ParkingApp.mAppCtx.setServerversion(serverversion);
						ParkingApp.mAppCtx.setUpdateInfo(infos[2]);
						CheckVersionActivity.this.myversion = myversion;
						CheckVersionActivity.this.serverversion = serverversion;
						updateInfo = infos[2];
						initView();
					}

					@Override
					public void onFailure(HttpException error, String msg) {
						// TODO Auto-generated method stub
						Toast.makeText(getApplicationContext(), "检查更新失败", Toast.LENGTH_SHORT).show();
						btnUpdate.setClickable(true);
					}
				});
	}
}
