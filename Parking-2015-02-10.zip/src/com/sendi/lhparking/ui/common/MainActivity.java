package com.sendi.lhparking.ui.common;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import org.sendi.parking.ui.R;

import com.sendi.lhparking.ctx.ParkingConstant;
import com.sendi.lhparking.util.HttpUtils;
import com.sendi.lhparking.util.ParkingPrefs;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.telephony.TelephonyManager;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends BaseActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		init();
	}
	
	private void init() {
		boolean boIsFirstLogin = ParkingPrefs.getBoolValue("is_first_login", true);
		boolean boAutoLogin = ParkingPrefs.getBoolValue("auto_login", false);
		if(boIsFirstLogin) {
			Intent intent = new Intent();
			intent.setClass(MainActivity.this, SplashActivity.class);
			startActivity(intent);
		}else {
			if(!boAutoLogin) {
				ParkingPrefs.setStrValue(LoginActivity.PREF_LANGHUA_UID, ParkingConstant.NO_USER_GUEST);
			}
			Intent intent = new Intent();
			intent.setClass(MainActivity.this, AppActivity.class);
//			intent.setClass(MainActivity.this, DoorActivity.class);
			startActivity(intent);
		}
		
		this.finish();
	}
}
	