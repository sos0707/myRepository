package com.sendi.lhparking.ui.common;


import org.sendi.parking.ui.R;
import org.sendi.parking.ui.R.id;
import org.sendi.parking.ui.R.layout;

import com.ab.util.AbStrUtil;
import com.google.gson.Gson;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.lidroid.xutils.view.annotation.ViewInject;
import com.lidroid.xutils.view.annotation.event.OnClick;
import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.ctx.ParkingConstant;
import com.sendi.lhparking.model.OrderViewModel;
import com.sendi.lhparking.server.IServer;
import com.sendi.lhparking.ui.common.base.BaseFragmentActivity;
import com.sendi.lhparking.ui.common.frag.ViewOrderCarOwnerFragment;
import com.sendi.lhparking.ui.common.frag.ViewOrderParkingOwnerFragment;
import com.sendi.lhparking.ui.common.frag.ViewOrderQuarterOwnerFragment;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 查看 订单信息 3个角色
 * 
 * @author Administrator
 * 
 */
public class ViewOrderActivity extends BaseFragmentActivity {

	// for top bar
	@ViewInject(R.id.topbar_left_btn)
	private TextView vTopLeft;
	@ViewInject(R.id.topbar_center_btn)
	private TextView vTopCenter;
	@ViewInject(R.id.topbar_right_btn)
	private TextView vTopRight;

	@OnClick(value = { R.id.topbar_left_btn })
	public void topLeftClick(View v) {
		finish();
	}

	private boolean isFromSystem;

	private OrderViewModel mModel;
	private String mOrderId;
	private int mState;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		if (!parseIntent()) {
			showToastTips("订单号出错");
			finish();
			return;
		}
		setContentView(R.layout.activity_view_order);
		initViews();
		getOrderModelFromServer();
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		if (isFromSystem && ParkingApp.mAppCtx.isNeedLoadMainActivity()) {
			startActivity(new Intent(this, AppActivity.class));
		}
	}

	private boolean mFragReqRefreshModel;

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		Log.i("qh", "view order_ on activity result : req_ " + requestCode
				+ " , res_ " + resultCode);

		if (requestCode == ViewOrderCarOwnerFragment.REQ_CODE_CAPTURE) {
			mFrag.onActivityResult(requestCode, resultCode, data);
			if (resultCode == Activity.RESULT_OK) {
				reqRefreshFromFragUI();
			}
		}
	}

	public OrderViewModel getOrderViewModel() {
		return mModel;
	}

	public int getState() {
		return mState;
	}

	/**
	 * 联系物业
	 */
	public void requestQuartOwner() {
		showProgressDialog();
		getJsonFromServer(mServer.getURL(
				IServer.URL_FLAG_POST_NEED_QUARTER_GUARD, mModel.getId()));
		mWaitForQuartOwner = true;
	}

	public void reqRefreshFromFragUI() {
		mFragReqRefreshModel = true;
		getOrderModelFromServer();
	}

	private boolean parseIntent() {
		Intent intent = getIntent();
		if (intent == null) {
			return false;
		}
		String orderid = intent
				.getStringExtra(ParkingConstant.INTENT_EXTRA_ORDER_ID);
		if (AbStrUtil.isEmpty(orderid)) {
			return false;
		}
		mOrderId = orderid;
		isFromSystem = intent.getBooleanExtra(
				ParkingConstant.INTENT_EXTRA_BOOL_FROM_SYSMSG, false);
		return true;
	}

	private void initViews() {
		// TODO Auto-generated method stub
		vTopLeft.setText("  返 回");
		vTopCenter.setText("订单详情");
		vTopLeft.setVisibility(View.VISIBLE);
	}

	private void getOrderModelFromServer() {
		showProgressDialog();
		getJsonFromServer(mServer.getURL(IServer.URL_FLAG_GET_ORDER_VIEW,
				mOrderId));
	}

	private void getJsonFromServer(String url) {
		HttpUtils http = new HttpUtils();
		http.configDefaultHttpCacheExpiry(5000);// 5秒内请求 使用缓存
		Log.i("qh", "url : " + url);
		http.send(HttpMethod.GET, url, new RequestCallBack<String>() {

			@Override
			public void onSuccess(ResponseInfo<String> responseInfo) {
				// TODO Auto-generated method stub
				Log.i("qh", "result from cache : "
						+ responseInfo.resultFormCache);
				Log.i("qh", "result code : " + responseInfo.statusCode);
				callbackFromGetJsonSuccess(responseInfo.result);
			}

			@Override
			public void onFailure(HttpException error, String msg) {
				// TODO Auto-generated method stub
				callbackFromGetJsonFail(error.getExceptionCode(), msg);
			}
		});
	}

	private boolean mWaitForQuartOwner;

	private void handleReqQuartOwnerFail(int failcode, String msg) {
		showToastTips("联系物业失败.请稍后重试...");
		mWaitForQuartOwner = false;
	}

	private void handleReqQuartOwnerSuccess(String json) {
		showToastTips("已成功通知物业");
		mWaitForQuartOwner = false;
		reqRefreshFromFragUI();
	}

	// call back
	@SuppressWarnings("deprecation")
	private void callbackFromGetJsonSuccess(String json) {
		// empty
		try {
			dismissDialog(DIALOG_PROGRESS);
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		if (mWaitForQuartOwner) {
			handleReqQuartOwnerSuccess(json);
			return;
		}
		Log.i("qh", "json : " + json);
		Gson gson = new Gson();
		mModel = gson.fromJson(json, OrderViewModel.class);
		if (mModel == null) {
			handleNoModel();
			return;
		}
		try {
			mState = Integer.valueOf(mModel.getState_int());
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			handleNoModel();
			return;
		}
		if (mFragReqRefreshModel) {
			refreshFrag();
			mFragReqRefreshModel = false;
			return;
		}
		handleUI();
	}

	@SuppressWarnings("deprecation")
	private void callbackFromGetJsonFail(int failcode, String msg) {
		// empty
		dismissDialog(DIALOG_PROGRESS);
		if (mWaitForQuartOwner) {
			handleReqQuartOwnerFail(failcode, msg);
			return;
		}
		handleNoModel();
	}

	private void handleNoModel() {
		showToastTips("加载数据失败");
		finish();
	}

	private void handleUI() {
		if (ParkingApp.mAppCtx.getUType() == ParkingConstant.ROLE_GUARDER) {// 物业查看
			useUI(new ViewOrderQuarterOwnerFragment());
		} else if (ParkingApp.mAppCtx.getUID().equals(mModel.getBoss_id())) {// 业主查看
			useUI(new ViewOrderParkingOwnerFragment());
		} else {// 车主
			useUI(new ViewOrderCarOwnerFragment());
		}
	}

	private Fragment mFrag;

	private void useUI(Fragment frag) {
		FragmentManager mgr = getSupportFragmentManager();
		FragmentTransaction trans = mgr.beginTransaction();
		trans.add(R.id.view_order_content, frag);
		trans.commit();
		mFrag = frag;
	}

	private void refreshFrag() {
		if (ParkingApp.mAppCtx.getUType() == ParkingConstant.ROLE_GUARDER) {// 物业查看
		// useUI(new ViewOrderQuarterOwnerFragment());
			ViewOrderQuarterOwnerFragment frag = (ViewOrderQuarterOwnerFragment) mFrag;
			frag.refresh();
		} else if (ParkingApp.mAppCtx.getUID().equals(mModel.getBoss_id())) {// 业主查看
		// useUI(new ViewOrderParkingOwnerFragment());
			ViewOrderParkingOwnerFragment frag = (ViewOrderParkingOwnerFragment) mFrag;
			frag.refresh();
		} else {// 车主
		// useUI(new ViewOrderCarOwnerFragment());
			ViewOrderCarOwnerFragment frag = (ViewOrderCarOwnerFragment) mFrag;
			frag.refresh();
		}
	}
	
}
