package com.sendi.lhparking.ui.common;

import org.json.JSONException;
import org.json.JSONObject;
import org.sendi.parking.ui.R;

import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.sendi.lhparking.ctx.ParkingApp;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.TextView.OnEditorActionListener;
/**
 * 反馈
 * @author Administrator
 *
 */
public class FeedBackActivity extends BaseActivity {

	private ProgressDialog mDialog;
	private String curShowView = "0";
	private int dialogDismiss = 0;
	private Button btnOK;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.view_feedback);
		
		TextView tvTitle = (TextView) this.findViewById(R.id.topbar_center_btn);
		TextView tvReturn = (TextView) this.findViewById(R.id.topbar_left_btn);
		final EditText edTitle = (EditText) this.findViewById(R.id.edTitle);
		final EditText edFeedback = (EditText) this.findViewById(R.id.edFeedback);
		btnOK = (Button) this.findViewById(R.id.btnOK);
		
		tvTitle.setText("反  馈");
		tvReturn.setVisibility(View.VISIBLE);
		tvReturn.setText("  返 回");
		
		tvReturn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				hideKeyborad();
				FeedBackActivity.this.finish();
			}
		});
		
		btnOK.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(edTitle.getText().length() == 0) {
					showTipsDialog("请输入标题！", FeedBackActivity.this);
					return;
				}
				if(edFeedback.getText().length() == 0) {
					showTipsDialog("请输入反馈内容！", FeedBackActivity.this);
					return;
				}
				boolean bo = isNetConnected();
				if(!bo) {
					Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
					return;
				}
				btnOK.setClickable(false);
				doFeedback(edTitle.getText().toString(), edFeedback.getText().toString());
			}
		});
		
		edFeedback.setOnEditorActionListener(new OnEditorActionListener() {
			
			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				// TODO Auto-generated method stub
				switch(actionId) {
				case EditorInfo.IME_ACTION_DONE:
					btnOK.performClick();
					break;
				}
				return false;
			}
		});
	
	}
	
	/** 
	 * 服务器提交反馈
	 * */
	private void doFeedback(String title, String remark) {
		curShowView = "FeedBack";		
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("title", title);
		params.addBodyParameter("remark", remark);
		params.addBodyParameter("method", "config_2008");
		Log.i(TAG, "FeedBackActivity doFeedback remark : " + remark);
		HttpUtils http = new HttpUtils(6000);
		showProgDialog("正在提交反馈...",http);
		http.send(HttpMethod.POST, 
				ServerURL,
				params,
				new RequestCallBack<String>() {

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// TODO Auto-generated method stub
						if(curShowView.equals("FeedBack")) {
							try {
								JSONObject jsob = new JSONObject(responseInfo.result);
								boolean bo = jsob.getBoolean("success");
								String msg = jsob.getString("msg");
								if(bo) {
									showTipsDialog(msg, FeedBackActivity.this);
								}else {
									showTipsDialog("提交反馈失败："+msg, FeedBackActivity.this);
								}
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							if(mDialog != null) {
								dialogDismiss = 1;
								mDialog.dismiss();
							}
						}
						
						Log.i(TAG, responseInfo.result);
					}

					@Override
					public void onFailure(HttpException error, String msg) {
						// TODO Auto-generated method stub
						if(curShowView.equals("FeedBack")) {
							showTipsDialog("提交反馈失败，请检查网络，稍后再试 ", FeedBackActivity.this);
						}
						if(mDialog != null) {
							dialogDismiss = 1;
							mDialog.dismiss();
						}
					}});
	}
	
	private void showProgDialog(final String msg, final HttpUtils httpUtils) {
		mDialog = new ProgressDialog(this);
		mDialog.setCanceledOnTouchOutside(false);
		mDialog.setOnDismissListener(new OnDismissListener() {
			
			@Override
			public void onDismiss(DialogInterface dialog) {
				// TODO Auto-generated method stub
				btnOK.setClickable(true);
				if(dialogDismiss == 0 ) {
					httpUtils.getHttpClient().getConnectionManager().closeExpiredConnections();
//					httpUtils.getHttpClient().getConnectionManager().shutdown();
				}
				dialogDismiss = 0;
				curShowView = "0";
				Log.i(TAG, "dialog dismiss : "+msg);
			}
		});
		mDialog.setMessage(msg);
		mDialog.show();
	}
	
}
