package com.sendi.lhparking.ui.common;


import org.sendi.parking.ui.R;
import org.sendi.parking.ui.R.anim;
import org.sendi.parking.ui.R.color;
import org.sendi.parking.ui.R.id;
import org.sendi.parking.ui.R.layout;

import com.google.gson.Gson;
import com.lidroid.xutils.view.annotation.ViewInject;
import com.lidroid.xutils.view.annotation.event.OnClick;
import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.ctx.ParkingConstant;
import com.sendi.lhparking.model.OrderViewModel;
import com.sendi.lhparking.server.IServer;
import com.sendi.lhparking.ui.common.base.BaseActivityWithDialog;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

/**
 * 点击查看 已完成订单的界面
 * 
 * @author Administrator
 * 
 */
public class ViewOrderHistoryActivity extends BaseActivityWithDialog {

	public static final int REQ_EVALUATION = 1001;

	public static final int EVA_TYPE_CAR_TO_PARK = 1;
	public static final int EVA_TYPE_PARK_TO_CAR = 2;

	// for top bar
	@ViewInject(R.id.topbar_left_btn)
	private TextView vTopLeft;
	@ViewInject(R.id.topbar_center_btn)
	private TextView vTopCenter;
	@ViewInject(R.id.topbar_right_btn)
	private TextView vTopRight;

	@OnClick(value = { R.id.topbar_left_btn })
	public void topLeftClick(View v) {
		finish();
	}

	@ViewInject(R.id.history_order_parking_owner_info_panel)
	private View vOwnerInfoPanel;
	@ViewInject(R.id.history_order_parking_owner_name)
	private TextView vParkingOwner;
	@ViewInject(R.id.history_order_address)
	private TextView vParkingInfo;
	@ViewInject(R.id.history_order_parking_price)
	private TextView vParkingPublishPrice;

	@ViewInject(R.id.history_order_car_owner_info_panel)
	private View vCarOwnerInfoPanel;
	@ViewInject(R.id.history_order_car_owner)
	private TextView vCarOwner;
	@ViewInject(R.id.history_order_car_num)
	private TextView vCarNum;
	@ViewInject(R.id.history_order_car_in_time)
	private TextView vCarInTime;
	@ViewInject(R.id.history_order_car_out_time)
	private TextView vCarOutTime;

	@ViewInject(R.id.history_order_pay_info)
	private TextView vPayTotal;
	@ViewInject(R.id.history_order_pay_desc)
	private TextView vPayDesc;

	@ViewInject(R.id.history_order_option_panel)
	private View vOptPanel;
	@ViewInject(R.id.history_order_do_evalution)
	private TextView vEvaluation;

	@OnClick(value = { R.id.history_order_do_evalution })    // 评价
	private void doEvalution(View view) {
		Intent intent = new Intent(this, EvaluationActivity.class);
		intent.putExtra(ParkingConstant.INTENT_EXTRA_EVALUTION_ORDERID,   // 订单 ID
				mOrderId);
		intent.putExtra(ParkingConstant.INTENT_EXTRA_EVALUTION_MASTERID,   // 评价者ID
				mEvaType == EVA_TYPE_CAR_TO_PARK ? mModel.getWorker_id()
						: mModel.getBoss_id());
		intent.putExtra(
				ParkingConstant.INTENT_EXTRA_EVALUTION_GUESTID,             // 被评价者ID 
				mEvaType == EVA_TYPE_CAR_TO_PARK ? mModel.getBoss_id() : mModel
						.getWorker_id());
		startActivityForResult(intent, REQ_EVALUATION);
	}

	private OrderViewModel mModel;
	private String mOrderId;
	private boolean isFromSystem;

	private int mEvaType = -1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_view_order_history);
		if (!parseIntent()) {
			showToastTips("数据错误");
			finish();
			return;
		}
		initViews();
		getOrderModelFromServer();
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		if (isFromSystem && ParkingApp.mAppCtx.isNeedLoadMainActivity()) {
			startActivity(new Intent(this, AppActivity.class));
		}
	}

	private void initViews() {
		// TODO Auto-generated method stub
		vTopLeft.setText("  返 回");
		vTopCenter.setText("订单记录");
		vTopLeft.setVisibility(View.VISIBLE);
	}

	private boolean parseIntent() {
		Intent intent = getIntent();
		if (intent != null) {
			mOrderId = intent
					.getStringExtra(ParkingConstant.INTENT_EXTRA_ORDER_ID);
			isFromSystem = intent.getBooleanExtra(
					ParkingConstant.INTENT_EXTRA_BOOL_FROM_SYSMSG, false);
			if (mOrderId != null) {
				return true;
			}
		}
		return false;
	}

	private void getOrderModelFromServer() {
		showProgressDialog();
		getJsonFromServer(mServer.getURL(IServer.URL_FLAG_GET_ORDER_VIEW,
				mOrderId));
	}

	@Override
	protected void callbackFromGetJsonSuccess(String json) {
		// TODO Auto-generated method stub
		dismissDialog(DIALOG_PROGRESS);
		Log.i("qh", "json : " + json);
		Gson gson = new Gson();
		mModel = gson.fromJson(json, OrderViewModel.class);
		if (mModel == null) {
			showToastTips("数据错误");
			finish();
			return;
		}
		handleUI();
	}

	private void handleUI() {
		// TODO Auto-generated method stub
		vParkingOwner.setText(mModel.getBoss_name());
		vParkingInfo.setText(mModel.getParking_no());
		vParkingPublishPrice.setText(mModel.getPrice());

		vCarOwner.setText(mModel.getWorker_name());
		vCarNum.setText(mModel.getCar_no());
		vCarInTime.setText(mModel.getCar_in_time());
		vCarOutTime.setText(mModel.getCar_out_time());
		String evatips = null;
		String paytips = null;
		int color = -1;
		if (ParkingApp.mAppCtx.isRoleGuard()) {// 物业
			paytips = "+" + mModel.getConsume();
			color = getResources().getColor(
					R.color.text_in_come);
		} else if (ParkingApp.mAppCtx.isRoleParkingOwner(mModel.getBoss_id())) {// 业主
			vOwnerInfoPanel.setVisibility(View.GONE);
			paytips = "+" + mModel.getConsume();
			color = getResources().getColor(
					R.color.text_in_come);
			if(!mModel.hasEvaParkToCar()){
				mEvaType = EVA_TYPE_PARK_TO_CAR;
				evatips = "对车主进行评价";
			}
			if(mModel.getState_int().equals("-1") ) {   // 取消了的订单是否可以评价？
				mEvaType = -1;
			}
		} else if(ParkingApp.mAppCtx.isRoleCarOwner(mModel.getWorker_id())){// 车主
			vCarOwnerInfoPanel.setVisibility(View.GONE);
			paytips = "-" + mModel.getConsume();
			color = getResources().getColor(
					R.color.text_pay_out);
			
			if(!mModel.hasEvaCarToPark()){
				mEvaType = EVA_TYPE_CAR_TO_PARK;
				evatips = "对业主进行评价";
			}
			if(mModel.getState_int().equals("-1") ) {   // 取消了的订单是否可以评价？
				mEvaType = -1;
			}
		}
		vPayTotal.setText(paytips);
		vPayTotal.setTextColor(color);
		vPayDesc.setText(mModel.getDesc());
		Log.i("qh", "mEvaType = ? "+mEvaType);
		if (mEvaType != -1) {
			vEvaluation.setText(evatips);
			vOptPanel.startAnimation(AnimationUtils.loadAnimation(this,
					R.anim.visible_from_bottom));
			vOptPanel.setVisibility(View.VISIBLE);
		}
	}
	
	@Override
	protected void callbackFromGetJsonFail(int failcode, String msg) {
		// TODO Auto-generated method stub
		dismissDialog(DIALOG_PROGRESS);
		showToastTips("数据错误");
		finish();
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		if(resultCode == Activity.RESULT_OK){
			vOptPanel.setVisibility(View.GONE);
		}
	}
}
