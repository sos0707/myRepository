package com.sendi.lhparking.ui.common;


import org.sendi.parking.ui.R;
import org.sendi.parking.ui.R.id;
import org.sendi.parking.ui.R.layout;

import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.view.annotation.ViewInject;
import com.lidroid.xutils.view.annotation.event.OnClick;
import com.sendi.lhparking.ui.common.frag.PersonInfoFragment;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.view.Window;
import android.widget.TextView;

/**
 * 评价页面
 * 
 * @author Administrator
 * 
 */
public class PersonInfoActivity extends FragmentActivity {
	
	// for top bar
	@ViewInject(R.id.topbar_left_btn)
	protected TextView vTopLeft;
	@ViewInject(R.id.topbar_center_btn)
	protected TextView vTopCenter;
	@ViewInject(R.id.topbar_right_btn)
	protected TextView vTopRight;
	
	@OnClick(value={R.id.topbar_left_btn})
	private void topLeftDoCancel(View view){
		finish();
	}

	@Override
	protected void onCreate(Bundle bundle) {
		// TODO Auto-generated method stub
		super.onCreate(bundle);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_fragment_default_layout);
		ViewUtils.inject(this);
		
		vTopCenter.setText("我的信息");
		vTopLeft.setText("  返 回");
		vTopLeft.setVisibility(View.VISIBLE);
		
		FragmentManager mgr = getSupportFragmentManager();
		FragmentTransaction trans = mgr.beginTransaction();
		trans.add(R.id.activity_frag_default_content, PersonInfoFragment.newInstance());
		trans.commit();
	}

}
