package com.sendi.lhparking.ui.common;

import org.json.JSONException;
import org.json.JSONObject;
import org.sendi.parking.ui.R;

import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.util.MD5Crypter;
import com.sendi.lhparking.util.ParkingPrefs;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnDismissListener;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.TextView.OnEditorActionListener;
/**
 * 登录
 * @author Administrator
 *
 */
public class LoginActivity extends BaseActivity {

	private ProgressDialog dialog;
	private EditText edUsername, edPassword;
	private Button btnLogin, btnRegist;
	private TextView tvForgetpsw, tvStatement;
	private static final String TAG = "TEST";
	public static final String AUTO_LOGIN = "auto_login";
	public static final String PREF_LANGHUA_UID = "langhua_uid";/* string */
	public static final String PREF_LANGHUA_UTYPE = "langhua_utype";/* string */
	public static final int RESULT_CODE_LOGIN_SUCCESS = 101;
	public static final int REQUEST_LOGIN = 11;
	private Dialog mDialog;
	private ProgressDialog proDialog;
	private String curShowView = "0";
	private int dialogDismiss = 0;
	private int mAppTypeCode = 0;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		setContentView(R.layout.activity_login);
		init();
		try{
			if( this.getIntent().getStringExtra("phone") != null ){
				String phone = this.getIntent().getStringExtra("phone");
				String password = this.getIntent().getStringExtra("password");
				doLogin(phone, password);
			}
		}catch(Exception e){
			
		}
		
	}

	private void init() {
		edUsername = (EditText) this.findViewById(R.id.username_edit);
		edPassword = (EditText) this.findViewById(R.id.password_edit);
		tvForgetpsw = (TextView) this.findViewById(R.id.tvForgetpsw);
		tvStatement = (TextView) this.findViewById(R.id.tvStatement);
		btnLogin = (Button) this.findViewById(R.id.btn_login);
		btnRegist = (Button) this.findViewById(R.id.btn_regist);
		edUsername.setInputType(EditorInfo.TYPE_CLASS_PHONE);

		btnLogin.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if (edUsername.getText().length() == 0
						|| edUsername.getText().length() > 11) {
					showTipsDialog("请输入正确的手机号码");
					return;
				}
				if (edPassword.getText().length() == 0) {
					showTipsDialog("请输入密码");
					return;
				}
				boolean bo = isNetConnected();
				if(bo) {
					btnLogin.setClickable(false);
					doLogin(edUsername.getText().toString(), edPassword.getText()
							.toString());
				}else {
					Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
				}
			}
		});

		btnRegist.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(LoginActivity.this,
						RegisterActivity.class);
				startActivity(intent);
				LoginActivity.this.finish();
			}
		});

		tvForgetpsw.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(LoginActivity.this,
						ForgetPswActivity.class);
				startActivity(intent);
//				LoginActivity.this.finish();
			}
		});
		
		tvStatement.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(LoginActivity.this, StatementActivity.class);
				startActivity(intent);
			}
		});
		
		edPassword.setOnEditorActionListener(new OnEditorActionListener() {
			
			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				// TODO Auto-generated method stub
				switch(actionId) {
				case EditorInfo.IME_ACTION_DONE:
					btnLogin.performClick();
					break;
				}
				return false;
			}
		});
	}

	private void doLogin(String username, String password) {
		curShowView = "Login";
		String psw = MD5Crypter.MD5Encode(password);
		RequestParams params = new RequestParams();
		params.addBodyParameter("phone", username);
		params.addBodyParameter("password", psw);
		params.addBodyParameter("method", "2012");
Log.i("TEST", "Login url : " +ServerURL+"?method=2012&phone="+username+"&password="+psw );
		HttpUtils http = new HttpUtils(10000);
		showProgDialog("正在登陆...", http);
		http.send(HttpMethod.POST, ServerURL, params,
				new RequestCallBack<String>() {

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// TODO Auto-generated method stub
						Log.i("TEST", "Login result : " + responseInfo.result);
						if(curShowView.equals("Login")) {
							try {
								JSONObject jsob = new JSONObject(
										responseInfo.result);
								boolean bo = jsob.getBoolean("success");
								String msg = jsob.getString("msg");
								if (bo) {
									String[] ss = msg.split("\\,");
									showDialog();
									ParkingPrefs.setStrValue(PREF_LANGHUA_UID,
											ss[0]);
									ParkingPrefs.setStrValue(PREF_LANGHUA_UTYPE,
											String.valueOf(ParkingApp.mAppCtx.getAppTypeCode()));
//									ParkingPrefs.setStrValue(PREF_LANGHUA_UTYPE,
//											ss[1]);
									Log.i(TAG, "uid: " + ss[0]);
									ParkingApp.mAppCtx.startXmppService();
								} else {
									showTipsDialog(msg);
								}
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							if (proDialog != null) {
								dialogDismiss = 1;
								proDialog.dismiss();
							}
						}
						
						Log.i(TAG, responseInfo.result);
					}

					@Override
					public void onFailure(HttpException error, String msg) {
						// TODO Auto-generated method stub
						if(curShowView.equals("Login")) {
							Toast.makeText(LoginActivity.this, "登录失败", Toast.LENGTH_LONG).show();
						}
						if (proDialog != null) {
							dialogDismiss = 1;
							proDialog.dismiss();
						}
					}
				});

	}

	private void showTipsDialog(String msg) {
		AlertDialog dialog;
		AlertDialog.Builder builder = new AlertDialog.Builder(
				LoginActivity.this);
		builder.setTitle("消息").setIcon(android.R.drawable.stat_notify_error);
		builder.setMessage(msg);
		builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub

			}
		});
		dialog = builder.create();
		dialog.show();
	}

	private void showProgDialog(String msg) {
		dialog = ProgressDialog.show(LoginActivity.this, "消息", msg);
	}

	private void showDialog() {
		if (mDialog == null) {
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setTitle("提醒");
			builder.setMessage("下次是否自动登录？");
			builder.setCancelable(false);
			builder.setNegativeButton("取消",
					new DialogInterface.OnClickListener() {

						@Override
						public void onClick(DialogInterface dialog, int which) {
							// TODO Auto-generated method stub
							mDialog.dismiss();
							ParkingPrefs.setBoolValue(AUTO_LOGIN, false);
							setResult(RESULT_CODE_LOGIN_SUCCESS);
							LoginActivity.this.finish();
							if (!ParkingApp.mAppCtx.isHasMainActivity()) {
								ParkingApp.mAppCtx.startMainActivity();
							}
						}
					});
			builder.setPositiveButton("确定",
					new DialogInterface.OnClickListener() {

						@Override
						public void onClick(DialogInterface dialog, int which) {
							// TODO Auto-generated method stub\
							setResult(RESULT_CODE_LOGIN_SUCCESS);
							ParkingPrefs.setBoolValue(AUTO_LOGIN, true);
							LoginActivity.this.finish();
							if (!ParkingApp.mAppCtx.isHasMainActivity()) {
								ParkingApp.mAppCtx.startMainActivity();
							}
						}
					});
			mDialog = builder.create();
		}
		mDialog.show();
	}

	private void showProgDialog(final String msg, final HttpUtils httpUtils) {
		proDialog = new ProgressDialog(this);
		proDialog.setCanceledOnTouchOutside(false);
		proDialog.setOnDismissListener(new OnDismissListener() {
			
			@Override
			public void onDismiss(DialogInterface dialog) {
				// TODO Auto-generated method stub
				btnLogin.setClickable(true);
				if(dialogDismiss == 0 ) {
					httpUtils.getHttpClient().getConnectionManager().closeExpiredConnections();
//					httpUtils.getHttpClient().getConnectionManager().shutdown();
				}
				dialogDismiss = 0;
				curShowView = "0";
				Log.i(TAG, "dialog dismiss : "+msg);
			}
		});
		proDialog.setMessage(msg);
		proDialog.show();
	}
	
}
