package com.sendi.lhparking.ui.common.base;


import com.ab.util.AbStrUtil;
import com.lidroid.xutils.DbUtils;
import com.lidroid.xutils.ViewUtils;
import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.server.IServer;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.widget.Toast;

/**
 * 
 * @author Administrator
 * 
 */
public class BaseFragmentActivity extends FragmentActivity {

	public static final int DIALOG_BOTTOM = 1;
	public static final int DIALOG_PROGRESS = 10;

	protected IServer mServer;
	protected DbUtils mDB;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		mServer = ParkingApp.mAppCtx.getServerConfig();
		mDB = DbUtils.create(this);
		diaplayWidth = getWindowManager().getDefaultDisplay().getWidth();
		if (diaplayWidth < 400) {
			dialogPadding = 30;
		} else if (diaplayWidth > 700) {
			dialogPadding = 50;
		}
	}

	public IServer getServer() {
		return mServer;
	}

	public DbUtils getDB() {
		return mDB;
	}

	@Override
	public void setContentView(int layoutResID) {
		// TODO Auto-generated method stub
		super.setContentView(layoutResID);
		ViewUtils.inject(this);
	}

	@Override
	public void setContentView(View view) {
		// TODO Auto-generated method stub
		super.setContentView(view);
		ViewUtils.inject(this);
	}

	@Override
	public void setContentView(View view, LayoutParams params) {
		// TODO Auto-generated method stub
		super.setContentView(view, params);
		ViewUtils.inject(this);
	}

	public void showToastTips(String text) {
		Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
	}
	
	// ----------------提供dialog功能 -------------------------------

	private int diaplayWidth;
	private int dialogPadding;
	private int showingDialogId = -1;

	private Dialog mBottomDialog;
	/** 加载框的文字说明. */
	private String mProgressMessage = "请稍候...";
	
	/** 全局的加载框对象，已经完成初始化. */
	private ProgressDialog mProgressDialog;
	
	public void showProgressDialog(){
		showProgressDialog(null);
	}
	
	/**
	 * 描述：显示进度框.
	 * @param message the message
	 */
	@SuppressWarnings("deprecation")
	public void showProgressDialog(String message) {
		// 创建一个显示进度的Dialog
		if(!AbStrUtil.isEmpty(message)){
			mProgressMessage = message;
		}
		if (mProgressDialog == null) {
			mProgressDialog = new ProgressDialog(this);
			// 设置点击屏幕Dialog不消失    
			mProgressDialog.setCanceledOnTouchOutside(false);
			mProgressDialog.setOnDismissListener(new OnDismissListener() {
				
				@Override
				public void onDismiss(DialogInterface dialog) {
					// TODO Auto-generated method stub
					showingDialogId = -1;
					callbackOnDismissDialog(dialog);
				}
			});
		}
		mProgressDialog.setMessage(mProgressMessage);
		showingDialogId = DIALOG_PROGRESS;
		showDialog(DIALOG_PROGRESS);
    }

	@SuppressWarnings("deprecation")
	public void showDialog(int dialogid, View contentView) {
		if(showingDialogId == dialogid){
			changeDialogView(contentView);
			return;
		}
		if (dialogid == DIALOG_BOTTOM) {
			if (mBottomDialog == null) {
				mBottomDialog = new Dialog(this);
				setDialogLayoutParams(mBottomDialog, dialogPadding,
						Gravity.BOTTOM);
				mBottomDialog.setOnDismissListener(new OnDismissListener() {
					
					@Override
					public void onDismiss(DialogInterface dialog) {
						// TODO Auto-generated method stub
						showingDialogId = -1;
						callbackOnDismissDialog(dialog);
					}
				});
			}
			showingDialogId = dialogid;
			changeDialogView(contentView);
			showDialog(dialogid);
		}
	}
	
	// dialog display
	/**
	 * 描述：设置弹出Dialog的属性.
	 * 
	 * @param dialog
	 *            弹出Dialog
	 * @param dialogPadding
	 *            如果Dialog不是充满屏幕，要设置这个值
	 * @param gravity
	 *            the gravity
	 */
	private void setDialogLayoutParams(Dialog dialog, int dialogPadding,
			int gravity) {
		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		Window window = dialog.getWindow();
		WindowManager.LayoutParams lp = window.getAttributes();
		// 此处可以设置dialog显示的位置
		window.setGravity(gravity);
		// 设置宽度
		lp.width = diaplayWidth - dialogPadding;
		lp.type = WindowManager.LayoutParams.TYPE_APPLICATION_ATTACHED_DIALOG;
		// 背景透明
		// lp.screenBrightness = 0.2f;
		lp.alpha = 0.8f;
		lp.dimAmount = 0f;
		window.setAttributes(lp);
		// 添加动画
		window.setWindowAnimations(android.R.style.Animation_Dialog);
		// 设置点击屏幕Dialog不消失
		dialog.setCanceledOnTouchOutside(false);

	}
	
	private Dialog getDialogById(int dialogid){
		if(dialogid == DIALOG_BOTTOM){
			return mBottomDialog;
		}
		return null;
	}
	
	private void changeDialogView(View contentView){
		Dialog dialog = getDialogById(showingDialogId);
		if(dialog == null){
			return;
		}
		dialog.setContentView(contentView, new LayoutParams(
				diaplayWidth - dialogPadding, LayoutParams.WRAP_CONTENT));
	}
	
	protected void callbackOnDismissDialog(DialogInterface dialog){
		//empty
	}
	
	public boolean isShowingDialog(){
		return showingDialogId != -1;
	}

	@Override
	protected Dialog onCreateDialog(int id) {
		// TODO Auto-generated method stub
		switch (id) {
		case DIALOG_BOTTOM:
			return mBottomDialog;
		case DIALOG_PROGRESS:
			return mProgressDialog;
		default:
			break;
		}
		return null;
	}
	
}
