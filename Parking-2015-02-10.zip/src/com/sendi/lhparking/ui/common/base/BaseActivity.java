package com.sendi.lhparking.ui.common.base;


import com.lidroid.xutils.DbUtils;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.server.IServer;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.widget.Toast;

/**
 * 不提供 dialog
 * @author Administrator
 * 1.ioc注入
 * 2.json基本反问
 */
public class BaseActivity extends Activity {

	public static final int DIALOG_BOTTOM = 1;
	public static final int DIALOG_PROGRESS = 10;
	private static final String DB_NAME = "LANGHUA_DB";
	protected IServer mServer;
	protected DbUtils mDB;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		mServer = ParkingApp.mAppCtx.getServerConfig();
		mDB = DbUtils.create(this);
//		mDB = DbUtils.create(this,DB_NAME);
	}

	@Override
	public void setContentView(int layoutResID) {
		// TODO Auto-generated method stub
		super.setContentView(layoutResID);
		ViewUtils.inject(this);
	}

	@Override
	public void setContentView(View view) {
		// TODO Auto-generated method stub
		super.setContentView(view);
		ViewUtils.inject(this);
	}

	@Override
	public void setContentView(View view, LayoutParams params) {
		// TODO Auto-generated method stub
		super.setContentView(view, params);
		ViewUtils.inject(this);
	}

	public void showToastTips(String text) {
		Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
	}

	// ----------------------
	public void getJsonFromServer(String url) {
		HttpUtils http = new HttpUtils();
		http.configTimeout(10000);
		http.configSoTimeout(6000);
		http.configDefaultHttpCacheExpiry(5000);//5秒内请求 使用缓存
		Log.i("qh", "url : " + url);
		http.send(HttpMethod.GET, url, new RequestCallBack<String>() {

			@Override
			public void onSuccess(ResponseInfo<String> responseInfo) {
				// TODO Auto-generated method stub
				Log.i("qh", "result from cache : "+responseInfo.resultFormCache);
				Log.i("qh", "result code : "+responseInfo.statusCode);
				callbackFromGetJsonSuccess(responseInfo.result);
			}

			@Override
			public void onFailure(HttpException error, String msg) {
				// TODO Auto-generated method stub
				callbackFromGetJsonFail(error.getExceptionCode(), msg);
			}
		});
	}

	// call back
	protected void callbackFromGetJsonSuccess(String json) {
		// empty
	}

	protected void callbackFromGetJsonFail(int failcode, String msg) {
		// empty
	}

	// -----------------------------------------------
}
