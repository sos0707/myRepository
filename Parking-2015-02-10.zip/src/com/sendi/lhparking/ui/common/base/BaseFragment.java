package com.sendi.lhparking.ui.common.base;


import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;

import android.app.Activity;
import android.support.v4.app.Fragment;
import android.util.Log;

/**
 * 
 * @author Administrator
 *
 */
public abstract class BaseFragment<A extends BaseFragmentActivity> extends Fragment{
	
	protected A mOwner;
	
	@SuppressWarnings("unchecked")
	@Override
	public void onAttach(Activity activity) {
		// TODO Auto-generated method stub
		super.onAttach(activity);
		this.mOwner = (A) activity;
	}
	
	protected void getJsonFromServer(String url) {
		HttpUtils http = new HttpUtils();
		http.configDefaultHttpCacheExpiry(500);// 1秒内请求 使用缓存
		Log.i("qh", "url : " + url);
		http.send(HttpMethod.GET, url, new RequestCallBack<String>() {

			@Override
			public void onSuccess(ResponseInfo<String> responseInfo) {
				// TODO Auto-generated method stub
				Log.i("TEST", "getJsonFromServer Success : " + responseInfo.result);
				callbackFromGetJsonSuccess(responseInfo.result);
			}

			@Override
			public void onFailure(HttpException error, String msg) {
				// TODO Auto-generated method stub
				callbackFromGetJsonFail(error.getExceptionCode(), msg);
			}
		});
	}
	
	// call back
	protected void callbackFromGetJsonSuccess(String json) {
		// empty
	}

	protected void callbackFromGetJsonFail(int failcode, String msg) {
		// empty
	}

}
