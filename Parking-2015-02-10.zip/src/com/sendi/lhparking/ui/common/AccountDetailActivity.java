package com.sendi.lhparking.ui.common;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.sendi.parking.ui.R;

import com.ab.view.pullview.AbPullToRefreshView;
import com.ab.view.pullview.AbPullToRefreshView.OnFooterLoadListener;
import com.ab.view.pullview.AbPullToRefreshView.OnHeaderRefreshListener;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.sendi.lhparking.adapter.AccountDetailStickyListAdapter;
import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.payutil.Result;
import com.sendi.lhparking.ui.chezhu.TransferAccountActivity;
import com.sendi.lhparking.util.AccountBaseInfo;
import com.sendi.lhparking.util.AccountDetailInfo;
import com.sendi.lhparking.view.StickyListHeadersListView;
import com.sendi.lhparking.view.StickyListHeadersListView.OnHeaderClickListener;
import com.sendi.lhparking.view.StickyListHeadersListView.OnLoadingMoreLinstener;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnDismissListener;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.PaintDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.RelativeLayout.LayoutParams;

/**
 * 账本详细界面
 * @author Administrator
 *
 */
public class AccountDetailActivity extends BaseActivity implements OnHeaderClickListener,AdapterView.OnItemClickListener
,OnLoadingMoreLinstener, OnHeaderRefreshListener, OnFooterLoadListener {

	private double totalIn = 0, totalOut = 0;
	private List<AccountDetailInfo> accountDetailInfos = null;
	private List<AccountDetailInfo> accountSortInfos = null;
	private StickyListHeadersListView lvAccountDetail;
	private PopupWindow pwAccounttype;
	private AccountDetailStickyListAdapter adapter;
	private LayoutInflater inflater;
	private RelativeLayout moredata;
	private View progressBarView;
	private TextView progressBarTextView;
	private AnimationDrawable loadingAnimation; //加载更多，动画
	private boolean isLoading = false;
	private Drawable imgUp, imgDown;
	private int iYear, iMonth;
	private String curDate, date;
	private boolean isShowAll = true;
	private String curType = "  全    部";
	
	private ProgressDialog mDialog;
	private String curShowView = "0";
	private int dialogDismiss = 0;
	private int layoutNo = 0;
	
	private Button btnIncome, btnOutcome , btnRecharge , btnOut , btnAllinfo;
	private Button btnType ;
	private int showview = 0;
	private LinearLayout layoutShownull;
	private TextView tvShownull;
	private AbPullToRefreshView pullView;
	private Drawable rPullDrawable;//= this.getResources().getDrawable(R.drawable.progress_circular);

	private int mAppTypeCode = 0;
	
	private AccountBaseInfo bInfo;
	private TextView tvBalance, tvDayIncome;
	private boolean firstInit = false;
	private LinearLayout llayout1, llayout2;
	private int iCheckMonthCount = 1;
	private AbPullToRefreshView pullViewList;
	@SuppressLint("NewApi")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.view_account_detail);
		
		ParkingApp.mAppCtx.setPayHandler(mHandler);
		mAppTypeCode = ParkingApp.mAppCtx.getAppTypeCode();
		
		Intent intent = getIntent();
		if(intent != null) {
			showview = intent.getIntExtra("showview", 0);
		}
		rPullDrawable = this.getResources().getDrawable(R.drawable.progress_circular);
		init();
		initView();
		getCountInfo();
//		getCountDetail();
	}
	
	private void init() {
		Resources res = this.getResources();
		imgUp = res.getDrawable(R.drawable.triup);
		imgDown = res.getDrawable(R.drawable.tridown);
		imgUp.setBounds(0, 0, imgUp.getMinimumWidth(), imgUp.getMinimumHeight());
		imgDown.setBounds(0, 0, imgDown.getMinimumWidth(), imgDown.getMinimumHeight());
		Calendar calendar = Calendar.getInstance();
		iYear = calendar.get(Calendar.YEAR);
		iMonth = calendar.get(Calendar.MONTH)+1;
		if(iMonth<10) {
			String smonth = "0"+String.valueOf(iMonth);
			curDate = String.valueOf(iYear)+"-"+smonth;
		}else {
			curDate = String.valueOf(iYear)+"-"+String.valueOf(iMonth);
		}
		date = curDate;
		accountDetailInfos = new ArrayList<AccountDetailInfo>();
		accountSortInfos = new ArrayList<AccountDetailInfo>();
		Log.i(TAG, "showAccountDetailView");
		
		inflater = LayoutInflater.from(this);
		moredata = (RelativeLayout)inflater.inflate(R.layout.list_accountdetail_footer_item, null);
		progressBarView = (View) moredata.findViewById(R.id.loadmore_foot_progressbar);
		progressBarTextView = (TextView) moredata.findViewById(R.id.loadmore_foot_text);
		loadingAnimation = (AnimationDrawable) progressBarView.getBackground();
		
		
	}
	
	@SuppressLint("NewApi")
	private void initView() {
		setContentView(R.layout.view_account_detail);
		View v1 = LayoutInflater.from(AccountDetailActivity.this).inflate(R.layout.popw_accounttype, null);
		btnIncome = (Button) v1.findViewById(R.id.btnIncome);
		btnOutcome = (Button) v1.findViewById(R.id.btnOutcome);
		btnRecharge = (Button) v1.findViewById(R.id.btnRecharge);
		btnOut = (Button) v1.findViewById(R.id.btnOut);
		btnAllinfo = (Button) v1.findViewById(R.id.btnAllinfo);
		tvBalance  = (TextView) this.findViewById(R.id.tvBalance);
		tvDayIncome  = (TextView) this.findViewById(R.id.tvDayIncome);
		llayout1 = (LinearLayout) this.findViewById(R.id.llayout1);
		llayout2 = (LinearLayout) this.findViewById(R.id.llayout2);
		
		tvBalance.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				getCountInfo();
			}
		});
		
		switch(mAppTypeCode) {
		case 2:
			btnIncome.setVisibility(View.GONE);
			btnOut.setVisibility(View.GONE);
			llayout2.setVisibility(View.GONE);
			break;
		case 1:
			btnOutcome.setVisibility(View.GONE);
			btnRecharge.setVisibility(View.GONE);
			llayout1.setVisibility(View.GONE);
			break;
		case 4:
			btnOutcome.setVisibility(View.GONE);
			btnRecharge.setVisibility(View.GONE);
			llayout1.setVisibility(View.GONE);
			break;
		}
		pullView = (AbPullToRefreshView) this.findViewById(R.id.null_pull_view);
		pullView.setOnHeaderRefreshListener(this);
		pullView.getHeaderView().setHeaderProgressBarDrawable(rPullDrawable);
		pullView.setPullRefreshEnable(true);
		pullView.setLoadMoreEnable(false);
		
		pullViewList = (AbPullToRefreshView) this.findViewById(R.id.list_pull_view);
		pullViewList.setOnHeaderRefreshListener(this);
		pullViewList.setOnFooterLoadListener(this);
		pullViewList.getHeaderView().setHeaderProgressBarDrawable(rPullDrawable);
		pullViewList.setPullRefreshEnable(true);
		pullViewList.setLoadMoreEnable(true);
//		pullView.setOnHeaderRefreshListener(new OnHeaderRefreshListener() {
//			
//			@Override
//			public void onHeaderRefresh(AbPullToRefreshView view) {
//				// TODO Auto-generated method stub
//				OnLoadingMore();
//			}
//		});
		
		layoutNo = 0;
		isShowAll = true;
//		final LinearLayout layoutShownull = (LinearLayout) this.findViewById(R.id.layoutShownull);
		layoutShownull = (LinearLayout) this.findViewById(R.id.layoutShownull);
		
		pullView.setVisibility(View.VISIBLE);
		layoutShownull.setVisibility(View.VISIBLE);
		
		pwAccounttype = new PopupWindow(v1, LayoutParams.MATCH_PARENT,LayoutParams.MATCH_PARENT);
		final LinearLayout layout = (LinearLayout) this.findViewById(R.id.layoutbtn);
//		TextView tvTitle = (TextView) this.findViewById(R.id.topbar_center_btn);    // 原来的标题栏
//		TextView tvReturn = (TextView) this.findViewById(R.id.topbar_left_btn);
		tvShownull = (TextView) this.findViewById(R.id.tvShownull);
//		final TextView tvShownull = (TextView) this.findViewById(R.id.tvShownull);
		final Button btnAll = (Button) this.findViewById(R.id.btnAll);
		btnType = (Button) this.findViewById(R.id.btnType);
		adapter = new AccountDetailStickyListAdapter(this, accountDetailInfos);

		lvAccountDetail = (StickyListHeadersListView) this.findViewById(R.id.lvAccountDetail);
		lvAccountDetail.addFooterView(moredata);
		lvAccountDetail.setAdapter(adapter);
		lvAccountDetail.setLoadingMoreListener(this);
		lvAccountDetail.setOnItemClickListener(this);
		lvAccountDetail.setOnHeaderClickListener(this);
//		btnAll.setBackground(this.getResources().getDrawable(R.drawable.leftdown_shape));
		btnAll.setBackgroundResource(R.drawable.leftdown_shape);
		btnAll.setTextColor(Color.WHITE);
		btnType.setCompoundDrawables(null, null, imgDown, null);
//		tvReturn.setVisibility(View.VISIBLE);
//		tvTitle.setText("我的账本");
//		tvReturn.setText("  返 回");
//
//		tvReturn.setOnClickListener(new OnClickListener() {
//			
//			@Override
//			public void onClick(View arg0) {
//				// TODO Auto-generated method stub
//				Message msg = new Message();
//				msg.what = 3;
//				ParkingApp.payHandler.sendMessage(msg);
//				hideKeyborad();
//				AccountDetailActivity.this.finish();
//			}
//		});
		
		pwAccounttype.setOnDismissListener(new android.widget.PopupWindow.OnDismissListener() {
			
			@Override
			public void onDismiss() {
//					btnType.setBackground(AccountDetailActivity.this.getResources().getDrawable(R.drawable.rightup_shape));
					btnType.setBackgroundResource(R.drawable.rightup_shape);
					btnType.setTextColor(Color.BLACK);
					btnType.setCompoundDrawables(null, null, imgDown, null);
					btnType.setText(curType);
			}
		});
		
		btnType.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
//				btnType.setBackground(AccountDetailActivity.this.getResources().getDrawable(R.drawable.rightdown_shape));
				btnType.setBackgroundResource(R.drawable.rightdown_shape);
				btnType.setTextColor(Color.WHITE);
//				btnAll.setBackground(AccountDetailActivity.this.getResources().getDrawable(R.drawable.leftup_shape));
				btnAll.setBackgroundResource(R.drawable.leftup_shape);
				btnAll.setTextColor(Color.BLACK);
				btnType.setCompoundDrawables(null, null, imgUp, null);
				
				pwAccounttype.setBackgroundDrawable(new PaintDrawable(0x00000000));  
				pwAccounttype.setOutsideTouchable(false);
				pwAccounttype.setFocusable(true);
				pwAccounttype.showAsDropDown(layout);
			}
		});
		
		btnIncome.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				accountSortInfos.clear();
				for(int i=0; i<accountDetailInfos.size(); i++) {
					AccountDetailInfo info = accountDetailInfos.get(i);
					if(info.getTaskName().equals("收益")) {
						accountSortInfos.add(info);
					}
				}
				if(accountSortInfos.size() == 0) {
					tvShownull.setText("\" 收益 \" 分类记录为空");
					layoutShownull.setVisibility(View.VISIBLE);
					pullView.setVisibility(View.VISIBLE);
				}else {
					adapter.updateListView(accountSortInfos);
					pullView.setVisibility(View.GONE);
					layoutShownull.setVisibility(View.GONE);
				}
				isShowAll = false;
				curType = "  收    益";
				showview = 1;
				pwAccounttype.dismiss();
			}
		});
		
		btnOutcome.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				accountSortInfos.clear();
				for(int i=0; i<accountDetailInfos.size(); i++) {
					AccountDetailInfo info = accountDetailInfos.get(i);
					if(info.getTaskName().equals("支出")) {
						accountSortInfos.add(info);
					}
				}
				if(accountSortInfos.size() == 0) {
					tvShownull.setText("\" 支出 \" 分类记录为空");
					pullView.setVisibility(View.VISIBLE);
					layoutShownull.setVisibility(View.VISIBLE);
				}else {
					adapter.updateListView(accountSortInfos);
					pullView.setVisibility(View.GONE);
					layoutShownull.setVisibility(View.GONE);
				}
				isShowAll = false;
				curType = "  支    出";
				showview = 2;
				pwAccounttype.dismiss();
			}
		});
		
		btnRecharge.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				accountSortInfos.clear();
				for(int i=0; i<accountDetailInfos.size(); i++) {
					AccountDetailInfo info = accountDetailInfos.get(i);
					if(info.getTaskName().equals("充值")) {
						accountSortInfos.add(info);
					}
				}
				if(accountSortInfos.size() == 0) {
					tvShownull.setText("\" 充值 \" 分类记录为空");
					pullView.setVisibility(View.VISIBLE);
					layoutShownull.setVisibility(View.VISIBLE);
				}else {
					adapter.updateListView(accountSortInfos);
					pullView.setVisibility(View.GONE);
					layoutShownull.setVisibility(View.GONE);
				}
				isShowAll = false;
				curType = "  充    值";
				showview = 4;
				pwAccounttype.dismiss();
			}
		});
		
		btnOut.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				accountSortInfos.clear();
				for(int i=0; i<accountDetailInfos.size(); i++) {
					AccountDetailInfo info = accountDetailInfos.get(i);
					if(info.getTaskName().equals("提现")) {
						accountSortInfos.add(info);
					}
				}
				if(accountSortInfos.size() == 0) {
					tvShownull.setText("\" 提现 \" 分类记录为空");
					pullView.setVisibility(View.VISIBLE);
					layoutShownull.setVisibility(View.VISIBLE);
				}else {
					adapter.updateListView(accountSortInfos);
					pullView.setVisibility(View.GONE);
					layoutShownull.setVisibility(View.GONE);
				}
				isShowAll = false;
				curType = "  提    现";
				showview = 3;
				pwAccounttype.dismiss();
			}
		});
		
		btnAllinfo.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				adapter.updateListView(accountDetailInfos);
				curType = "  全    部";
				isShowAll = true;
				showview = 0;
				pullView.setVisibility(View.GONE);
				layoutShownull.setVisibility(View.GONE);
				if(accountDetailInfos.size() == 0) {
//					tvShownull.setText("本月收支记录为空");
					if(iCheckMonthCount <=10) {
						tvShownull.setText("近"+String.valueOf(iCheckMonthCount)+"月收支记录为空");
					}else {
						tvShownull.setText("近10月收支记录为空");
					}
					pullView.setVisibility(View.VISIBLE);
					layoutShownull.setVisibility(View.VISIBLE);
				}
				pwAccounttype.dismiss();
			}
		});
	
	}
	
	/** 
	 * 服务器查询收益明细
	 * */
	private void getCountDetail() {
		boolean bo = isNetConnected();
		if(!bo) {
			Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
			pullView.onHeaderRefreshFinish();
			pullViewList.onHeaderRefreshFinish();
			return;
		}
		curShowView = "CountDetail";
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID() );
//		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("utype", "1");
		params.addBodyParameter("method", "2015");
		params.addBodyParameter("month", curDate);
		
		Log.i(TAG, curDate);
		HttpUtils http = new HttpUtils(6000);
		showProgDialog("正在查询收益明细 . . .", http);
		http.send(HttpMethod.POST, 
				ServerURL, 
				params, 
				new RequestCallBack< String >() {

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// TODO Auto-generated method stub
						Log.i(TAG, responseInfo.result);
						if(curShowView.equals("CountDetail")) {
							try {
								JSONObject jsob = new JSONObject(responseInfo.result);
								int count = jsob.getInt("totalCount");
								
								totalIn = 0;
								totalOut = 0;
								if(count == 0) {
									accountDetailInfos = new ArrayList<AccountDetailInfo>();
//									AccountDetailInfo info = new AccountDetailInfo();
//									info.setUserName("user_name");
//									info.setTime(curDate);
//									info.setTaskName("本月收支记录为空");
//									info.setTaskId("task_id");
//									info.setMoney(0);
//									accountDetailInfos.add(info);
									tvShownull.setText("本月收支记录为空");
									pullView.setVisibility(View.VISIBLE);
									layoutShownull.setVisibility(View.VISIBLE);
									showAccountDetailView();
									if(dialog != null) {
										dialog.dismiss();
									}
								}else {
//									{user_name,time,task_name,task_id,money,flag} 
//									user_name：姓名  time：结算时间 money：金额（收入为正，支出为负） task_name：值为4种：收入，支出，充值，提现。 Flag：parkcar/money
//									当task_name为“充值”时，返回值 新增---pay_type_en：1支付宝 2微信支付   pay_type：pay_type_en的中文说明 amountId：交易流水号
//									  当task_name为“提现”时，返回值 新增 ---pay_type_en 1支付宝 2理财通 3：银行卡 pay_type：pay_type_en的中文说明  。
//									  account：账号。 bank：银行名称(当 pay_type=3的时候显示)
									JSONArray jsoa = jsob.getJSONArray("data");
									JSONObject jso;
									accountDetailInfos = new ArrayList<AccountDetailInfo>();
									for(int i=0; i<count; i++) {
										jso = jsoa.getJSONObject(i);
										AccountDetailInfo info = new AccountDetailInfo();
										info.setUserName(jso.getString("user_name"));
										info.setTime(jso.getString("time"));
										info.setTaskName(jso.getString("task_name"));
										info.setTaskId(jso.getString("task_id"));
										info.setMoney(jso.getDouble("money"));
										if(jso.getDouble("money") > 0) {
											totalIn = totalIn + jso.getDouble("money");
										}else {
											totalOut = totalOut + jso.getDouble("money");
										}
										if(jso.getString("task_name").equals("充值")) {
											info.setPayTypeEn(jso.getInt("pay_type_en"));
											info.setPayType(jso.getString("pay_type"));
											info.setAmountId(jso.getString("amountId"));
										}
										if(jso.getString("task_name").equals("提现")) {
											info.setPayTypeEn(jso.getInt("pay_type_en"));
											info.setPayType(jso.getString("pay_type"));
											info.setAccount(jso.getString("account"));
											info.setState(jso.getString("state"));
											if(jso.getInt("pay_type_en") == 3) {
												info.setBank(jso.getString("bank"));
											}
										}
										switch(mAppTypeCode) {
										case 0:
											accountDetailInfos.add(info);
											break;
										case 2:
											if(!jso.getString("task_name").equals("提现")&&!jso.getString("task_name").equals("收益")) {
												accountDetailInfos.add(info);
											}
											break;
										default:
											if(!jso.getString("task_name").equals("充值")&&!jso.getString("task_name").equals("支出")) {
												accountDetailInfos.add(info);
											}
											break;
										}
										
									}
									showAccountDetailView();
								}
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								pullView.onHeaderRefreshFinish();
								pullViewList.onHeaderRefreshFinish();
								e.printStackTrace();
							}
							if( mDialog != null) {
								dialogDismiss = 1;
								mDialog.dismiss();
							}
						}
						pullView.onHeaderRefreshFinish();
						pullViewList.onHeaderRefreshFinish();
					}

					@Override
					public void onFailure(HttpException error, String msg) {
						// TODO Auto-generated method stub
						Log.i(TAG, msg);
						if(curShowView.equals("CountDetail")) {
							showTipsDialog("查询失败，请检查网络连接，稍后再试 ", AccountDetailActivity.this);
						}
						pullView.onHeaderRefreshFinish();
						pullViewList.onHeaderRefreshFinish();
						if(mDialog != null) {
							dialogDismiss = 1;
							mDialog.dismiss();
						}
					}
				});
	}
	
	/** 
	 * 账本详细信息界面
	 * */
	@SuppressLint("NewApi")
	private void showAccountDetailView() {
//		Log.i(TAG, "showAccountDetailView");
//		setContentView(R.layout.view_account_detail);
		layoutNo = 0;
		isShowAll = true;
//		View v1 = LayoutInflater.from(AccountDetailActivity.this).inflate(R.layout.popw_accounttype, null);
//		final LinearLayout layoutShownull = (LinearLayout) this.findViewById(R.id.layoutShownull);
//		
//		pwAccounttype = new PopupWindow(v1, LayoutParams.MATCH_PARENT,LayoutParams.MATCH_PARENT);
//		final LinearLayout layout = (LinearLayout) this.findViewById(R.id.layoutbtn);
//		TextView tvTitle = (TextView) this.findViewById(R.id.topbar_center_btn);
//		TextView tvReturn = (TextView) this.findViewById(R.id.topbar_left_btn);
//		final TextView tvShownull = (TextView) this.findViewById(R.id.tvShownull);
//		final Button btnAll = (Button) this.findViewById(R.id.btnAll);
//		final Button btnType = (Button) this.findViewById(R.id.btnType);
//		lvAccountDetail = (StickyListHeadersListView) this.findViewById(R.id.lvAccountDetail);
//		btnAll.setBackground(this.getResources().getDrawable(R.drawable.leftdown_shape));
//		btnAll.setTextColor(Color.WHITE);
//		btnType.setCompoundDrawables(null, null, imgDown, null);
//		tvReturn.setVisibility(View.VISIBLE);
//		tvTitle.setText("我的账本");
//		tvReturn.setText("  返 回");

		adapter = new AccountDetailStickyListAdapter(this, accountDetailInfos);
		inflater = LayoutInflater.from(this);
		moredata = (RelativeLayout)inflater.inflate(R.layout.list_accountdetail_footer_item, null);
		progressBarView = (View) moredata.findViewById(R.id.loadmore_foot_progressbar);
		progressBarTextView = (TextView) moredata.findViewById(R.id.loadmore_foot_text);
		loadingAnimation = (AnimationDrawable) progressBarView.getBackground();
		lvAccountDetail.addFooterView(moredata);
		lvAccountDetail.setAdapter(adapter);
		lvAccountDetail.setLoadingMoreListener(this);
		lvAccountDetail.setOnItemClickListener(this);
		lvAccountDetail.setOnHeaderClickListener(this);
		
		switch(showview) {
		case 1:   // 收益
			btnIncome.performClick();
			pwAccounttype.dismiss();
//			btnType.setBackground(AccountDetailActivity.this.getResources().getDrawable(R.drawable.rightup_shape));
			btnType.setBackgroundResource(R.drawable.rightup_shape);
			btnType.setTextColor(Color.BLACK);
			btnType.setCompoundDrawables(null, null, imgDown, null);
			btnType.setText(curType);
			break;
		case 2:   // 支出
			btnOutcome.performClick();
//			btnType.setBackground(AccountDetailActivity.this.getResources().getDrawable(R.drawable.rightup_shape));
			btnType.setBackgroundResource(R.drawable.rightup_shape);
			btnType.setTextColor(Color.BLACK);
			btnType.setCompoundDrawables(null, null, imgDown, null);
			btnType.setText(curType);
			break;
		case 3:   // 提现
			btnOut.performClick();
//			btnType.setBackground(AccountDetailActivity.this.getResources().getDrawable(R.drawable.rightup_shape));
			btnType.setBackgroundResource(R.drawable.rightup_shape);
			btnType.setTextColor(Color.BLACK);
			btnType.setCompoundDrawables(null, null, imgDown, null);
			btnType.setText(curType);
			break;
		case 4:
			btnRecharge.performClick();
//			btnType.setBackground(AccountDetailActivity.this.getResources().getDrawable(R.drawable.rightup_shape));
			btnType.setBackgroundResource(R.drawable.rightup_shape);
			btnType.setTextColor(Color.BLACK);
			btnType.setCompoundDrawables(null, null, imgDown, null);
			btnType.setText(curType);
			break;
		default:
			btnAllinfo.performClick();
			if(accountDetailInfos.size() != 0) {
				pullView.setVisibility(View.GONE);
				layoutShownull.setVisibility(View.GONE);
			}
			break;
			
		}
//		tvReturn.setOnClickListener(new OnClickListener() {
//			
//			@Override
//			public void onClick(View arg0) {
//				// TODO Auto-generated method stub
//				hideKeyborad();
//				AccountDetailActivity.this.finish();
//			}
//		});
//		
//		pwAccounttype.setOnDismissListener(new android.widget.PopupWindow.OnDismissListener() {
//			
//			@Override
//			public void onDismiss() {
//					btnType.setBackground(AccountDetailActivity.this.getResources().getDrawable(R.drawable.rightup_shape));
//					btnType.setTextColor(Color.BLACK);
//					btnType.setCompoundDrawables(null, null, imgDown, null);
//					btnType.setText(curType);
//			}
//		});
//		
//		btnType.setOnClickListener(new OnClickListener() {
//			
//			@Override
//			public void onClick(View v) {
//				// TODO Auto-generated method stub
//				btnType.setBackground(AccountDetailActivity.this.getResources().getDrawable(R.drawable.rightdown_shape));
//				btnType.setTextColor(Color.WHITE);
//				btnAll.setBackground(AccountDetailActivity.this.getResources().getDrawable(R.drawable.leftup_shape));
//				btnAll.setTextColor(Color.BLACK);
//				btnType.setCompoundDrawables(null, null, imgUp, null);
//				
//				pwAccounttype.setBackgroundDrawable(new PaintDrawable(0x00000000));  
//				pwAccounttype.setOutsideTouchable(false);
//				pwAccounttype.setFocusable(true);
//				pwAccounttype.showAsDropDown(layout);
//			}
//		});
//		
//		btnIncome.setOnClickListener(new OnClickListener() {
//			
//			@Override
//			public void onClick(View v) {
//				// TODO Auto-generated method stub
//				accountSortInfos.clear();
//				for(int i=0; i<accountDetailInfos.size(); i++) {
//					AccountDetailInfo info = accountDetailInfos.get(i);
//					if(info.getTaskName().equals("收益")) {
//						accountSortInfos.add(info);
//					}
//				}
//				if(accountSortInfos.size() == 0) {
//					tvShownull.setText("\" 收益 \" 分类记录为空");
//					layoutShownull.setVisibility(View.VISIBLE);
//				}else {
//					adapter.updateListView(accountSortInfos);
//					layoutShownull.setVisibility(View.GONE);
//				}
//				isShowAll = false;
//				curType = "  收    益";
//				pwAccounttype.dismiss();
//			}
//		});
//		
//		btnOutcome.setOnClickListener(new OnClickListener() {
//			
//			@Override
//			public void onClick(View v) {
//				// TODO Auto-generated method stub
//				accountSortInfos.clear();
//				for(int i=0; i<accountDetailInfos.size(); i++) {
//					AccountDetailInfo info = accountDetailInfos.get(i);
//					if(info.getTaskName().equals("支出")) {
//						accountSortInfos.add(info);
//					}
//				}
//				if(accountSortInfos.size() == 0) {
//					tvShownull.setText("\" 支出 \" 分类记录为空");
//					layoutShownull.setVisibility(View.VISIBLE);
//				}else {
//					adapter.updateListView(accountSortInfos);
//					layoutShownull.setVisibility(View.GONE);
//				}
//				isShowAll = false;
//				curType = "  支    出";
//				pwAccounttype.dismiss();
//			}
//		});
//		
//		btnRecharge.setOnClickListener(new OnClickListener() {
//			
//			@Override
//			public void onClick(View v) {
//				// TODO Auto-generated method stub
//				accountSortInfos.clear();
//				for(int i=0; i<accountDetailInfos.size(); i++) {
//					AccountDetailInfo info = accountDetailInfos.get(i);
//					if(info.getTaskName().equals("充值")) {
//						accountSortInfos.add(info);
//					}
//				}
//				if(accountSortInfos.size() == 0) {
//					tvShownull.setText("\" 充值 \" 分类记录为空");
//					layoutShownull.setVisibility(View.VISIBLE);
//				}else {
//					adapter.updateListView(accountSortInfos);
//					layoutShownull.setVisibility(View.GONE);
//				}
//				isShowAll = false;
//				curType = "  充    值";
//				pwAccounttype.dismiss();
//			}
//		});
//		
//		btnOut.setOnClickListener(new OnClickListener() {
//			
//			@Override
//			public void onClick(View v) {
//				// TODO Auto-generated method stub
//				accountSortInfos.clear();
//				for(int i=0; i<accountDetailInfos.size(); i++) {
//					AccountDetailInfo info = accountDetailInfos.get(i);
//					if(info.getTaskName().equals("提现")) {
//						accountSortInfos.add(info);
//					}
//				}
//				if(accountSortInfos.size() == 0) {
//					tvShownull.setText("\" 提现 \" 分类记录为空");
//					layoutShownull.setVisibility(View.VISIBLE);
//				}else {
//					adapter.updateListView(accountSortInfos);
//					layoutShownull.setVisibility(View.GONE);
//				}
//				isShowAll = false;
//				curType = "  提    现";
//				pwAccounttype.dismiss();
//			}
//		});
//		
//		btnAllinfo.setOnClickListener(new OnClickListener() {
//			
//			@Override
//			public void onClick(View v) {
//				// TODO Auto-generated method stub
//				adapter.updateListView(accountDetailInfos);
//				curType = "  全    部";
//				isShowAll = true;
//				layoutShownull.setVisibility(View.GONE);
//				pwAccounttype.dismiss();
//			}
//		});
	}
	
	@Override
	public void OnLoadingMore() {
		// TODO Auto-generated method stub
		if(false){
			progressBarView.setVisibility(View.VISIBLE);
			progressBarTextView.setVisibility(View.VISIBLE);
			loadingAnimation.start();
			
			if(!isLoading) {
				isLoading = true;
				new Handler().postDelayed(new Runnable() {
					
					@Override
					public void run() {
						iMonth--;
						iCheckMonthCount ++;
						if(iMonth == 0) {
							iMonth = 12;
							iYear--;
						}
						if(iMonth<10) {
							String smonth = "0"+String.valueOf(iMonth);
							curDate = String.valueOf(iYear)+"-"+smonth;
						}else {
							curDate = String.valueOf(iYear)+"-"+String.valueOf(iMonth);
						}
						RequestParams params = new RequestParams();
						params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID() );
						params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
						params.addBodyParameter("method", "2015");
						params.addBodyParameter("month", curDate);
						
						Log.i(TAG, curDate);
						HttpUtils http = new HttpUtils();
						http.configTimeout(6000);
						http.send(HttpMethod.POST, 
								ServerURL, 
								params, 
								new RequestCallBack< String >() {

									@Override
									public void onSuccess(ResponseInfo<String> responseInfo) {
										// TODO Auto-generated method stub
										Log.i(TAG, responseInfo.result);
										
										try {
											JSONObject jsob = new JSONObject(responseInfo.result);
											int count = jsob.getInt("totalCount");
											totalIn = 0;
											totalOut = 0;
											if(count == 0) {
//												AccountDetailInfo info = new AccountDetailInfo();
//												info.setUserName("user_name");
//												info.setTime(curDate);
//												info.setTaskName("本月收支记录为空");
//												info.setTaskId("task_id");
//												info.setMoney(0);
//												accountDetailInfos.add(info);
											}else {
//												{user_name,time,task_name,task_id,money,flag} 
//												user_name：姓名  time：结算时间 money：金额（收入为正，支出为负） task_name：值为4种：收入，支出，充值，提现。 Flag：parkcar/money
												JSONArray jsoa = jsob.getJSONArray("data");
												JSONObject jso;
												for(int i=0; i<count; i++) {
													jso = jsoa.getJSONObject(i);
													AccountDetailInfo info = new AccountDetailInfo();
													info.setUserName(jso.getString("user_name"));
													info.setTime(jso.getString("time"));
													info.setTaskName(jso.getString("task_name"));
													info.setTaskId(jso.getString("task_id"));
													info.setMoney(jso.getDouble("money"));
													if(jso.getDouble("money") > 0) {
														totalIn = totalIn + jso.getDouble("money");
													}else {
														totalOut = totalOut + jso.getDouble("money");
													}
													if(jso.getString("task_name").equals("充值")) {
														info.setPayTypeEn(jso.getInt("pay_type_en"));
														info.setPayType(jso.getString("pay_type"));
														info.setAmountId(jso.getString("amountId"));
													}
													if(jso.getString("task_name").equals("提现")) {
														info.setPayTypeEn(jso.getInt("pay_type_en"));
														info.setPayType(jso.getString("pay_type"));
														info.setAccount(jso.getString("account"));
														info.setState(jso.getString("state"));
														if(jso.getInt("pay_type_en") == 3) {
															info.setBank(jso.getString("bank"));
														}
													}
//													accountDetailInfos.add(info);
													switch(mAppTypeCode) {
													case 0:
														accountDetailInfos.add(info);
														break;
													case 1:
														if(!jso.getString("task_name").equals("提现")&&!jso.getString("task_name").equals("收益")) {
															accountDetailInfos.add(info);
														}
														break;
													default:
														if(!jso.getString("task_name").equals("充值")&&!jso.getString("task_name").equals("支出")) {
															accountDetailInfos.add(info);
														}
														break;
													}
												}
											}
											loadingFinished();
											pullView.onHeaderRefreshFinish();
											pullViewList.onHeaderRefreshFinish();
											showAccountDetailView();
										} catch (JSONException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
									}

									@Override
									public void onFailure(HttpException error, String msg) {
										// TODO Auto-generated method stub
										Log.i(TAG, msg);
										loadingFinished();
										pullView.onHeaderRefreshFinish();
										pullViewList.onHeaderRefreshFinish();
									}
								});
					}
				},1200);
			}
		}
	}

	public void loadingFinished() {

		if (null != loadingAnimation && loadingAnimation.isRunning()) {
			loadingAnimation.stop();
		}
		progressBarView.setVisibility(View.INVISIBLE);
		progressBarTextView.setVisibility(View.INVISIBLE);
		isLoading = false;
//		adapter.getTotal();
//		adapter.notifyDataSetChanged();
		adapter.updateListView(accountDetailInfos);
//		if(accountDetailInfos.size() != 0) {
//			pullView.setVisibility(View.GONE);
//			layoutShownull.setVisibility(View.GONE);
//		}
	}
	
	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub
		if(isShowAll) {
			if(arg2 >= accountDetailInfos.size()){
				return;
			}
			if(accountDetailInfos.get(arg2).getTaskName().equals("收益") || accountDetailInfos.get(arg2).getTaskName().equals("支出")) {
				Intent intent  = new Intent(AccountDetailActivity.this, ViewOrderHistoryActivity.class);
				intent.putExtra("order_server_id", accountDetailInfos.get(arg2).getTaskId());
				startActivity(intent);
			}else {
				Intent intent  = new Intent(AccountDetailActivity.this, ViewPayHistoryActivity.class);
				Bundle bundle = new Bundle();
				bundle.putParcelable("accountDetailInfo", accountDetailInfos.get(arg2));
				intent.putExtras(bundle);
				startActivity(intent);
			}
		}else {
			if(arg2 == accountSortInfos.size()){
				return;
			}
			if(accountSortInfos.get(arg2).getTaskName().equals("收益") || accountSortInfos.get(arg2).getTaskName().equals("支出")) {
				Intent intent  = new Intent(AccountDetailActivity.this, ViewOrderHistoryActivity.class);
				intent.putExtra("order_server_id", accountSortInfos.get(arg2).getTaskId());
				startActivity(intent);
			}else {
				Intent intent  = new Intent(AccountDetailActivity.this, ViewPayHistoryActivity.class);
				Bundle bundle = new Bundle();
				bundle.putParcelable("accountDetailInfo", accountSortInfos.get(arg2));
				intent.putExtras(bundle);
				startActivity(intent);
			}
		}
		
	}
	
	@Override
	public void onHeaderClick(StickyListHeadersListView l, View header,
			int itemPosition, long headerId, boolean currentlySticky) {
		// TODO Auto-generated method stub
		
	}
	
	private void showProgDialog(final String msg, final HttpUtils httpUtils) {
		mDialog = new ProgressDialog(this);
		mDialog.setCanceledOnTouchOutside(false);
		mDialog.setOnDismissListener(new OnDismissListener() {
			
			@Override
			public void onDismiss(DialogInterface dialog) {
				// TODO Auto-generated method stub
				if(dialogDismiss == 0 ) {
					httpUtils.getHttpClient().getConnectionManager().closeExpiredConnections();
//					httpUtils.getHttpClient().getConnectionManager().shutdown();
				}
				dialogDismiss = 0;
				Log.i(TAG, "dialog dismiss : "+msg);
				if(curShowView.equals("CountInfo") && !firstInit ) {
					getCountDetail();
					firstInit = true;
				}else {
					curShowView = "0";
				}
			}
		});
		mDialog.setMessage(msg);
		mDialog.show();
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		if(keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN) {
			switch (layoutNo) {
			case 0:
				Message msg = new Message();
				msg.what = 3;
				ParkingApp.payHandler.sendMessage(msg);
				AccountDetailActivity.this.finish();
				break;
			case 1:
				init();
				initView();
				showAccountDetailView();
				break;
			default:
				break;
			}
			return false;
		}
		return super.onKeyDown(keyCode, event);
	}

//	@Override
//	public void onHeaderRefresh(AbPullToRefreshView view) {
//		// TODO Auto-generated method stub
//		this.OnLoadingMore();
//	}
	public void onPay(View v) {
		Intent intent = new Intent(AccountDetailActivity.this, com.sendi.lhparking.ui.chezhu.PayActivity.class);
		startActivity(intent);
	}
	
	Handler mHandler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			String s[] = String.valueOf(msg.obj).split("\\,");
			Result result = new Result(s[0]);

			switch (msg.what) {
			case 1:
				String rs = result.getResultStatus();
				Log.i("TEST", "payresult: "+ rs + "  " + msg.obj);
				if(rs.equals("9000")) {
//					showTipsDialog("支付成功 ！ ", AccountActivity.this);
		            Toast.makeText(getApplicationContext(), "支付成功 ！", Toast.LENGTH_SHORT).show(); 

				}else {
//					showTipsDialog("支付失败 : "+result.getResult(), AccountActivity.this);
					Toast.makeText(getApplicationContext(), "支付失败 : "+result.getResult(), Toast.LENGTH_SHORT).show();
				}
				break;
			case 2:
				int flag = (Integer) msg.obj;
				if( flag == 0) {
					Toast.makeText(getApplicationContext(), "支付成功 ！", Toast.LENGTH_SHORT).show();
				}else {
//					showTipsDialog("支付失败,errCode: "+flag, AccountActivity.this);
					Toast.makeText(getApplicationContext(), "支付失败 : "+flag, Toast.LENGTH_SHORT).show();
				}
				break;
			}
//			init();
//			boolean bo = isNetConnected();
//			if(bo) {
//				getCountInfo();
//			}else {
//				Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
//			}
		};
	};
	@Override
	public void onHeaderRefresh(AbPullToRefreshView view) {
		// TODO Auto-generated method stub
		if(!firstInit) {
			getCountDetail();
		}else{
			onPullRefresh();
		}
	}
	
	/** 
	 * 服务器查询账本基本信息
	 * */
	private void getCountInfo() {
		boolean bo = isNetConnected();
		if(!bo) {
			Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
			return;
		}
		curShowView = "CountInfo";
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("method", "2001");  //2014
		Log.i("TEST", "POST URL : " + ServerURL+"?uid="+ParkingApp.mAppCtx.getUID()+"&utype="+ParkingApp.mAppCtx.getUType()
				+"&method=2001");
		HttpUtils http = new HttpUtils(6000);
		showProgDialog("正在进行账本查询 . . .", http);
		http.send(HttpMethod.POST, 
				ServerURL,
				params,
				new RequestCallBack< String >() {

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// TODO Auto-generated method stub
//						{balance,total_income,day_income,week_income,week_outcome,total_outcome} 
//						分别代表 金额 ，总收益，昨日收益，一周收益，一周支出，总支出
						Log.i(TAG , "getCountInfo:" + responseInfo.result);
						if(curShowView.equals("CountInfo")) {
							try {
								JSONObject jsob = new JSONObject(responseInfo.result);
								switch(mAppTypeCode) {
								case 1:
								case 4:
									tvDayIncome.setText(jsob.getString("total_income"));
									break;
								case 2:
									tvBalance.setText(jsob.getString("balance"));
									break;
								}
//								bInfo = new AccountBaseInfo();
//								bInfo.setBalance(jsob.getString("balance"));
//								bInfo.setTotalIncome(jsob.getString("total_income"));
//								bInfo.setDayIncome(jsob.getString("day_income"));
//								if(jsob.getString("day_income").equals("0.0")) {
//									bInfo.setDayIncome("暂无收益");
//								}
//								bInfo.setWeekIncome(jsob.getString("week_income"));
//								bInfo.setWeekOutcome(jsob.getString("week_outcome"));
//								bInfo.setTotalOutcome(jsob.getString("total_outcome"));
//								bInfo.setRanking(jsob.getString("ranking"));
								
//								tvDayIncome.setText(bInfo.getTotalIncome());
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}							
							
							if(mDialog != null) {
								dialogDismiss = 1;
								mDialog.dismiss();
							}
						}
						
					}

					@Override
					public void onFailure(HttpException error, String msg) {
						// TODO Auto-generated method stub
						if(curShowView.equals("CountInfo")) {
							showTipsDialog("查询失败，请检查网络连接，稍后再试 ", AccountDetailActivity.this);
						}
						if(mDialog != null) {
							dialogDismiss = 1;
							mDialog.dismiss();
						}
					}
				});
		
	}
	
	public void onCheckCountDetail(View v) {
		getCountInfo();
	}
	
	public void onTransfer(View v) {
		boolean bo = isNetConnected();
		if(bo) {
			if(bInfo == null) {
				Toast.makeText(getApplicationContext(), "无法查询账户余额，请点击\"昨日收益\"刷新后再试", Toast.LENGTH_SHORT).show();
				return;
			}
			if(Double.valueOf(bInfo.getBalance()) < 0) {
				Toast.makeText(getApplicationContext(), "账户余额错误，请点击\"昨日收益\"刷新后再试", Toast.LENGTH_SHORT).show();
				return;
			}
			Intent intent = new Intent(AccountDetailActivity.this, TransferAccountActivity.class);
			intent.putExtra("maxMoney", bInfo.getBalance());
			startActivity(intent);
		}else {
			Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
		}
		
	}
	
	private int iLastYear;
	private int iLastMonth = 0;
	private int iLastCheckMonthCount = 0;
	
	private void onPullRefresh() {
		// TODO Auto-generated method stub
		if(true){
			if(!isLoading) {
				isLoading = true;
				new Handler().postDelayed(new Runnable() {
					
					@Override
					public void run() {
						iLastYear = iYear;
						iLastMonth = iMonth;
						iLastCheckMonthCount = iCheckMonthCount;
						
						iMonth--;
						iCheckMonthCount ++;
						if(iMonth == 0) {
							iMonth = 12;
							iYear--;
						}
						if(iMonth<10) {
							String smonth = "0"+String.valueOf(iMonth);
							curDate = String.valueOf(iYear)+"-"+smonth;
						}else {
							curDate = String.valueOf(iYear)+"-"+String.valueOf(iMonth);
						}
						RequestParams params = new RequestParams();
						params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID() );
						params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
						params.addBodyParameter("method", "2015");
						params.addBodyParameter("month", curDate);
						
						Log.i(TAG, curDate);
						HttpUtils http = new HttpUtils();
						http.configTimeout(6000);
						http.send(HttpMethod.POST, 
								ServerURL, 
								params, 
								new RequestCallBack< String >() {

									@Override
									public void onSuccess(ResponseInfo<String> responseInfo) {
										// TODO Auto-generated method stub
										Log.i(TAG, responseInfo.result);
										
										try {
											JSONObject jsob = new JSONObject(responseInfo.result);
											int count = jsob.getInt("totalCount");
											totalIn = 0;
											totalOut = 0;
											if(count == 0) {
//												AccountDetailInfo info = new AccountDetailInfo();
//												info.setUserName("user_name");
//												info.setTime(curDate);
//												info.setTaskName("本月收支记录为空");
//												info.setTaskId("task_id");
//												info.setMoney(0);
//												accountDetailInfos.add(info);
											}else {
//												{user_name,time,task_name,task_id,money,flag} 
//												user_name：姓名  time：结算时间 money：金额（收入为正，支出为负） task_name：值为4种：收入，支出，充值，提现。 Flag：parkcar/money
												JSONArray jsoa = jsob.getJSONArray("data");
												JSONObject jso;
												for(int i=0; i<count; i++) {
													jso = jsoa.getJSONObject(i);
													AccountDetailInfo info = new AccountDetailInfo();
													info.setUserName(jso.getString("user_name"));
													info.setTime(jso.getString("time"));
													info.setTaskName(jso.getString("task_name"));
													info.setTaskId(jso.getString("task_id"));
													info.setMoney(jso.getDouble("money"));
													if(jso.getDouble("money") > 0) {
														totalIn = totalIn + jso.getDouble("money");
													}else {
														totalOut = totalOut + jso.getDouble("money");
													}
													if(jso.getString("task_name").equals("充值")) {
														info.setPayTypeEn(jso.getInt("pay_type_en"));
														info.setPayType(jso.getString("pay_type"));
														info.setAmountId(jso.getString("amountId"));
													}
													if(jso.getString("task_name").equals("提现")) {
														info.setPayTypeEn(jso.getInt("pay_type_en"));
														info.setPayType(jso.getString("pay_type"));
														info.setAccount(jso.getString("account"));
														info.setState(jso.getString("state"));
														if(jso.getInt("pay_type_en") == 3) {
															info.setBank(jso.getString("bank"));
														}
													}
//													accountDetailInfos.add(info);
													switch(mAppTypeCode) {
													case 0:
														accountDetailInfos.add(info);
														break;
													case 2:
														if(!jso.getString("task_name").equals("提现")&&!jso.getString("task_name").equals("收益")) {
															accountDetailInfos.add(info);
														}
														break;
													default:
														if(!jso.getString("task_name").equals("充值")&&!jso.getString("task_name").equals("支出")) {
															accountDetailInfos.add(info);
														}
														break;
													}
												}
											}
											loadingFinished();
											pullView.onHeaderRefreshFinish();
											pullViewList.onHeaderRefreshFinish();
											showAccountDetailView();
										} catch (JSONException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
									}

									@Override
									public void onFailure(HttpException error, String msg) {
										// TODO Auto-generated method stub
										Log.i(TAG, msg);
										iYear = iLastYear;
										iMonth = iLastMonth;
										iCheckMonthCount = iLastCheckMonthCount;
										
										loadingFinished();
										pullView.onHeaderRefreshFinish();
										pullViewList.onHeaderRefreshFinish();
									}
								});
					}
				},1200);
			}
		}
	
	}

	@Override
	public void onFooterLoad(AbPullToRefreshView view) {
		// TODO Auto-generated method stub

		// TODO Auto-generated method stub
		if(true){
			if(!isLoading) {
				isLoading = true;
				new Handler().postDelayed(new Runnable() {
					
					@Override
					public void run() {
						iLastYear = iYear;
						iLastMonth = iMonth;
						iLastCheckMonthCount = iCheckMonthCount;
						
						iMonth--;
						iCheckMonthCount ++;
						if(iMonth == 0) {
							iMonth = 12;
							iYear--;
						}
						if(iMonth<10) {
							String smonth = "0"+String.valueOf(iMonth);
							curDate = String.valueOf(iYear)+"-"+smonth;
						}else {
							curDate = String.valueOf(iYear)+"-"+String.valueOf(iMonth);
						}
						RequestParams params = new RequestParams();
						params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID() );
						params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
						params.addBodyParameter("method", "2015");
						params.addBodyParameter("month", curDate);
						
						Log.i(TAG, curDate);
						HttpUtils http = new HttpUtils();
						http.configTimeout(6000);
						http.send(HttpMethod.POST, 
								ServerURL, 
								params, 
								new RequestCallBack< String >() {

									@Override
									public void onSuccess(ResponseInfo<String> responseInfo) {
										// TODO Auto-generated method stub
										Log.i(TAG, responseInfo.result);
										
										try {
											JSONObject jsob = new JSONObject(responseInfo.result);
											int count = jsob.getInt("totalCount");
											totalIn = 0;
											totalOut = 0;
											if(count == 0) {
												
											}else {
//												{user_name,time,task_name,task_id,money,flag} 
//												user_name：姓名  time：结算时间 money：金额（收入为正，支出为负） task_name：值为4种：收入，支出，充值，提现。 Flag：parkcar/money
												JSONArray jsoa = jsob.getJSONArray("data");
												JSONObject jso;
												for(int i=0; i<count; i++) {
													jso = jsoa.getJSONObject(i);
													AccountDetailInfo info = new AccountDetailInfo();
													info.setUserName(jso.getString("user_name"));
													info.setTime(jso.getString("time"));
													info.setTaskName(jso.getString("task_name"));
													info.setTaskId(jso.getString("task_id"));
													info.setMoney(jso.getDouble("money"));
													if(jso.getDouble("money") > 0) {
														totalIn = totalIn + jso.getDouble("money");
													}else {
														totalOut = totalOut + jso.getDouble("money");
													}
													if(jso.getString("task_name").equals("充值")) {
														info.setPayTypeEn(jso.getInt("pay_type_en"));
														info.setPayType(jso.getString("pay_type"));
														info.setAmountId(jso.getString("amountId"));
													}
													if(jso.getString("task_name").equals("提现")) {
														info.setPayTypeEn(jso.getInt("pay_type_en"));
														info.setPayType(jso.getString("pay_type"));
														info.setAccount(jso.getString("account"));
														info.setState(jso.getString("state"));
														if(jso.getInt("pay_type_en") == 3) {
															info.setBank(jso.getString("bank"));
														}
													}
//													accountDetailInfos.add(info);
													switch(mAppTypeCode) {
													case 0:
														accountDetailInfos.add(info);
														break;
													case 2:
														if(!jso.getString("task_name").equals("提现")&&!jso.getString("task_name").equals("收益")) {
															accountDetailInfos.add(info);
														}
														break;
													default:
														if(!jso.getString("task_name").equals("充值")&&!jso.getString("task_name").equals("支出")) {
															accountDetailInfos.add(info);
														}
														break;
													}
												}
											}
											loadingFinished();
											pullViewList.onFooterLoadFinish();
											showAccountDetailView();
										} catch (JSONException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
									}

									@Override
									public void onFailure(HttpException error, String msg) {
										// TODO Auto-generated method stub
										Log.i(TAG, msg);
										iYear = iLastYear;
										iMonth = iLastMonth;
										iCheckMonthCount = iLastCheckMonthCount;
										
										loadingFinished();
										pullViewList.onFooterLoadFinish();
									}
								});
					}
				},1200);
			}
		}
	}
	
	private void getCountInfo(int type) {

		boolean bo = isNetConnected();
		if(!bo) {
			Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
			return;
		}
		curShowView = "CountInfo";
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		
//		params.addBodyParameter("method", "2001");  //2014
		HttpUtils http = new HttpUtils(6000);
		showProgDialog("正在进行账本查询 . . .", http);
		http.send(HttpMethod.POST, 
				ServerURL,
				params,
				new RequestCallBack< String >() {

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// TODO Auto-generated method stub
//						{balance,total_income,day_income,week_income,week_outcome,total_outcome} 
//						分别代表 金额 ，总收益，昨日收益，一周收益，一周支出，总支出
						Log.i(TAG , "getCountInfo:" + responseInfo.result);
						if(curShowView.equals("CountInfo")) {
							try {
								JSONObject jsob = new JSONObject(responseInfo.result);
								bInfo = new AccountBaseInfo();
								bInfo.setBalance(jsob.getString("balance"));
								bInfo.setTotalIncome(jsob.getString("total_income"));
								bInfo.setDayIncome(jsob.getString("day_income"));
								if(jsob.getString("day_income").equals("0.0")) {
									bInfo.setDayIncome("暂无收益");
								}
								bInfo.setWeekIncome(jsob.getString("week_income"));
								bInfo.setWeekOutcome(jsob.getString("week_outcome"));
								bInfo.setTotalOutcome(jsob.getString("total_outcome"));
								bInfo.setRanking(jsob.getString("ranking"));
								
								tvBalance.setText(bInfo.getBalance());
								tvDayIncome.setText(bInfo.getTotalIncome());
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}							
							
							if(mDialog != null) {
								dialogDismiss = 1;
								mDialog.dismiss();
							}
						}
						
					}

					@Override
					public void onFailure(HttpException error, String msg) {
						// TODO Auto-generated method stub
						if(curShowView.equals("CountInfo")) {
							showTipsDialog("查询失败，请检查网络连接，稍后再试 ", AccountDetailActivity.this);
						}
						if(mDialog != null) {
							dialogDismiss = 1;
							mDialog.dismiss();
						}
					}
				});
		}
	
	private void getSimpleCount() {

		boolean bo = isNetConnected();
		if(!bo) {
			Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
			pullView.onHeaderRefreshFinish();
			pullViewList.onHeaderRefreshFinish();
			return;
		}
		curShowView = "CountDetail";
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID() );
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("method", "2004");
		params.addBodyParameter("num", "1");
		
		Log.i(TAG, curDate);
		HttpUtils http = new HttpUtils(6000);
		showProgDialog("正在查询收益明细 . . .", http);
		http.send(HttpMethod.POST, 
				ServerURL, 
				params, 
				new RequestCallBack< String >() {

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// TODO Auto-generated method stub
						Log.i(TAG, responseInfo.result);
						if(curShowView.equals("CountDetail")) {
							try {
								JSONObject jsob = new JSONObject(responseInfo.result);
								int count = jsob.getInt("totalCount");
								
								totalIn = 0;
								totalOut = 0;
								if(count == 0) {
									accountDetailInfos = new ArrayList<AccountDetailInfo>();
									tvShownull.setText("本月收支记录为空");
									pullView.setVisibility(View.VISIBLE);
									layoutShownull.setVisibility(View.VISIBLE);
									showAccountDetailView();
									if(dialog != null) {
										dialog.dismiss();
									}
								}else {
//									{user_name,time,task_name,task_id,money,flag} 
//									user_name：姓名  time：结算时间 money：金额（收入为正，支出为负） task_name：值为4种：收入，支出，充值，提现。 Flag：parkcar/money
//									当task_name为“充值”时，返回值 新增---pay_type_en：1支付宝 2微信支付   pay_type：pay_type_en的中文说明 amountId：交易流水号
//									  当task_name为“提现”时，返回值 新增 ---pay_type_en 1支付宝 2理财通 3：银行卡 pay_type：pay_type_en的中文说明  。
//									  account：账号。 bank：银行名称(当 pay_type=3的时候显示)
									JSONArray jsoa = jsob.getJSONArray("data");
									JSONObject jso;
									accountDetailInfos = new ArrayList<AccountDetailInfo>();
									for(int i=0; i<count; i++) {
										jso = jsoa.getJSONObject(i);
										AccountDetailInfo info = new AccountDetailInfo();
										info.setUserName(jso.getString("user_name"));
										info.setTime(jso.getString("time"));
										info.setTaskName(jso.getString("task_name"));
										info.setTaskId(jso.getString("task_id"));
										info.setMoney(jso.getDouble("money"));
										if(jso.getDouble("money") > 0) {
											totalIn = totalIn + jso.getDouble("money");
										}else {
											totalOut = totalOut + jso.getDouble("money");
										}
										if(jso.getString("task_name").equals("充值")) {
											info.setPayTypeEn(jso.getInt("pay_type_en"));
											info.setPayType(jso.getString("pay_type"));
											info.setAmountId(jso.getString("amountId"));
										}
										if(jso.getString("task_name").equals("提现")) {
											info.setPayTypeEn(jso.getInt("pay_type_en"));
											info.setPayType(jso.getString("pay_type"));
											info.setAccount(jso.getString("account"));
											info.setState(jso.getString("state"));
											if(jso.getInt("pay_type_en") == 3) {
												info.setBank(jso.getString("bank"));
											}
										}
										switch(mAppTypeCode) {
										case 0:
											accountDetailInfos.add(info);
											break;
										case 2:
											if(!jso.getString("task_name").equals("提现")&&!jso.getString("task_name").equals("收益")) {
												accountDetailInfos.add(info);
											}
											break;
										default:
											if(!jso.getString("task_name").equals("充值")&&!jso.getString("task_name").equals("支出")) {
												accountDetailInfos.add(info);
											}
											break;
										}
										
									}
									showAccountDetailView();
								}
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								pullView.onHeaderRefreshFinish();
								pullViewList.onHeaderRefreshFinish();
								e.printStackTrace();
							}
							if( mDialog != null) {
								dialogDismiss = 1;
								mDialog.dismiss();
							}
						}
						pullView.onHeaderRefreshFinish();
						pullViewList.onHeaderRefreshFinish();
					}

					@Override
					public void onFailure(HttpException error, String msg) {
						// TODO Auto-generated method stub
						Log.i(TAG, msg);
						if(curShowView.equals("CountDetail")) {
							showTipsDialog("查询失败，请检查网络连接，稍后再试 ", AccountDetailActivity.this);
						}
						pullView.onHeaderRefreshFinish();
						pullViewList.onHeaderRefreshFinish();
						if(mDialog != null) {
							dialogDismiss = 1;
							mDialog.dismiss();
						}
					}
				});
	
	}
	
}
