package com.sendi.lhparking.ui.common;

import org.json.JSONException;
import org.json.JSONObject;
import org.sendi.parking.ui.R;

import com.ab.view.wheel.AbObjectWheelAdapter;
import com.ab.view.wheel.AbOnWheelChangedListener;
import com.ab.view.wheel.AbWheelView;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.sendi.lhparking.ctx.ParkingApp;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.TextView.OnEditorActionListener;
/**
 * 设置密保界面
 * @author Administrator
 *
 */
public class SetSecretActivity extends BaseActivity {

	private ProgressDialog mDialog;
	private String curShowView = "0";
	private int dialogDismiss = 0;
	
	private String[] secretItems;
	private AlertDialog wDialog;
	private AbWheelView wheelItems;
	
	private Button btnReset;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);

		setContentView(R.layout.view_setsecret);
		secretItems = this.getResources().getStringArray(R.array.secret_items);
		TextView tvTitle = (TextView) this.findViewById(R.id.topbar_center_btn);
		tvTitle.setText("设 置 密 保");
		final TextView tvQuest1 = (TextView) this.findViewById(R.id.tvQuest1);
		final TextView tvQuest2 = (TextView) this.findViewById(R.id.tvQuest2);
		final TextView tvQuest3 = (TextView) this.findViewById(R.id.tvQuest3);
		final EditText edAnswer1 = (EditText) this.findViewById(R.id.edtAnswer1);
		final EditText edAnswer2 = (EditText) this.findViewById(R.id.edtAnswer2);
		final EditText edAnswer3 = (EditText) this.findViewById(R.id.edtAnswer3);
		final Button btnOK = (Button) this.findViewById(R.id.btnOK);
		Button btnCancel = (Button) this.findViewById(R.id.btnCancel);
		TextView tvReturn = (TextView) this.findViewById(R.id.topbar_left_btn);		
		
		tvReturn.setText("  返 回");
		tvReturn.setVisibility(View.VISIBLE);
		tvReturn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				hideKeyborad();
				SetSecretActivity.this.finish();
			}
		});
		
		tvQuest1.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				showItemsPickerDialog(tvQuest1);
			}
		});
		
		tvQuest2.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				showItemsPickerDialog(tvQuest2);
			}
		});
		
		tvQuest3.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				showItemsPickerDialog(tvQuest3);
			}
		});
		
		btnOK.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String q1 = tvQuest1.getText().toString();
				String q2 = tvQuest2.getText().toString();
				String q3 = tvQuest3.getText().toString();
				if(q1.equals(q2) || q1.equals(q3) || q2.equals(q3)) {
					showTipsDialog("密保问题不能重复！", SetSecretActivity.this);
					return;
				}
				if(edAnswer1.getText().length() == 0 || edAnswer2.getText().length() == 0 || edAnswer3.getText().length() == 0) {
					showTipsDialog("请输入完整答案！", SetSecretActivity.this);
					return;
				}
				boolean bo = isNetConnected();
				if(bo) {
					doSetSecret(
							tvQuest1.getText().toString(),
							tvQuest2.getText().toString(),
							tvQuest3.getText().toString(),
							edAnswer1.getText().toString(), 
							edAnswer2.getText().toString(), 
							edAnswer3.getText().toString()
							);
				}else {
					Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
				}
				
			}
		});
		
		btnCancel.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				SetSecretActivity.this.finish();
			}
		});
		
		edAnswer3.setOnEditorActionListener(new OnEditorActionListener() {
			
			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				// TODO Auto-generated method stub
				switch(actionId) {
				case EditorInfo.IME_ACTION_DONE:
					btnOK.performClick();
					break;
				}
				return false;
			}
		});
	
	}
	
	private void init() {
		btnReset = (Button) this.findViewById(R.id.btnReset);
		
		btnReset.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
			}
		});
		
	}
	
	/** 
	 * 服务器修改密保
	 * */
	private void doSetSecret(String q1, String q2, String q3, String a1, String a2, String a3) {
		curShowView = "SetSecret";		
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("quest1", q1);
		params.addBodyParameter("quest2", q2);
		params.addBodyParameter("quest3", q3);
		params.addBodyParameter("answer1", a1);
		params.addBodyParameter("answer2", a2);
		params.addBodyParameter("answer3", a3);

		params.addBodyParameter("method", "config_2002");
Log.i("TEST SetSecret : ", q1 + ":"+a1 +"\n"+ q2 + ":"+a2 +"\n"+q3 + ":"+a3);
		HttpUtils http = new HttpUtils(6000);
		showProgDialog("正在修改密保...", http);
		http.send(HttpMethod.POST, 
				ServerURL, 
				params,
				new RequestCallBack<String>() {

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// TODO Auto-generated method stub
						if(curShowView.equals("SetSecret")) {
							try {
								JSONObject jsob = new JSONObject(responseInfo.result);
								boolean bo = jsob.getBoolean("success");
								String msg = jsob.getString("msg");
								if(bo) {
									showTipsDialog("修改密保成功！", SetSecretActivity.this);
								}else {
									showTipsDialog("修改密保失败，"+msg, SetSecretActivity.this);
								}
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							if(mDialog != null) {
								dialogDismiss  = 1;
								mDialog.dismiss();
							}
						}
						
						Log.i(TAG, responseInfo.result);
					}

					@Override
					public void onFailure(HttpException error, String msg) {
						// TODO Auto-generated method stub
						if(curShowView.equals("SetSecret")) {
							showTipsDialog("修改密保失败，请检查网络，稍后再试 ", SetSecretActivity.this);
						}
						if(mDialog != null) {
							dialogDismiss = 1;
							mDialog.dismiss();
						}
					}});
	
	
	}
	
	private void showProgDialog(final String msg, final HttpUtils httpUtils) {
		mDialog = new ProgressDialog(this);
		mDialog.setCanceledOnTouchOutside(false);
		mDialog.setOnDismissListener(new OnDismissListener() {
			
			@Override
			public void onDismiss(DialogInterface dialog) {
				// TODO Auto-generated method stub
				if(dialogDismiss == 0 ) {
					httpUtils.getHttpClient().getConnectionManager().closeExpiredConnections();
//					httpUtils.getHttpClient().getConnectionManager().shutdown();
				}
				dialogDismiss = 0;
				curShowView = "0";
				Log.i(TAG, "dialog dismiss : "+msg);
			}
		});
		mDialog.setMessage(msg);
		mDialog.show();
	}
	
	/** 
	 * 显示密保问题选择
	 * */
	private void showItemsPickerDialog(final TextView tv) {

        AlertDialog.Builder builder = new AlertDialog.Builder(SetSecretActivity.this);  
        View v = LayoutInflater.from(this).inflate(R.layout.layout_wheel_chooser_one, null);
        wheelItems = (AbWheelView) v.findViewById(R.id.wheel_panel_wheel);
        
        Button btnCancel = (Button) v.findViewById(R.id.wheel_panel_cancelBtn);
        btnCancel.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				wDialog.dismiss();
			}
		});
        
        Button btnOk = (Button) v.findViewById(R.id.wheel_panel_okBtn);
        btnOk.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				tv.setText(secretItems[wheelItems.getCurrentItem()]);
				wDialog.dismiss();
			}
		});
        
        AbObjectWheelAdapter<String> adapterItems = new AbObjectWheelAdapter<String>(secretItems, 30);
        wheelItems.setAdapter(adapterItems);
		
        wheelItems.setCurrentItem(0);
       
        wheelItems.addChangingListener(new AbOnWheelChangedListener() {
			
			@Override
			public void onChanged(AbWheelView wheel, int oldValue, int newValue) {
				// TODO Auto-generated method stub
				Log.i(TAG, String.valueOf(oldValue)+ "  "+String.valueOf(newValue));
			}
		});
        
        builder.setView(v);
        wDialog = builder.create();
        wDialog.setCanceledOnTouchOutside(false);
        wDialog.show();
	}	
	
	private void checkSetSecret() {
		curShowView = "checkSetSecret";		
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("method", "config_2002");

		HttpUtils http = new HttpUtils(6000);
		showProgDialog("正在查询密保...", http);
		http.send(HttpMethod.POST, 
				ServerURL, 
				params,
				new RequestCallBack<String>() {

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// TODO Auto-generated method stub
						if(curShowView.equals("checkSetSecret")) {
							try {
								JSONObject jsob = new JSONObject(responseInfo.result);
								boolean bo = jsob.getBoolean("success");
								
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							if(mDialog != null) {
								dialogDismiss  = 1;
								mDialog.dismiss();
							}
						}
						
						Log.i(TAG, responseInfo.result);
					}

					@Override
					public void onFailure(HttpException error, String msg) {
						// TODO Auto-generated method stub
						if(curShowView.equals("checkSetSecret")) {
							showTipsDialog("查询密保失败，请检查网络，稍后再试 ", SetSecretActivity.this);
						}
						if(mDialog != null) {
							dialogDismiss = 1;
							mDialog.dismiss();
						}
					}});
	}
	
}
