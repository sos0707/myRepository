package com.sendi.lhparking.ui.common;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.JSONException;
import org.json.JSONObject;
import org.sendi.parking.ui.R;

import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.util.MD5Crypter;
import com.sendi.lhparking.util.ParkingPrefs;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnDismissListener;
import android.os.Bundle;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.TextView.OnEditorActionListener;
/**
 * 注册界面
 * @author Administrator
 *
 */
public class RegisterActivity extends BaseActivity {
	
	public static final String PREF_LANGHUA_UID = "langhua_uid";/*string*/
	public static final String PREF_LANGHUA_UTYPE = "langhua_utype";/*string*/
	private static final String TAG = "TEST";
	private ProgressDialog dialog;
	private EditText edUsername, edPhone, edPsw, edRPsw ;
	private Button btnReg, btnReturn;
	private String curShowView = "0";
	private int dialogDismiss = 0;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

		setContentView(R.layout.activity_register);
		init();
	}
	
	private void init() {
		edUsername = (EditText) this.findViewById(R.id.edUsername);
		edPhone = (EditText) this.findViewById(R.id.edPhone);
		edPsw = (EditText) this.findViewById(R.id.edPassword);
		edRPsw = (EditText) this.findViewById(R.id.edRPassword);
		btnReg = (Button) this.findViewById(R.id.btn_register);
		TextView tvTitle = (TextView) this.findViewById(R.id.topbar_center_btn);
		TextView tvReturn = (TextView) this.findViewById(R.id.topbar_left_btn);
		
		tvTitle.setText("注  册");
		tvReturn.setVisibility(View.VISIBLE);
		tvReturn.setText("  返 回");
		
		btnReg.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(edUsername.getText().length() == 0 || edPhone.getText().length() == 0 || edPsw.getText().length() == 0 || edRPsw.getText().length() == 0) {
					showTipsDialog("请输入完整信息!", RegisterActivity.this);
					return;
				}
				boolean bo = checkPhone(edPhone.getText().toString());
				if(!bo) {
					showTipsDialog("请输入正确的手机号码！", RegisterActivity.this);
					edPhone.setText("");
					edPhone.setFocusable(true);
					edPhone.setFocusableInTouchMode(true);
					edPhone.requestFocus();
					return;
				}
				if(edPsw.getText().length() < 6 || edPsw.getText().length()>12) {
					showTipsDialog("密码长度错误 (长度: 6 - 12)", RegisterActivity.this);
					return;
				}
				if( !edPsw.getText().toString().equals( edRPsw.getText().toString())) {
					showTipsDialog("两次输入密码不同,请重新输入!", RegisterActivity.this);
					return;
				}
				doRegister(edUsername.getText().toString(), edPsw.getText().toString(), edPhone.getText().toString());
			}
		});
		
		tvReturn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				hideKeyborad();
				Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
				startActivity(intent);
				RegisterActivity.this.finish();
			}
		});
		
		edRPsw.setOnEditorActionListener(new OnEditorActionListener() {
			
			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				// TODO Auto-generated method stub
				switch(actionId) {
				case EditorInfo.IME_ACTION_DONE:
					btnReg.performClick();
					break;
				}
				return false;
			}
		});
		
	}
	
	private void doRegister(String username, final String password, final String phone) {
		curShowView = "Register";
		String psw = MD5Crypter.MD5Encode(password);
		RequestParams params = new RequestParams();
		params.addBodyParameter("name", username);
		params.addBodyParameter("phone", phone);
		params.addBodyParameter("password", psw);
		params.addBodyParameter("method", "2011");
		
		HttpUtils http = new HttpUtils(6000);
		showProgDialog("正在注册...", http);		
		http.send(HttpMethod.POST,
				ServerURL,
				params,
				new RequestCallBack<String>() {

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// TODO Auto-generated method stub
						Log.i(TAG, "Register result : " + responseInfo);
						if(curShowView.equals("Register")) {
							if(dialog != null) {
								dialogDismiss = 1;
								dialog.dismiss();
							}
							try {
								JSONObject jsob = new JSONObject(responseInfo.result);
								boolean bo = jsob.getBoolean("success");
								String msg = jsob.getString("msg");
								if(bo) {
//									showTipsDialog("注册成功，请重新登录！");
						            Toast.makeText(getApplicationContext(), "注册成功,自动登录", Toast.LENGTH_SHORT).show();
									Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
									Bundle bundle = new Bundle();
									bundle.putString("phone", phone);
									bundle.putString("password", password);
									intent.putExtras(bundle);
									startActivity(intent);
									RegisterActivity.this.finish();
								}else {
									showTipsDialog(msg, RegisterActivity.this);
								}
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
						Log.i(TAG, responseInfo.result);
					}

					@Override
					public void onFailure(HttpException error, String msg) {
						// TODO Auto-generated method stub
						if(curShowView.equals("Register")) {
							showTipsDialog("注册失败，请检查网络，稍后再试 ", RegisterActivity.this);
						}
						if(dialog != null) {
							dialogDismiss = 1;
							dialog.dismiss();
						}
					}
				});
		
	
	}
	
	private void showTipsDialog(String msg){  
        AlertDialog dialog;  
        AlertDialog.Builder builder = new AlertDialog.Builder(RegisterActivity.this);  
        builder.setTitle("消息").setIcon(android.R.drawable.stat_notify_error);  
        builder.setMessage(msg);  
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener(){  
            @Override 
            public void onClick(DialogInterface dialog, int which) {  
                // TODO Auto-generated method stub  
            	Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
				startActivity(intent);
				RegisterActivity.this.finish();
            }                     
        });  
        dialog = builder.create();  
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();  
    } 
	
	private void showProgDialog(String msg) {
		dialog = ProgressDialog.show(RegisterActivity.this, "消息", msg);
	}
	
	private void showProgDialog(final String msg, final HttpUtils httpUtils) {
		dialog = new ProgressDialog(this);
		dialog.setCanceledOnTouchOutside(false);
		dialog.setOnDismissListener(new OnDismissListener() {
			
			@Override
			public void onDismiss(DialogInterface dialog) {
				// TODO Auto-generated method stub
				if(dialogDismiss == 0 ) {
					httpUtils.getHttpClient().getConnectionManager().closeExpiredConnections();
//					httpUtils.getHttpClient().getConnectionManager().shutdown();
				}
				dialogDismiss = 0;
				curShowView = "0";
				Log.i(TAG, "dialog dismiss : "+msg);
			}
		});
		dialog.setMessage(msg);
		dialog.show();
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		if(keyCode == KeyEvent.KEYCODE_BACK) {
			Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
			startActivity(intent);
			RegisterActivity.this.finish();
			return false;
		}
		return super.onKeyDown(keyCode, event);
	}
	
	private boolean checkPhone(String phone) {
		String check = "^[1]{1}[0-9]{10}$";
		Pattern pt = Pattern.compile(check);
		Matcher matcher = pt.matcher(phone);
		if(matcher.matches()) {
			return true;
		}
		return false;
	}
}
