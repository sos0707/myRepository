package com.sendi.lhparking.ui.common;


import org.sendi.parking.ui.R;
import org.sendi.parking.ui.R.id;
import org.sendi.parking.ui.R.layout;

import com.ab.view.myview.ScaleLayout;
import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.ui.common.base.BaseActivity;
import com.sendi.lhparking.util.SysUtils;

import android.os.Bundle;
import android.util.Log;
import android.view.ScaleGestureDetector;
import android.view.ScaleGestureDetector.OnScaleGestureListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.TextView;

/**
 * 
 * @author Administrator
 * 
 */
public class ScaleLayActivity extends BaseActivity implements
		OnScaleGestureListener {

	public static final float NORMAL_SP = SysUtils.sp2px(ParkingApp.mAppCtx,
			18.0F);
	public static final float SMALLEST_SP = SysUtils.sp2px(ParkingApp.mAppCtx,
			13.0F);
	public static final float BIGGEST_SP = SysUtils.sp2px(ParkingApp.mAppCtx,
			25.0F);

	private float mScaleSize = NORMAL_SP;
	
	private TextView vScaleTv;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
//		ScaleLayout layout = new ScaleLayout(this);
//		layout.setFocusable(true);
//		layout.setClientListener(this);
//		setContentView(layout, new LayoutParams(LayoutParams.MATCH_PARENT,
//				LayoutParams.MATCH_PARENT));
		setContentView(R.layout.activity_scale_layout);
		vScaleTv = (TextView) findViewById(R.id.scale_tv);
		vScaleTv.setTextSize(mScaleSize);
		ScaleLayout scale = (ScaleLayout) findViewById(R.id.scale_layout);
		scale.setClientListener(this);
	}

	@Override
	public boolean onScale(ScaleGestureDetector detector) {
		// TODO Auto-generated method stub
		float scale = detector.getScaleFactor();
		Log.i("qh", "scale : " + scale);
		if ((scale - 0.1) <= 0.0000F) {
			return false;
		}
		if (scale > 1 && mScaleSize >= BIGGEST_SP) {
			Log.i("qh", "已经最大");
			return false;
		}
		if (scale < 1 && mScaleSize <= SMALLEST_SP) {
			Log.i("qh", "已经最小");
			return false;
		}
		mScaleSize = mScaleSize * scale;
		Log.i("qh", "size : " + mScaleSize);
		vScaleTv.setTextSize(mScaleSize);
		return true;
	}

	@Override
	public boolean onScaleBegin(ScaleGestureDetector detector) {
		// TODO Auto-generated method stub
		Log.i("qh", "scale begin");
		return true;
	}

	@Override
	public void onScaleEnd(ScaleGestureDetector detector) {
		// TODO Auto-generated method stub
		Log.i("qh", "scale end");
	}
}
