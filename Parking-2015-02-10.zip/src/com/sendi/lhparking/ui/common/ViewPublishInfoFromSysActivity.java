package com.sendi.lhparking.ui.common;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.sendi.parking.ui.R;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.DbException;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.lidroid.xutils.view.ResType;
import com.lidroid.xutils.view.annotation.ResInject;
import com.lidroid.xutils.view.annotation.ViewInject;
import com.lidroid.xutils.view.annotation.event.OnClick;
import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.ctx.ParkingConstant;
import com.sendi.lhparking.ctx.WeakHandler;
import com.sendi.lhparking.model.PublishListForm;
import com.sendi.lhparking.server.IServer;
import com.sendi.lhparking.ui.common.base.BaseActivityWithDialog;
import com.sendi.lhparking.util.AccountBaseInfo;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnDismissListener;
import android.os.Bundle;
import android.os.Message;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 通过系统通知 进入 浏览 车位信息 角色功能: 1.审核(通过/拒绝) 2.暂停/删除
 * 
 * @author Administrator
 * 
 */
public class ViewPublishInfoFromSysActivity extends BaseActivityWithDialog {

	// for top bar
	@ViewInject(R.id.topbar_left_btn)
	private TextView vTopLeft;
	@ViewInject(R.id.topbar_center_btn)
	private TextView vTopCenter;
	@ViewInject(R.id.topbar_right_btn)
	private TextView vTopRight;

	@OnClick(value = { R.id.topbar_left_btn })
	private void topLeftDoCancel(View view) {
		finish();
	}

	// 资源  按钮动画
	@ResInject(id = R.anim.gone_from_bottom, type = ResType.Animation)
	private Animation rAnimGoneFromBottom;
	@ResInject(id = R.anim.visible_from_bottom, type = ResType.Animation)
	private Animation rAnimVisibleFromBottom;

	// 滚动
	@ViewInject(R.id.view_publish_scroll_panel)
	private ScrollView vScrollView;

	// 车位信息
	@ViewInject(R.id.view_publish_parking_quarter)
	private TextView vInfoQuarter;  // 小区/车位
	@ViewInject(R.id.view_publish_parking_checked)
	private TextView vInfoChecked;  // 审核状态
	@ViewInject(R.id.view_publish_parking_price)
	private TextView vInfoPrice;    //  车位价格
	@ViewInject(R.id.view_publish_parking_vaild_date)
	private TextView vInfoVaildDate;   //  起止日期
	@ViewInject(R.id.view_publish_parking_time)
	private TextView vInfoTime;    //  停车时段

	// 业主信息    // 物业可见
	@ViewInject(R.id.view_publish_owner_panel)
	private View vOwnerPanel;
	@ViewInject(R.id.view_publish_owner_name)
	private TextView vOwnerName;    // 业主姓名
	@ViewInject(R.id.view_publish_owner_phone)
	private TextView vOwnerPhone;   // 业主电话

	// 操作面板
	@ViewInject(R.id.view_publish_option_panel)
	private View vOptPanel;
	@ViewInject(R.id.view_publish_opt_left_btn)
	private TextView vOptLeft;
	@ViewInject(R.id.view_publish_opt_right_btn)
	private TextView vOptRight;

	// @OnTouch(value={R.id.view_publish_scroll_panel})
	public boolean catchScrollAction(View v, MotionEvent event) {
		// TODO Auto-generated method stub
		if (!canDoOption) {
			return false;
		}
		switch (event.getAction()) {
		case MotionEvent.ACTION_MOVE:
			Log.i("qh", "move ?");
			hideOptionPanel();
			return false;
		default:
			break;
		}
		return false;
	}

	@OnClick(value = { R.id.view_publish_opt_left_btn })
	private void optLeftDo(View view) {
		if (mRoleType == ParkingConstant.ROLE_USER) {   // 删除
			mOptUrl = mServer.getURL(IServer.URL_FLAG_POST_USER_OPT_PUBLISH,
					mModel.getId(),
					String.valueOf(IServer.USER_OPT_STATE_DELETE));
			mOptType = OPT_TYPE_USER_DELETE;
		} else if (mRoleType == ParkingConstant.ROLE_GUARDER) {   // 拒绝车位
			mOptType = OPT_TYPE_GUARD_REFUSE;
		}
		showConfirmDialog();
	}

	@OnClick(value = { R.id.view_publish_opt_right_btn })
	private void optRightDo(View view) {
		if (mRoleType == ParkingConstant.ROLE_USER) {
			if (ParkingConstant.PUBLISH_PAUSE.equals(mModel.getState_en())) {// 取消暂停
				mOptUrl = mServer.getURL(
						IServer.URL_FLAG_POST_USER_OPT_PUBLISH, mModel.getId(),
						String.valueOf(IServer.USER_OPT_STATE_UN_PAUSE));
				mOptType = OPT_TYPE_USER_UN_PAUSE;
			} else {// 暂停
				mOptUrl = mServer.getURL(
						IServer.URL_FLAG_POST_USER_OPT_PUBLISH, mModel.getId(),
						String.valueOf(IServer.USER_OPT_STATE_PAUSE));
				mOptType = OPT_TYPE_USER_PAUSE;
			}
		} else if (mRoleType == ParkingConstant.ROLE_GUARDER) {   // 通过车位
			mOptType = OPT_TYPE_GUARD_OK;
		}
		showConfirmDialog();
	}

	private PublishListForm mModel;

	private int mRoleType;

	private boolean canDoOption = true;
	
	private boolean isFromSystem;

	private String taskId;
	private WorkHandler mWorkHandler = new WorkHandler(this);

	private static class WorkHandler extends
			WeakHandler<ViewPublishInfoFromSysActivity> {

		public static final int MSG_SHOW_OPT = 1;
		public static final int MSG_HIDE_OPT = 2;

		public WorkHandler(ViewPublishInfoFromSysActivity owner) {
			super(owner);
			// TODO Auto-generated constructor stub
		}

		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			switch (msg.what) {
			case MSG_HIDE_OPT:
				getOwner().doHideOptionPanel();
				break;
			case MSG_SHOW_OPT:
				getOwner().doShowOptionPanel();
				break;
			default:
				break;
			}
		}

	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		if (!parseIntent()) {
			Log.i("qh", "ViewPublishInfoActivity onCreate parseIntent == null");
			finish();
			return;
		}
		setContentView(R.layout.activity_view_publish);
		initDatas();
		if(isFromSystem) {
			taskId = getIntent().getStringExtra("publish_id");
			refreshModelFromServer();
		}else {
			initViews();
		}
		
	}
	
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		if(isFromSystem && ParkingApp.mAppCtx.isNeedLoadMainActivity()){
			startActivity(new Intent(this, AppActivity.class));
		}
	}

	/**
	 * 根据Id 在DB中查询对应额数据
	 * @return false（没有数据）
	 */
	private boolean parseIntent() {
		Intent intent = getIntent();
		if (intent == null) {
			return false;
		}
		isFromSystem = intent.getBooleanExtra(ParkingConstant.INTENT_EXTRA_BOOL_FROM_SYSMSG, false);
		if(isFromSystem) {
			return true;
		}
		String modelid = intent
				.getStringExtra(ParkingConstant.INTENT_EXTRA_PUBLISH_DB_ID);
		if (modelid == null) {
			return false;
		}
		try {
			mModel = mDB.findById(PublishListForm.class, modelid);
		} catch (DbException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (mModel == null) {
			return false;
		}
		Log.i("qh", mModel.toString());
		return true;
	}

	/**
	 * 获取角色类型
	 * */
	private void initDatas() {
		this.mRoleType = ParkingApp.mAppCtx.getUType();  
	}

	private void initViews() {
		vTopCenter.setText("车位详情");
		vTopLeft.setText("  返 回");
		vTopLeft.setVisibility(View.VISIBLE);

		vInfoChecked.setText(mModel.getState());
		vInfoPrice.setText(mModel.getPrice());
		vInfoQuarter.setText(mModel.getParking_no());
		vInfoTime.setText(mModel.getTime_hour());
		vInfoVaildDate.setText(mModel.getTime_date());

		vOwnerPanel.setVisibility(View.GONE);
		vOptPanel.setVisibility(View.GONE);

		// 物业角色
		if (mRoleType == ParkingConstant.ROLE_GUARDER) {
			vOwnerPanel.setVisibility(View.VISIBLE);
			vOwnerName.setText(mModel.getBoss_name());
			vOwnerPhone.setText(mModel.getPhone());

			// 是否通过审核
			if (!ParkingConstant.PUBLISH_UN_CHECK.equals(mModel
					.getState_en())) {
				canDoOption = false;
				return;
			}

			vOptLeft.setText("拒绝");
			vOptLeft.setTextColor(getResources().getColor(
					R.color.text_color_red));
			vOptRight.setText("通过");
			vOptRight.setTextColor(getResources().getColor(
					R.color.text_color_light_blue));

		} else if (mRoleType == ParkingConstant.ROLE_USER) {
			vOwnerPanel.setVisibility(View.GONE);

			vOptLeft.setText("删除");
			vOptLeft.setTextColor(getResources().getColor(
					R.color.text_color_red));
			if (ParkingConstant.PUBLISH_CHECK_SUCCESS.equals(mModel
					.getState_en())) {
				vOptRight.setText("暂停");
				vOptRight.setTextColor(getResources().getColor(
						R.color.text_color_light_blue));
			} else if (ParkingConstant.PUBLISH_PAUSE.equals(mModel
					.getState_en())) {
				vOptRight.setText("取消暂停");
				vOptRight.setTextColor(getResources().getColor(
						R.color.text_color_light_blue));
			} else {
				vOptRight.setVisibility(View.GONE);
			}
		}

		hideOptionPanel();
	}

	private void hideOptionPanel() {
		mWorkHandler.sendEmptyMessage(WorkHandler.MSG_HIDE_OPT);
		mWorkHandler.removeMessages(WorkHandler.MSG_SHOW_OPT);
		mWorkHandler.sendEmptyMessageDelayed(WorkHandler.MSG_SHOW_OPT, 500);
	}

	private void doHideOptionPanel() {
		if (vOptPanel.getVisibility() == View.GONE) {
			return;
		}
		vOptPanel.startAnimation(rAnimGoneFromBottom);
		vOptPanel.setVisibility(View.GONE);
	}

	private void doShowOptionPanel() {
		if (vOptPanel.getVisibility() == View.VISIBLE) {
			return;
		}
		vOptPanel.startAnimation(rAnimVisibleFromBottom);
		vOptPanel.setVisibility(View.VISIBLE);
	}

	private void reqOptToServer() {
		if (mOptUrl == null) {
			return;
		}
		showProgressDialog();
		getJsonFromServer(mOptUrl);
	}

	@Override
	protected void callbackFromGetJsonFail(int failcode, String msg) {
		// TODO Auto-generated method stub
		dismissDialog(DIALOG_PROGRESS);
		showToastTips("提交操作失败");
		mOptType = -1;
		mOptUrl = null;
	}

	@Override
	protected void callbackFromGetJsonSuccess(String json) {
		// TODO Auto-generated method stub
		dismissDialog(DIALOG_PROGRESS);
		boolean issuccess = false;
		String msg = "操作成功";
		try {
			JSONObject jobj = new JSONObject(json);
			issuccess = jobj.getBoolean("success");
			if (!issuccess) {
				msg = jobj.getString("msg");
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		showToastTips(msg);
		if (issuccess) {
			setResult(RESULT_OK);// 要求列表界面刷新
			finish();
		} else {
			mOptType = -1;
			mOptUrl = null;
		}
	}

	// confirm dialog

	public static final int OPT_TYPE_USER_DELETE = 1;
	public static final int OPT_TYPE_USER_PAUSE = 2;
	public static final int OPT_TYPE_USER_UN_PAUSE = 3;

	public static final int OPT_TYPE_GUARD_REFUSE = 10;
	public static final int OPT_TYPE_GUARD_OK = 11;

	private AlertDialog mConfirmDialog;
	private AlertDialog mGuardConfirmDialog;
	private int mOptType;
	private String mOptUrl;
	private boolean ifTrust;

	private void showConfirmDialog() {
		if (mOptType == -1) {
			return;
		}
		if (mOptType == OPT_TYPE_GUARD_OK || mOptType == OPT_TYPE_GUARD_REFUSE) {
			showGuardConfirmDialog();
			return;
		}
		if (mOptUrl == null) {
			return;
		}
		if (mConfirmDialog == null) {
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setCancelable(false)
					.setPositiveButton("确定",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int id) {
									reqOptToServer();
									mOptType = -1;
									mOptUrl = null;
								}
							})
					.setNegativeButton("取消",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int id) {
									mOptType = -1;
									mOptUrl = null;
									mConfirmDialog.dismiss();
								}
							});
			mConfirmDialog = builder.create();
		}
		mConfirmDialog.setTitle(getConfirmOptDialogTitle());
		mConfirmDialog.setMessage(getConfirmOptDialogMsg());
		mConfirmDialog.show();
	}

	private void showGuardConfirmDialog() {
		if(mGuardConfirmDialog != null){
			mGuardConfirmDialog = null;
		}
		mGuardConfirmDialog = new AlertDialog.Builder(this)
				.setMultiChoiceItems(new String[] { "自动审核该车位的发布" },
						new boolean[] { false },
						new DialogInterface.OnMultiChoiceClickListener() {

							@Override
							public void onClick(DialogInterface dialog,
									int which, boolean isChecked) {
								// TODO Auto-generated method stub
								ifTrust = isChecked;
							}
						})
				.setNegativeButton("取消", new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						mOptType = -1;
						ifTrust = false;
					}
				})
				.setPositiveButton("确定", new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						if(mOptType == OPT_TYPE_GUARD_OK){
							mOptUrl = mServer.getURL(IServer.URL_FLAG_POST_GUARD_OPT_PUBLISH, mModel.getId(),
									String.valueOf(IServer.GUARD_OPT_STATE_OK),
									String.valueOf(ifTrust));
						}else{
							mOptUrl = mServer.getURL(IServer.URL_FLAG_POST_GUARD_OPT_PUBLISH, mModel.getId(),
									String.valueOf(IServer.GUARD_OPT_STATE_REFUSE),
									String.valueOf(ifTrust));
						}
						reqOptToServer();
						mOptType = -1;
						ifTrust = false;
					}
				}).create();
		mGuardConfirmDialog.setTitle(getConfirmOptDialogTitle());
		mGuardConfirmDialog.show();
	}

	private String getConfirmOptDialogTitle() {
		switch (mOptType) {
		case OPT_TYPE_USER_DELETE:
			return "删除车位";
		case OPT_TYPE_USER_PAUSE:
			return "暂停车位";
		case OPT_TYPE_USER_UN_PAUSE:
			return "取消暂停车位";
		case OPT_TYPE_GUARD_OK:
			return "通过该车位信息的发布";
		case OPT_TYPE_GUARD_REFUSE:
			return "拒绝该车位信息的发布";
		default:
			break;
		}
		return null;
	}

	private String getConfirmOptDialogMsg() {
		switch (mOptType) {
		case OPT_TYPE_USER_DELETE:
			return "是否确定删除该车位信息的发布?";
		case OPT_TYPE_USER_PAUSE:
			return "是否确定暂停该车位信息的发布?";
		case OPT_TYPE_USER_UN_PAUSE:
			return "是否重新发布该车位信息?";
		case OPT_TYPE_GUARD_OK:
			return "是否通过该车位信息的发布?";
		case OPT_TYPE_GUARD_REFUSE:
			return "是否拒绝该车位信息的发布?";
		default:
			break;
		}
		return null;
	}
	
	/** 
	 * 请求服务器，刷新数据 
	 **/ 
	private void refreshModelFromServer() { 

		curShowView = "refreshModelFromServer";
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("method", "2009");
		HttpUtils http = new HttpUtils(6000);
		showProgDialog("正在查询 . . .", http);
		http.send(HttpMethod.POST, 
				"https://121.33.214.30:8443/lhparking/servlet/SysInterface",
				params,
				new RequestCallBack< String >() {

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// TODO Auto-generated method stub
						Log.i("lh", responseInfo.result);
						if(curShowView.equals("refreshModelFromServer")) {
							try {
								JSONObject jsob = new JSONObject(responseInfo.result);
								int totalCount = jsob.getInt("totalCount");
								if( totalCount == 0 ) {
									Toast.makeText(getApplicationContext(), "查询失败", Toast.LENGTH_LONG);
								}else {
									JSONArray jsoa = jsob.getJSONArray("data");
									JSONObject jso;
									for(int i=0; i<totalCount; i++) {
										jso = jsoa.getJSONObject(i);
										if(jso.getString("id").equals(taskId)) {
											String jsonstr = jso.toString();
											Gson gson = new Gson();
											TypeToken<PublishListForm> token = new TypeToken<PublishListForm>() {
											};
											mModel = gson.fromJson(jsonstr, token.getType());
											initViews();
											break;
										}
									}
								}
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							
							if(mDialog != null) {
								dialogDismiss = 1;
								mDialog.dismiss();
							}
						}
						
					}

					@Override
					public void onFailure(HttpException error, String msg) {
						// TODO Auto-generated method stub
						if(curShowView.equals("refreshModelFromServer")) {
							Toast.makeText(getApplicationContext(), "查询失败", Toast.LENGTH_LONG);
						}
						if(mDialog != null) {
							dialogDismiss = 1;
							mDialog.dismiss();
						}
					}
				});
		
	
	}
	
	private ProgressDialog mDialog;
	private String curShowView = "0";
	private int dialogDismiss = 0;
	
	private void showProgDialog(final String msg, final HttpUtils httpUtils) {
		mDialog = new ProgressDialog(this);
		mDialog.setCanceledOnTouchOutside(false);
		mDialog.setOnDismissListener(new OnDismissListener() {
			
			@Override
			public void onDismiss(DialogInterface dialog) {
				// TODO Auto-generated method stub
				if(dialogDismiss == 0 ) {
					httpUtils.getHttpClient().getConnectionManager().closeExpiredConnections();
//					httpUtils.getHttpClient().getConnectionManager().shutdown();
				}
				dialogDismiss = 0;
				curShowView = "0";
				Log.i("TEST", "dialog dismiss : "+msg);
			}
		});
		mDialog.setMessage(msg);
		mDialog.show();
	}
	
}
