package com.sendi.lhparking.ui.common;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.sendi.parking.ui.R;

import com.ab.view.wheel.AbObjectWheelAdapter;
import com.ab.view.wheel.AbOnWheelChangedListener;
import com.ab.view.wheel.AbWheelView;
import com.baidu.mapapi.model.LatLng;
import com.baidu.mapapi.search.core.SearchResult;
import com.baidu.mapapi.search.geocode.GeoCodeResult;
import com.baidu.mapapi.search.geocode.GeoCoder;
import com.baidu.mapapi.search.geocode.OnGetGeoCoderResultListener;
import com.baidu.mapapi.search.geocode.ReverseGeoCodeOption;
import com.baidu.mapapi.search.geocode.ReverseGeoCodeResult;
import com.baidu.mapapi.search.geocode.ReverseGeoCodeResult.AddressComponent;
import com.lidroid.xutils.BitmapUtils;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.im.conn.XmppManager;
import com.sendi.lhparking.ui.wuye.AddParkingHistoryActivity;
import com.sendi.lhparking.util.ParkingPrefs;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnDismissListener;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.opengl.Visibility;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
/**
 * 设置界面
 * @author Administrator
 *
 */
public class SettingActivity extends BaseActivity {
	private Button btnPersonalinfo;
	private Button btnChangepsw;
	private Button btnSecret;
	private Button btnFeedback;
	private Button btnAbout;
	private Button btnAddparking;
	private Button btnDefaultSetting;
	private Button btnCheckVersion;
	private Button btnExit;
	
	public static final String PREF_LANGHUA_UID = "langhua_uid";/*string*/
	public static final String PREF_LANGHUA_UTYPE = "langhua_utype";/*string*/

	private List<String> dataCity = new ArrayList<String>();
	private List<String> dataDistrict = new ArrayList<String>();
	
	private int mAppTypeCode = 0;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);

		mAppTypeCode = ParkingApp.mAppCtx.getAppTypeCode();
		initView();
	}
	
	/** 
	 * 初始界面
	 * */
	private void initView() {
		setContentView(R.layout.activity_setting); 

		btnChangepsw = (Button) this.findViewById(R.id.btn_changepsw);
		btnSecret = (Button) this.findViewById(R.id.btn_secret);
		btnExit = (Button) this.findViewById(R.id.btn_exit);
		btnFeedback = (Button) this.findViewById(R.id.btn_feedback);
		btnAbout = (Button) this.findViewById(R.id.btn_about);
		btnPersonalinfo = (Button) this.findViewById(R.id.btn_personalinfo);
		btnAddparking = (Button) this.findViewById(R.id.btn_addparking);
		btnDefaultSetting = (Button) this.findViewById(R.id.btn_defaultSetting);
		btnCheckVersion = (Button) this.findViewById(R.id.btn_checkversion);
		TextView tvTitle = (TextView) this.findViewById(R.id.topbar_center_btn);
		
		if(mAppTypeCode == 4) {
			btnAddparking.setVisibility(View.VISIBLE);
		}
		tvTitle.setText("设  置");
		
		btnChangepsw.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(SettingActivity.this, ChangePswActivity.class);
				startActivity(intent);
			}
		});
		
		btnSecret.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(SettingActivity.this, SetSecretActivity.class);
				startActivity(intent);
			}
		});
		
		btnFeedback.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(SettingActivity.this, FeedBackActivity.class);
				startActivity(intent);
			}
		});
		
		btnAbout.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(SettingActivity.this, AboutActivity.class);
				startActivity(intent);
			}
		});
		
		btnAddparking.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
//				Intent intent = new Intent(SettingActivity.this, AddParkingBtnActivity.class);
				Intent intent = new Intent(SettingActivity.this, AddParkingHistoryActivity.class);
				startActivity(intent);
			}
		});
		
		btnDefaultSetting.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(SettingActivity.this, DefaultSettingActivity.class);
				startActivity(intent);
			}
		});
		
		btnCheckVersion.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(SettingActivity.this, CheckVersionActivity.class);
				startActivity(intent);
			}
		});
		
		btnExit.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				showExitDialog();
			}
		});
		
		btnPersonalinfo.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(SettingActivity.this, PersonInfoActivity.class);
				startActivity(intent);
			}
		});
	}
	
	
	
	private void getCity() {
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("method", "201301");

		HttpUtils http = new HttpUtils();
		http.configTimeout(10000);
		http.send(HttpMethod.POST, 
				ServerURL, 
				params,
				new RequestCallBack<String>() {

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// TODO Auto-generated method stub
						String result = responseInfo.result;
						List<String> data = new ArrayList<String>();
						try {
							JSONObject jsob = new JSONObject(result);
							int count = jsob.getInt("totalCount");
							if(count != 0) {
								JSONArray jsoa = jsob.getJSONArray("data");
								for(int i=0; i< count; i++) {
									JSONObject jso = jsoa.getJSONObject(i);
									data.add(jso.getString("city_name"));
								}
							}else {
								data.add("广州市");
							}
							dataCity = data;							
							if(dialog != null) {
								dialog.dismiss();
							}
						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}

					@Override
					public void onFailure(HttpException error, String msg) {
						// TODO Auto-generated method stub
						if(dataCity == null || dataCity.size() == 0) {
							dataCity.add("广州市");
						}						
						if(dialog != null) {
							dialog.dismiss();
						}
					}
		});
	}
	
	private void getDistrict(String cityCode) {
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("method", "201301");
		params.addBodyParameter("city_code", cityCode);

		HttpUtils http = new HttpUtils();
		http.configTimeout(10000);
		http.send(HttpMethod.POST, 
				ServerURL, 
				params,
				new RequestCallBack<String>() {

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// TODO Auto-generated method stub
						String result = responseInfo.result;
						List<String> data = new ArrayList<String>();
						try {
							JSONObject jsob = new JSONObject(result);
							int count = jsob.getInt("totalCount");
							if(count != 0) {
								JSONArray jsoa = jsob.getJSONArray("data");
								for(int i=0; i< count; i++) {
									JSONObject jso = jsoa.getJSONObject(i);
									data.add(jso.getString("district"));
								}
							}else {
								data.add("暂  无");
							}
							dataDistrict = data;							
							if(dialog != null) {
								dialog.dismiss();
							}
						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}

					@Override
					public void onFailure(HttpException error, String msg) {
						// TODO Auto-generated method stub
						if(dataDistrict == null || dataDistrict.size() == 0) {
							dataDistrict.add("暂  无");
						}
						if(dialog != null) {
							dialog.dismiss();
						}
					}
		});
	}
	
	/** 
	 * 是否退出提示框
	 * */
	private void showExitDialog() {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("提醒");
		builder.setMessage("是否确定退出？");
		builder.setCancelable(false);
		builder.setNegativeButton("取消",
				new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						return;
					}
				});
		builder.setPositiveButton("确定",
				new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub\
						ParkingPrefs.loginOut();
						XmppManager.getXmpp().disConn();
						Intent intentLogin = new Intent(SettingActivity.this, LoginActivity.class);
						startActivity(intentLogin);
						ParkingApp.mAppCtx.finishMainActivity();
					}
				});	
		builder.create().show();
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
	}	
	
}
