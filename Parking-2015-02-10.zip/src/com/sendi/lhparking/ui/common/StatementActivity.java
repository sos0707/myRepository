package com.sendi.lhparking.ui.common;

import org.sendi.parking.ui.R;


import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
/**
 * 免责声明界面
 * @author Administrator
 *
 */
public class StatementActivity extends BaseActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		

		setContentView(R.layout.activity_statement);
		TextView tvTitle = (TextView) this.findViewById(R.id.topbar_center_btn);
		TextView tvReturn = (TextView) this.findViewById(R.id.topbar_left_btn);
		
		tvTitle.setText("免 责 声 明");
		tvReturn.setVisibility(View.VISIBLE);
		tvReturn.setText("  返 回");
		tvReturn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				hideKeyborad();
				StatementActivity.this.finish();
			}
		});
	
	}

	
}
