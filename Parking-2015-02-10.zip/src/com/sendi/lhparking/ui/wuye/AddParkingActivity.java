package com.sendi.lhparking.ui.wuye;

import java.io.File;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.sendi.parking.ui.R;

import com.baidu.mapapi.model.LatLng;
import com.baidu.mapapi.search.core.SearchResult;
import com.baidu.mapapi.search.geocode.GeoCodeResult;
import com.baidu.mapapi.search.geocode.GeoCoder;
import com.baidu.mapapi.search.geocode.OnGetGeoCoderResultListener;
import com.baidu.mapapi.search.geocode.ReverseGeoCodeOption;
import com.baidu.mapapi.search.geocode.ReverseGeoCodeResult;
import com.baidu.mapapi.search.geocode.ReverseGeoCodeResult.AddressComponent;
import com.google.gson.JsonObject;
import com.lidroid.xutils.BitmapUtils;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.lidroid.xutils.http.client.entity.BodyParamsEntity;
import com.lidroid.xutils.http.client.multipart.HttpMultipartMode;
import com.lidroid.xutils.http.client.multipart.MultipartEntity;
import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.payutil.Result;
import com.sendi.lhparking.ui.chezhu.MapLocationActivity;
import com.sendi.lhparking.ui.common.BaseActivity;
import com.sendi.lhparking.util.CityInfo;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnDismissListener;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class AddParkingActivity extends BaseActivity implements OnGetGeoCoderResultListener {

	GeoCoder mSearch = null;  // baidu map sdk 搜索模块
	
	public static final String PREF_LANGHUA_UID = "langhua_uid";/*string*/
	public static final String PREF_LANGHUA_UTYPE = "langhua_utype";/*string*/
	private static int RESULT_LOAD_IMAGE1 = 1;
	private static int RESULT_LOAD_IMAGE2 = 2;
	private ImageView imgYyzz;
	private ImageView imgSfzm;
	private TextView tvYyzz;
	private TextView tvSfzm;
	private EditText edParkingname ;
	private EditText edCity ;
	private EditText edDistrict ;
	private EditText edAddress ;
	private EditText edNumberfield ;
	private EditText edChargeunit ;
	private EditText edInchargename ;
	private EditText edInchargephone ;
	private EditText edInchargemobile ;
	private Button btnSubmit;
	private String curCity = "广州市";
	private String curDistrit = "越秀区";
	private Spinner spCity, spDisc;
	private ProgressDialog mDialog;
	private String curShowView = "0";
	private int dialogDismiss = 0;
	private String timeStamp ;
	private String serverUrl = ServerURL;
	private List<String> dataCity = new ArrayList<String>();
	private List<String> dataDistrict = new ArrayList<String>();
	private List<CityInfo> cityInfos = new ArrayList<CityInfo>();
	private ArrayAdapter<String> adapter;
	private ArrayAdapter<String> dadapter;
	private int spIndex = 0;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.view_addparking);

		mSearch = GeoCoder.newInstance();
		mSearch.setOnGetGeoCodeResultListener(AddParkingActivity.this);
		LatLng ptCenter = new LatLng((MapLocationActivity.mCurrentLantitude), (MapLocationActivity.mCurrentLongitude));
		// 反Geo搜索
		mSearch.reverseGeoCode(new ReverseGeoCodeOption()
				.location(ptCenter));
		showAddparking();
		getCity();
	}

	List<EditText> edList = new ArrayList<EditText>();
	
	private void setSpinner() {
		adapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, dataCity);
        //设置下拉列表的风格
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //将adapter 添加到spinner中
        spCity.setAdapter(adapter);
        spCity.setSelection(spIndex, true);
	}
	
	private void setDiscSpinner() {
		dadapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, dataDistrict);
        //设置下拉列表的风格
        dadapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //将adapter 添加到spinner中
        spDisc.setAdapter(dadapter);
	}
	
	/** 
	 * 新增小区输入信息界面
	 * */
	private void showAddparking() {
//		setContentView(R.layout.view_addparking);
		TextView tvTitle = (TextView) this.findViewById(R.id.topbar_center_btn);
		TextView tvReturn = (TextView) this.findViewById(R.id.topbar_left_btn);
		tvYyzz = (TextView) this.findViewById(R.id.tvSetyyzz);
		tvSfzm = (TextView) this.findViewById(R.id.tvSetsfzm);
	    edParkingname = (EditText) this.findViewById(R.id.edParkingname);
		edCity = (EditText) this.findViewById(R.id.edCity);
		edDistrict = (EditText) this.findViewById(R.id.edDistrict);
		edAddress = (EditText) this.findViewById(R.id.edAddress);
		edNumberfield = (EditText) this.findViewById(R.id.edNumberfield);
		edChargeunit = (EditText) this.findViewById(R.id.edChargeunit);
		edInchargename = (EditText) this.findViewById(R.id.edInchargename);
		edInchargephone = (EditText) this.findViewById(R.id.edInchargephonenum);
		edInchargemobile = (EditText) this.findViewById(R.id.edInchargeMobilenum);
		spCity = (Spinner) this.findViewById(R.id.spCity);
		spDisc = (Spinner) this.findViewById(R.id.spDisc);
		edList.add(edParkingname);
//		edList.add(edCity);
//		edList.add(edDistrict);
		edList.add(edAddress);
		edList.add(edNumberfield);
		edList.add(edChargeunit);
		edList.add(edInchargename);
		edList.add(edInchargephone);
		edList.add(edInchargemobile);
		Button btnSetyyzz = (Button) this.findViewById(R.id.btnSetyyzz);
		Button btnSetsfzm = (Button) this.findViewById(R.id.btnSetsfzm);
		btnSubmit = (Button) this.findViewById(R.id.btnSubmit);
		imgYyzz = (ImageView) this.findViewById(R.id.imgYyzz);
		imgSfzm = (ImageView) this.findViewById(R.id.imgSfzm);
		
		tvTitle.setText("申请加盟");
		tvReturn.setVisibility(View.VISIBLE);
		tvReturn.setText("  返 回");
		
		if(curCity!=null && curCity != "") {
			edCity.setText(curCity);
		}
		if(curDistrit != null && curDistrit != "") {
			edDistrict.setText(curDistrit);
		}
		tvReturn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				hideKeyborad();
				AddParkingActivity.this.finish();
			}
		});
		
		spCity.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				// TODO Auto-generated method stub
				Log.i(TAG, "spCity onItemSelected : " + arg2);
				if(cityInfos != null && cityInfos.size() != 0 ) {
					getDistrict(cityInfos.get(arg2).getCityCode());
				}
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				Log.i(TAG, "spCity onNothingSelected : " );
			}
		});
		
		btnSubmit.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				boolean bo = checkEditTextIsNull(edList);
				if(!bo) {
					showTipsDialog("请输入完整信息！", AddParkingActivity.this);
					return;
				}
				if(tvYyzz.getText().toString().equals("未选择文件") || tvSfzm.getText().toString().equals("未选择文件")) {
					showTipsDialog("请提交扫描件资料！", AddParkingActivity.this);
					return;
				}
				boolean boNet = isNetConnected();
				if(boNet) {
					timeStamp = getTimeStamp();
					btnSubmit.setClickable(false);
					showProgDialog("提交营业执照扫描件  . . . ", AddParkingActivity.this);
					doPostYyzz();
				}else {
					Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
				}
				
			}
		});
		
		btnSetyyzz.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(
                        Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, RESULT_LOAD_IMAGE1);
			}
		});
		
		btnSetsfzm.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(
                        Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, RESULT_LOAD_IMAGE2);
			}
		});
	}
	
	/** 
	 * 检查输入是否为空
	 * */
	private boolean checkEditTextIsNull(List<EditText> list) {
		for(EditText ed : list) {
			if(ed.getText().length() == 0) {
				return false;
			}
		}
		return true;
	}
	
	/** 
	 * 获取图片返回结果
	 * */
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		if (requestCode == RESULT_LOAD_IMAGE1 && resultCode == RESULT_OK && null != data) {
            Uri selectedImage = data.getData();
            
            String[] filePathColumn = { MediaStore.Images.Media.DATA };
  
            Cursor cursor = getContentResolver().query(selectedImage,
                    filePathColumn, null, null, null);
            cursor.moveToFirst();
  
            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            String picturePath = cursor.getString(columnIndex);
            cursor.close();
            ContentResolver cr = this.getContentResolver();
            BitmapUtils bitmapUtils = new BitmapUtils(this);
            bitmapUtils.display(imgYyzz, picturePath);
            tvYyzz.setText(picturePath);
        }
		if (requestCode == RESULT_LOAD_IMAGE2 && resultCode == RESULT_OK && null != data) {
            Uri selectedImage = data.getData();
            String[] filePathColumn = { MediaStore.Images.Media.DATA };
  
            Cursor cursor = getContentResolver().query(selectedImage,
                    filePathColumn, null, null, null);
            cursor.moveToFirst();
  
            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            String picturePath = cursor.getString(columnIndex);
            cursor.close();
            ContentResolver cr = this.getContentResolver();
            BitmapUtils bitmapUtils = new BitmapUtils(this);
            bitmapUtils.display(imgSfzm, picturePath);
            tvSfzm.setText(picturePath);
        }
	}

	@Override
	public void onGetGeoCodeResult(GeoCodeResult result) {
		// TODO Auto-generated method stub
		
	}

	/** 
	 * 获取反地理编码返回结果
	 * */
	@Override
	public void onGetReverseGeoCodeResult(ReverseGeoCodeResult result) {
		// TODO Auto-generated method stub
		Log.i(TAG, "regeo reslut");
		if (result == null || result.error != SearchResult.ERRORNO.NO_ERROR) {
			
		}else {
			String add = result.getAddress();
			AddressComponent addcomp = result.getAddressDetail();
			curCity = addcomp.city;
			curDistrit = addcomp.district;
			if(curCity!=null && curCity != "") {
				edCity.setText(curCity);
			}
			if(curDistrit != null && curDistrit != "") {
				edDistrict.setText(curDistrit);
			}
			Log.i(TAG, "get reverseGeoCodeResult:"+add);
		}
	}
	
	/**
	 * 参数：method：2025 parkingName：小区名字  
	 * city //所属市  district：区 address：详细地址
	 * numberField：车位数 chargeUnit：物业公司  inchargeName：姓名  
	 * phoneNumber：联系电话 mobileNumber：手机  
	 * yyzzPhoto：file类型 营业执照扫描件   sfzmPhoto：file类型 申请函扫描件
	 */
	private void doAddParking() {
		curShowView = "AddParking";		
		dialogDismiss = 1;
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("method", "2025");
		params.addBodyParameter("parkingName", edParkingname.getText().toString());
//		params.addBodyParameter("city", edCity.getText().toString());
//		params.addBodyParameter("district", edDistrict.getText().toString());
		params.addBodyParameter("city", dataCity.get(spCity.getSelectedItemPosition()));
		params.addBodyParameter("district", dataDistrict.get(spDisc.getSelectedItemPosition()));
		params.addBodyParameter("address", edAddress.getText().toString());
		params.addBodyParameter("numberField", edNumberfield.getText().toString());
		params.addBodyParameter("chargeUnit", edChargeunit.getText().toString());
		params.addBodyParameter("inchargeName", edInchargename.getText().toString());
		params.addBodyParameter("phoneNumber", edInchargephone.getText().toString());
		params.addBodyParameter("mobileNumber", edInchargemobile.getText().toString());
		params.addBodyParameter("timestamp", timeStamp);
		HttpUtils http = new HttpUtils(20000);
		showProgDialog("正在提交 . . . ",http);
		http.send(HttpRequest.HttpMethod.POST, 
				ServerURL,
				params,
				new RequestCallBack<String>() {

					@Override
			        public void onStart() {
						Log.i(TAG, "conn . . . . . . ");
			        }
					
					@Override
			        public void onLoading(long total, long current, boolean isUploading) {
			            if (isUploading) {
			            	Log.i(TAG, "upload: " + current + "/" + total);
			            } else {
			            	Log.i(TAG, "reply: " + current + "/" + total);
			            }
			        }
					
					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// TODO Auto-generated method stub
						Log.i(TAG, "AddParking result : "+responseInfo.result);
						if(curShowView.equals("AddParking")) {
							try {
								JSONObject jsob = new JSONObject(responseInfo.result);
								Message msg = new Message();
								msg.obj = jsob.getString("msg");
								msg.what = 1;
								ParkingApp.addHandler.sendMessage(msg);
								AddParkingActivity.this.finish();
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							if(mDialog != null) {
								dialogDismiss = 1;
								mDialog.dismiss();
							}
							
						}
					}

					@Override
					public void onFailure(HttpException error, String msg) {
						// TODO Auto-generated method stub
						Log.i(TAG, "AddParking result : "+ msg);
						showTipsDialog("AddParking result : "+msg, AddParkingActivity.this);
						if(curShowView.equals("AddParking")) {
							showTipsDialog("提交失败，请检查网络，稍后再试 ", AddParkingActivity.this);
						}
						if(mDialog != null) {
							dialogDismiss = 1;
							mDialog.dismiss();
						}
					}});
	
	}
	
	private void showProgDialog(final String msg, final HttpUtils httpUtils) {
		mDialog = new ProgressDialog(this);
		mDialog.setCanceledOnTouchOutside(false);
		mDialog.setOnDismissListener(new OnDismissListener() {
			
			@Override
			public void onDismiss(DialogInterface dialog) {
				// TODO Auto-generated method stub
				btnSubmit.setClickable(true);
				if(dialogDismiss == 0 ) {
					httpUtils.getHttpClient().getConnectionManager().closeExpiredConnections();
//					httpUtils.getHttpClient().getConnectionManager().shutdown();
				}
				dialogDismiss = 0;
				curShowView = "0";
				Log.i(TAG, "dialog dismiss : "+msg);
			}
		});
		mDialog.setMessage(msg);
		mDialog.show();
	}
	
	private void doPostYyzz() {
		final String url = serverUrl + "?method=pic_2025&uid="+ParkingApp.mAppCtx.getUID()+"&timestamp="+timeStamp+"&phoneType=1";
		final File file = new File(tvYyzz.getText().toString());
		new Thread(){

			@Override
			public void run() {
				// TODO Auto-generated method stub
				super.run();
				String respondString = com.sendi.lhparking.util.HttpUtils.queryStringForPost(url, file);
				System.out.println("yyzz上传结果:" + (null == respondString?"null":respondString));
				JSONObject jsob;
				try {
					jsob = new JSONObject(respondString);
					boolean bo = jsob.getBoolean("success");
					Message msg = new Message();
					msg.obj = bo;
					msg.what = 1;
					mHandler.sendMessage(msg);
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					boolean bo = false;
					Message msg = new Message();
					msg.obj = bo;
					msg.what = 1;
					mHandler.sendMessage(msg);
					e.printStackTrace();
				}
				Log.i(TAG, (null == respondString?"null":respondString));
			}
		}.start();
	}
	
	private void doPostSfzm() {
		final String url = serverUrl + "?method=pic_2025&uid="+ParkingApp.mAppCtx.getUID()+"&timestamp="+timeStamp+"&phoneType=2";
		final File file = new File(tvSfzm.getText().toString());
		new Thread(){

			@Override
			public void run() {
				// TODO Auto-generated method stub
				super.run();
				String respondString = com.sendi.lhparking.util.HttpUtils.queryStringForPost(url, file);
				System.out.println("sfzm上传结果:" + (null == respondString?"null":respondString));
				Log.i(TAG, (null == respondString?"null":respondString));
				JSONObject jsob;
				try {
					jsob = new JSONObject(respondString);
					boolean bo = jsob.getBoolean("success");
					Message msg = new Message();
					msg.obj = bo;
					msg.what = 2;
					mHandler.sendMessage(msg);
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}.start();
	}
	
	private String getTimeStamp() {
//		long time = System.currentTimeMillis() / 1000;
		long time = System.currentTimeMillis();
		SimpleDateFormat format=new SimpleDateFormat("yyyyMMddHHmmss");  
        Date d1=new Date(time);  
        String t1=format.format(d1);
        int i=(int)(Math.random()*900)+100; 
		String t2 = String.valueOf(i);
		String timeStamp = t1+t2;
		return timeStamp;
	}
	
	Handler mHandler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			boolean bo = (Boolean) msg.obj;
			switch (msg.what) {
			case 1:
				if(bo) {
					doPostSfzm();
				}else {
					dialog.dismiss();
					showTipsDialog("提交失败", AddParkingActivity.this);
					btnSubmit.setClickable(true);
				}
				break;
			case 2:
				dialog.dismiss();
				if(bo) {
					doAddParking();
				}else {
					showTipsDialog("提交失败", AddParkingActivity.this);
					btnSubmit.setClickable(true);
				}
				break;
			case 3:
				setSpinner();
				break;
			case 4:
				setDiscSpinner();
				break;
			}

		};
	};
	
	private void getCity() {
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("method", "201301");

		HttpUtils http = new HttpUtils(6000);
		http.send(HttpMethod.POST, 
				ServerURL, 
				params,
				new RequestCallBack<String>() {

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// TODO Auto-generated method stub
							Log.i(TAG, "getCity: "+responseInfo.result);
							String result = responseInfo.result;
							List<String> data = new ArrayList<String>();
							try {
								JSONObject jsob = new JSONObject(result);
								int count = jsob.getInt("totalCount");
								if(count != 0) {
									JSONArray jsoa = jsob.getJSONArray("data");
									for(int i=0; i< count; i++) {
										JSONObject jso = jsoa.getJSONObject(i);
										data.add(jso.getString("city_name"));
										CityInfo info = new CityInfo();
										info.setCityName(jso.getString("city_name"));
										info.setCityCode(jso.getString("city_code"));
										cityInfos.add(info);
										if(curCity != null && curCity != "") {
											if(curCity.contains(jso.getString("city_name"))) {
												spIndex = i;
												Log.i(TAG, "AddParkingActivity getCity : " + curCity + "  " + jso.getString("city_name"));
											}
										}
									}
								}else {
									data.add(curCity);
								}
								dataCity = data;							
								Message msg = new Message();
								msg.what = 3;
								msg.obj = true;
								mHandler.sendMessage(msg);
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
					}

					@Override
					public void onFailure(HttpException error, String msg) {
						// TODO Auto-generated method stub
						if(curShowView.equals("getCity")) {
							if(dataCity == null || dataCity.size() == 0) {
								dataCity.add(curCity);
							}
						}
					}
		});
	}
	
	private void getDistrict(String cityCode) {
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("method", "201302");
		params.addBodyParameter("city_code", cityCode);

		HttpUtils http = new HttpUtils(6000);
		http.send(HttpMethod.POST, 
				ServerURL, 
				params,
				new RequestCallBack<String>() {

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// TODO Auto-generated method stub
							String result = responseInfo.result;
							List<String> data = new ArrayList<String>();
							try {
								JSONObject jsob = new JSONObject(result);
								int count = jsob.getInt("totalCount");
								if(count != 0) {
									JSONArray jsoa = jsob.getJSONArray("data");
									for(int i=0; i< count; i++) {
										JSONObject jso = jsoa.getJSONObject(i);
										data.add(jso.getString("district"));
									}
								}else {
									data.add(curDistrit);
								}
								dataDistrict = data;							
								Message msg = new Message();
								msg.what = 4;
								msg.obj = true;
								mHandler.sendMessage(msg);
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						
					}

					@Override
					public void onFailure(HttpException error, String msg) {
						// TODO Auto-generated method stub
//						if
						if(dataDistrict == null || dataDistrict.size() == 0) {
							dataDistrict.add(curDistrit);
						}
					}
		});
	}
	
}
