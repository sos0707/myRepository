package com.sendi.lhparking.ui.wuye;

import org.sendi.parking.ui.R;

import com.sendi.lhparking.ui.common.BaseActivity;
import com.sendi.lhparking.util.AddParkingHistoryInfo;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
/**
 * 小区加盟记录界面
 * @author Administrator
 *
 */
public class ViewAddParkingHistoryActivity extends BaseActivity {

	private TextView tvParkingName, tvCity, tvDistrict, tvAddress, tvNumberField, tvChargeUnit, tvInchargeName,
	tvPhnoeNumber, tvMobileNumber, tvAddState;
	
	private AddParkingHistoryInfo info;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_addparkinghistoryinfo);
		
		info = getIntent().getParcelableExtra("ParkingHistoryInfo");
		init();
	}
	
	private void init() {
		TextView tvTitle = (TextView) this.findViewById(R.id.topbar_center_btn);
		TextView tvReturn = (TextView) this.findViewById(R.id.topbar_left_btn);
		tvTitle.setText("新增记录");
		tvReturn.setVisibility(View.VISIBLE);
		tvReturn.setText("  返 回");
		
		tvReturn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				hideKeyborad();
				ViewAddParkingHistoryActivity.this.finish();
			}
		});		
		
		tvParkingName = (TextView) this.findViewById(R.id.tvParkingname);
		tvCity = (TextView) this.findViewById(R.id.tvCity);
		tvDistrict = (TextView) this.findViewById(R.id.tvDistrict);
		tvAddress = (TextView) this.findViewById(R.id.tvAddress);
		tvNumberField = (TextView) this.findViewById(R.id.tvNumberfield);
		tvChargeUnit = (TextView) this.findViewById(R.id.tvChargeunit);
		tvInchargeName = (TextView) this.findViewById(R.id.tvInchargename);
		tvPhnoeNumber = (TextView) this.findViewById(R.id.tvInchargephonenum);
		tvMobileNumber = (TextView) this.findViewById(R.id.tvInchargeMobilenum);
		tvAddState = (TextView) this.findViewById(R.id.tvAddstate);
		
		tvAddState.setText("状态："+info.getState());
		tvParkingName.setText(info.getParkingName());
		tvCity.setText(info.getCity());
		tvDistrict.setText(info.getDistrict());
		tvAddress.setText(info.getAddress());
		tvNumberField.setText(info.getNumberField());
		tvChargeUnit.setText(info.getChargeUnit());
		tvInchargeName.setText(info.getInchargeName());
		tvPhnoeNumber.setText(info.getPhoneNumber());
		tvMobileNumber.setText(info.getMobileNumber());
	}
}
