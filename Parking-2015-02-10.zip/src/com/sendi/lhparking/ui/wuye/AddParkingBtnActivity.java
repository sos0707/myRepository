package com.sendi.lhparking.ui.wuye;

import org.sendi.parking.ui.R;

import com.sendi.lhparking.ui.common.BaseActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
/**
 * 小区加盟
 * @author Administrator
 *
 */
public class AddParkingBtnActivity extends BaseActivity {

	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		showAddparkingBtn();
	}

	private void showAddparkingBtn() {
		setContentView(R.layout.view_twobtn);
		TextView tvTitle = (TextView) this.findViewById(R.id.topbar_center_btn);
		TextView tvReturn = (TextView) this.findViewById(R.id.topbar_left_btn);
		tvTitle.setText("新增小区");
		tvReturn.setVisibility(View.VISIBLE);
		tvReturn.setText("  返 回");
		tvReturn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				hideKeyborad();
				AddParkingBtnActivity.this.finish();
			}
		});
		
		Button btnHistory = (Button) this.findViewById(R.id.btnAddhitory);
		Button btnAdd = (Button) this.findViewById(R.id.btnAddparking);
		
		btnAdd.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(AddParkingBtnActivity.this, AddParkingActivity.class);
				startActivity(intent);
			}
		});
		
		btnHistory.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(AddParkingBtnActivity.this, AddParkingHistoryActivity.class);
				startActivity(intent);
			}
		});
	}
}
