package com.sendi.lhparking.ui.wuye;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.sendi.parking.ui.R;

import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.sendi.lhparking.adapter.AddParkingHistoryListAdapter;
import com.sendi.lhparking.adapter.ParkingDetailListAdapter;
import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.ui.common.BaseActivity;
import com.sendi.lhparking.util.AddParkingHistoryInfo;
import com.sendi.lhparking.util.ParkingDetailInfo;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnDismissListener;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class AddParkingHistoryActivity extends BaseActivity {

	private ProgressDialog mDialog;
	private String curShowView = "0";
	private int dialogDismiss = 0;
	private LinearLayout layoutShowNull;
	private ListView lvAddparkingHistory;
	private List<AddParkingHistoryInfo> mAddHistoryInfos = null;
	private Button btnJoinus;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.view_addparkinghistory);
		ParkingApp.mAppCtx.setAddHandler(mHandler);
		init();
		boolean bo = isNetConnected();
		if(bo) {
			doGetAddparkingHistory();
		}else {
			Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
		}
	}
	
	private void init() {
		TextView tvTitle = (TextView) this.findViewById(R.id.topbar_center_btn);
		TextView tvReturn = (TextView) this.findViewById(R.id.topbar_left_btn);
		tvTitle.setText("小区加盟");
		tvReturn.setVisibility(View.VISIBLE);
		tvReturn.setText("  返 回");
		
		tvReturn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				hideKeyborad();
				AddParkingHistoryActivity.this.finish();
			}
		});			
		
		btnJoinus = (Button) this.findViewById(R.id.btnJoinus);
		layoutShowNull = (LinearLayout) this.findViewById(R.id.layoutAddshownull);
		lvAddparkingHistory = (ListView) this.findViewById(R.id.lvAddhistory);
		
		btnJoinus.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(AddParkingHistoryActivity.this, AddParkingActivity.class);
				startActivity(intent);
			}
		});
		
	}
	
	private void doGetAddparkingHistory() {
		curShowView = "GetAddparkHistory";
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
//		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("method", "2026");

		HttpUtils http = new HttpUtils(6000);
		showProgDialog("正在查询申请加盟记录 . . . ", http);
		http.send(HttpMethod.POST, 
				ServerURL, 
				params,
				new RequestCallBack<String>() {

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// TODO Auto-generated method stub
						if(curShowView.equals("GetAddparkHistory")) {
							Log.i(TAG, "addparking history : "+ responseInfo.result);
							try {
								JSONObject jsob = new JSONObject(responseInfo.result);
								int count = jsob.getInt("totalCount");
								JSONArray jsoa = jsob.getJSONArray("data");
								mAddHistoryInfos = new ArrayList<AddParkingHistoryInfo>();
								for(int i=0; i< count; i++) {	
//									parkingName：小区名字  city //所属市  district：区 address：详细地址
//									numberField：车位数 chargeUnit：物业公司  inchargeName：姓名  phoneNumber：联系电话 mobileNumber：手机
									AddParkingHistoryInfo info = new AddParkingHistoryInfo();
									JSONObject jso = jsoa.getJSONObject(i);
									info.setParkingName(jso.getString("parkingName"));
									info.setCity(jso.getString("city"));
									info.setDistrict(jso.getString("district"));
									info.setAddress(jso.getString("address"));
									info.setNumberField(jso.getString("numberField"));
									info.setChargeUnit(jso.getString("chargeUnit"));
									info.setInchargeName(jso.getString("inchargeName"));
									info.setPhoneNumber(jso.getString("phoneNumber"));
									info.setMobileNumber(jso.getString("mobileNumber"));
									info.setState(jso.getString("state"));
									mAddHistoryInfos.add(info);
								}
								if(mAddHistoryInfos != null && mAddHistoryInfos.size() != 0 ) {
									showAddHistory();
								}
								if(mDialog != null) {
									dialogDismiss = 1;
									mDialog.dismiss();
								}							
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					}

					@Override
					public void onFailure(HttpException error, String msg) {
						// TODO Auto-generated method stub
						if(curShowView.equals("GetAddparkHistory")) {
							showTipsDialog("查询失败，请检查网络，稍后再试 ", AddParkingHistoryActivity.this);
						}
						if(mDialog != null) {
							dialogDismiss = 1;
							mDialog.dismiss();
						}	
					}
		});
	
	}
	
	private void showAddHistory() {
		layoutShowNull.setVisibility(View.GONE);
		lvAddparkingHistory.setVisibility(View.VISIBLE);
		AddParkingHistoryListAdapter adapter = new AddParkingHistoryListAdapter(this, mAddHistoryInfos);
		lvAddparkingHistory.setAdapter(adapter);
		
		lvAddparkingHistory.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position,
					long arg3) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(AddParkingHistoryActivity.this, ViewAddParkingHistoryActivity.class);
				Bundle bundle = new Bundle();
				bundle.putParcelable("ParkingHistoryInfo", mAddHistoryInfos.get(position));
				intent.putExtras(bundle);
				startActivity(intent);
			}
		});	
	}
	
	private void showProgDialog(final String msg, final HttpUtils httpUtils) {
		mDialog = new ProgressDialog(this);
		mDialog.setCanceledOnTouchOutside(false);
		mDialog.setOnDismissListener(new OnDismissListener() {
			
			@Override
			public void onDismiss(DialogInterface dialog) {
				// TODO Auto-generated method stub
				if(dialogDismiss == 0 ) {
					httpUtils.getHttpClient().getConnectionManager().closeExpiredConnections();
//					httpUtils.getHttpClient().getConnectionManager().shutdown();
				}
				dialogDismiss = 0;
				curShowView = "0";
				Log.i(TAG, "dialog dismiss : "+msg);
			}
		});
		mDialog.setMessage(msg);
		mDialog.show();
	}
	
	Handler mHandler = new Handler(){

		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			switch(msg.what) {
			case 1:
				String strMsg = (String) msg.obj;
				showTipsDialog( strMsg, AddParkingHistoryActivity.this);
				init();
				doGetAddparkingHistory();
				break;
			}
		}
		
	};
}
