package com.sendi.lhparking.ui.chezhu;

import java.sql.Date;
import java.text.SimpleDateFormat;

import org.sendi.parking.ui.R;

import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.payutil.AliPayUtil;
import com.sendi.lhparking.ui.common.BaseActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupWindow;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView.OnEditorActionListener;
/**
 * 充值界面
 * @author Administrator
 *
 */
public class PayActivity extends BaseActivity {
	private String payMoney = "0";
	private int paytype = 0;
	private PopupWindow pwPayment;
	private String outTradeNo;
	private int layoutNo = 0;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);

		showPayView();
	}
	
	/** 
	 * 充值界面（输入金额）
	 * */
	private void showPayView() {
		layoutNo = 0;
		payMoney = "0";
		setContentView(R.layout.view_pay1);
		final EditText edMoney = (EditText) this.findViewById(R.id.edMoney);
		final Button btnDel = (Button) this.findViewById(R.id.btnDel);
		final Button btnNext = (Button) this.findViewById(R.id.btnNext);
		TextView tvReturn = (TextView) this.findViewById(R.id.topbar_left_btn);
		TextView tvTitle = (TextView) this.findViewById(R.id.topbar_center_btn);
		edMoney.setInputType(EditorInfo.TYPE_CLASS_PHONE);
		tvReturn.setText("  返 回");
		tvReturn.setVisibility(View.VISIBLE);
		tvTitle.setText("浪花停车充值");
		
		edMoney.addTextChangedListener(new TextWatcher() {
			
			@Override
			public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void beforeTextChanged(CharSequence arg0, int arg1, int arg2,
					int arg3) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void afterTextChanged(Editable arg0) {
				// TODO Auto-generated method stub
//				if( edMoney.getText().length() != 0) {
//					btnDel.setVisibility(View.VISIBLE);
//					int i = Integer.valueOf( edMoney.getText().toString() );
//					if( i > 500 ) {
//						edMoney.setText("500");
//					}
//				}else {
//					btnDel.setVisibility(View.GONE);
//				}
			}
		});
		
		btnDel.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				edMoney.setText("");
			}
		});
		
		btnNext.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
//				int i = 0;
				double i = 0;
				if(edMoney.getText().length() != 0) {
					i = Double.valueOf( edMoney.getText().toString() );
					
				}
				if( i <= 0 ) {
					edMoney.setText("0.01");
					showTipsDialog("充值金额最少为 10 ", PayActivity.this);
					return;
				}
//				int m = Integer.valueOf(edMoney.getText().toString());
				double m = Double.valueOf(edMoney.getText().toString());

				payMoney = String.valueOf(m);
				hideKeyborad();
				showNextPayView(payMoney);
			}
		});
		
		tvReturn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				hideKeyborad();
				PayActivity.this.finish();
			}
		});
		
		edMoney.setOnEditorActionListener(new OnEditorActionListener() {
			
			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				// TODO Auto-generated method stub
				switch(actionId) {
				case EditorInfo.IME_ACTION_DONE:
					btnNext.performClick();
					break;
				}
				return false;
			}
		});
	}
	
	/** 
	 * 充值界面（支付方式）
	 * */
	private void showNextPayView(String money) {
		layoutNo = 1;
		paytype = 0;
		setContentView(R.layout.view_pay2);
		TextView tvPayMoney = (TextView) this.findViewById(R.id.tvPayMoney);
		TextView tvReturn = (TextView) this.findViewById(R.id.topbar_left_btn);
		TextView tvTitle = (TextView)this.findViewById(R.id.topbar_center_btn);
		Button btnNext = (Button) this.findViewById(R.id.btnNext);
		TextView tvWX = (TextView) this.findViewById(R.id.tvWX);
		TextView tvAli = (TextView) this.findViewById(R.id.tvAli);
		final RadioButton rbwx = (RadioButton) this.findViewById(R.id.rbWX);
		final RadioButton rbali = (RadioButton) this.findViewById(R.id.rbALI);
		
		tvPayMoney.setText("充值金额（元）: "+money);
		tvReturn.setText("  返 回");
		tvReturn.setVisibility(View.VISIBLE);
		tvTitle.setText("浪花停车充值");
		
		rbwx.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				rbali.setChecked(false);
				paytype = 1;
			}
		});
		tvWX.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				rbwx.setChecked(true);
				rbali.setChecked(false);
				paytype = 1;
			}
		});
		
		rbali.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				rbwx.setChecked(false);
				paytype = 2;
			}
		});
		tvAli.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				rbali.setChecked(true);
				rbwx.setChecked(false);
				paytype = 2;
			}
		});
		
		tvReturn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				hideKeyborad();
				showPayView();
			}
		});
		
		btnNext.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if(paytype == 0) {
					showTipsDialog("请选择充值方式", PayActivity.this);
					return;
				}
//				showPowPayment();
				showDialogPayment();
			}
		});
		
	}
	
	/** 
	 * 充值订单界面
	 * */
	private void showPowPayment() {
//		payMoney  = "0.01";
		View v = LayoutInflater.from(PayActivity.this).inflate(R.layout.popw_payment, null);
		v.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
		
		Button btnReturn = (Button) v.findViewById(R.id.btnreturn);
		Button btnCancel = (Button) v.findViewById(R.id.btnCancel);
		Button btnPay = (Button) v.findViewById(R.id.btnPay);
		TextView tvTitle = (TextView) v.findViewById(R.id.tvTitle);
		TextView tvPayMoney = (TextView) v.findViewById(R.id.tvPayMoney);
		TextView tvOutTradeNo = (TextView) v.findViewById(R.id.tvOutTradeNo);
		
		if(paytype == 1) {
			tvTitle.setText("微信支付支付订单");
		}else {
			tvTitle.setText("支付宝支付订单");
		}
		
		outTradeNo = getOutTradeNo();
		
		tvOutTradeNo.setText(outTradeNo);
		tvPayMoney.setText(payMoney);
		
		btnPay.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				switch(paytype) {
				case 1:	
					ParkingApp.mAppCtx.setPayHandler(ParkingApp.payHandler);
					Intent intent = new Intent(PayActivity.this, org.sendi.parking.ui.wxapi.PayActivity.class);
					Bundle bundle = new Bundle();
					bundle.putString("payMoney", payMoney);
					bundle.putString("outTradeNo", outTradeNo);
					intent.putExtras(bundle);
					startActivity(intent);
					break;
				case 2:
					AliPayUtil alipay = new AliPayUtil(PayActivity.this, ParkingApp.payHandler);
					alipay.doAliPay("浪花停车充值", payMoney, outTradeNo);
					break;
				default:
					break;
				}
				pwPayment.dismiss();
//				PayActivity.this.finish();
			}
		});
		
		btnReturn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				pwPayment.dismiss();
			}
		});
		btnCancel.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				pwPayment.dismiss();
			}
		});
		pwPayment = new PopupWindow(v, LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
//		pwPayment.setBackgroundDrawable(new PaintDrawable(0x00000000));  0x7DC0C0C0
		pwPayment.setOutsideTouchable(false);
		pwPayment.setFocusable(true);
		pwPayment.showAtLocation(v, Gravity.CENTER, 0, 0);
	}
	
	private void showDialogPayment() {
		View v = LayoutInflater.from(PayActivity.this).inflate(R.layout.dialog_payment, null);
		final AlertDialog.Builder builder = new AlertDialog.Builder(this);

		if(paytype == 1) {
			builder.setTitle("微信支付支付订单");
		}else {
			builder.setTitle("支付宝支付订单");
		}
		builder.setCancelable(false);
		builder.setView(v);
//		builder.setCancelable(true);
		final AlertDialog pdialog = builder.show(); 
		
		Button btnCancel = (Button) v.findViewById(R.id.btnCancel);
		Button btnPay = (Button) v.findViewById(R.id.btnPay);
		TextView tvPayMoney = (TextView) v.findViewById(R.id.tvPayMoney);
		TextView tvOutTradeNo = (TextView) v.findViewById(R.id.tvOutTradeNo);
		
		outTradeNo = getOutTradeNo();
		
		tvOutTradeNo.setText(outTradeNo);
		tvPayMoney.setText(payMoney);
		
		btnPay.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				switch(paytype) {
				case 1:	
					ParkingApp.mAppCtx.setPayHandler(ParkingApp.payHandler);
					Intent intent = new Intent(PayActivity.this, org.sendi.parking.ui.wxapi.PayActivity.class);
					Bundle bundle = new Bundle();
					bundle.putString("payMoney", payMoney);
					bundle.putString("outTradeNo", outTradeNo);
					intent.putExtras(bundle);
					startActivity(intent);
					break;
				case 2:
					AliPayUtil alipay = new AliPayUtil(PayActivity.this, ParkingApp.payHandler);
					alipay.doAliPay("浪花停车充值", payMoney, outTradeNo);
					break;
				default:
					break;
				}
				pdialog.dismiss();			}
		});
		
		btnCancel.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				pdialog.dismiss();			}
		});
		
		
		
//		builder.create().show();
	}
	
	/** 
	 * 生成支付订单号
	 * */
	private String getOutTradeNo() {
		long time = System.currentTimeMillis();
		SimpleDateFormat format=new SimpleDateFormat("yyyyMMddHHmmss");  
        Date d1=new Date(time);  
        String t1=format.format(d1);
		return ParkingApp.mAppCtx.getUID() + "_" + t1;
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		if(keyCode == KeyEvent.KEYCODE_BACK) {
			switch (layoutNo) {
			case 0:
				PayActivity.this.finish();
				break;
			case 1:
				showPayView();
				break;
			default:
				break;
			}
			return false;
		}
		return super.onKeyDown(keyCode, event);
	}
	
	
}
