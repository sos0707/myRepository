package com.sendi.lhparking.ui.chezhu;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.JSONException;
import org.json.JSONObject;
import org.sendi.parking.ui.R;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnDismissListener;
import android.os.Bundle;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.ui.common.BaseActivity;
import com.sendi.lhparking.ui.common.LoginActivity;
import com.sendi.lhparking.util.ParkingDetailInfo;
import com.sendi.lhparking.util.ParkingPrefs;

public class FastParkingActivity extends BaseActivity {

	private TextView tvName, tvReturn;
	private TextView tvPname, tvPno, tvPrice, tvPtime, tvRange, tvUsecount;
	private Button btnReserve;
	private EditText edtCarno;
	private String curCarno;
	private String parkTime = "2";
	private String parkNo, parkName, price, timeRange, taskId;
	private int num = 0;
	private ProgressDialog mDialog;
	private String curShowView = "0";
	private int dialogDismiss = 0;
	private boolean carInParkDefault;
	private String id, orderId;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_fastparking);
		parkTime = this.getIntent().getStringExtra("parkTime");
		parkName = this.getIntent().getStringExtra("parkName");
		parkNo = this.getIntent().getStringExtra("parkNo");
		price = this.getIntent().getStringExtra("price");
		timeRange = this.getIntent().getStringExtra("timeRange");
		taskId = this.getIntent().getStringExtra("taskId");
		num = this.getIntent().getIntExtra("num", 0);
		carInParkDefault = this.getIntent().getBooleanExtra("carinparkdefault", false);
		if(carInParkDefault) {
			id = this.getIntent().getStringExtra("id");
			orderId = this.getIntent().getStringExtra("orderid");
		}
		init();
	}
	
	private void init() {
		tvName = (TextView) this.findViewById(R.id.topbar_center_btn);
		tvReturn = (TextView) this.findViewById(R.id.topbar_left_btn);
		tvPname = (TextView) this.findViewById(R.id.tvParkName);
		tvPno = (TextView) this.findViewById(R.id.tvParkno2);
		tvPrice = (TextView) this.findViewById(R.id.tvPrice2);
		tvRange = (TextView) this.findViewById(R.id.tvParkrate);
		tvPtime = (TextView) this.findViewById(R.id.tvParktime);
		edtCarno = (EditText) this.findViewById(R.id.edtCarno2);
		tvUsecount = (TextView) this.findViewById(R.id.tv_usedcount);
		btnReserve = (Button) this.findViewById(R.id.btnReserve);
				
		curCarno = ParkingPrefs.getStrValue("last_carno");
		if(curCarno != null) {
			edtCarno.setText(curCarno);
		}
		tvPtime.setText(parkTime+" 小时");
		tvPname.setText(parkName);
		tvPno.setText(parkNo);
		tvPrice.setText(price + " 元/小时");
		tvRange.setText(timeRange);
		tvUsecount.setText("小区当前可用车位数 : "+String.valueOf(num));
		
		tvName.setText("快 速 停 车");
		tvReturn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				FastParkingActivity.this.finish();
			}
		});
	}
	
	public void onReserve(View v) {
		btnReserve.setClickable(false);
		if(ParkingApp.mAppCtx.isNeedLogin()){
			startActivity(new Intent(this, LoginActivity.class));
			btnReserve.setClickable(true);
			return ;
		}
		curCarno = edtCarno.getText().toString();
		if(curCarno == null || curCarno.length() == 0) {
			showTipsDialog("请输入车牌号码");
			btnReserve.setClickable(true);
			return;
		}
	
		String check = "^[\u4e00-\u9fa5]{1}[A-Z]{1}[A-Z_0-9]{5}$";
		Pattern pt = Pattern.compile(check);
		Matcher matcher = pt.matcher(curCarno);
		if(!matcher.matches()) {
			showTipsDialog("输入的车牌号码格式不正确（例：粤AXXXXX）");
			btnReserve.setClickable(true);
			return;
		}
		if(carInParkDefault) {
			doReserve();
		}else {
			doReserve();
		}
		ParkingPrefs.setStrValue("last_carno", curCarno);
	
	}
	
	public void onCancel(View v) {
		FastParkingActivity.this.finish();
	}
	
	//返回并刷新车位列表
	public void onNext(View v) {
		Message handlermsg = new Message();
		Message mapMsg = new Message();
		handlermsg.what = 0;
		mapMsg.what = 1;
		ParkingApp.appHandler.sendMessage(handlermsg);
		ParkingApp.mapHandler.sendMessage(mapMsg);
        FastParkingActivity.this.finish();
	}
	

	private void doReserve() {
		curShowView = "doReserve";
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("method", "2032");  //2005
		params.addBodyParameter("car_no", curCarno);
		params.addBodyParameter("task_id", taskId);
		params.addBodyParameter("hour", parkTime);
		
		Log.i("TEST", "POST URL : " + ServerURL+"?uid="+ParkingApp.mAppCtx.getUID()+"&utype="+ParkingApp.mAppCtx.getUType()
				+"&method=2032"
				+"&task_id="+taskId
				+"&hour="+parkTime
				+"&car_no"+curCarno);
		
		HttpUtils http = new HttpUtils(6000);
		showProgDialog("正在进行车位预约...", http);
		http.send(HttpMethod.POST, 
				ServerURL, 
				params,
				new RequestCallBack<String>() {

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// TODO Auto-generated method stub
						Log.i("TEST", "FastParking doReserve : " + responseInfo.result);
						if(curShowView.equals("doReserve")) {
							String result = responseInfo.result;
							boolean success = false;
							String msg = null;
							
							if(mDialog != null) {
								dialogDismiss = 1;
								mDialog.dismiss();
							}
							try {
								JSONObject jsob = new JSONObject(result);
								success = jsob.getBoolean("success");
								msg = jsob.getString("msg");
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							
							if(success) {
					            Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
								Message handlermsg = new Message();
								Message mapMsg = new Message();
								handlermsg.what = 0;
								mapMsg.what = 0;
								mapMsg.obj = taskId;
								ParkingApp.appHandler.sendMessage(handlermsg);
								ParkingApp.mapHandler.sendMessage(mapMsg);
					            FastParkingActivity.this.finish();

							}else {
								showTipsDialog("预约失败："+ msg);
							}
						}
						
					}

					@Override
					public void onFailure(HttpException error, String msg) {
						// TODO Auto-generated method stub
						if(curShowView.equals("doReserve")) {
							showTipsDialog("预约失败，请稍后再试");
						}
						if(mDialog != null) {
							dialogDismiss = 1;
							mDialog.dismiss();
						}
						
					}
				} );
	
	
	}
	
	private void showProgDialog(final String msg, final HttpUtils httpUtils) {
		mDialog = new ProgressDialog(this);
		mDialog.setCanceledOnTouchOutside(false);
		mDialog.setOnDismissListener(new OnDismissListener() {
			
			@Override
			public void onDismiss(DialogInterface dialog) {
				// TODO Auto-generated method stub
				btnReserve.setClickable(true);
				if(dialogDismiss == 0 ) {
					httpUtils.getHttpClient().getConnectionManager().closeExpiredConnections();
//					httpUtils.getHttpClient().getConnectionManager().shutdown();
				}
				dialogDismiss = 0;
				curShowView = "0";
				Log.i(TAG, "dialog dismiss : "+msg);
			}
		});
		mDialog.setMessage(msg);
		mDialog.show();
	}
	
	private void showTipsDialog(String msg){  
        AlertDialog dialog;  
        AlertDialog.Builder builder = new AlertDialog.Builder(FastParkingActivity.this);  
        builder.setTitle("消息").setIcon(android.R.drawable.stat_notify_error);  
        builder.setMessage(msg);  
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener(){  
            @Override 
            public void onClick(DialogInterface dialog, int which) {  
                // TODO Auto-generated method stub  
                  
            }                     
        });  
        dialog = builder.create();  
        dialog.show();  
    }  
	
	private void doCarOutScan(String orderid, String taskid) {
		
	}
	
}
