package com.sendi.lhparking.ui.chezhu;

import org.sendi.parking.ui.R;

import com.baidu.lbsapi.BMapManager;
import com.baidu.lbsapi.panoramaview.PanoramaView;
import com.baidu.lbsapi.panoramaview.PanoramaViewListener;
import com.sendi.lhparking.ctx.ParkingApp;

import android.app.Activity;
import android.os.Bundle;

public class PanoramaActivity extends Activity implements PanoramaViewListener {

	private PanoramaView mPanoView;
	private double lon;
	private double lat;
	
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_panorama);
		
		ParkingApp app = (ParkingApp) this.getApplication();
		if (app.mBMapManager == null) {  
		    app.mBMapManager = new BMapManager(app);  
		 
		    app.mBMapManager.init(new ParkingApp.MyGeneralListener());  
		} 
		
		lon = this.getIntent().getDoubleExtra("lon", 116.404);
		lat = this.getIntent().getDoubleExtra("lat", 39.945);
				
		mPanoView = (PanoramaView) this.findViewById(R.id.panorama);
		// 全景图清晰度  1-5  5最清晰
		mPanoView.setPanoramaImageLevel(4);  
		mPanoView.setPanoramaViewListener(this);
		//是否显示指示邻接街景的箭头
		mPanoView.setShowTopoLink(true);
		//设置是否允许缩放手势
        mPanoView.setZoomGestureEnabled(true);
        //设置是否允许旋转手势
        mPanoView.setRotateGestureEnabled(true);
        //根据经纬度设置街景点
		mPanoView.setPanorama(lon, lat);
//		mPanoView.setPanorama(116.404, 39.945);

//		initView();
	}

	private void initView() {
		
	}

	private void show() {
		mPanoView.setPanorama(lon, lat);
//		mPanoView.setPanorama("0100220000130817164838355J5");   // 根据pid设置街景点
	}
	
	@Override
	public void onLoadPanoramBegin() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onLoadPanoramaEnd() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onLoadPanoramaError() {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		mPanoView.destroy();
		super.onDestroy();
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		mPanoView.onPause();
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		mPanoView.onResume();
	}
	
	
}
