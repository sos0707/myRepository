package com.sendi.lhparking.ui.chezhu;

import java.util.ArrayList;
import java.util.List;

import org.sendi.parking.ui.R;

import com.sendi.lhparking.ui.common.BaseActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
/**
 * 转账界面
 * @author Administrator
 *
 */
public class TransferAccountActivity extends BaseActivity {

	private Button btnZFB, btnCFT, btnBank;
	private String maxMoney;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_transferaccount);
		
		maxMoney = this.getIntent().getStringExtra("maxMoney");
		init();
	}
	
	@SuppressLint("NewApi")
	private void init() {
		btnZFB = (Button) this.findViewById(R.id.btnZFB);
		btnCFT = (Button) this.findViewById(R.id.btnCFT);
		btnBank = (Button) this.findViewById(R.id.btnBank);
		
		TextView tvTitle = (TextView) this.findViewById(R.id.topbar_center_btn);
		TextView tvReturn = (TextView) this.findViewById(R.id.topbar_left_btn);
		
		tvTitle.setText("转    出");
		tvReturn.setVisibility(View.VISIBLE);
		tvReturn.setText("  返 回");
		
		tvReturn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				TransferAccountActivity.this.finish();
			}
		});
		
		btnZFB.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(TransferAccountActivity.this, Transfer2ZfbActivity.class);
				intent.putExtra("maxMoney", maxMoney);
				startActivityForResult(intent, 1);
			}
		});
		
		btnCFT.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(TransferAccountActivity.this, Transfer2CftActivity.class);
				intent.putExtra("maxMoney", maxMoney);
				startActivityForResult(intent, 1);
			}
		});
		
		btnBank.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(TransferAccountActivity.this, Transfer2BankActivity.class);
				intent.putExtra("maxMoney", maxMoney);
//				startActivity(intent);
				startActivityForResult(intent, 1);
			}
		});
		
	}

	@Override
	protected void onActivityResult(int arg0, int arg1, Intent arg2) {
		// TODO Auto-generated method stub
		if(arg1 == 1) {
			this.finish();
		}
		super.onActivityResult(arg0, arg1, arg2);
	}
	
	
}
