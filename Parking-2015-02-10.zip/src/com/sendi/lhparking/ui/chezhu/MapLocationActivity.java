package com.sendi.lhparking.ui.chezhu;

import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.zip.DataFormatException;

import org.apache.http.NameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


import org.sendi.parking.ui.R;

import com.ab.util.AbStrUtil;
import com.ab.view.pullview.AbPullToRefreshView;
import com.ab.view.pullview.AbPullToRefreshView.OnHeaderRefreshListener;
import com.baidu.lbsapi.BMapManager;
import com.baidu.lbsapi.auth.LBSAuthManagerListener;
import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;
import com.baidu.mapapi.SDKInitializer;
import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.BaiduMap.OnMapStatusChangeListener;
import com.baidu.mapapi.map.BaiduMap.OnMarkerClickListener;
import com.baidu.mapapi.map.BaiduMapOptions;
import com.baidu.mapapi.map.BitmapDescriptor;
import com.baidu.mapapi.map.BitmapDescriptorFactory;
import com.baidu.mapapi.map.InfoWindow;
import com.baidu.mapapi.map.MapStatus;
import com.baidu.mapapi.map.MapStatusUpdate;
import com.baidu.mapapi.map.MapStatusUpdateFactory;
import com.baidu.mapapi.map.MapView;
import com.baidu.mapapi.map.Marker;
import com.baidu.mapapi.map.MarkerOptions;
import com.baidu.mapapi.map.MyLocationConfiguration;
import com.baidu.mapapi.map.MyLocationConfiguration.LocationMode;
import com.baidu.mapapi.map.MyLocationData;
import com.baidu.mapapi.map.InfoWindow.OnInfoWindowClickListener;
import com.baidu.mapapi.map.OverlayOptions;
import com.baidu.mapapi.model.LatLng;
import com.baidu.mapapi.overlayutil.PoiOverlay;
import com.baidu.mapapi.search.core.PoiInfo;
import com.baidu.mapapi.search.core.SearchResult;
import com.baidu.mapapi.search.geocode.GeoCodeResult;
import com.baidu.mapapi.search.geocode.GeoCoder;
import com.baidu.mapapi.search.geocode.OnGetGeoCoderResultListener;
import com.baidu.mapapi.search.geocode.ReverseGeoCodeOption;
import com.baidu.mapapi.search.geocode.ReverseGeoCodeResult;
import com.baidu.mapapi.search.poi.OnGetPoiSearchResultListener;
import com.baidu.mapapi.search.poi.PoiCitySearchOption;
import com.baidu.mapapi.search.poi.PoiDetailResult;
import com.baidu.mapapi.search.poi.PoiDetailSearchOption;
import com.baidu.mapapi.search.poi.PoiResult;
import com.baidu.mapapi.search.poi.PoiSearch;
import com.baidu.mapapi.utils.DistanceUtil;
import com.baidu.navisdk.BNaviPoint;
import com.baidu.navisdk.BaiduNaviManager;
import com.baidu.navisdk.BNaviEngineManager.NaviEngineInitListener;
import com.baidu.navisdk.BaiduNaviManager.OnStartNavigationListener;
import com.baidu.navisdk.comapi.routeplan.RoutePlanParams.NE_RoutePlan_Mode;
import com.fourmob.datetimepicker.date.DatePickerDialog;
import com.fourmob.datetimepicker.date.DatePickerDialog.OnDateSetListener;
import com.google.gson.Gson;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.sendi.lhparking.adapter.FastParkDetaiListAdapter;
import com.sendi.lhparking.adapter.FastParkInfoListAdapter;
import com.sendi.lhparking.adapter.FindinfoAdapter;
import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.ctx.ParkingConstant;
import com.sendi.lhparking.func.barcode.main.CaptureActivity;
import com.sendi.lhparking.model.CarInTime;
import com.sendi.lhparking.model.FastParkDetailInfo;
import com.sendi.lhparking.model.FastParkInfo;
import com.sendi.lhparking.model.OrderViewModel;
import com.sendi.lhparking.model.ScanTask;
import com.sendi.lhparking.server.IServer;
import com.sendi.lhparking.ui.common.BaseActivity;
import com.sendi.lhparking.ui.common.ViewOrderHistoryActivity;
import com.sendi.lhparking.ui.wuye.AddParkingActivity;
import com.sendi.lhparking.util.CityInfo;
import com.sendi.lhparking.util.ParkInfo;
import com.sendi.lhparking.util.ParkingDetailInfo;
import com.sendi.lhparking.util.SysUtils;
import com.sendi.lhparking.view.AbObjectWheelAdapter;
import com.sendi.lhparking.view.AbWheelView;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.app.ProgressDialog;
import android.app.Fragment.SavedState;
import android.app.FragmentManager.BackStackEntry;
import android.app.FragmentManager.OnBackStackChangedListener;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnDismissListener;
import android.graphics.Point;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.PaintDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.os.SystemClock;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView.OnEditorActionListener;

public class MapLocationActivity extends BaseActivity implements OnGetPoiSearchResultListener, OnDateSetListener, OnGetGeoCoderResultListener, 
	OnHeaderRefreshListener, OnClickListener {

	// 定位相关
	private GeoCoder geo = null;
	private String address = "暂时无法获取，请检查网络连接";
	
	private DisplayMetrics dm;
	private LocationClient mLocClient;
	public MyLocationListenner myLocListener = new MyLocationListenner();
	private MapView mMapView;
	private BaiduMap mBaiduMap;
	private LocationMode mCurrentMode = LocationMode.NORMAL;
	private boolean isFirstLoc = true;// 是否首次定位
	private boolean isReLoc = true;
	private static String TAG = "TEST Log";
	private Button btnDate, btnSer, btnLoc, btnFind;
	private EditText edFind;
	private String strDate = null;
	private String rangeTime = null;
	private DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");  //日期格式
	private List<ParkInfo> mCurParkInfo = null;   //当前小区信息
	private List<ParkInfo> mCityParkInfo = null, mDisParkInfo = null;
	private List<ParkingDetailInfo> mCurParkDetailInfo = null;
	private BitmapDescriptor mIconMaker;   //定位图标
	private PopupWindow pwMarkerInfo;   //marker点击弹出窗口
	private PopupWindow pwCityInfo, pwFindInfo;
	private boolean isCityShow = true;
	private PoiSearch mPoiSearch = null;
	private AbWheelView wheelYear;
	private AbWheelView wheelMon;
	private AbWheelView wheelDay;
	private AlertDialog wDialog;
	private ProgressDialog dialog;
	String[] mYear = new String[5];
    String[] mMon = new String[12];
    String[] mDay = new String[31];
    private List<String> dataCity = new ArrayList<String>();
	private List<String> dataDistrict = new ArrayList<String>();
	private List<CityInfo> cityInfos = new ArrayList<CityInfo>();
	
	public static final String DATEPICKER_TAG = "datepicker";
	private DatePickerDialog datePickerDialog;
	private RelativeLayout rlayoutMyorder;
	/**
	 * 最新一次定位到的经纬度
	 */
	public static double mCurrentLantitude ;
	public static double mCurrentLongitude ;
	/**
	 * 当前的精度
	 */
	private float mCurrentAccracy;
	private String curShowView = "0";
	private int dialogDismiss = 0;
	private boolean mIsEngineInitSuccess = false;
	private boolean isShowDis = false;  //显示 行政区    
	private boolean isShowCity = false; //显示 市
	private boolean isShowPark = true; //显示 小区
	private boolean isMapChangeStart = false;
	
	private TextView tvAdd, tvParknull;
	private RadioButton rbOne, rbTwo;
	private ListView lvFastP;
	private Button btnBook, btnFastB, btnMore;
	private LinearLayout llFastP, llMap;
	private LinearLayout.LayoutParams fastpParams, mapParams;
	private int screenWidth;
	private boolean isShowMap = false;
	
	private AbPullToRefreshView pullView;
	private Drawable rPullDrawable;
	
	private AbPullToRefreshView pullViewNull;
	private AbPullToRefreshView pullViewOrder;
	private AbPullToRefreshView pullViewParknull;
	private boolean isShowOrder = true;
	private boolean isFirstGetFastPark = true;
	private PopupWindow pwMoreTime;
	private TextView tvMoretime;
	private int parkTime = 2;
	private List<FastParkInfo> mFastParkInfo = new ArrayList<FastParkInfo>();
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		SDKInitializer.initialize(ParkingApp.mAppCtx);  
		setContentView(R.layout.activity_location);
		
		mMapView = (MapView) findViewById(R.id.bmapView);
	    mBaiduMap = mMapView.getMap();
	    MapStatusUpdate msu = MapStatusUpdateFactory.zoomTo(15.0f); // 地图缩放级别 3~19 float
	    mBaiduMap.setMapStatus(msu);
	    mOwner = this;
        final Calendar calendar = Calendar.getInstance();
        datePickerDialog = DatePickerDialog.newInstance(this, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH), false);
        ParkingApp.mAppCtx.setMapHandler(mapHandler);
        
        geo = GeoCoder.newInstance();
        geo.setOnGetGeoCodeResultListener(MapLocationActivity.this);
		rlayoutMyorder = (RelativeLayout) this.findViewById(R.id.rlayout_myorder);
		llayoutShowNull = (LinearLayout) this.findViewById(R.id.layoutShownull);
		
		llFastP = (LinearLayout) this.findViewById(R.id.llayout_fastparking);
		llMap = (LinearLayout) this.findViewById(R.id.llayout_map);
		
		tvAdd = (TextView) this.findViewById(R.id.tv_add);
		tvParknull = (TextView) this.findViewById(R.id.tvparknull);
		tvAdd.setFocusableInTouchMode(true);
//        initParkView();
		showOrderView();
		init();
		initNavigator();
		initMyLocation();
//	    init();
//	    initMapListener();
//	    initMyLocation();
//	    initNavigator();
	    hideKeyborad();
	}
	
	private void initParkView() {
		rlayoutMyorder.setVisibility(View.GONE);
		llFastpark.setVisibility(View.GONE);
		llFastP.setVisibility(View.VISIBLE);
		llMap.setVisibility(View.VISIBLE);
		isShowOrder = false;
//		init();
	    initMapListener();
	    initMyLocation();
	    initNavigator();
//	    getFastParkInfo();
	}
	
	private void showFastParkingView() {
		
	}
	
	private void initNavigator() {
		BaiduNaviManager.getInstance().initEngine(this, getSdcardDir(),
                mNaviEngineInitListener, new LBSAuthManagerListener() {
                    @Override
                    public void onAuthResult(int status, String msg) {
                        String str = null;
                        if (0 == status) {
                            str = "Navigator key校验成功!";
                        } else {
                            str = "Navigator key校验失败, " + msg;
                        }
                        Log.i(TAG, str);
                    }
                });
	}
	
	private void init() {
		// 获取屏幕分辨率
		DisplayMetrics dm = new DisplayMetrics();
		WindowManager wm = (WindowManager)getApplicationContext().getSystemService(Context.WINDOW_SERVICE);
		wm.getDefaultDisplay().getMetrics(dm);
		screenWidth = dm.widthPixels;
		
		edFind = (EditText) findViewById(R.id.ed_find);
		btnDate = (Button) findViewById(R.id.btnDate);
		btnSer = (Button) findViewById(R.id.btnSer);
		btnLoc = (Button) findViewById(R.id.btnLoc);
		btnFind = (Button) findViewById(R.id.btnFind);
		
		
		rbOne = (RadioButton) this.findViewById(R.id.rb_one);
		rbTwo = (RadioButton) this.findViewById(R.id.rb_two);
		lvFastP = (ListView) this.findViewById(R.id.lv_fastparkinfo);
		btnBook = (Button) this.findViewById(R.id.btn_book);
		btnFastB = (Button) this.findViewById(R.id.btn_fastbook);
		btnMore = (Button) this.findViewById(R.id.btn_more);
		llFastP = (LinearLayout) this.findViewById(R.id.llayout_fastparking);
		llMap = (LinearLayout) this.findViewById(R.id.llayout_map);
		tvMoretime = (TextView) this.findViewById(R.id.tv_moretime);
		
//		pullView = (AbPullToRefreshView) this.findViewById(R.id.pullView);
		rPullDrawable = this.getResources().getDrawable(R.drawable.progress_circular);
//		pullView.setOnHeaderRefreshListener(this);
//		pullView.getHeaderView().setHeaderProgressBarDrawable(rPullDrawable);
//		pullView.setPullRefreshEnable(true);
//		pullView.setLoadMoreEnable(false);
//		rbTwo.setFocusable(true);
//		rbTwo.setFocusableInTouchMode(true);
		rbTwo.setChecked(true);
		parkTime = 2;
		
		fastpParams = (android.widget.LinearLayout.LayoutParams) llFastP.getLayoutParams();
		mapParams = (android.widget.LinearLayout.LayoutParams) llMap.getLayoutParams();
		fastpParams.width = screenWidth;

		mapParams.width = screenWidth;
		
		rbOne.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				tvMoretime.setText("已选择停车 1 小时");
				parkTime = 1;
				getFastParkInfo(1);
			}
		});
		
		rbTwo.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				tvMoretime.setText("已选择停车 2 小时");
				parkTime = 2;
				getFastParkInfo(2);
			}
		});

		btnBook.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				new SlidingTask().execute(-40);
			}
		});
		
		btnFastB.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				new SlidingTask().execute(40);
			}
		});
		
		btnMore.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				showMoreTime();
			}
		});
		
		lvFastP.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				// TODO Auto-generated method stub
				FastParkInfo info = mFastParkInfo.get(arg2);
				boolean bo = isNetConnected();
				if(bo) {
					getFastParkOrder(info.getId(), String.valueOf(parkTime), info.getName(), info.getNum());
				}else {
					Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
				}
			}
		});
		
		mPoiSearch = PoiSearch.newInstance();
		mPoiSearch.setOnGetPoiSearchResultListener(this);
		btnDate.setOnClickListener( new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
//				showTimePickerDialog();
				datePickerDialog.setVibrate(false);
                datePickerDialog.setYearRange(1985, 2028);
                datePickerDialog.setCloseOnSingleTapDay(false);
                datePickerDialog.show(getSupportFragmentManager(), DATEPICKER_TAG);
			}
		});
		
		btnLoc.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				setMyLoaction();
			}
		});
		
		btnSer.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				boolean bo = isNetConnected();
				if(bo) {
//					getCity();
					new SlidingTask().execute(40);
//					getParkByDate();
				}else {
					Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
				}
			}
		});
		
		btnFind.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				boolean bo = isNetConnected();
				if(edFind.getText().toString() == null || edFind.getText().length() == 0) {
					Toast.makeText(getApplicationContext(), "请输入搜索关键字", Toast.LENGTH_SHORT).show();
//					showPopw();
					return;
				}
				String keyword = edFind.getText().toString();
				if(bo) {
					hideKeyborad();
					doSearchByKeyword(keyword);
				}else {
					Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
				}
			}
		});
		
		edFind.setOnEditorActionListener(new OnEditorActionListener() {
			
			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				// TODO Auto-generated method stub
				switch(actionId) {
				case EditorInfo.IME_ACTION_DONE:
					btnFind.performClick();
					break;
				}
				return false;
			}
		});
	}
	
	private void showPwCityInfo() {
		View v = LayoutInflater.from(MapLocationActivity.this).inflate(R.layout.popw_cityinfo, null);
		final RelativeLayout location =  (RelativeLayout) View.inflate(MapLocationActivity.this,R.layout.popw_cityinfo, null);
		pwCityInfo = new PopupWindow(location, LayoutParams.WRAP_CONTENT, 800);
		
		Button btn = (Button) location.findViewById(R.id.btreturn);
		
		final ListView lvcity = (ListView) location.findViewById(R.id.lvCity);
		final ListView lvarea = (ListView) location.findViewById(R.id.lvArea);
		final TextView tv = (TextView) location.findViewById(R.id.tvCity);

		lvcity.setAdapter(new ArrayAdapter<String>(MapLocationActivity.this, android.R.layout.simple_list_item_1, dataCity));
		
		lvcity.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				// TODO Auto-generated method stub
//				lvarea.setAdapter(new ArrayAdapter<String>(MapLocationActivity.this, android.R.layout.simple_list_item_1,getArea()));
//				lvarea.setVisibility(View.VISIBLE);
				tv.setText("请选择行政区");
				getDistrict(cityInfos.get(arg2).getCityCode(), lvarea, tv);
				isCityShow = false;
			}
		});
		
		btn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if(isCityShow){
					pwCityInfo.dismiss();
				}else {
					lvarea.setVisibility(View.GONE);
					isCityShow = true;
					tv.setText("请选择城市");
				}
			}
		});
		
		lvarea.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View v, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				String str = ((TextView)v).getText().toString();
				mPoiSearch.searchInCity((new PoiCitySearchOption())
						.city("广州市")
						.keyword(str)
						.pageNum(1));
				pwCityInfo.dismiss();
			}
		});
		
		pwCityInfo.setBackgroundDrawable(new PaintDrawable(0x00000000));  
		pwCityInfo.setOutsideTouchable(false);
		pwCityInfo.setFocusable(true);
		pwCityInfo.showAtLocation(location, Gravity.CENTER, 0, 0);
	}
	
	private void initMapListener() {
		mBaiduMap.setOnMarkerClickListener(new OnMarkerClickListener() {
			
			@Override
			public boolean onMarkerClick(Marker marker) {
				// TODO Auto-generated method stub
				if(isShowCity) {
					MapStatusUpdate msu = MapStatusUpdateFactory.zoomTo(12.0f); // 地图缩放级别 3~19 float
				    mBaiduMap.setMapStatus(msu);
				    
				    List<ParkInfo> mParkInfo = new ArrayList<ParkInfo>();
					ParkInfo info = new ParkInfo();
					info.setLat(23.132702);
					info.setLng(113.281516);
					info.setId("city");
					int num = 0;
					for(ParkInfo f : mCurParkInfo) {
						num = num+f.getNum();
					}
					info.setNum(num);
					info.setName("GZ");
					double distance = DistanceUtil.getDistance(new LatLng(mCurrentLantitude, mCurrentLongitude), new LatLng(info.getLat(), info.getLng()));
					info.setDistance(distance);
					mParkInfo.add(info);
//					addParkInfoOverLay(mParkInfo);
					addParkInfoOverLay(mDisParkInfo);
				    isShowCity = false;
				    isShowDis = true;
				    isShowPark = false;
				    return true;
				}
				if(isShowDis) {
					MapStatusUpdate msu = MapStatusUpdateFactory.zoomTo(15.0f); // 地图缩放级别 3~19 float
				    mBaiduMap.setMapStatus(msu);
				    addParkInfoOverLay(mCurParkInfo);
				    isShowCity = false;
				    isShowDis = false;
				    isShowPark = true;
				    return true;
				}
				// 获得marker中的数据
				final ParkInfo info = (ParkInfo) marker.getExtraInfo().get("info");
				final LatLng ll = marker.getPosition();
				setMyLoaction(ll);
				boolean bo = isNetConnected();
				if(bo) {
					getDetailParkingInfo(info.getId(), strDate, info.getName(), info.getNum(), info );
				}else {
					Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
				}
//				View v = LayoutInflater.from(MapLocationActivity.this).inflate(R.layout.popw_markerinfo, null);
//				v.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
//				LinearLayout location = (LinearLayout) View.inflate(MapLocationActivity.this,R.layout.popw_markerinfo, null);
//				pwMarkerInfo = new PopupWindow(v, v.getMeasuredWidth(), v.getMeasuredHeight());
//
//				TextView tv1 = (TextView) v.findViewById(R.id.name);
//				TextView tv2 = (TextView) v.findViewById(R.id.num);
//				tv1.setText("小区名称："+info.getName());
//				tv2.setText("车位数量："+String.valueOf(info.getNum()));
//				
//				Button btn = (Button) v.findViewById(R.id.reserve);
//				
//				btn.setOnClickListener(new OnClickListener() {
//					
//					@Override
//					public void onClick(View arg0) {
//						// TODO Auto-generated method stub
//						getDetailParkingInfo(info.getId(), strDate, info.getName() );
//						pwMarkerInfo.dismiss();
//					}
//				});
//				
//				// 将marker所在的经纬度的信息转化成屏幕上的坐标
//				Point p = mBaiduMap.getProjection().toScreenLocation(ll);
//				p.y -= 47;
//				// 为弹出的InfoWindow添加点击事件
//
//				// 显示InfoWindow
//				dm = new DisplayMetrics();
//
//				MapLocationActivity.this.getWindowManager().getDefaultDisplay().getMetrics(dm);
//				int width = dm.widthPixels/2;
//				int height = dm.heightPixels/2;
//
//				pwMarkerInfo.setBackgroundDrawable(new PaintDrawable(0x00000000));  
//				pwMarkerInfo.setOutsideTouchable(false);
//				pwMarkerInfo.setFocusable(true);
//				pwMarkerInfo.showAsDropDown(location, width-pwMarkerInfo.getWidth()/2-2, height-pwMarkerInfo.getHeight()-85);
				return true;
			}
		});
		
		// 监听地图状态变化    地图缩放级别 3~19 float
		//  < 13 行政区 显示
		//  < 11 市 显示   广州：lat：23.132702 lon：113.281516
		mBaiduMap.setOnMapStatusChangeListener(new OnMapStatusChangeListener() {
			
			@Override
			public void onMapStatusChangeStart(MapStatus arg0) {
				// TODO Auto-generated method stub
				Log.i("Map Activity onMapStatusChangeStart", String.valueOf(arg0.zoom));
				isMapChangeStart = true;
			}
			
			@SuppressWarnings("null")
			@Override
			public void onMapStatusChangeFinish(MapStatus arg0) {
				// TODO Auto-generated method stub
				Log.i("Map Activity onMapStatusChangeFinish ", String.valueOf(arg0.zoom));
				LatLng latlng = arg0.target;
				Log.i("Map Activity", "latlng : " + latlng.toString());
				if(arg0.zoom < 11) {
					if(!isShowCity) {
						List<ParkInfo> mParkInfo = new ArrayList<ParkInfo>();
						ParkInfo info = new ParkInfo();
						info.setLat(23.147083);
						info.setLng(113.250705);
						info.setId("city");
						int num = 0;
						for(ParkInfo f : mCurParkInfo) {
							num = num+f.getNum();
						}
						info.setNum(num);
						info.setName("GZ");
						double distance = DistanceUtil.getDistance(new LatLng(mCurrentLantitude, mCurrentLongitude), new LatLng(info.getLat(), info.getLng()));
						info.setDistance(distance);
						mParkInfo.add(info);
//						addParkInfoOverLay(mParkInfo);
						addParkInfoOverLay(mCityParkInfo);
						Log.i("Map Activity", "showCity");
						isShowCity = true;
						isShowDis = false;
						isShowPark = false;
					}
				}else if(arg0.zoom < 12.5) {
					if(!isShowDis) {
						List<ParkInfo> mParkInfo = new ArrayList<ParkInfo>();
						ParkInfo info = new ParkInfo();
						info.setLat(23.132702);
						info.setLng(113.281516);
						info.setId("city");
						int num = 0;
						for(ParkInfo f : mCurParkInfo) {
							num = num+f.getNum();
						}
						info.setNum(num);
						info.setName("GZ");
						double distance = DistanceUtil.getDistance(new LatLng(mCurrentLantitude, mCurrentLongitude), new LatLng(info.getLat(), info.getLng()));
						info.setDistance(distance);
						mParkInfo.add(info);
//						addParkInfoOverLay(mParkInfo);
						addParkInfoOverLay(mDisParkInfo);
						Log.i("Map Activity", "showDis");
						isShowCity = false;
						isShowDis = true;
						isShowPark = false;
					}
				}else if(arg0.zoom >13) {
					if(!isShowPark) {
						addParkInfoOverLay(mCurParkInfo);
						isShowCity = false;
						isShowDis = false;
						isShowPark = true;
					}
				}
				isMapChangeStart = false;
			}
			
			@Override
			public void onMapStatusChange(MapStatus arg0) {
				// TODO Auto-generated method stub
				Log.i("Map Activity onMapStatusChange ", String.valueOf(arg0.zoom));
			}
			
		});
	}
	
	private void setMyLoaction(){
		isReLoc = true;
		LatLng ll = new LatLng(mCurrentLantitude, mCurrentLongitude);
		MapStatusUpdate u = MapStatusUpdateFactory.newLatLng(ll);
		mBaiduMap.animateMapStatus(u);
	}
	
	private void setMyLoaction(LatLng ll){
		MapStatusUpdate u = MapStatusUpdateFactory.newLatLng(ll);
		mBaiduMap.animateMapStatus(u);
	}
	
	private void initMyLocation( ) {
		// 定位初始化
		mLocClient = new LocationClient(ParkingApp.mAppCtx);
		myLocListener = new MyLocationListenner();
		mLocClient.registerLocationListener(myLocListener);
		// 设置定位的相关配置
		LocationClientOption option = new LocationClientOption();
		option.setOpenGps(true);// 打开gps
		option.setCoorType("bd09ll"); // 设置坐标类型
		option.setScanSpan(1000);
		mLocClient.setLocOption(option);
		mLocClient.requestLocation();
	}
	
	/**
	 * 定位SDK监听函数
	 */
	public class MyLocationListenner implements BDLocationListener {

		@Override
		public void onReceiveLocation(BDLocation location) {
			mCurrentLantitude = location.getLatitude();
			mCurrentLongitude = location.getLongitude();
			if(isFirstGetFastPark) {
				getFastParkInfo();
				isFirstGetFastPark = false;
			}
			LatLng ptCenter = new LatLng((MapLocationActivity.mCurrentLantitude), (MapLocationActivity.mCurrentLongitude));
			// 反Geo搜索
			geo.reverseGeoCode(new ReverseGeoCodeOption()
					.location(ptCenter));
			if(isShowOrder) {
				return;
			}
//			Log.i(TAG, String.valueOf(mCurrentLantitude) + " : " + String.valueOf(mCurrentLongitude));
			if (isReLoc) {
				// map view 销毁后不在处理新接收的位置
//				showProgDialog("正在加载地图 . . .");
				if (location == null || mMapView == null)
					return;
				MyLocationData locData = new MyLocationData.Builder()
						.accuracy(location.getRadius())
						// 此处设置开发者获取到的方向信息，顺时针0-360
						.direction(100).latitude(location.getLatitude())
						.longitude(location.getLongitude()).build();
				mBaiduMap.setMyLocationData(locData);
				// 设置自定义图标
				MyLocationConfiguration config = new MyLocationConfiguration(
						mCurrentMode, true, null);
				mBaiduMap.setMyLocationConfigeration(config);
				LatLng ll = new LatLng(location.getLatitude(),
						location.getLongitude());
				MapStatusUpdate u = MapStatusUpdateFactory.newLatLng(ll);
				mBaiduMap.animateMapStatus(u);
				if(dialog != null) {
					dialogDismiss = 1;
					dialog.dismiss();
				}
				if(isFirstLoc) {
					boolean bo = isNetConnected();
					if(bo) {
					    getParkByDate();
					    getParkByDate("big", 0);
					    getParkByDate("middle", 1);
					}else {
						Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
					}
					isFirstLoc = false;
				}
				isReLoc = false;
			}
		}

		public void onReceivePoi(BDLocation poiLocation) {
			
		}
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		// 退出时销毁定位
		if(mLocClient != null) {
			mLocClient.stop();
		}
		
		// 关闭定位图层
		mBaiduMap.setMyLocationEnabled(false);
		mMapView.onDestroy();
		mMapView = null;
		super.onDestroy();
	}

	private void getDetailParkingInfo(String id, String date, final String name, final int num, final ParkInfo info) {
		boolean bo = isNetConnected();
		if(!bo) {
			Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
			return;
		}
		curShowView = "DetailParkingInfo";
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("method", "park_2000");
		params.addBodyParameter("area_id", id);
		params.addBodyParameter("parktime", strDate);
		params.addBodyParameter("timeRange", rangeTime);   // timeRange： 1上午，2中午，3下午，4晚上， 可多选
		HttpUtils http = new HttpUtils(6000);
		showProgDialog("正在查询详细信息  . . .", http);
		http.send(HttpMethod.POST, 
				ServerURL, 
				params,
				new RequestCallBack<String>() {

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// TODO Auto-generated method stub
						if(curShowView.equals("DetailParkingInfo")) {
							String result = responseInfo.result;
							
							try {
								JSONObject jsob = new JSONObject(result);
								int count = jsob.getInt("totalCount");
								JSONArray jsoa = jsob.getJSONArray("data");
								Log.i(TAG, "park detail info:"+result);
								mCurParkDetailInfo = new ArrayList<ParkingDetailInfo>();
								for(int i=0; i< count; i++) {	
									ParkingDetailInfo info = new ParkingDetailInfo();
									JSONObject jso = jsoa.getJSONObject(i);
//									"id":"218","time_hour":"08:50---21:50","price":"10元/小时","parking_no":"1"
									info.setPid(jso.getString("id"));
									info.setPno(jso.getString("parking_no"));
									info.setPrice(jso.getString("price"));
									info.setTimeHour(jso.getString("time_hour"));
									info.setPrate(jso.getString("park_rate"));
									info.setPdate(strDate);
									info.setBossId(jso.getString("boss_id"));
									mCurParkDetailInfo.add(info);
								}
								
								if(dialog != null) {
									dialogDismiss = 1;
									dialog.dismiss();
								}
								
								Intent intent = new Intent(MapLocationActivity.this, MapReserveParkingActivity.class);
								Bundle bundle = new Bundle();
								bundle.putParcelableArrayList("ParkDetailInfo", (ArrayList<? extends Parcelable>) mCurParkDetailInfo);
								bundle.putString("name", name);
								bundle.putString("pdate", strDate);
								bundle.putInt("pnum", count);
								bundle.putDouble("lon", info.getLng());
								bundle.putDouble("lat", info.getLat());
								intent.putExtras(bundle);
								mMapView.onPause();
								startActivity(intent);
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								Toast.makeText(getApplicationContext(), "获取数据错误", Toast.LENGTH_SHORT).show();
								e.printStackTrace();
							}
						}
					}

					@Override
					public void onFailure(HttpException error, String msg) {
						// TODO Auto-generated method stub
						if(curShowView.equals("DetailParkingInfo")) {
							showTipsDialog("查询失败，请检查网络，稍后再试");
						}
						if(dialog != null) {
							dialogDismiss = 1;
							dialog.dismiss();
						}
					}
		});
	}
	
	private void getParkByDate() {
		boolean bo = isNetConnected();
		if(!bo) {
			Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
			return;
		}
		curShowView = "getParkByDate";
		if(strDate == null) {
			Calendar cal = Calendar.getInstance();
			Date date = cal.getTime();
			strDate = dateFormat.format(date);
		}
		Log.i("TEST", strDate);
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("method", "park_2001");
		params.addBodyParameter("parktime", strDate);
		params.addBodyParameter("timeRange", rangeTime);   // timeRange： 1上午，2中午，3下午，4晚上， 可多选
		params.addBodyParameter("flag", "small");  //small 小区模式显示，middle 行政区显示，big 市显示
		Log.i("TEST", "method=park_2001 "+"parktime="+strDate+" timeRange="+rangeTime+" flag=small");
		HttpUtils http = new HttpUtils(6000);
		if(dialog != null) {
			dialogDismiss = 1;
			dialog.dismiss();
		}
		showProgDialog("正在查询车位 . . .", http);
		http.send(HttpMethod.POST, 
				ServerURL, 
				params, 
				new RequestCallBack<String>() {

			@Override
			public void onSuccess(ResponseInfo<String> responseInfo) {
				// TODO Auto-generated method stub
				Log.i("TEST", "curShowView : " + curShowView);
				if(curShowView.equals("getParkByDate") || isForce) {
					isForce = false;
					String str = null;
					Log.i(TAG, "getParkByDate : " + responseInfo.result);
					try {
						byte[] bt = responseInfo.result.getBytes();
						str = new String(bt, "UTF-8");
					} catch (UnsupportedEncodingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					try {
						JSONObject jsob = new JSONObject(str);
						int count = jsob.getInt("totalCount");
						
						if(count == 0) {
							
							if(dialog != null) {
								dialogDismiss = 1;
								dialog.dismiss();
							}
							
							showTipsDialog("当天没有停车位信息");
							mBaiduMap.clear();
							return;
						}
						
						JSONArray jsoa = jsob.getJSONArray("data");
						mCurParkInfo = new ArrayList<ParkInfo>();
						
						for(int i=0; i< count; i++) {	
							ParkInfo info = new ParkInfo();
							JSONObject jso = jsoa.getJSONObject(i);
							info.setId(jso.getString("id"));
							info.setName(jso.getString("name"));
							info.setNum(jso.getInt("num"));
							info.setLat(jso.getDouble("lat"));
							info.setLng(jso.getDouble("lng"));
							double distance = DistanceUtil.getDistance(new LatLng(mCurrentLantitude, mCurrentLongitude), new LatLng(info.getLat(), info.getLng()));
							info.setDistance(distance);
							mCurParkInfo.add(info);
						}
						addParkInfoOverLay(mCurParkInfo);
						if(dialog != null) {
							dialogDismiss = 1;
							dialog.dismiss();
						}
						pullView.onHeaderRefreshFinish();
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				if(dialog != null) {
					dialogDismiss = 1;
					dialog.dismiss();
				}
			}

			@Override
			public void onFailure(HttpException error, String msg) {
				// TODO Auto-generated method stub
				
				if(curShowView.equals("getParkByDate")) {
					showTipsDialog("查询失败，请检查网络连接，稍后再试");
				}
				if(dialog != null) {
					dialogDismiss = 1;
					dialog.dismiss();
				}
			}
		});
	}
	
	private void getParkByDate(final String flag, final int index) {
		boolean bo = isNetConnected();
		if(!bo) {
			Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
			return;
		}
//		curShowView = "getParkByDate";
		if(strDate == null) {
			Calendar cal = Calendar.getInstance();
			Date date = cal.getTime();
			strDate = dateFormat.format(date);
		}
		Log.i("TEST", strDate);
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("method", "park_2001");
		params.addBodyParameter("parktime", strDate);
		params.addBodyParameter("timeRange", rangeTime);   // timeRange： 1上午，2中午，3下午，4晚上， 可多选
		params.addBodyParameter("flag", flag);  //small 小区模式显示，middle 行政区显示，big 市显示
		
		HttpUtils http = new HttpUtils(6000);
//		showProgDialog("正在进行查询 . . .", http);
		http.send(HttpMethod.POST, 
				ServerURL, 
				params, 
				new RequestCallBack<String>() {

			@Override
			public void onSuccess(ResponseInfo<String> responseInfo) {
				// TODO Auto-generated method stub
				String str = null;
				Log.i(TAG, "getParkByDate flag : " + flag +" : "+ responseInfo.result);
				try {
					byte[] bt = responseInfo.result.getBytes();
					str = new String(bt, "UTF-8");
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					JSONObject jsob = new JSONObject(str);
					int count = jsob.getInt("totalCount");
					
					if(count == 0) {
						
//						if(dialog != null) {
//							dialogDismiss = 1;
//							dialog.dismiss();
//						}
//						showTipsDialog("当天没有停车位信息 : "+flag);
//						mBaiduMap.clear();
						return;
					}
					
					JSONArray jsoa = jsob.getJSONArray("data");
					switch(index) {
					case 0:
						mCityParkInfo = new ArrayList<ParkInfo>();
						break;
					case 1:
						mDisParkInfo = new ArrayList<ParkInfo>();
						break;
					}
					for(int i=0; i< count; i++) {	
						ParkInfo info = new ParkInfo();
						JSONObject jso = jsoa.getJSONObject(i);
						info.setId(jso.getString("id"));
						info.setName(jso.getString("name"));
						info.setNum(jso.getInt("num"));
						info.setLat(jso.getDouble("lat"));
						info.setLng(jso.getDouble("lng"));
						double distance = DistanceUtil.getDistance(new LatLng(mCurrentLantitude, mCurrentLongitude), new LatLng(info.getLat(), info.getLng()));
						info.setDistance(distance);
						switch(index) {
						case 0:
							mCityParkInfo.add(info);
							break;
						case 1:
							mDisParkInfo.add(info);
							break;
						}
						
					}
//					addParkInfoOverLay(mCurParkInfo);
//					if(dialog != null) {
//						dialogDismiss = 1;
//						dialog.dismiss();
//					}
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					Toast.makeText(getApplicationContext(), "获取数据错误", Toast.LENGTH_SHORT).show();
					e.printStackTrace();
				}
			}

			@Override
			public void onFailure(HttpException error, String msg) {
				// TODO Auto-generated method stub
				
//				if(curShowView.equals("getParkByDate")) {
//					showTipsDialog("查询失败，请检查网络连接，稍后再试");
//				}
//				if(dialog != null) {
//					dialogDismiss = 1;
//					dialog.dismiss();
//				}
			}
		});
	}
	
	// 添加坐标覆盖
	private void addParkInfoOverLay(List<ParkInfo> infos) {
		if(infos != null && infos.size() != 0) {

			mBaiduMap.clear();
			LatLng latLng = null;
			LatLng nearLL = null;
			OverlayOptions overlayOptions = null;
			Marker marker = null;
			View v = LayoutInflater.from(MapLocationActivity.this).inflate(R.layout.view_marker, null);
			TextView tv = (TextView) v.findViewById(R.id.tvParkingNum);
			double minDis = -1;
			for (ParkInfo info : infos)
			{
				// 位置
				latLng = new LatLng(info.getLat(), info.getLng());
				tv.setText(String.valueOf(info.getNum()));
				
				if(minDis == -1) {
					minDis = info.getDistance();
					nearLL = latLng;
				}else {
					if(minDis > info.getDistance()) {
						minDis = info.getDistance();
						nearLL = latLng;
					}
				}
				Log.i(TAG, "addparkinfoOverLay distance : " + String.valueOf(minDis));
				if(mIconMaker != null) {
					mIconMaker.recycle();
				}
				mIconMaker = BitmapDescriptorFactory.fromView(v);
				// 图标
				overlayOptions = new MarkerOptions().position(latLng)
						.icon(mIconMaker).zIndex(5);
				marker = (Marker) (mBaiduMap.addOverlay(overlayOptions));
				marker.setPerspective(true);
				Bundle bundle = new Bundle();
				bundle.putSerializable("info", info);
				marker.setExtraInfo(bundle);
			}
			// 将地图移到到最后一个经纬度位置
			MapStatusUpdate u = MapStatusUpdateFactory.newLatLng(nearLL);
			mBaiduMap.setMapStatus(u);
//			showPopw();
		}
	}
	
	 private List<String> getFCity(){
         
	        List<String> data = new ArrayList<String>();
	        data.add("广州市");
	         
	        return data;
	    }
	 
	 private List<String> getArea(){
         
	        List<String> data = new ArrayList<String>();
	        data.add("荔湾区");
	        data.add("越秀区");
	        data.add("海珠区");
	        data.add("天河区");
	        data.add("黄埔区");
	        data.add("番禺区");
	        
	        return data;
	    }

	@Override
	public void onGetPoiDetailResult(PoiDetailResult arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onGetPoiResult(PoiResult result) {
		// TODO Auto-generated method stub
		if (result.error == SearchResult.ERRORNO.NO_ERROR) {
			mBaiduMap.clear();
			
			List<PoiInfo> infos = result.getAllPoi();
			PoiInfo info = infos.get(0);
			LatLng ll = info.location;
			setMyLoaction(ll);
			
			return;
		}
	}
	
	private class MyPoiOverlay extends PoiOverlay {

		public MyPoiOverlay(BaiduMap baiduMap) {
			super(baiduMap);
		}

		@Override
		public boolean onPoiClick(int index) {
			super.onPoiClick(index);
			PoiInfo poi = getPoiResult().getAllPoi().get(index);
			if (poi.hasCaterDetails) {
				mPoiSearch.searchPoiDetail((new PoiDetailSearchOption())
						.poiUid(poi.uid));
			}
			return true;
		}
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		mMapView.onPause();
		Log.i("Map Activity", "onPause");
		super.onPause();
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		Log.i("Map Activity", "onResume");

		super.onResume();
		mBaiduMap.setMyLocationEnabled(true);
		if( mLocClient != null && !mLocClient.isStarted()) {
			mLocClient.start();
		}
		mMapView.onResume();
		if(vTime != null) {
			vTime.start();
		}
	}
	
	private void showTipsDialog(String msg){  
        AlertDialog dialog;  
        AlertDialog.Builder builder = new AlertDialog.Builder(MapLocationActivity.this);  
        builder.setTitle("消息").setIcon(android.R.drawable.stat_notify_error);  
        builder.setMessage(msg);  
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener(){  
            @Override 
            public void onClick(DialogInterface dialog, int which) {  
                // TODO Auto-generated method stub  
                  
            }                     
        });  
        dialog = builder.create();  
        dialog.show();  
    }  
	
	private void showProgDialog(final String msg) {
		dialog = ProgressDialog.show(MapLocationActivity.this, "消息", msg);
	}
	
	/**
	 * 显示等待框
	 * @param msg
	 * @param httpUtils
	 */
	private void showProgDialog(final String msg, final HttpUtils httpUtils) {
		dialog = new ProgressDialog(this);
		dialog.setCanceledOnTouchOutside(false);
		dialog.setOnDismissListener(new OnDismissListener() {
			
			@Override
			public void onDismiss(DialogInterface dialog) {
				// TODO Auto-generated method stub
				if(dialogDismiss == 0 ) {
					httpUtils.getHttpClient().getConnectionManager().closeExpiredConnections();
//					httpUtils.getHttpClient().getConnectionManager().shutdown();
				}
				dialogDismiss = 0;
				curShowView = "0";
				Log.i(TAG, "dialog dismiss : "+msg);
			}
		});
		dialog.setMessage(msg);
		dialog.show();
	}
	
	private void showTimePickerDialog() {
		AlertDialog dialog;
        AlertDialog.Builder builder = new AlertDialog.Builder(MapLocationActivity.this);  
        View v = LayoutInflater.from(this).inflate(R.layout.timepicker, null);
        wheelYear = (AbWheelView) v.findViewById(R.id.year);
        wheelMon = (AbWheelView) v.findViewById(R.id.month);
        wheelDay = (AbWheelView) v.findViewById(R.id.day);
        Button btnCancel = (Button) v.findViewById(R.id.wheel_panel_cancelBtn);
        btnCancel.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				wDialog.dismiss();
			}
		});
        
        Button btnOk = (Button) v.findViewById(R.id.wheel_panel_okBtn);
        btnOk.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String y = mYear[wheelYear.getCurrentItem()];
				String m = mMon[wheelMon.getCurrentItem()];
				String d = mDay[wheelDay.getCurrentItem()];
				strDate = y + "-" + m + "-" + d ;
				wDialog.dismiss();
				boolean bo = isNetConnected();
				if(bo) {
				    getParkByDate();
				}else {
					Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
				}
			}
		});
        
        Calendar calendar = Calendar.getInstance();
		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH);
		int day = calendar.get(Calendar.DAY_OF_MONTH);
        
        
        for(int i = 0; i<5; i++) {
        	mYear[i] = String.valueOf(year);
        	year = year+1;
        }
        for(int i = 0; i<12; i++) {
        	if(i<9) {
            	mMon[i] = "0"+String.valueOf(i+1);
        	}else
        	mMon[i] = String.valueOf(i+1);
        }
        for(int i = 0; i<31; i++) {
        	if(i<9) {
        		mDay[i] = "0"+String.valueOf(i+1);
        	}else
        	mDay[i] = String.valueOf(i+1);
        }
        
        AbObjectWheelAdapter<String> adapterhoursY = new AbObjectWheelAdapter<String>(mYear, 5);
		wheelYear.setAdapter(adapterhoursY);
		AbObjectWheelAdapter<String> adapterhoursM = new AbObjectWheelAdapter<String>(mMon, 2);
		wheelMon.setAdapter(adapterhoursM);
		AbObjectWheelAdapter<String> adapterhoursD = new AbObjectWheelAdapter<String>(mDay, 2);
		wheelDay.setAdapter(adapterhoursD);
		
		wheelYear.setCurrentItem(0);
        wheelMon.setCurrentItem(calendar.get(Calendar.MONTH));
        wheelDay.setCurrentItem(calendar.get(Calendar.DAY_OF_MONTH)-1);
        
		setWheel(wheelYear);
		setWheel(wheelMon);
		setWheel(wheelDay);
        builder.setView(v);
        wDialog = builder.create();
        wDialog.setTitle("选择停车日期");
        wDialog.setCanceledOnTouchOutside(false);
        wDialog.show();
	}
	
	private void setWheel(AbWheelView wheel){
		wheel.setCyclic(false);
//		wheel.setCurrentItem(0);
		wheel.setValueTextSize(28);
		wheel.setLabelTextSize(25);
		wheel.setLabelTextColor(0x80000000);
		wheel.setCenterSelectDrawable(this.getResources().getDrawable(R.drawable.wheel_select));
	}
	
	@Override
	public void finish() {
		// TODO Auto-generated method stub
		mMapView.onPause();
		Log.i("Map Activity ", "finish");
		super.finish();
	}

	@Override
	protected void onRestart() {
		// TODO Auto-generated method stub
		Log.i("Map Activity", "onRestart");
		super.onRestart();
	}
	
	private void getCity() {
		boolean bo = isNetConnected();
		if(!bo) {
			Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
			return;
		}
		curShowView = "getCity";
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("method", "201301");

		HttpUtils http = new HttpUtils(6000);
		showProgDialog("正在查询城市 . . .", http);
		http.send(HttpMethod.POST, 
				ServerURL, 
				params,
				new RequestCallBack<String>() {

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// TODO Auto-generated method stub
						if(curShowView.equals("getCity")) {
							Log.i(TAG, "getCity: "+responseInfo.result);
							String result = responseInfo.result;
							List<String> data = new ArrayList<String>();
							try {
								JSONObject jsob = new JSONObject(result);
								int count = jsob.getInt("totalCount");
								if(count != 0) {
									JSONArray jsoa = jsob.getJSONArray("data");
									for(int i=0; i< count; i++) {
										JSONObject jso = jsoa.getJSONObject(i);
										data.add(jso.getString("city_name"));
										CityInfo info = new CityInfo();
										info.setCityName(jso.getString("city_name"));
										info.setCityCode(jso.getString("city_code"));
										cityInfos.add(info);
									}
								}else {
									data.add("暂  无");
								}
								dataCity = data;							
								if(dialog != null) {
									dialogDismiss = 1;
									dialog.dismiss();
								}
								showPwCityInfo();
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								Toast.makeText(getApplicationContext(), "获取数据错误", Toast.LENGTH_SHORT).show();
								e.printStackTrace();
							}
						}
					}

					@Override
					public void onFailure(HttpException error, String msg) {
						// TODO Auto-generated method stub
						if(curShowView.equals("getCity")) {
							if(dataCity == null || dataCity.size() == 0) {
								dataCity.add("暂  无");
							}
							showPwCityInfo();
						}
						if(dialog != null) {
							dialogDismiss = 1;
							dialog.dismiss();
						}
					}
		});
	}
	
	private void getDistrict(String cityCode, final ListView lv, final TextView tv) {
		boolean bo = isNetConnected();
		if(!bo) {
			Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
			return;
		}
		curShowView = "getDistrict";
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("method", "201302");
		params.addBodyParameter("city_code", cityCode);

		HttpUtils http = new HttpUtils(6000);
		showProgDialog("正在查询行政区 . . . ", http);
		http.send(HttpMethod.POST, 
				ServerURL, 
				params,
				new RequestCallBack<String>() {

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// TODO Auto-generated method stub
						Log.i(TAG, "Map getDistrict : " + responseInfo.result );
						if(curShowView.equals("getDistrict")) {
							String result = responseInfo.result;
							List<String> data = new ArrayList<String>();
							try {
								JSONObject jsob = new JSONObject(result);
								int count = jsob.getInt("totalCount");
								if(count != 0) {
									JSONArray jsoa = jsob.getJSONArray("data");
									for(int i=0; i< count; i++) {
										JSONObject jso = jsoa.getJSONObject(i);
										data.add(jso.getString("district"));
									}
								}else {
									data.add("暂  无");
								}
								dataDistrict = data;							
								if(dialog != null) {
									dialogDismiss = 1;
									dialog.dismiss();
								}
								lv.setAdapter(new ArrayAdapter<String>(MapLocationActivity.this, android.R.layout.simple_list_item_1,dataDistrict));
								lv.setVisibility(View.VISIBLE);
								tv.setText("请选择行政区");
								isCityShow = false;
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
						
					}

					@Override
					public void onFailure(HttpException error, String msg) {
						// TODO Auto-generated method stub
//						if
						if(dataDistrict == null || dataDistrict.size() == 0) {
							dataDistrict.add("暂  无");
						}
						if(dialog != null) {
							dialog.dismiss();
						}
					}
		});
	}

	@Override
	public void onDateSet(DatePickerDialog datePickerDialog, int year,
			int month, int day, String rangeTime) {
		// TODO Auto-generated method stub      
		month = month + 1;
        strDate = year + "-" + month + "-" + day ;
        if(month < 10) {
            strDate = year + "-0" + month + "-" + day ;
        }
        if(day < 10) {
            strDate = year + "-" + month + "-0" + day ;
        }
        this.rangeTime = rangeTime;
//        Toast.makeText(MapLocationActivity.this, strDate + " : "+this.rangeTime, Toast.LENGTH_LONG).show();
		boolean bo = isNetConnected();
		if(bo) {
		    getParkByDate();
		    getParkByDate("big", 0);
		    getParkByDate("middle", 1);
		}else {
			Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
		}
	}
	
	private long exitTime = 0;
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
//		Log.i("TEST", "appActivity onKeyDown ");
//		if(keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP){   
//	        if((System.currentTimeMillis()-exitTime) > 2000){  
//	            Toast.makeText(getApplicationContext(), " maploc 再按一次返回键退出程序", Toast.LENGTH_SHORT).show();                                
//	            exitTime = System.currentTimeMillis();   
//	        } else {
//	            finish();
//	            System.exit(0);
//	        }
//	        return true;   
//	    }
		return super.onKeyDown(keyCode, event);
	}
	
	/**
	 * 根据关键字查找小区车位信息
	 * @param keyword
	 */
	private void doSearchByKeyword(String keyword) {
		curShowView = "doSearchByKeyword";
		Calendar cal = Calendar.getInstance();
		Date date = cal.getTime();
		String strdate = dateFormat.format(date);
		Log.i("TEST", "doSearchByKeyword : "+keyword + " date : " + strdate);
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("method", "park_2002");
		params.addBodyParameter("parktime", strdate);
		params.addBodyParameter("timeRange", "0");   // timeRange： 1上午，2中午，3下午，4晚上， 可多选
		params.addBodyParameter("keyword", keyword);
		
		HttpUtils http = new HttpUtils(6000);
		Log.i("TEST", "doSearchByKeyword : "+"uid:"+ParkingApp.mAppCtx.getUID() +"  utype:"+ParkingApp.mAppCtx.getUType()+"  "+"method:"+ "park_2002"
				+"  parktime:"+ strdate+"  timeRange:"+"0"+"  keyword:"+ keyword);
		showProgDialog("正在进行查询 . . .", http);
		http.send(HttpMethod.POST,
				ServerURL, 
				params, 
				new RequestCallBack<String>() {

			@Override
			public void onSuccess(ResponseInfo<String> responseInfo) {
				// TODO Auto-generated method stub
				if(curShowView.equals("doSearchByKeyword")) {
					String str = null;
					Log.i(TAG, "doSearchByKeyword" + responseInfo.result);
					try {
						byte[] bt = responseInfo.result.getBytes();
						str = new String(bt, "UTF-8");
					} catch (UnsupportedEncodingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					
					try {
						JSONObject jsob = new JSONObject(str);
						int count = jsob.getInt("totalCount");
						
						if(count == 0) {
							
							if(dialog != null) {
								dialogDismiss = 1;
								dialog.dismiss();
							}
							
							showTipsDialog("没有相关的停车位信息");
//							mBaiduMap.clear();
							return;
						}
						
						JSONArray jsoa = jsob.getJSONArray("data");
						mCurParkInfo = new ArrayList<ParkInfo>();
						for(int i=0; i< count; i++) {	
							ParkInfo info = new ParkInfo();
							JSONObject jso = jsoa.getJSONObject(i);
							info.setId(jso.getString("id"));
							info.setName(jso.getString("name"));
							info.setNum(jso.getInt("num"));
							info.setLat(jso.getDouble("lat"));
							info.setLng(jso.getDouble("lng"));
							double distance = DistanceUtil.getDistance(new LatLng(mCurrentLantitude, mCurrentLongitude), new LatLng(info.getLat(), info.getLng()));
//							double distance = DistanceUtil.getDistance(new LatLng(mCurrentLantitude, mCurrentLongitude), new LatLng(116.404, 39.945));
							info.setDistance(distance);
							mCurParkInfo.add(info);
						}
//						addParkInfoOverLay(mCurParkInfo);
						showFindResult(mCurParkInfo);
						if(dialog != null) {
							dialogDismiss = 1;
							dialog.dismiss();
						}
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						Toast.makeText(getApplicationContext(), "获取数据错误", Toast.LENGTH_SHORT).show();
						e.printStackTrace();
					}
				}
			}

			@Override
			public void onFailure(HttpException error, String msg) {
				// TODO Auto-generated method stub
				
				if(curShowView.equals("doSearchByKeyword")) {
					showTipsDialog("查询失败，请检查网络连接，稍后再试");
				}
				if(dialog != null) {
					dialogDismiss = 1;
					dialog.dismiss();
				}
			}
		});
		
	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		if((System.currentTimeMillis()-exitTime) > 2000){  
            Toast.makeText(getApplicationContext(), "再按一次返回键退出程序", Toast.LENGTH_SHORT).show();                                
            exitTime = System.currentTimeMillis();   
        } else {
            finish();
            System.exit(0);
        }
//		super.onBackPressed();
	}

	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
		mBaiduMap.setMyLocationEnabled(true);
		if( mLocClient != null && !mLocClient.isStarted()) {
			mLocClient.start();
		}
		Log.i("Map Activity", "onStart");
		super.onStart();
	}

	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		mBaiduMap.setMyLocationEnabled(false);
		if(mLocClient != null) {
			mLocClient.stop();
		}
		Log.i("Map Activity", "onStop");
		if(vTime != null) {
			vTime.stop();
		}
		super.onStop();
	}
	
	private String getSdcardDir() {
		if (Environment.getExternalStorageState().equalsIgnoreCase(
				Environment.MEDIA_MOUNTED)) {
			return Environment.getExternalStorageDirectory().toString();
		}
		return null;
	}
	
	private NaviEngineInitListener mNaviEngineInitListener = new NaviEngineInitListener() {
		public void engineInitSuccess() {
			mIsEngineInitSuccess = true;
		}

		public void engineInitStart() {
		}

		public void engineInitFail() {
		}
	};
	
	/**
	 * 显示搜索结果界面
	 * @param infos
	 */
	private void showFindResult(final List<ParkInfo> infos) {
		View v = LayoutInflater.from(MapLocationActivity.this).inflate(R.layout.popw_cityinfo, null);
		final RelativeLayout location =  (RelativeLayout) View.inflate(MapLocationActivity.this,R.layout.popw_findinfo, null);
		pwFindInfo = new PopupWindow(location, LayoutParams.WRAP_CONTENT, 800);
		
		Button btn = (Button) location.findViewById(R.id.btn_return);
		
		final ListView lvFind = (ListView) location.findViewById(R.id.lv_findinfo);
		FindinfoAdapter adapter = new FindinfoAdapter(MapLocationActivity.this, infos);
		lvFind.setAdapter(adapter);
		
		lvFind.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				// TODO Auto-generated method stub
				ParkInfo info = infos.get(arg2);
				boolean bo = isNetConnected();
				if(bo) {
					getDetailParkingInfo(info.getId(), strDate, info.getName(), info.getNum(), info );
					pwFindInfo.dismiss();
				}else {
					Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
				}
			}
		});
		
		btn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				pwFindInfo.dismiss();
			}
		});
		
		
		pwFindInfo.setBackgroundDrawable(new PaintDrawable(0x00000000));  
		pwFindInfo.setOutsideTouchable(false);
		pwFindInfo.setFocusable(true);
		pwFindInfo.showAtLocation(location, Gravity.CENTER, 0, 0);
	}

	/**
	 * 刷新快速预约界面
	 */
	private void showPopw() {
//		final RelativeLayout location =  (RelativeLayout) View.inflate(MapLocationActivity.this,R.layout.popw_fastparking, null);
//		pwFindInfo = new PopupWindow(location, LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
//		ImageButton btn = (ImageButton) location.findViewById(R.id.btn_close);
//		RadioButton rbOne = (RadioButton) location.findViewById(R.id.rb_one);
//		RadioButton rbTwe = (RadioButton) location.findViewById(R.id.rb_two);
//		TextView tvAdd = (TextView) location.findViewById(R.id.tv_add);
		pullView.setVisibility(View.VISIBLE);
		pullViewParknull.setVisibility(View.GONE);
//		rbTwo.setChecked(true);
//		parkTime = 2;
//		final ListView lvFind = (ListView) location.findViewById(R.id.lv_fastparkinfo);
//		FindinfoAdapter adapter = new FindinfoAdapter(MapLocationActivity.this, mCurParkInfo);
		FastParkInfoListAdapter adapter = new FastParkInfoListAdapter(MapLocationActivity.this, mFastParkInfo);
		lvFastP.setAdapter(adapter);
		
//		lvFind.setOnItemClickListener(new OnItemClickListener() {
//			@Override
//			public void onItemClick(AdapterView<?> arg0, View arg1,
//					int arg2, long arg3) {
//				// TODO Auto-generated method stub
//				ParkInfo info = mCurParkInfo.get(arg2);
//				boolean bo = isNetConnected();
//				if(bo) {
////					getDetailParkingInfo(info.getId(), strDate, info.getName(), info.getNum(), info );
//					Intent intent = new Intent(MapLocationActivity.this, FastParkingActivity.class);
//					startActivity(intent);
//					pwFindInfo.dismiss();
//				}else {
//					Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
//				}
//			}
//		});		
		
		Log.i("TEST", address);
//		btn.setOnClickListener(new OnClickListener() {
//			
//			@Override
//			public void onClick(View arg0) {
//				// TODO Auto-generated method stub
//				pwFindInfo.dismiss();
//			}
//		});
//		
//		
//		pwFindInfo.setBackgroundDrawable(new PaintDrawable(0x00000000));  
//		pwFindInfo.setOutsideTouchable(false);
//		pwFindInfo.setFocusable(true);
//		pwFindInfo.showAtLocation(location, Gravity.CENTER, 0, 0);
	}
	
	@Override
	public void onRangSet(DatePickerDialog datePickerDialog, String rangeTime) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onGetGeoCodeResult(GeoCodeResult arg0) {
		// TODO Auto-generated method stub
		
	}

	/**
	 * 地理位置返回结果
	 */
	@Override
	public void onGetReverseGeoCodeResult(ReverseGeoCodeResult arg0) {
		// TODO Auto-generated method stub
		address = arg0.getAddress();
		tvAdd.setText("当前位置："+address);
	}
	
	/**
	 * 左右滑动布局
	 * @author Administrator
	 */
	class SlidingTask extends AsyncTask<Integer, Integer, Integer> {

		@Override
		protected Integer doInBackground(Integer... params) {
			// TODO Auto-generated method stub
			int leftMargin = fastpParams.leftMargin;
			while(true) {
				leftMargin = leftMargin + params[0];
				if(leftMargin > 0) {
					leftMargin = 0;
					break;
				}
				if(leftMargin < -screenWidth) {
					leftMargin = -screenWidth;
					break;
				}
				publishProgress(leftMargin);
				sleep(5);
			}
			if(params[0] >0) {
				isShowMap = false;
			}else {
				isShowMap = true;
			}
			return leftMargin;
		}

		@Override
		protected void onPostExecute(Integer result) {
			// TODO Auto-generated method stub
			fastpParams.leftMargin = result;
			llFastP.setLayoutParams(fastpParams);
		}

		@Override
		protected void onProgressUpdate(Integer... values) {
			// TODO Auto-generated method stub
			fastpParams.leftMargin = values[0];
			llFastP.setLayoutParams(fastpParams);
		}
	}
	
	/**
	 * 线程睡眠
	 * @param millis
	 */
	private void sleep(long millis) {
		try {
			Thread.sleep(millis);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 下拉刷新列表执行方法
	 */
	@Override
	public void onHeaderRefresh(AbPullToRefreshView view) {
		// TODO Auto-generated method stub
		switch(view.getId()) {
		case R.id.pullView:
//			onLoadingMore();
			getFastParkInfo();
			break;
		case R.id.null_pull_view:
			onRefresh();
			break;
		case R.id.order_pull_view:
			getIsHaveOrder();
			break;
		case R.id.pullviewparknull:
			getFastParkInfo();
			break;
		}
	}
	
	private void onLoadingMore() {
		String d = "";
		Calendar cal = Calendar.getInstance();
		Date date = cal.getTime();
		d = dateFormat.format(date);
	
		Log.i("TEST", d);
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("method", "park_2001");
		params.addBodyParameter("parktime", d);
		params.addBodyParameter("timeRange", "1,2,3,4");   // timeRange： 1上午，2中午，3下午，4晚上， 可多选
		params.addBodyParameter("flag", "small");  //small 小区模式显示，middle 行政区显示，big 市显示
		
		HttpUtils http = new HttpUtils(6000);
		http.send(HttpMethod.POST, 
				ServerURL, 
				params, 
				new RequestCallBack<String>() {

			@Override
			public void onSuccess(ResponseInfo<String> responseInfo) {
				// TODO Auto-generated method stub
					String str = null;
					Log.i(TAG, "getParkByDate" + responseInfo.result);
					try {
						byte[] bt = responseInfo.result.getBytes();
						str = new String(bt, "UTF-8");
					} catch (UnsupportedEncodingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					try {
						JSONObject jsob = new JSONObject(str);
						int count = jsob.getInt("totalCount");
						
						if(count == 0) {
							mBaiduMap.clear();
							return;
						}
						
						JSONArray jsoa = jsob.getJSONArray("data");
						mCurParkInfo = new ArrayList<ParkInfo>();
						for(int i=0; i< count; i++) {	
							ParkInfo info = new ParkInfo();
							JSONObject jso = jsoa.getJSONObject(i);
							info.setId(jso.getString("id"));
							info.setName(jso.getString("name"));
							info.setNum(jso.getInt("num"));
							info.setLat(jso.getDouble("lat"));
							info.setLng(jso.getDouble("lng"));
							double distance = DistanceUtil.getDistance(new LatLng(mCurrentLantitude, mCurrentLongitude), new LatLng(info.getLat(), info.getLng()));
							info.setDistance(distance);
							mCurParkInfo.add(info);
						}
						addParkInfoOverLay(mCurParkInfo);
						
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						Toast.makeText(getApplicationContext(), "获取数据错误", Toast.LENGTH_SHORT).show();
					}
					pullView.onHeaderRefreshFinish();
			}

			@Override
			public void onFailure(HttpException error, String msg) {
				// TODO Auto-generated method stub
				boolean bo = isNetConnected();
				if(!bo) {
					Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
				}
				pullView.onHeaderRefreshFinish();
			}
		});
	}
	
public static final int REQ_CODE_CAPTURE = 111;//请求二维码扫描
	
	private TextView vBaseQuarter;
	private TextView vBaseState;
	private TextView vBasePrice;
	private TextView vBaseTime;
	private TextView vBaseParkingOwner;
	private TextView vBaseOrderId;
	
	private View vTimePanel;
	private Chronometer vTime;
	
	private View vOptPanel;
	private TextView vOptBtn;
	private TextView vOptBtn2;
	private TextView tvToast;
	private LinearLayout layout;
	private TextView vCallTel;
	private CarInTime mInTime;
	private ProgressDialog mDialog;
	private Button btnNavigator;
	private Button btnPhone;
	private MapLocationActivity mOwner;
	private OrderViewModel mModel;
	private boolean mWaitForQuartOwner;
	private int mState;
	private boolean mFragReqRefreshModel;
	private String mOrderId;
	private boolean isFromSystem;
	private ScrollView scrollvOrder;
	private LinearLayout llayoutShowNull;
	
	private void showOrderView() {
		mServer = ParkingApp.mAppCtx.getServerConfig();
		isShowOrder = true;
//		if (!parseIntent()) {
//			showToastTips("订单号出错");
//			finish();
//			return;
//		}
		rlayoutMyorder.setVisibility(View.VISIBLE);
		llFastP.setVisibility(View.GONE);
		llMap.setVisibility(View.GONE);
		findBasePanel();
		initFaskParkingListView();
		findOptPanel();
		findTimePanel();
		getIsHaveOrder();
//		mOrderId = "200";
//		getOrderModelFromServer();
	}
	
	private void showOrderView(String taskid) {
		mServer = ParkingApp.mAppCtx.getServerConfig();
		isShowOrder = true;
		rlayoutMyorder.setVisibility(View.VISIBLE);
		llFastpark.setVisibility(View.GONE);
		llFastP.setVisibility(View.GONE);
		llMap.setVisibility(View.GONE);
		findBasePanel();
		findOptPanel();
		findTimePanel();
		mOrderId = taskid;
		getOrderModelFromServer();
	}
	
	private OrderViewModel getOrderViewModel() {
		return mModel;
	}
	
	private void findBasePanel(){
		vBaseQuarter = (TextView) this.findViewById(R.id.layout_view_order_parking_quarter);
		vBaseState = (TextView) this.findViewById(R.id.layout_view_order_parking_state);
		vBasePrice = (TextView) this.findViewById(R.id.layout_view_order_parking_price);
		vBaseTime = (TextView) this.findViewById(R.id.layout_view_order_parking_time);
		vBaseParkingOwner = (TextView) this.findViewById(R.id.layout_view_order_parking_owner);
		vBaseOrderId = (TextView) this.findViewById(R.id.layout_view_order_id);
		
		this.findViewById(R.id.layout_view_order_parking_owner_panel).setVisibility(View.GONE);   // 业主信息栏
		vBaseState.setFocusableInTouchMode(true);
		pullViewNull = (AbPullToRefreshView) this.findViewById(R.id.null_pull_view);
		rPullDrawable = this.getResources().getDrawable(R.drawable.progress_circular);
		pullViewNull.setOnHeaderRefreshListener(this);
		pullViewNull.getHeaderView().setHeaderProgressBarDrawable(rPullDrawable);
		pullViewNull.setPullRefreshEnable(true);
		pullViewNull.setLoadMoreEnable(false);
		
		pullViewOrder = (AbPullToRefreshView) this.findViewById(R.id.order_pull_view);
		pullViewOrder.setOnHeaderRefreshListener(this);
		pullViewOrder.getHeaderView().setHeaderProgressBarDrawable(rPullDrawable);
		pullViewOrder.setPullRefreshEnable(true);
		pullViewOrder.setLoadMoreEnable(false);
		scrollvOrder = (ScrollView) this.findViewById(R.id.scrollv_order);
		
		pullViewParknull = (AbPullToRefreshView) this.findViewById(R.id.pullviewparknull);
		pullViewParknull.setOnHeaderRefreshListener(this);
		pullViewParknull.getHeaderView().setHeaderProgressBarDrawable(rPullDrawable);
		pullViewParknull.setPullRefreshEnable(true);
		pullViewParknull.setLoadMoreEnable(false);
		
		pullView = (AbPullToRefreshView) this.findViewById(R.id.pullView);
		rPullDrawable = this.getResources().getDrawable(R.drawable.progress_circular);
		pullView.setOnHeaderRefreshListener(this);
		pullView.getHeaderView().setHeaderProgressBarDrawable(rPullDrawable);
		pullView.setPullRefreshEnable(true);
		pullView.setLoadMoreEnable(false);
	}
	
	private void findOptPanel(){
		vOptPanel = this.findViewById(R.id.frag_vorder_co_option_panel);
		layout = (LinearLayout) this.findViewById(R.id.layout_toast);
		vCallTel = (TextView) this.findViewById(R.id.tv_call_tel);
		btnPhone = (Button)this.findViewById(R.id.btn_call_tel);
		vOptBtn = (TextView) this.findViewById(R.id.frag_vorder_co_opt_btn);
		vOptBtn2 = (TextView) this.findViewById(R.id.frag_vorder_co_opt);
		btnNavigator = (Button) this.findViewById(R.id.btn_navigator);
		tvToast = (TextView) this.findViewById(R.id.tv_parking_toast);
//		tvToast.setVisibility(View.GONE);
		
		btnNavigator.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				launchNavigator();
			}
		});
		
		vOptBtn2.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(parkDefault) {
					// 停车失败
					Log.i("TEST", "停车失败");
					getFastParkOrder(mModel.getArea_id(), mModel.getId(), mModel.getArea_name());
//					getFastParkOrder("3", mModel.getId(), mModel.getArea_name());
				}else {
					doCancelOrder();
				}
			}
		});
		
		btnPhone.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
//				Toast.makeText(mOwner, "打电话通知物业", Toast.LENGTH_SHORT).show();
				makeCall(mOwner, vCallTel.getText().toString());
			}
		});
	}
	
	private void findTimePanel(){
		vTime = (Chronometer) this.findViewById(R.id.layout_time_timer);
		vTimePanel = this.findViewById(R.id.frag_vorder_co_carintime_panel);
	}
	
	/**
	 * 启动GPS导航. 前置条件：导航引擎初始化成功
	 */
	private void launchNavigator(){
		//可以通过POI检索、外部POI来源等方式获取起终点坐标
		
		BNaviPoint startPoint = new BNaviPoint( MapLocationActivity.mCurrentLongitude, MapLocationActivity.mCurrentLantitude,  
		        "起始位置", BNaviPoint.CoordinateType.BD09_MC);  
		BNaviPoint endPoint = new BNaviPoint(113.315807, 23.133144, 
		        "金羊花园", BNaviPoint.CoordinateType.BD09_MC);
		Log.i("TEST","launchNavigator1");
		BaiduNaviManager.getInstance().launchNavigator(mOwner,
//				MapLocationActivity.mCurrentLantitude, MapLocationActivity.mCurrentLongitude,"起始位置", 
//		        23.133144, 113.315807,"金羊花园",
				startPoint,
				endPoint,
				NE_RoutePlan_Mode.ROUTE_PLAN_MOD_MIN_TIME, 		 //算路方式
				true, 									   		 //真实导航
				BaiduNaviManager.STRATEGY_FORCE_ONLINE_PRIORITY, //在离线策略
				new OnStartNavigationListener() {				 //跳转监听
					
					@Override
					public void onJumpToNavigator(Bundle configParams) {
						Log.i("TEST","launchNavigator2");
						Intent intent = new Intent(mOwner, NavigatorActivity.class);
						intent.putExtras(configParams);
						Log.i("TEST","launchNavigator3");
				        startActivity(intent);
					}
					
					@Override
					public void onJumpToDownloader() {
					}
				});
	}
	
	/**
	 * 打电话
	 * @param context
	 * @param phone
	 */
	public static void makeCall(Context context, String phone) {
		Uri uri = Uri.parse("tel:" + phone);
		Intent it = new Intent(Intent.ACTION_CALL, uri);
		context.startActivity(it);
	}
	
	/**
	 * 取消预约
	 */
	private void doCancelOrder() {
		curShowView = "doCancelOrder";
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("method", "cancel_2005");
		params.addBodyParameter("task_id",(mOwner).getOrderViewModel().getId());
		Log.i(TAG, "ServerURL:"+ServerURL +"  method:cancel_2005"+ " task_id:"+mOwner.getOrderViewModel().getId());
		HttpUtils http = new HttpUtils(6000);
		showProgDialog("正在取消预约 . . .", http);
		http.send(HttpMethod.POST, 
				ServerURL,
				params,
				new RequestCallBack< String >() {

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// TODO Auto-generated method stub
						Log.i(TAG, responseInfo.result);
						if(curShowView.equals("doCancelOrder")) {
							try {
								JSONObject jsob = new JSONObject(responseInfo.result);
								boolean bo = jsob.getBoolean("success");
								String msg = jsob.getString("msg");
								Toast.makeText(mOwner, msg, Toast.LENGTH_SHORT).show();
								if(bo) {
									isForce = true;
									initParkView();
									boolean bon = isNetConnected();
									if(bon) {
									    getParkByDate();
									    getParkByDate("big", 0);
									    getParkByDate("middle", 1);
									    getFastParkInfo();
									}else {
										Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
									}
									isFirstLoc = false;
								}
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								Toast.makeText(getApplicationContext(), "获取数据错误", Toast.LENGTH_SHORT).show();
								e.printStackTrace();
							}
							if(dialog != null) {
								dialogDismiss = 1;
								dialog.dismiss();
							}
						}
					}

					@Override
					public void onFailure(HttpException error, String msg) {
						// TODO Auto-generated method stub
						if(curShowView.equals("doCancelOrder")) {
							Toast.makeText(mOwner, "取消预约失败，请稍后再试", Toast.LENGTH_SHORT).show();
						}
						if(dialog != null) {
							dialogDismiss = 1;
							dialog.dismiss();
						}
					}
				});
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {

		// TODO Auto-generated method stub
		Log.i("qh", "car frag : on activity result : req_ "+requestCode +" , res_ "+resultCode);
		if(requestCode == REQ_CODE_CAPTURE){
			if(resultCode == Activity.RESULT_OK ){
				if(mOwner.getState() == IServer.PARKING_STATE_CONFIRM){//进场成功
					getOrderModelFromServer();
				}else{//离场成功
					initParkView();
					boolean bo = isNetConnected();
					if(bo) {
					    getParkByDate();
					    getParkByDate("big", 0);
					    getParkByDate("middle", 1);
					}else {
						Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
					}
					isFirstLoc = false;
				}
			}else if(resultCode == 100) {
				getIsHaveOrder();
			}else {
				showConfirmDialog();
			}
		}
	
	}

	private int getState() {
		// 
		return mState;
	}
	
	private AlertDialog mConfirmDialog;
	private void showConfirmDialog(){
		Log.i("qh", "show dialog confirm");
		if (mConfirmDialog == null) {
			AlertDialog.Builder builder = new AlertDialog.Builder(mOwner);
			builder
				.setTitle("扫描操作信息")
				.setCancelable(true)
					.setPositiveButton("联系物业",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int id) {
									mConfirmDialog.dismiss();
									mOwner.requestQuartOwner();
								}
							})
					.setNegativeButton("重新扫描",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int id) {
									mConfirmDialog.dismiss();
									scan();
								}
							});
			mConfirmDialog = builder.create();
		}
		mConfirmDialog.setMessage("扫描失败");
		mConfirmDialog.show();
	}
	
	private void scan(){
		ScanTask task = new ScanTask();
		task.setTask_id(mOwner.getOrderViewModel().getId());
		task.setNumOfScan(mOwner.getState() == IServer.PARKING_STATE_CONFIRM ? "1" : "2");
		Intent intent = new Intent(mOwner, CaptureActivity.class);
		intent.putExtra(ParkingConstant.INTENT_EXTRA_OBJ_SCANTASK, task);
		mOwner.startActivityForResult(intent, REQ_CODE_CAPTURE);
	}
	
	/**
	 * 联系物业
	 */
	public void requestQuartOwner() {
//		showProgressDialog(); 
		getJsonFromServer(mServer.getURL(
				IServer.URL_FLAG_POST_NEED_QUARTER_GUARD, mModel.getId()));
		mWaitForQuartOwner = true;
	}
	protected IServer mServer;
	
	private void getJsonFromServer(String url) {
		boolean bo = isNetConnected();
		if(!bo) {
			Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
			return;
		}
		HttpUtils http = new HttpUtils();
		http.configDefaultHttpCacheExpiry(5000);// 5秒内请求 使用缓存
		Log.i("qh", "url : " + url);
		http.send(HttpMethod.GET, url, new RequestCallBack<String>() {

			@Override
			public void onSuccess(ResponseInfo<String> responseInfo) {
				// TODO Auto-generated method stub
				Log.i("qh", "result from cache : "
						+ responseInfo.resultFormCache);
				Log.i("qh", "result code : " + responseInfo.statusCode);
				pullViewNull.onHeaderRefreshFinish();
				pullViewOrder.onHeaderRefreshFinish();
				callbackFromGetJsonSuccess(responseInfo.result);
			}

			@Override
			public void onFailure(HttpException error, String msg) {
				// TODO Auto-generated method stub
				pullViewNull.onHeaderRefreshFinish();
				pullViewOrder.onHeaderRefreshFinish();
				callbackFromGetJsonFail(error.getExceptionCode(), msg);
			}
		});
	}
	
	@SuppressWarnings("deprecation")
	private void callbackFromGetJsonSuccess(String json) {
		// empty
//		try {
//			dismissDialog(DIALOG_PROGRESS);
//		} catch (Exception e) {
//			// TODO: handle exception
//		}
		
		if (mWaitForQuartOwner) {
			handleReqQuartOwnerSuccess(json);
			return;
		}
		Log.i("qh", "json : " + json);
		Gson gson = new Gson();
		mModel = gson.fromJson(json, OrderViewModel.class);
		if (mModel == null) {
			handleNoModel();
			return;
		}
		try {
			mState = Integer.valueOf(mModel.getState_int());
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			handleNoModel();
			return;
		}
		if (mFragReqRefreshModel) {
			//更新UI
//			refreshFrag();
			initViews();
			mFragReqRefreshModel = false;
			return;
		}
		if(mState == 3 || mState == 7) {
			initParkView();
			boolean bo = isNetConnected();
			if(bo) {
			    getParkByDate();
			    getParkByDate("big", 0);
			    getParkByDate("middle", 1);
			}else {
				Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
			}
			isFirstLoc = false;
			return;
		}
		initViews();
		//更新UI
//		handleUI();  
	}

	@SuppressWarnings("deprecation")
	private void callbackFromGetJsonFail(int failcode, String msg) {
		// empty
//		dismissDialog(DIALOG_PROGRESS);
		if (mWaitForQuartOwner) {
			handleReqQuartOwnerFail(failcode, msg);
			return;
		}
		handleNoModel();
	}
	
	private void handleReqQuartOwnerFail(int failcode, String msg) {
		showToastTips("联系物业失败.请稍后重试...");
		mWaitForQuartOwner = false;
	}

	private void handleReqQuartOwnerSuccess(String json) {
		showToastTips("已成功通知物业");
		mWaitForQuartOwner = false;
		reqRefreshFromFragUI();
	}
	
	public void showToastTips(String text) {
		Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
	}
	
	private void handleNoModel() {
		showToastTips("加载数据失败");
//		finish();
		scrollvOrder.setVisibility(View.GONE);
		pullViewNull.setVisibility(View.VISIBLE);
	}
	
	public void reqRefreshFromFragUI() {
		mFragReqRefreshModel = true;
		getOrderModelFromServer();
	}
	
//	method=2007 {"state_int":"4","isShowCancelButton":false,"car_out_time":null,"boss_id":"907181297710",
//	"end_hour":"2015-01-07 18:00:00","state":"预约成功","car_in_time":null,"isShowTextView":true,
//	"booked_time_range":"01-07 09:50~10:20","worker_name":"huxs","id":"1767","price":"3.0元/小时",
//	"start_hour":"2015-01-07 09:00:00","area_name":"金羊小区","parking_no":"金羊小区,jy005","boss_name":"xixi",
//	"task_date":"2015-01-07","accept_time":"2015-01-07 09:42:07","worker_id":"813966819852","car_no":"粤AXXXXX"}
	private void getOrderModelFromServer() {
		boolean bo = isNetConnected();
		if(!bo) {
			Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
			return;
		}
		getJsonFromServer(mServer.getURL(IServer.URL_FLAG_GET_ORDER_VIEW,
				mOrderId));
	}
	
	private boolean parseIntent() {
		Intent intent = getIntent();
		if (intent == null) {
			return false;
		}
		String orderid = intent
				.getStringExtra(ParkingConstant.INTENT_EXTRA_ORDER_ID);
		if (AbStrUtil.isEmpty(orderid)) {
			return false;
		}
		mOrderId = orderid;
		isFromSystem = intent.getBooleanExtra(
				ParkingConstant.INTENT_EXTRA_BOOL_FROM_SYSMSG, false);
		return true;
	}
	
	private void initViews(){
		vBaseQuarter.setText(mOwner.getOrderViewModel().getParking_no());
		vBaseState.setText(mOwner.getOrderViewModel().getState());
		vBasePrice.setText(mOwner.getOrderViewModel().getPrice());
		vBaseTime.setText(mOwner.getOrderViewModel().getBooked_time_range());
		vBaseParkingOwner.setText(mOwner.getOrderViewModel().getBoss_name());
		vBaseOrderId.setText(mOwner.getOrderViewModel().getOrder_id());
		
		scrollvOrder.setVisibility(View.VISIBLE);
		pullViewOrder.setVisibility(View.VISIBLE);
		pullViewNull.setVisibility(View.GONE);
		
		rlayoutMyorder.setVisibility(View.VISIBLE);
		llFastpark.setVisibility(View.GONE);
		
		if(mOwner.getState() == IServer.PARKING_STATE_CONFIRM) {
			btnNavigator.setVisibility(View.VISIBLE);
		}else {
			btnNavigator.setVisibility(View.INVISIBLE);
		}
		Log.i("qh", "mState : "+mOwner.getState());
		vTimePanel.setVisibility(View.GONE);
		if(mOwner.getState() == IServer.PARKING_STATE_CONFIRM
				|| mOwner.getState() == IServer.PARKING_STATE_CAR_IN){
			initOptAndTimeViews();
		}else if(mOwner.getState() == IServer.PARKING_STATE_WAIT_CONFIRM) {
			vOptBtn2.setVisibility(View.GONE);
			vOptBtn.setText("取消预约");
			vOptBtn.setOnClickListener(this);
			vOptPanel.startAnimation(AnimationUtils.loadAnimation(mOwner, R.anim.visible_from_bottom));
			vOptPanel.setVisibility(View.VISIBLE);
			tvToast.setVisibility(View.VISIBLE);
		}else if(mOwner.getState() == IServer.PARKING_STATE_WAIT_QUARTER) {
			vCallTel.setText("12345678911");
			btnPhone.setText("18923456789");
			layout.setVisibility(View.VISIBLE);
			vOptPanel.setVisibility(View.GONE);
			tvToast.setVisibility(View.GONE);
			return;
		}else {
			vOptPanel.setVisibility(View.GONE);
			tvToast.setVisibility(View.GONE);
		}
	}

	private boolean parkDefault = false;   // 停车失败
	private boolean carInParkDefault = false;  // 进场后 停车失败
	private void initOptAndTimeViews(){
		if(mOwner.getState() == IServer.PARKING_STATE_CONFIRM){
			int check1 = 0;
			int check2 = 0;
			vOptBtn2.setVisibility(View.GONE);
			parkDefault = false;
			carInParkDefault = false;
			
			if(mOwner.getOrderViewModel().getIsShowCancelButton()) {   // 判断是否可取消，进场时间前1个小时不允许取消预约
				vOptBtn2.setText("取消预约");
				vOptBtn2.setVisibility(View.VISIBLE);
				layout.setVisibility(View.GONE);
				Log.i("TEST 取消预约  : ", mOwner.getOrderViewModel().getStart_hour());
				check1 = 1;
			}
			if(mOwner.getOrderViewModel().getIsShowTextView()) {  // 判断是否可进场，只允许提前30分钟
				vOptBtn.setText("扫描进场");
				vOptBtn2.setText("停车失败");
				vOptBtn2.setVisibility(View.VISIBLE);
				vOptBtn.setVisibility(View.VISIBLE);
				layout.setVisibility(View.GONE);
				tvToast.setVisibility(View.VISIBLE);
				Log.i("TEST 进场扫描  : ", mOwner.getOrderViewModel().getStart_hour());         
				check2 = 1;
				parkDefault = true;
			}else {
				vOptBtn.setVisibility(View.GONE);
			} 
			if(check1 == 0 && check2 == 0) {
				vOptPanel.setVisibility(View.GONE);
				return;
			}
		}else{
			vTimePanel.setVisibility(View.VISIBLE);
			vOptBtn2.setVisibility(View.VISIBLE);   //////////////////////////////////////////////////////////!!!!!!!!!!!!!!!!
			tvToast.setVisibility(View.GONE);

			long lastescape = 0;
			if(mInTime != null){
				long now = System.currentTimeMillis();
				lastescape = now - mInTime.getTime();
				Log.i("qh", "car_in_time getTime : "+ mInTime.getTime());
			}
			long now = System.currentTimeMillis();
			lastescape = now - getTime(mOwner.getOrderViewModel().getCar_in_time());
			if(lastescape < 0){
				lastescape = 0;
			}
			vTime.setBase(SystemClock.elapsedRealtime() - lastescape);
			vTime.start();
			vOptBtn.setText("离场扫描");
			vOptBtn2.setText("停车失败");
			layout.setVisibility(View.GONE);
			btnNavigator.setVisibility(View.GONE);
			parkDefault = true;
			carInParkDefault = true;
		}
		vOptBtn.setOnClickListener(this);
		vOptPanel.startAnimation(AnimationUtils.loadAnimation(mOwner, R.anim.visible_from_bottom));
		vOptPanel.setVisibility(View.VISIBLE);
		
	}
	
	private long getTime(String time) {
		SimpleDateFormat format= new SimpleDateFormat("yyyy-MM-dd kk:mm:ss");
		long timeStart = System.currentTimeMillis();
		try {
			timeStart=format.parse(time).getTime();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return timeStart;
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
			if(mOwner.getState() == IServer.PARKING_STATE_CONFIRM
			|| mOwner.getState() == IServer.PARKING_STATE_CAR_IN){
				scan();
			}else{
				doCancelOrder();
			}
	}
	
	Handler mapHandler = new Handler(){

		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			switch(msg.what) {
			case 0:
				showOrderView((String) msg.obj);
				break;
			case 1:
				getFastParkInfo();
				break;
			}
		}
		
	};
	
	private boolean isForce = false;
	private void getIsHaveOrder() {
		boolean bo = isNetConnected();
		if(!bo) {
			Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
			return;
		}
		curShowView = "getIsHaveOrder";
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("method", "2003");
		
		HttpUtils http = new HttpUtils(6000);
		showProgDialog("正在查询订单 . . .", http);
		http.send(HttpMethod.POST, 
				ServerURL, 
				params, 
				new RequestCallBack<String>() {

			@Override
			public void onSuccess(ResponseInfo<String> responseInfo) {
				// TODO Auto-generated method stub
				if(curShowView.equals("getIsHaveOrder")) {
					String str = null;
					Log.i(TAG, "getIsHaveOrder" + responseInfo.result);
					try {
						byte[] bt = responseInfo.result.getBytes();
						str = new String(bt, "UTF-8");
					} catch (UnsupportedEncodingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					if(dialog != null) {
						dialogDismiss = 1;
						dialog.dismiss();
					}
					try {
						JSONObject jsob = new JSONObject(str);
						int count = jsob.getInt("totalCount");
						
						if(count == 0) {
							pullViewOrder.onHeaderRefreshFinish();
							initParkView();
							boolean bo = isNetConnected();
							if(bo) {
								isForce = true;
							    getParkByDate();
							    getParkByDate("big", 0);
							    getParkByDate("middle", 1);
							}else {
								Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
							}
							isFirstLoc = false;
							return;
						}else {
							JSONArray jsoa = jsob.getJSONArray("data");
							JSONObject jso = jsoa.getJSONObject(0);
							mOrderId = jso.getString("id");
							getOrderModelFromServer();
						}						
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						Toast.makeText(getApplicationContext(), "获取数据错误", Toast.LENGTH_SHORT).show();
						e.printStackTrace();
					}
					
				}
			}

			@Override
			public void onFailure(HttpException error, String msg) {
				// TODO Auto-generated method stub
				pullViewOrder.onHeaderRefreshFinish();
				if(dialog != null) {
					dialogDismiss = 1;
					dialog.dismiss();
				}
			}
		});
	
	}
	
	private void onRefresh() {
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("method", "2003");
		
		HttpUtils http = new HttpUtils(6000);
		http.send(HttpMethod.POST, 
				ServerURL, 
				params, 
				new RequestCallBack<String>() {

			@Override
			public void onSuccess(ResponseInfo<String> responseInfo) {
				// TODO Auto-generated method stub
					String str = null;
					Log.i(TAG, "getIsHaveOrder" + responseInfo.result);
					try {
						byte[] bt = responseInfo.result.getBytes();
						str = new String(bt, "UTF-8");
					} catch (UnsupportedEncodingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					try {
						JSONObject jsob = new JSONObject(str);
						int count = jsob.getInt("totalCount");
						
						if(count == 0) {
							pullViewNull.onHeaderRefreshFinish();
							initParkView();
							boolean bo = isNetConnected();
							if(bo) {
							    getParkByDate();
							    getParkByDate("big", 0);
							    getParkByDate("middle", 1);
							}else {
								Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
							}
							isFirstLoc = false;
							return;
						}
						
						JSONArray jsoa = jsob.getJSONArray("data");
						JSONObject jso = jsoa.getJSONObject(0);
						mOrderId = jso.getString("id");
						getOrderModelFromServer();
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						Toast.makeText(getApplicationContext(), "获取数据错误", Toast.LENGTH_SHORT).show();
						e.printStackTrace();
					}
//					pullViewNull.onHeaderRefreshFinish();
			}

			@Override
			public void onFailure(HttpException error, String msg) {
				// TODO Auto-generated method stub
				boolean bo = isNetConnected();
				if(!bo) {
					Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
				}
				pullViewNull.onHeaderRefreshFinish();
			}
		});
	}
	
	private void showMoreTime() {
		final LinearLayout location =  (LinearLayout) View.inflate(MapLocationActivity.this,R.layout.popw_moretime, null);
		pwMoreTime = new PopupWindow(location, LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
		final RadioButton rbThree = (RadioButton) location.findViewById(R.id.rb_three);
		final RadioButton rbFour = (RadioButton) location.findViewById(R.id.rb_four);
		Button btnOk = (Button) location.findViewById(R.id.btn_ok);
		final EditText edTime = (EditText) location.findViewById(R.id.ed_time);
		
		rbThree.setChecked(true);
		edTime.addTextChangedListener(new TextWatcher() {
			
			@Override
			public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void beforeTextChanged(CharSequence arg0, int arg1, int arg2,
					int arg3) {
				// TODO Auto-generated method stub
				rbThree.setChecked(false);
				rbFour.setChecked(false);
			}
			
			@Override
			public void afterTextChanged(Editable arg0) {
				// TODO Auto-generated method stub
				int i = 1;
				try {
					 i = Integer.valueOf(edTime.getText().toString());
				}catch(Exception ex) {
					i = 1;
				}
				if(i > 24){
					edTime.setText("24");
				}
			}
		});
		
		btnOk.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				if(rbThree.isChecked()) {
					tvMoretime.setText("已选择停车 3 小时");
					parkTime = 3;
					rbOne.setChecked(false);
					rbTwo.setChecked(false);
					pwMoreTime.dismiss();
					getFastParkInfo(3);
					return;
				}
				if(rbFour.isChecked()) {
					tvMoretime.setText("已选择停车 4 小时");
					parkTime = 4;
					rbOne.setChecked(false);
					rbTwo.setChecked(false);
					pwMoreTime.dismiss();
					getFastParkInfo(4);
					return;
				}
				int i = 0;
				try {
					i = Integer.valueOf(edTime.getText().toString());
				}catch (Exception ex) {
					tvMoretime.setText("已选择停车 2 小时");
					parkTime = 2;
					rbTwo.setChecked(true);
					pwMoreTime.dismiss();
					getFastParkInfo(2);
					return;
				}
				if( i<=0 || i>24) {
					tvMoretime.setText("已选择停车 2 小时");
					parkTime = 2;
					rbTwo.setChecked(true);
					pwMoreTime.dismiss();
					getFastParkInfo(2);
					return;
				}else {
					tvMoretime.setText("已选择停车 "+i+" 小时");
					parkTime = i;
					rbOne.setChecked(false);
					rbTwo.setChecked(false);
					pwMoreTime.dismiss();
					getFastParkInfo(i);
					return;
				}
			}
		});
		
		pwMoreTime.setBackgroundDrawable(new PaintDrawable(0x00000000));  
		pwMoreTime.setOutsideTouchable(false);
		pwMoreTime.setFocusable(true);
		pwMoreTime.showAtLocation(location, Gravity.CENTER, 0, 0);
	
	}
	
	//{"totalCount":1,  "data":[{"id":"3","distance":89.0,"num":2,"name":"金羊小区"}]}
	private void getFastParkInfo() {
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("method", "2030");
		params.addBodyParameter("lant", String.valueOf(mCurrentLantitude));
		params.addBodyParameter("lng", String.valueOf(mCurrentLongitude));
		params.addBodyParameter("hour", String.valueOf(parkTime));   // 

		Log.i("TEST", "POST URL : " + ServerURL+"?uid="+ParkingApp.mAppCtx.getUID()+"&utype="+ParkingApp.mAppCtx.getUType()
				+"&method=2030&hour="+ String.valueOf(parkTime)
				+"&lant="+String.valueOf(mCurrentLantitude)+
				"&lng="+String.valueOf(mCurrentLongitude));
		
		HttpUtils http = new HttpUtils(6000);
		http.send(HttpMethod.POST, 
				ServerURL, 
				params, 
				new RequestCallBack<String>() {

			@Override
			public void onSuccess(ResponseInfo<String> responseInfo) {
				// TODO Auto-generated method stub
					String str = null;
					Log.i(TAG, "getFastParkInfo : " + responseInfo.result);
					try {
						JSONObject jsob = new JSONObject(responseInfo.result);
						int count = jsob.getInt("totalCount");
						if(count == 0) {
							tvParknull.setText("没有符合条件的车位，下拉可刷新");
							pullViewParknull.setVisibility(View.VISIBLE);
							pullView.setVisibility(View.GONE);
						}else {
							JSONArray jsoa = jsob.getJSONArray("data");
							mFastParkInfo = new ArrayList<FastParkInfo>();
							for(int i=0; i< count; i++) {	
								FastParkInfo info = new FastParkInfo();
								JSONObject jso = jsoa.getJSONObject(i);
								info.setId(jso.getString("id"));
								info.setName(jso.getString("name"));
								info.setNum(jso.getInt("num"));
								info.setDistance(jso.getDouble("distance"));
								mFastParkInfo.add(info);
							}
//							showToastTips("车位刷新成功");
							showPopw();
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					pullViewParknull.onHeaderRefreshFinish();
					pullView.onHeaderRefreshFinish();
			}

			@Override
			public void onFailure(HttpException error, String msg) {
				// TODO Auto-generated method stub
				boolean bo = isNetConnected();
				if(!bo) {
					Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
				}
				pullViewParknull.onHeaderRefreshFinish();
				pullView.onHeaderRefreshFinish();
			}
		});
	}
	
	private void getFastParkInfo(int i) {
		curShowView = "getFastParkInfoDetail";
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("method", "2030");
		params.addBodyParameter("lant", String.valueOf(mCurrentLantitude));
		params.addBodyParameter("lng", String.valueOf(mCurrentLongitude));
		params.addBodyParameter("hour", String.valueOf(parkTime));  

		Log.i("TEST", "POST URL : " + ServerURL+"?uid="+ParkingApp.mAppCtx.getUID()+"&utype="+ParkingApp.mAppCtx.getUType()
				+"&method=2030&hour="+ String.valueOf(parkTime)
				+"&lant="+String.valueOf(mCurrentLantitude)
				+"&lng="+String.valueOf(mCurrentLongitude) );
		
		HttpUtils http = new HttpUtils(6000);
		http.configSoTimeout(6000);
		showProgDialog("正在查询车位 . . .", http);
		http.send(HttpMethod.POST, 
				ServerURL, 
				params, 
				new RequestCallBack<String>() {

			@Override
			public void onSuccess(ResponseInfo<String> responseInfo) {
				// TODO Auto-generated method stub
					String str = null;
					Log.i(TAG, "getFastParkInfo : " + responseInfo.result);
					try {
						JSONObject jsob = new JSONObject(responseInfo.result);
						int count = jsob.getInt("totalCount");
						if(count == 0) {
							tvParknull.setText("没有符合条件的车位，下拉可刷新");
							pullViewParknull.setVisibility(View.VISIBLE);
							pullView.setVisibility(View.GONE);
						}else {
							JSONArray jsoa = jsob.getJSONArray("data");
							mFastParkInfo = new ArrayList<FastParkInfo>();
							for(int i=0; i< count; i++) {	
								FastParkInfo info = new FastParkInfo();
								JSONObject jso = jsoa.getJSONObject(i);
								info.setId(jso.getString("id"));
								info.setName(jso.getString("name"));
								info.setNum(jso.getInt("num"));
								info.setDistance(jso.getDouble("distance"));
								mFastParkInfo.add(info);
							}
							showToastTips("车位刷新成功");
							showPopw();
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					if(dialog != null) {
						dialogDismiss = 1;
						dialog.dismiss();
					}
					pullViewParknull.onHeaderRefreshFinish();
					pullView.onHeaderRefreshFinish();
			}

			@Override
			public void onFailure(HttpException error, String msg) {
				// TODO Auto-generated method stub
				boolean bo = isNetConnected();
				if(!bo) {
					Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
				}
				if(dialog != null) {
					dialogDismiss = 1;
					dialog.dismiss();
				}
				pullViewParknull.onHeaderRefreshFinish();
				pullView.onHeaderRefreshFinish();
			}
		});
	}
	
	private void getFastParkOrder(final String areaId, final String hour, final String parkname, final int num) {
		boolean bo = isNetConnected();
		if(!bo) {
			Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
			return;
		}
		curShowView = "getFastParkOrder";
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("method", "2031");
		params.addBodyParameter("area_id", areaId);
		params.addBodyParameter("hour", hour);
		
		Log.i("TEST", "POST URL : " + ServerURL+"?uid="+ParkingApp.mAppCtx.getUID()+"&utype="+ParkingApp.mAppCtx.getUType()
				+"&method=2031"
				+"&area_id="+areaId
				+"&hour="+hour);
		HttpUtils http = new HttpUtils(6000);
		showProgDialog("正在进行查询 . . .", http);
		http.send(HttpMethod.POST, 
				ServerURL, 
				params, 
				new RequestCallBack<String>() {

			@Override
			public void onSuccess(ResponseInfo<String> responseInfo) {
				// TODO Auto-generated method stub
				Log.i("TEST", "curShowView : " + curShowView);
				if(curShowView.equals("getFastParkOrder")) {
					Log.i(TAG, "getFastParkOrder : " + responseInfo.result);
					try {
						JSONObject jsob = new JSONObject(responseInfo.result);
						int count = jsob.getInt("totalCount");
						if(count == 0) {
							if(dialog != null) {
								dialogDismiss = 1;
								dialog.dismiss();
							}
							showTipsDialog("当前小区没有合适车位可用");
							return;
						}else {
							//parking_no：车位号 price:价格 time_range---可用时间   task_id--停车信息id
							JSONArray jsoa = jsob.getJSONArray("data");
//							int r = (int) (Math.random()*(count-1));
							int r = 0;
							for(int i=1; i<count; i++) {
								JSONObject jsoR = jsoa.getJSONObject(r);
								JSONObject jsoI = jsoa.getJSONObject(i);
								if(Double.valueOf(jsoR.getString("price")) > Double.valueOf(jsoI.getString("price"))) {
									r = i;
								}else if(Double.valueOf(jsoR.getString("price")).equals(Double.valueOf(jsoI.getString("price"))) ){
									int rr = (int) (Math.random()*(10));
									int ri = (int) (Math.random()*(10));
//									Log.i("TEST", "random : "+rr + " : " + ri);
									if(rr < ri){
										r = i;
									}
								}
							}
							Log.i("TEST", "random : "+ r);
							JSONObject jso = jsoa.getJSONObject(r);
							Intent intent = new Intent(MapLocationActivity.this, FastParkingActivity.class);
							Bundle bundle = new Bundle();
							bundle.putString("parkTime", hour);
							bundle.putString("parkName", parkname);
							bundle.putString("parkNo", jso.getString("parking_no"));
							bundle.putString("price", jso.getString("price"));
							bundle.putString("timeRange", jso.getString("time_range"));
							bundle.putString("taskId", jso.getString("task_id"));
							bundle.putInt("num", num);
							intent.putExtras(bundle);
							startActivity(intent);
						}						
						if(dialog != null) {
							dialogDismiss = 1;
							dialog.dismiss();
						}
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				if(dialog != null) {
					dialogDismiss = 1;
					dialog.dismiss();
				}
			}

			@Override
			public void onFailure(HttpException error, String msg) {
				// TODO Auto-generated method stub
				if(curShowView.equals("getFastParkOrder")) {
					showTipsDialog("查询失败，请检查网络连接，稍后再试");
				}
				if(dialog != null) {
					dialogDismiss = 1;
					dialog.dismiss();
				}
			}
		});
	}
	
//	停车失败也相当于取消了订单，并再次查询小区列表： 
//	参数：method:2031 ，area_id:小区id，task_id: 停车信息id （跟上面共用2031方法，参数不同）
//	返回：json list 格式    parking_no：车位号 price:价格 time_range---可用时间   task_id--停车信息id
	private void getFastParkOrder(final String areaId, String taskId, final String parkname) {
		boolean bo = isNetConnected();
		if(!bo) {
			Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
			return;
		}
		curShowView = "getFastParkOrder";
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("method", "2031");
		params.addBodyParameter("area_id", areaId);
		params.addBodyParameter("task_id", taskId);
		
		Log.i("TEST", "POST URL : " + ServerURL+"?uid="+ParkingApp.mAppCtx.getUID()+"&utype="+ParkingApp.mAppCtx.getUType()
				+"&method=2031"
				+"&area_id="+areaId
				+"&task_id="+taskId);
		HttpUtils http = new HttpUtils(6000);
		showProgDialog("正在处理订单 . . .", http);
		http.send(HttpMethod.POST, 
				ServerURL, 
				params, 
				new RequestCallBack<String>() {

			@Override
			public void onSuccess(ResponseInfo<String> responseInfo) {
				// TODO Auto-generated method stub
				if(!carInParkDefault) {
					showToastTips("订单已取消");
				}
				String str = null;
				Log.i(TAG, "getFastParkInfo : " + responseInfo.result);
				try {
					JSONObject jsob = new JSONObject(responseInfo.result);
					int count = jsob.getInt("totalCount");
					if(count == 0) {
						tvParknull.setText("没有符合条件的车位");
						pullViewParkNull.setVisibility(View.VISIBLE);
						pullViewPark.setVisibility(View.GONE);
					}else {
						JSONArray jsoa = jsob.getJSONArray("data");
						fastParkDetailInfo = new ArrayList<FastParkDetailInfo>();
						parkName = parkname;
						for(int i=0; i< count; i++) {	
							FastParkDetailInfo info = new FastParkDetailInfo();
							JSONObject jso = jsoa.getJSONObject(i);
							info.setParking_no(jso.getString("parking_no"));
							info.setPrice(jso.getString("price"));
							info.setTask_id(jso.getString("task_id"));
							info.setTime_range(jso.getString("time_range"));
							fastParkDetailInfo.add(info);
						}
						showFastParkDetailView();
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(dialog != null) {
					dialogDismiss = 1;
					dialog.dismiss();
				}
				pullViewParknull.onHeaderRefreshFinish();
				pullView.onHeaderRefreshFinish();
		}

			@Override
			public void onFailure(HttpException error, String msg) {
				// TODO Auto-generated method stub
				if(curShowView.equals("getFastParkOrder")) {
					showTipsDialog("查询失败，请检查网络连接，稍后再试");
				}
				if(dialog != null) {
					dialogDismiss = 1;
					dialog.dismiss();
				}
			}
		});
	}
	
	private TextView tvParkname, tvCancel;
	private AbPullToRefreshView pullViewParkNull, pullViewPark;
	private LinearLayout llFastpark;
	private List<FastParkDetailInfo> fastParkDetailInfo = new ArrayList<FastParkDetailInfo>();
	private String parkName = "小  区";
	private ListView lvFastParkDetail;
	private Button btnOther;
	
	private void initFaskParkingListView() {
		llFastpark = (LinearLayout) this.findViewById(R.id.rlayout_fastparkinglist);
		lvFastParkDetail = (ListView) this.findViewById(R.id.lv_fastparkdetail);
		tvParkname = (TextView) this.findViewById(R.id.tv_parkname);
		tvCancel = (TextView) this.findViewById(R.id.tv_cancel);
		btnOther = (Button) this.findViewById(R.id.btnOther);
		pullViewPark = (AbPullToRefreshView) this.findViewById(R.id.pullview_park);
		pullViewParkNull = (AbPullToRefreshView) this.findViewById(R.id.pullview_parknull);
		
		pullViewPark.setOnHeaderRefreshListener(this);
		pullViewPark.getHeaderView().setHeaderProgressBarDrawable(rPullDrawable);
		pullViewPark.setPullRefreshEnable(false);
		pullViewPark.setLoadMoreEnable(false);
		
		pullViewParkNull.setOnHeaderRefreshListener(this);
		pullViewParkNull.getHeaderView().setHeaderProgressBarDrawable(rPullDrawable);
		pullViewParkNull.setPullRefreshEnable(false);
		pullViewParkNull.setLoadMoreEnable(false);
	}
	
	private void showFastParkDetailView() {
		llFastpark.setVisibility(View.VISIBLE);
		rlayoutMyorder.setVisibility(View.GONE);
		pullViewParkNull.setVisibility(View.GONE);
		pullViewPark.setVisibility(View.VISIBLE);
		tvParkname.setText(parkName);
		if(carInParkDefault) {
			btnOther.setText("结 束 停 车");
			tvCancel.setText("可预约当前小区其他可用车位");
		}else {
			btnOther.setText("其 他 小 区");
			tvCancel.setText("订单已取消，可预约当前小区其他可用车位");
		}
		FastParkDetaiListAdapter adapter = new FastParkDetaiListAdapter(this, fastParkDetailInfo);
		lvFastParkDetail.setAdapter(adapter);
		lvFastParkDetail.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				FastParkDetailInfo info = fastParkDetailInfo.get(arg2);
				Intent intent = new Intent(MapLocationActivity.this, FastParkingActivity.class);
				Bundle bundle = new Bundle();
				if(carInParkDefault) {
					String str1[] = mModel.getBooked_time_range().split(" ");
					String str2[] = str1[1].split("\\~");
					String str3[] = str2[0].split("\\:");
					String str4[] = str2[1].split("\\:");
					int h1 = Integer.valueOf(str3[0]);
					int h2 = Integer.valueOf(str4[0]);
					String time = String.valueOf( (h2-h1) );
					bundle.putString("parkTime", String.valueOf(time));
				}else {
					bundle.putString("parkTime", String.valueOf(parkTime));
				}
				bundle.putString("parkName", parkName);
				bundle.putString("parkNo", info.getParking_no());
				bundle.putString("price", info.getPrice());
				bundle.putString("timeRange", info.getTime_range());
				bundle.putString("taskId", info.getTask_id());
				bundle.putInt("num", fastParkDetailInfo.size());
				bundle.putInt("type", 1);
				bundle.putBoolean("carinparkdefault", carInParkDefault);
				if(carInParkDefault) {
					bundle.putString("id", mModel.getId());
					bundle.putString("orderid", mModel.getOrder_id());
				}
				intent.putExtras(bundle);
				startActivity(intent);
			}
		});
	}
	
	//{"totalCount":1,  "data":[{"id":"3","distance":89.0,"num":2,"name":"金羊小区"}]}
	private void getFastParkInfo(String areaid) {
			curShowView = "getFastParkInfoDetail";
			RequestParams params = new RequestParams();
			params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
			params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
			params.addBodyParameter("method", "2030");
			params.addBodyParameter("lant", String.valueOf(mCurrentLantitude));
			params.addBodyParameter("lng", String.valueOf(mCurrentLongitude));
			params.addBodyParameter("hour", String.valueOf(parkTime));  
			params.addBodyParameter("area_id", areaid);

			Log.i("TEST", "POST URL : " + ServerURL+"?uid="+ParkingApp.mAppCtx.getUID()+"&utype="+ParkingApp.mAppCtx.getUType()
					+"&method=2030&hour="+ String.valueOf(parkTime)
					+"&lant="+String.valueOf(mCurrentLantitude)
					+"&lng="+String.valueOf(mCurrentLongitude)
					+"&area_id"+areaid);
			
			HttpUtils http = new HttpUtils(6000);
			showProgDialog("正在进行查询 . . .", http);
			http.send(HttpMethod.POST, 
					ServerURL, 
					params, 
					new RequestCallBack<String>() {

				@Override
				public void onSuccess(ResponseInfo<String> responseInfo) {
					// TODO Auto-generated method stub
						String str = null;
						Log.i(TAG, "getFastParkInfo : " + responseInfo.result);
						try {
							JSONObject jsob = new JSONObject(responseInfo.result);
							int count = jsob.getInt("totalCount");
							if(count == 0) {
								tvParknull.setText("没有符合条件的车位，下拉可刷新");
								pullViewParknull.setVisibility(View.VISIBLE);
								pullView.setVisibility(View.GONE);
							}else {
								JSONArray jsoa = jsob.getJSONArray("data");
								mFastParkInfo = new ArrayList<FastParkInfo>();
								for(int i=0; i< count; i++) {	
									FastParkInfo info = new FastParkInfo();
									JSONObject jso = jsoa.getJSONObject(i);
									info.setId(jso.getString("id"));
									info.setName(jso.getString("name"));
									info.setNum(jso.getInt("num"));
									info.setDistance(jso.getDouble("distance"));
									mFastParkInfo.add(info);
								}
								showPopw();
							}
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						if(dialog != null) {
							dialogDismiss = 1;
							dialog.dismiss();
						}
						pullViewParknull.onHeaderRefreshFinish();
						pullView.onHeaderRefreshFinish();
				}

				@Override
				public void onFailure(HttpException error, String msg) {
					// TODO Auto-generated method stub
					boolean bo = isNetConnected();
					if(!bo) {
						Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
					}
					if(dialog != null) {
						dialogDismiss = 1;
						dialog.dismiss();
					}
					pullViewParknull.onHeaderRefreshFinish();
					pullView.onHeaderRefreshFinish();
				}
			});
		}
		
	public void onOther(View v) {
		boolean bo = isNetConnected();
		if(!bo) {
			Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
			return;
		}
		if(carInParkDefault) {
			showToastTips("请扫描二维码离场");
			scan();
		}else {
			rlayoutMyorder.setVisibility(View.GONE);
			llFastpark.setVisibility(View.GONE);
			llFastP.setVisibility(View.VISIBLE);
			llMap.setVisibility(View.VISIBLE);
			btnFastB.performClick();
			getFastParkInfo("3");
		}
	}
	
	public void onCancel(View v) {
		if(carInParkDefault) {
			llFastpark.setVisibility(View.GONE);
			showOrderView(mModel.getId());
		}else {
			rlayoutMyorder.setVisibility(View.GONE);
			llFastpark.setVisibility(View.GONE);
			llFastP.setVisibility(View.VISIBLE);
			llMap.setVisibility(View.VISIBLE);
			btnFastB.performClick();
			getFastParkInfo();
		}
		
	}
	
}
