package com.sendi.lhparking.ui.chezhu;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;
import org.sendi.parking.ui.R;

import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.im.conn.XmppManager;
import com.sendi.lhparking.ui.common.AccountDetailActivity;
import com.sendi.lhparking.ui.common.BaseActivity;
import com.sendi.lhparking.util.MD5Crypter;
import com.sendi.lhparking.util.ParkingPrefs;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnDismissListener;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.TextView.OnEditorActionListener;
/**
 * 转出到银行界面
 * @author Administrator
 *
 */
public class Transfer2BankActivity extends BaseActivity {

	private static final String TRANSFER_TYPE_BANK = "3";
	private EditText edBankmoney, edBankName2, edBankUser, edCardnum, edReCardnum;
	private EditText edPsw;
	private Spinner spinnerBank;
	private TextView tvTransDate;
	private String maxMoney;
	private Double dMaxmoney;
	private Button btnOk;
	private String[] bankType;
	private ArrayAdapter<String> adapter;
	private ProgressDialog mDialog;
	private String curShowView = "0";
	private int dialogDismiss = 0;
	private List<EditText> list;
	private String loginPsw;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_transfer2bank);
		
		maxMoney = this.getIntent().getStringExtra("maxMoney");
		dMaxmoney = Double.valueOf(maxMoney);
		bankType = this.getResources().getStringArray(R.array.bank_type);
		init();
	}

	private void init() {

		TextView tvTitle = (TextView) this.findViewById(R.id.topbar_center_btn);
		TextView tvReturn = (TextView) this.findViewById(R.id.topbar_left_btn);
		
		tvTitle.setText("转出到银行卡");
		tvReturn.setVisibility(View.VISIBLE);
		tvReturn.setText("  返 回");
		
		tvReturn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Transfer2BankActivity.this.finish();
			}
		});
		list = new ArrayList<EditText>();
		edBankmoney = (EditText) this.findViewById(R.id.edBankmoney);
		spinnerBank = (Spinner) this.findViewById(R.id.spBankname);
		edBankName2 = (EditText) this.findViewById(R.id.edBankname2);
		edBankUser = (EditText) this.findViewById(R.id.edBankuser);
		edCardnum = (EditText) this.findViewById(R.id.edCardnum);
		edReCardnum = (EditText) this.findViewById(R.id.edReCardnum);
		tvTransDate = (TextView) this.findViewById(R.id.tvTransdate);
		btnOk = (Button) this.findViewById(R.id.btnOK);
		list.add(edBankmoney);
//		list.add(edBankName);
		list.add(edBankName2);
		list.add(edBankUser);
		list.add(edCardnum);
		list.add(edReCardnum);
		
		adapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, bankType);
        //设置下拉列表的风格
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //将adapter 添加到spinner中
        spinnerBank.setAdapter(adapter);
        //设置默认值
        spinnerBank.setVisibility(View.VISIBLE);
	        
		edBankmoney.setHint("本次可转出"+maxMoney+"元");
		tvTransDate.setText("预计"+getNextDate()+"前到账");
		btnOk.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if( !checkIsNull(list)) {
					showTipsDialog("请输入完整信息", Transfer2BankActivity.this);
					return;
				}
				if( !edCardnum.getText().toString().equals( edReCardnum.getText().toString() )) {
					showTipsDialog("两次输入银行卡不同，请重新输入 ", Transfer2BankActivity.this);
					return;
				}
				Double money = Double.valueOf(edBankmoney.getText().toString());
				if(money < 10) {
					showTipsDialog("最少转出10元", Transfer2BankActivity.this);
					edBankmoney.setText("10");
					return;
				}
//				doTransfer2Bank();
				showSurePswDialog();
				hideKeyborad();
			}
		});
		
		edBankmoney.addTextChangedListener(new TextWatcher() {
			
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void afterTextChanged(Editable s) {
				// TODO Auto-generated method stub
				if(edBankmoney.getText().length() != 0) {
					Double money = Double.valueOf(edBankmoney.getText().toString());
					if(money > dMaxmoney) {
						edBankmoney.setText(maxMoney);
					}
				}
			}
		});
		
		edReCardnum.setOnEditorActionListener(new OnEditorActionListener() {
			
			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				// TODO Auto-generated method stub
				switch(actionId) {
				case EditorInfo.IME_ACTION_DONE:
					btnOk.performClick();
					break;
				}
				return false;
			}
		});
	}
	
	/**
	 * 3银行卡  account： 账号信息 money：金额 当type为3的时候，继续有3个参数---bank：银行 sub_bank:支行  person_name：开户人姓名
	 */
	private void doTransfer2Bank() {
		curShowView = "Transfer2Bank";		
		String psw = MD5Crypter.MD5Encode(loginPsw);
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("method", "2024");
		params.addBodyParameter("type", TRANSFER_TYPE_BANK);
		params.addBodyParameter("account", edCardnum.getText().toString());
		params.addBodyParameter("money", edBankmoney.getText().toString());
		params.addBodyParameter("bank", bankType[spinnerBank.getSelectedItemPosition()] );
		params.addBodyParameter("sub_bank", edBankName2.getText().toString());
		params.addBodyParameter("person_name", edBankUser.getText().toString());
		params.addBodyParameter("password", psw);
		
		Log.i(TAG, bankType[spinnerBank.getSelectedItemPosition()]);
		HttpUtils http = new HttpUtils(6000);
		showProgDialog("正在提交...",http);
		http.send(HttpMethod.POST, 
				ServerURL,
				params,
				new RequestCallBack<String>() {

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// TODO Auto-generated method stub
						if(curShowView.equals("Transfer2Bank")) {
							try {
								JSONObject jsob = new JSONObject(responseInfo.result);
								String msg = jsob.getString("msg");
								boolean bo = jsob.getBoolean("success");
								showTipsDialog(msg, Transfer2BankActivity.this);
								if(bo) {
									Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show(); 
									Intent intent = new Intent(Transfer2BankActivity.this, AccountDetailActivity.class);
									intent.putExtra("showview", 3);
									startActivity(intent);
									Transfer2BankActivity.this.setResult(1);
									Transfer2BankActivity.this.finish();
									
								}
								
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							if(mDialog != null) {
								dialogDismiss = 1;
								mDialog.dismiss();
							}
						}
						
						Log.i(TAG, responseInfo.result);
					}

					@Override
					public void onFailure(HttpException error, String msg) {
						// TODO Auto-generated method stub
						if(curShowView.equals("Transfer2Bank")) {
							showTipsDialog("提交失败，请检查网络，稍后再试 ", Transfer2BankActivity.this);
						}
						if(mDialog != null) {
							dialogDismiss = 1;
							mDialog.dismiss();
						}
					}});
	
	}
	
	private void showProgDialog(final String msg, final HttpUtils httpUtils) {
		mDialog = new ProgressDialog(this);
		mDialog.setCanceledOnTouchOutside(false);
		mDialog.setOnDismissListener(new OnDismissListener() {
			
			@Override
			public void onDismiss(DialogInterface dialog) {
				// TODO Auto-generated method stub
				if(dialogDismiss == 0 ) {
					httpUtils.getHttpClient().getConnectionManager().closeExpiredConnections();
//					httpUtils.getHttpClient().getConnectionManager().shutdown();
				}
				dialogDismiss = 0;
				curShowView = "0";
				Log.i(TAG, "dialog dismiss : "+msg);
			}
		});
		mDialog.setMessage(msg);
		mDialog.show();
	}
	
	private boolean checkIsNull(List<EditText> list) {
		for(EditText ed : list) {
			if( 0 == ed.getText().length()) {
				return false;
			}
		}
		return true;
	}
	
	/** 
	 * 输入密码提示框
	 * */
	private void showSurePswDialog() {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		edPsw = new EditText(this);
		edPsw.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
		builder.setTitle("提醒");
		builder.setMessage("转出前请输入登录密码");
		builder.setCancelable(false);
		builder.setView(edPsw);
		builder.setCancelable(true);
		builder.setNegativeButton("取消",
				new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						return;
					}
				});
		builder.setPositiveButton("确定",
				new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub\
						Log.i(TAG, "edPsw"+edPsw.getText().toString());
						loginPsw = edPsw.getText().toString();
						if( 0 == edPsw.getText().length()) {
//							loginPsw = "null";
							Toast.makeText(getApplicationContext(), "转出前请输入登录密码", Toast.LENGTH_SHORT).show();
							return;
						}
						doTransfer2Bank();
					}
				});	
		builder.create().show();
	}
}
