package com.sendi.lhparking.ui.chezhu;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.JSONException;
import org.json.JSONObject;
import org.sendi.parking.ui.R;

import test.BMapApiDemoMain;
import test.PanoramaDemoActivityMain;

import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.sendi.lhparking.adapter.ParkingDetailListAdapter;
import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.ctx.ParkingConstant;
import com.sendi.lhparking.ui.common.BaseActivity;
import com.sendi.lhparking.ui.common.LoginActivity;
import com.sendi.lhparking.ui.common.ViewEvaluationListActivity;
import com.sendi.lhparking.ui.common.ViewOrderActivity;
import com.sendi.lhparking.util.ParkingDetailInfo;
import com.sendi.lhparking.util.ParkingPrefs;
import com.sendi.lhparking.view.AbObjectWheelAdapter;
import com.sendi.lhparking.view.AbOnWheelChangedListener;
import com.sendi.lhparking.view.AbWheelView;

import android.app.ActionBar.LayoutParams;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnDismissListener;
import android.graphics.drawable.PaintDrawable;
import android.os.Bundle;
import android.os.Message;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.util.Patterns;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MapReserveParkingActivity extends BaseActivity {
	public static final int REQ_VIEW_ORDER = 1001;
	private ListView lvParkDetail;
	private TextView tvName, tvPnum;
	private TextView tvReturn;
	private Button btnReserve;
	private String strComName;
	private String TAG = "TEST";
	private String strtime;
	private String curDate;
	private String sTime;   //设置开始时间
	private String eTime;   //设置结束时间
	private String pDate;   //停车日期    2014-01-01
	private String time1;   //开始时间
	private String time2;   //结束时间
	private int sHindex = 0, eHindex = 0;
	private int sMindex = 0, eMindex = 0;
	private int pnum;
	private boolean isSetBtime = false;
	private boolean isSetEtime = false;
	
	private String curCarno = null;  //车牌号码
	
	private ArrayList<ParkingDetailInfo> infos;
	private ArrayList<ParkingDetailInfo> infoSort;
	private int mCurPosition = 0;
	private ProgressDialog dialog;
	private int layoutNo = 0;
	private String[] wHour ;
	private String[] wMin ;
	private String[] mins;
	private AbWheelView wheelYear;
	private AbWheelView wheelMon;
	private AbWheelView wheelDay;
	private AbWheelView wheelHour;
	private AbWheelView wheelMin;
	
	private AlertDialog wDialog;

	private ProgressDialog mDialog;
	private String curShowView = "0";
	private int dialogDismiss = 0;
	private double lon;
	private double lat;
	private Button btnPan;// 全景图按钮
	private Button btnSort; 
	private int sortType = 0;
	private ParkingDetailListAdapter adapter;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
//		wHour = this.getResources().getStringArray(R.array.time_hours);
		curDate = getCurDate();
		mins = new String[60];
		for(int i=0; i<60; i++) {
			mins[i] = String.valueOf(i);
			if(i<10) {
				mins[i] = "0"+String.valueOf(i);
			}
		}
		
		wMin = this.getResources().getStringArray(R.array.time_minutes);
		wMin = mins;
		
		lon = getIntent().getDoubleExtra("lon", 0);
		lat = getIntent().getDoubleExtra("lat", 0);
		
		initView();
		initListView();
	}
	
	private void initView() {
		setContentView(R.layout.activity_mapreserveparking);
		layoutNo = 0;
		lvParkDetail = (ListView) this.findViewById(R.id.lvParkDetail);
		tvName = (TextView) this.findViewById(R.id.topbar_center_btn);
		tvPnum = (TextView) this.findViewById(R.id.tvPnum);
		tvReturn = (TextView) this.findViewById(R.id.topbar_left_btn);
		btnPan = (Button)this.findViewById(R.id.btn_panorama);
		btnSort = (Button) this.findViewById(R.id.btn_sort);
		infos = getIntent().getParcelableArrayListExtra("ParkDetailInfo");
//		infoSort = infos;
//		Collections.sort(infoSort, new CompartorWithTime());
		strComName = getIntent().getStringExtra("name");
		pDate = getIntent().getStringExtra("pdate");
		Log.i(TAG, "pDate : "+pDate + "  "+curDate);
		pnum = getIntent().getIntExtra("pnum", 0);
		tvName.setText(strComName+"停车位信息");
		tvPnum.setText(String.valueOf(pnum));
		tvReturn.setVisibility(View.VISIBLE);
		tvReturn.setText("  返 回");
		
		tvReturn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				MapReserveParkingActivity.this.finish();
			}
		});
		
		btnPan.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				showPanorama();
			}
		});
		
		btnSort.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(sortType == 0) {
					sortType = 1;
					btnSort.setText("时间段 ");
					Collections.sort(infos, new CompartorWithTime());
					adapter.updateListView(infos);
					Log.i(TAG, "btnSort type 1");
				}else {
					sortType = 0;
					btnSort.setText("价    格 "); 
					Collections.sort(infos, new ComparatorWithPrice()); 
					adapter.updateListView(infos); 
					Log.i(TAG, "btnSort type 0"); 
				}
			}
		});
	}   
	
	private void initListView() {
		Collections.sort(infos, new ComparatorWithPrice());
//		Collections.sort(infos, new CompartorWithTime());
		adapter = new ParkingDetailListAdapter(this, infos);
		lvParkDetail.setAdapter(adapter);
		
		lvParkDetail.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position,
					long arg3) {
				// TODO Auto-generated method stub
				isSetBtime = false;
				isSetEtime = false;
				curCarno = null;
				setContentView(R.layout.activity_mapreserveparking2);
				layoutNo = 1;
				initDetailInfo(position);

			}
		});
		
	}
	
	private TextView tvParkBtime ;
	private TextView tvParkEtime ;
	
	private void initDetailInfo(int position) {
		mCurPosition = position;
		final ParkingDetailInfo info = infos.get(position);
		TextView tvComName = (TextView) this.findViewById(R.id.tvComName2);
		TextView tvParkno = (TextView) this.findViewById(R.id.tvParkno2);
		TextView tvPrice = (TextView) this.findViewById(R.id.tvPrice2);
		TextView tvParkrate = (TextView) this.findViewById(R.id.tvParkrate);
		TextView tv = (TextView) this.findViewById(R.id.topbar_center_btn);
		tvParkBtime = (TextView) this.findViewById(R.id.tvParkBtime2);
		tvParkEtime = (TextView) this.findViewById(R.id.tvParEtime2);
		
		btnReserve = (Button) this.findViewById(R.id.btnReserve);
		if (ParkingApp.mAppCtx.isRoleGuard()) {// 物业
			btnReserve.setClickable(false);
		}
		final EditText edtCarno = (EditText) this.findViewById(R.id.edtCarno2);
		curCarno = ParkingPrefs.getStrValue("last_carno");
		if(curCarno != null) {
			edtCarno.setText(curCarno);
		}
		tv.setText("错时停车任务详情");
		tvComName.setText(strComName);
		tvParkno.setText(info.getPno());
		tvPrice.setText(info.getPrice());
		tvParkrate.setText(info.getPrate());
		String ss[] = info.getTimeHour().split("\\-");
		time1 = ss[0];
		time2 = ss[3];
		if(curDate.equals(pDate) && (time1.compareTo(getCurTime()) < 0) ) {
			time1 = getCurTime();
		}
		
		sTime = time1;
		eTime = time2;
		wHour = getHourString(time1, time2);
		
		final Button btnReserve = (Button) this.findViewById(R.id.btnReserve);
		TextView tvReturn = (TextView) this.findViewById(R.id.topbar_left_btn);
		tvReturn.setText("  返 回");
		tvReturn.setVisibility(View.VISIBLE);
		tvReturn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				hideKeyborad();
				initView();
				initListView();
			}
		});
		
		tvParkBtime.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				showTimePickerDialog(0);
			}
		});
		
		tvParkEtime.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				showTimePickerDialog(1);
			}
		});
		
		edtCarno.addTextChangedListener(new TextWatcher() {
			
			@Override
			public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void beforeTextChanged(CharSequence arg0, int arg1, int arg2,
					int arg3) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void afterTextChanged(Editable arg0) {
				// TODO Auto-generated method stub
				curCarno = edtCarno.getText().toString();
			}
		});
		
		tvParkrate.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Log.i(TAG, "bossid:"+info.getBossId());
				Intent intent = ViewEvaluationListActivity.getLaunchIntent(MapReserveParkingActivity.this, info.getBossId(), 2);
				startActivity(intent);
			}
		});
		
		edtCarno.setOnEditorActionListener(new OnEditorActionListener() {
			
			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				// TODO Auto-generated method stub
				switch(actionId) {
				case EditorInfo.IME_ACTION_DONE:
					btnReserve.performClick();
					break;
				}
				return false;
			}
		});
	}
	
	public void onCancel(View v) {
		initView();
		initListView();
	}
	
	public void onReserve(View v) {
		btnReserve.setClickable(false);
		if(ParkingApp.mAppCtx.isNeedLogin()){
			startActivity(new Intent(this, LoginActivity.class));
			btnReserve.setClickable(true);
			return ;
		}
		
		if( isSetBtime == false || isSetEtime == false ) {
			showTipsDialog("请输入完整预约时间");
			btnReserve.setClickable(true);
			return;
		}
		
		if(curCarno == null || curCarno.length() == 0) {
			showTipsDialog("请输入车牌号码");
			btnReserve.setClickable(true);
			return;
		}
	
		String check = "^[\u4e00-\u9fa5]{1}[A-Z]{1}[A-Z_0-9]{5}$";
		Pattern pt = Pattern.compile(check);
		Matcher matcher = pt.matcher(curCarno);
		if(!matcher.matches()) {
			showTipsDialog("输入的车牌号码格式不正确（例：粤AXXXXX）");
			btnReserve.setClickable(true);
			return;
		}
		
		doReserve();
		ParkingPrefs.setStrValue("last_carno", curCarno);
	}
	
	private void doReserve() {
		curShowView = "doReserve";
		final ParkingDetailInfo info =  infos.get(mCurPosition);
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("method", "2005");
		params.addBodyParameter("btime", sTime );
		params.addBodyParameter("etime", eTime );
		params.addBodyParameter("task_id", info.getPid());
		params.addBodyParameter("car_no", curCarno);
		
		Log.i("TEST", "POST URL : " + ServerURL+"?uid="+ParkingApp.mAppCtx.getUID()+"&utype="+ParkingApp.mAppCtx.getUType()
				+"&method=2005&hour"
				+"&btime="+sTime
				+"&etime="+eTime
				+"&task_id="+info.getPid()
				+"&car_no="+curCarno);
		
		HttpUtils http = new HttpUtils(6000);
		showProgDialog("正在进行车位预约...", http);
		http.send(HttpMethod.POST, 
				ServerURL, 
				params,
				new RequestCallBack<String>() {

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// TODO Auto-generated method stub
						if(curShowView.equals("doReserve")) {
							String result = responseInfo.result;
							boolean success = false;
							String msg = null;
							
							if(mDialog != null) {
								dialogDismiss = 1;
								mDialog.dismiss();
							}
							try {
								JSONObject jsob = new JSONObject(result);
								success = jsob.getBoolean("success");
								msg = jsob.getString("msg");
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							
							if(success) {
					            Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
//								showTipsDialog(msg);
//								initView();
//								initListView();
								Message handlermsg = new Message();
								Message mapMsg = new Message();
								handlermsg.what = 0;
								mapMsg.what = 0;
								mapMsg.obj = info.getPid();
								ParkingApp.appHandler.sendMessage(handlermsg);
								ParkingApp.mapHandler.sendMessage(mapMsg);
								
//								Intent intent = new Intent(MapReserveParkingActivity.this, ViewOrderActivity.class);
//								intent.putExtra(ParkingConstant.INTENT_EXTRA_ORDER_ID, info.getPid());
//								startActivityForResult(intent, REQ_VIEW_ORDER);
					            MapReserveParkingActivity.this.finish();

//								ParkingApp.orderHandler.sendMessage(handlermsg);
							}else {
								showTipsDialog("预约失败："+ msg);
							}
						}
						
					}

					@Override
					public void onFailure(HttpException error, String msg) {
						// TODO Auto-generated method stub
						if(curShowView.equals("doReserve")) {
							showTipsDialog("预约失败，请稍后再试");
						}
						if(mDialog != null) {
							dialogDismiss = 1;
							mDialog.dismiss();
						}
						
					}
				} );
	}
	
	private void showTipsDialog(String msg){  
        AlertDialog dialog;  
        AlertDialog.Builder builder = new AlertDialog.Builder(MapReserveParkingActivity.this);  
        builder.setTitle("消息").setIcon(android.R.drawable.stat_notify_error);  
        builder.setMessage(msg);  
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener(){  
            @Override 
            public void onClick(DialogInterface dialog, int which) {  
                // TODO Auto-generated method stub  
                  
            }                     
        });  
        dialog = builder.create();  
        dialog.show();  
    }  
	
	private void showProgDialog(String msg) {
		dialog = ProgressDialog.show(MapReserveParkingActivity.this, "消息", msg );
	}

	private void showTimePickerDialog(final int i) {
        AlertDialog.Builder builder = new AlertDialog.Builder(MapReserveParkingActivity.this);  
        View v = LayoutInflater.from(this).inflate(R.layout.timepicker, null);
        wheelYear = (AbWheelView) v.findViewById(R.id.year);
        wheelMon = (AbWheelView) v.findViewById(R.id.month);
        wheelDay = (AbWheelView) v.findViewById(R.id.day);
        wheelHour = (AbWheelView) v.findViewById(R.id.hour);
        wheelMin = (AbWheelView) v.findViewById(R.id.min);
        wheelYear.setVisibility(View.GONE);
        wheelMon.setVisibility(View.GONE);
        wheelDay.setVisibility(View.GONE);
        wheelHour.setVisibility(View.VISIBLE);
        wheelMin.setVisibility(View.VISIBLE);
        switch(i) {
		case 0:
			wHour = getHourString(time1, time2);
			break;
		case 1:
			wHour = getHourString(time1, time2);
			break;
		}	
        Button btnCancel = (Button) v.findViewById(R.id.wheel_panel_cancelBtn);
        btnCancel.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				wDialog.dismiss();
			}
		});
        
        Button btnOk = (Button) v.findViewById(R.id.wheel_panel_okBtn);
        btnOk.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String h = wHour[wheelHour.getCurrentItem()];
				String m = wMin[wheelMin.getCurrentItem()];
				switch(i) {
				case 0:
					sHindex = wheelHour.getCurrentItem();
					sMindex = wheelMin.getCurrentItem();
					sTime = h+":"+m;
					if(isSetEtime) {
						boolean bo = checkTime(sTime, eTime);
						if(bo) {
							tvParkBtime.setText(h+":"+m);
							isSetBtime = true;
						}else {
							tvParkBtime.setText("点击设置");
							isSetBtime = false;
				            Toast.makeText(getApplicationContext(), "预约时间设置错误", Toast.LENGTH_SHORT).show();
						}
					}else {
						tvParkBtime.setText(h+":"+m);
						isSetBtime = true;
					}
					break;
				case 1:
					eHindex = wheelHour.getCurrentItem();
					eMindex = wheelMin.getCurrentItem();
					eTime = h+":"+m;
					if(isSetBtime) {
						boolean bo = checkTime(sTime, eTime);
						if(bo) {
							tvParkEtime.setText(h+":"+m);
							isSetEtime = true;
						}else {
							tvParkEtime.setText("点击设置");
							isSetEtime = false;
				            Toast.makeText(getApplicationContext(), "预约时间设置错误", Toast.LENGTH_SHORT).show();    
						}
					}else {
						tvParkEtime.setText(h+":"+m);
						isSetEtime = true;
					}
					
					break;
				}	
				wDialog.dismiss();
			}
		});
        
        Calendar calendar = Calendar.getInstance();
		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH);
		int day = calendar.get(Calendar.DAY_OF_MONTH);
		wMin = MapReserveParkingActivity.this.getResources().getStringArray(R.array.time_minutes);
		wMin = mins;
        AbObjectWheelAdapter<String> adapterhoursH = new AbObjectWheelAdapter<String>(wHour, 2);
		wheelHour.setAdapter(adapterhoursH);
		AbObjectWheelAdapter<String> adapterhoursM = new AbObjectWheelAdapter<String>(wMin, 2);
		wheelMin.setAdapter(adapterhoursM);
        if(!isSetBtime && i == 0) {
        	wMin = getMinString(time1, 1);
			AbObjectWheelAdapter<String> adapterhours = new AbObjectWheelAdapter<String>(wMin, 2);
			wheelMin.setAdapter(adapterhours);
        }
        if(!isSetEtime && i == 1) {
        	wMin = getMinString(time1, 1);
			AbObjectWheelAdapter<String> adapterhours = new AbObjectWheelAdapter<String>(wMin, 2);
			wheelMin.setAdapter(adapterhours);
        }
        if(isSetBtime && sHindex == 0 && i == 0) {
        	wMin = getMinString(time1, 1);
			AbObjectWheelAdapter<String> adapterhours = new AbObjectWheelAdapter<String>(wMin, 2);
			wheelMin.setAdapter(adapterhours);
        }
        if(isSetBtime && sHindex == wHour.length-1 && i == 0) {
        	wMin = getMinString(time2, 0);
			AbObjectWheelAdapter<String> adapterhours = new AbObjectWheelAdapter<String>(wMin, 2);
			wheelMin.setAdapter(adapterhours);
        }
        if(isSetEtime && eHindex == 0 && i == 1) {
        	wMin = getMinString(time1, 1);
			AbObjectWheelAdapter<String> adapterhours = new AbObjectWheelAdapter<String>(wMin, 2);
			wheelMin.setAdapter(adapterhours);
        }
        if(isSetEtime && eHindex == wHour.length-1 && i == 1) {
        	wMin = getMinString(time2, 0);
			AbObjectWheelAdapter<String> adapterhours = new AbObjectWheelAdapter<String>(wMin, 2);
			wheelMin.setAdapter(adapterhours);
        }
        wheelHour.addChangingListener(new AbOnWheelChangedListener() {
			
			@Override
			public void onChanged(AbWheelView wheel, int oldValue, int newValue) {
				// TODO Auto-generated method stub
				if(newValue == 0) {
					wMin = getMinString(time1, 1);
					AbObjectWheelAdapter<String> adapterhoursM = new AbObjectWheelAdapter<String>(wMin, 2);
					wheelMin.setAdapter(adapterhoursM);
				}else if(newValue == (wHour.length-1) ) {
					wMin = getMinString(time2, 0);
					AbObjectWheelAdapter<String> adapterhoursM = new AbObjectWheelAdapter<String>(wMin, 2);
					wheelMin.setAdapter(adapterhoursM);
				}else {
					Log.i(TAG, "wheelhour");
					wMin = MapReserveParkingActivity.this.getResources().getStringArray(R.array.time_minutes);
					wMin = mins;
					AbObjectWheelAdapter<String> adapterhoursM = new AbObjectWheelAdapter<String>(wMin, 2);
					wheelMin.setAdapter(adapterhoursM);   
				}
			}
		});
        builder.setView(v);
        wDialog = builder.create();
        switch(i) {
        case 0:
        	wheelHour.setCurrentItem(sHindex);
            wheelMin.setCurrentItem(sMindex);
			wDialog.setTitle("选择预约开始时间("+time1+"--"+ time2+")");
        	break;
        case 1:
        	wheelHour.setCurrentItem(eHindex);
            wheelMin.setCurrentItem(eMindex);
            wDialog.setTitle("选择预约结束时间("+time1+"--"+ time2+")");
        	break;
        }
        wDialog.setCanceledOnTouchOutside(false);
        wDialog.show();
	}
	
	private String[] getHourString(String time1, String time2) {
		String[] ss = time1.split("\\:");
		String[] se = time2.split("\\:");
		int sHour = 0;
		int eHour = 0 ;
		String[] shour;
		try {
			sHour = Integer.valueOf(ss[0]);
			eHour = Integer.valueOf(se[0]);
			shour = new String[eHour-sHour+1];
			if(time2.compareTo(getCurTime()) < 0) {
				Toast.makeText(getApplicationContext(), "超出停车时段，无法预约", Toast.LENGTH_SHORT).show();  
	            hideKeyborad();
				initView();
				initListView();
				return null;
			}
		} catch (Exception e) {
			// TODO: handle exception
            Toast.makeText(getApplicationContext(), "停车时段错误，无法预约", Toast.LENGTH_SHORT).show();  
            hideKeyborad();
			initView();
			initListView();
			return null;
		}
		
		for(int i =0, j = sHour; j<=eHour; i++, j++) {
			if(j<10) {
				shour[i] = "0"+String.valueOf(j);
			}else {
				shour[i] = String.valueOf(j);
			}
		}
		return shour;
	}
	
	private boolean checkTime(String stime, String etime) {
		String[] st = stime.split("\\:");
		String[] et = etime.split("\\:");
		int sh = Integer.valueOf(st[0]);
		int sm = Integer.valueOf(st[1]);
		int eh = Integer.valueOf(et[0]);
		int em = Integer.valueOf(et[1]);
		if(sh > eh) {
			return false;
		}else if(sh == eh && sm >= em) {
			return false;
		}
		return true;
	}
	
	private String[] getMinString(String time, int t) {
		String[] ss = time.split("\\:");
		int min = Integer.valueOf(ss[1]);
		String[] m = null;
		switch(t) {
		case 0:
			m = new String[(min/1)+1];
			break;
		case 1:
			m = new String[ (60-min)/1 ];
			break;
		}
		
		switch(t) {
		case 0:   //结束时间
			m = new String[(min/1)+1];;
			for(int i=0,j=0; j<=min; i++) {
				if(j < 10) {
					m[i] = "0"+String.valueOf(j);
				}else {
					m[i] = String.valueOf(j);
				}
				j = j+1;
				Log.i(TAG, "getMinString : "+m[i]);
			}
			break;
		case 1:    //开始时间
			for(int i=0, j=min; j<=59; i++) {
				if(j < 10) {
					m[i] = "0"+String.valueOf(j);
				}else {
					m[i] = String.valueOf(j);
				}
				j = j+1;
				Log.i(TAG, "getMinString : "+m[i]);
			}
			break;
		}
		return m;
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		if(keyCode == KeyEvent.KEYCODE_BACK) {
			if(layoutNo == 1) {
				initView();
				initListView();
				return false;
			}
			MapReserveParkingActivity.this.finish();
			return false;
		}
		return super.onKeyDown(keyCode, event);
	}
	
	private void showProgDialog(final String msg, final HttpUtils httpUtils) {
		mDialog = new ProgressDialog(this);
		mDialog.setCanceledOnTouchOutside(false);
		mDialog.setOnDismissListener(new OnDismissListener() {
			
			@Override
			public void onDismiss(DialogInterface dialog) {
				// TODO Auto-generated method stub
				btnReserve.setClickable(true);
				if(dialogDismiss == 0 ) {
					httpUtils.getHttpClient().getConnectionManager().closeExpiredConnections();
//					httpUtils.getHttpClient().getConnectionManager().shutdown();
				}
				dialogDismiss = 0;
				curShowView = "0";
				Log.i(TAG, "dialog dismiss : "+msg);
			}
		});
		mDialog.setMessage(msg);
		mDialog.show();
	}
	
	private void showPanorama() {
		Intent intent = new Intent(MapReserveParkingActivity.this, PanoramaActivity.class);
		Bundle bundle = new Bundle();
		bundle.putDouble("lon", lon);
		bundle.putDouble("lat", lat);
		intent.putExtras(bundle);
		startActivity(intent);
		
//		Intent intent = null;
//		intent = new Intent(MapReserveParkingActivity.this, PanoramaDemoActivityMain.class);
//		intent.putExtra("type", 2);
//		this.startActivity(intent);
	}
	
	class ComparatorWithPrice implements Comparator<ParkingDetailInfo> {

		@Override
		public int compare(ParkingDetailInfo lhs, ParkingDetailInfo rhs) {
			// TODO Auto-generated method stub
			Log.i(TAG, "price : " + lhs.getStrPrice());
			return lhs.getStrPrice().compareTo(rhs.getStrPrice());
		}
		
	}
	
	class CompartorWithTime implements Comparator<ParkingDetailInfo> {

		@Override
		public int compare(ParkingDetailInfo lhs, ParkingDetailInfo rhs) {
			// TODO Auto-generated method stub
			Log.i(TAG, "price : " + lhs.getStrPrice());
			return lhs.getTimeHour().compareTo(rhs.getTimeHour());
		}
		
	}
	
}
