package com.sendi.lhparking.ui.baoan;

import org.json.JSONException;
import org.json.JSONObject;
import org.sendi.parking.ui.R;

import com.ab.util.AbStrUtil;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.ctx.ParkingConstant;
import com.sendi.lhparking.server.IServer;
import com.sendi.lhparking.ui.common.ViewOrderActivity;
import com.sendi.lhparking.ui.common.base.BaseFragmentActivity;
import com.sendi.lhparking.util.AccountBaseInfo;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnDismissListener;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
/**
 * 车辆放行处理
 * @author Administrator
 *
 */
public class DealActivity extends BaseFragmentActivity {

	private TextView tvTitle;
	private TextView tvReturn;
	private TextView tvCarno;
	private TextView tvDetail;
	private String mOrderId;
	private String carNo, taskId, carInOrOut, orderId;
	private ProgressDialog mDialog;
	private String curShowView = "0";
	private int dialogDismiss = 0;
	private Button btnOk, btnRej;
	private static String ServerURL = "https://121.33.214.30:8443/lhparking/servlet/SysInterface";
	private static String TAG = "TEST";

	private View btnPanel;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_deal);
		if (!parseIntent()) {
			Toast.makeText(getApplicationContext(), "订单号出错", Toast.LENGTH_SHORT).show();
			this.setResult(-1);
			finish();
			return;
		}
		init();
		if(ParkingApp.mAppCtx.isAutoLogin()){
			boolean bo = isNetConnected();
			if(bo) {
				getOrderInfo();
			}else {
				Toast.makeText(getApplicationContext(), "无法连接网络，请检查网络连接！", Toast.LENGTH_SHORT).show();
			}
		}
	}
	
	private void init() {
		btnPanel = this.findViewById(R.id.llayout6);
		tvDetail = (TextView) this.findViewById(R.id.tv_detail);
		tvCarno = (TextView) this.findViewById(R.id.tv_carno);
		btnOk = (Button) this.findViewById(R.id.btn_ok);
		btnRej = (Button) this.findViewById(R.id.btn_rej);
		tvTitle = (TextView) this.findViewById(R.id.topbar_center_btn);
		tvReturn = (TextView) this.findViewById(R.id.topbar_left_btn);
		
		btnPanel.setVisibility(View.GONE);
//		btnPanel.startAnimation(AnimationUtils.loadAnimation(this, R.anim.visible_from_bottom));
//		btnPanel.setVisibility(View.VISIBLE);
		
		tvTitle.setText("物 业 处 理");
		tvReturn.setVisibility(View.VISIBLE);
		tvReturn.setText("  返 回");
		tvReturn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				hideKeyborad();
				DealActivity.this.setResult(-1);
				DealActivity.this.finish();
			}
		});
		
		tvDetail.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(DealActivity.this, ViewOrderActivity.class);
				intent.putExtra(ParkingConstant.INTENT_EXTRA_ORDER_ID, mOrderId);
				startActivityForResult(intent, 111);
			}
		});
		
		btnOk.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				doOk();
			}
		});
		
		btnRej.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
			}
		});
		
	}
	
	private boolean parseIntent() {
		Intent intent = getIntent();
		if (intent == null) {
			return false;
		}
		String taskid = intent
				.getStringExtra(ParkingConstant.INTENT_EXTRA_ORDER_ID);
		if (AbStrUtil.isEmpty(taskid)) {
			return false;
		}
		taskId = taskid;
		return true;
	}
	
	/** 
	 * 服务器查询订单基本信息
	 * */
	private void getOrderInfo() {
		curShowView = "getOrderInfo";
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("method", "2007");
		params.addBodyParameter("task_id", taskId);
		HttpUtils http = new HttpUtils(6000);
		showProgDialog("正在进行订单查询 . . .", http);
		http.send(HttpMethod.POST, 
				ServerURL,
				params,
				new RequestCallBack< String >() {

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// TODO Auto-generated method stub
						Log.i(TAG, responseInfo.result);
						if(curShowView.equals("getOrderInfo")) {
							try {
								JSONObject jsob = new JSONObject(responseInfo.result);
								carNo = jsob.getString("car_no");
								taskId = jsob.getString("id");
								orderId = jsob.getString("order_id");
								Log.i(TAG, jsob.getString("car_in_time"));
								if(jsob.getString("car_in_time") == null || jsob.getString("car_in_time").equals("null")) {
									carInOrOut = "1";
								}else {
									carInOrOut = "2";
								} 
								tvCarno.setText(carNo);
								btnPanel.startAnimation(AnimationUtils.loadAnimation(DealActivity.this, R.anim.visible_from_bottom));
								btnPanel.setVisibility(View.VISIBLE);
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							
							if(mDialog != null) {
								dialogDismiss = 1;
								mDialog.dismiss();
							}
						}
						
						
					}

					@Override
					public void onFailure(HttpException error, String msg) {
						// TODO Auto-generated method stub
						if(curShowView.equals("getOrderInfo")) {
							showTipsDialog("查询失败，请检查网络连接，稍后再试 ", DealActivity.this);
						}
						if(mDialog != null) {
							dialogDismiss = 1;
							mDialog.dismiss();
						}
					}
				});
	}
	
	private void showProgDialog(final String msg, final HttpUtils httpUtils) {
		mDialog = new ProgressDialog(this);
		mDialog.setCanceledOnTouchOutside(false);
		mDialog.setOnDismissListener(new OnDismissListener() {
			
			@Override
			public void onDismiss(DialogInterface dialog) {
				// TODO Auto-generated method stub
				if(dialogDismiss == 0 ) {
					httpUtils.getHttpClient().getConnectionManager().closeExpiredConnections();
//					httpUtils.getHttpClient().getConnectionManager().shutdown();
				}
				dialogDismiss = 0;
				curShowView = "0";
				Log.i(TAG, "dialog dismiss : "+msg);
			}
		});
		mDialog.setMessage(msg);
		mDialog.show();
	}
	
	/** 
     * 检测网络是否连接 
     *  
     * @return 
     */ 
    private boolean isNetConnected() {  
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);  
        if (cm != null) {  
            NetworkInfo[] infos = cm.getAllNetworkInfo();  
            if (infos != null) {  
                for (NetworkInfo ni : infos) {  
                    if (ni.isConnected()) {  
                        return true;  
                    }  
                }  
            }  
        }  
        return false;  
    }
    
    private void hideKeyborad() {
		InputMethodManager imm =  (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE); 
		if(imm != null) { 
			imm.hideSoftInputFromWindow(getWindow().getDecorView().getWindowToken(),  
		    		   0); 
			}
	}
    
    private void showTipsDialog(String msg, Context context){  
        AlertDialog dialog;  
        AlertDialog.Builder builder = new AlertDialog.Builder(context);  
        builder.setTitle("消息").setIcon(android.R.drawable.stat_notify_error);  
        builder.setMessage(msg);  
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener(){  
            @Override 
            public void onClick(DialogInterface dialog, int which) {  
                // TODO Auto-generated method stub  
                  
            }                     
        });  
        dialog = builder.create();  
        dialog.show();  
    }
    
    private void doOk(){
		curShowView = "doOk";
		RequestParams params = new RequestParams();
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		params.addBodyParameter("method", "2017");
		params.addBodyParameter("task_id", taskId);
		params.addBodyParameter("order_id", orderId);
		Log.i(TAG, "carInOrOut : "+carInOrOut);
		params.addBodyParameter("numOfScan", carInOrOut);
		
		Log.i("TEST", "POST URL : " + ServerURL+"?uid="+ParkingApp.mAppCtx.getUID()+"&utype="+ParkingApp.mAppCtx.getUType()
				+"&method=2017"
				+"&task_id="+taskId
				+"&order_id="+orderId
				+"&numOfScan="+carInOrOut);
		
		HttpUtils http = new HttpUtils(6000);
		showProgDialog("正在进行车辆放行 . . .", http);
		http.send(HttpMethod.POST, 
				ServerURL,
				params,
				new RequestCallBack< String >() {

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// TODO Auto-generated method stub
						Log.i(TAG, responseInfo.result);
						if(curShowView.equals("doOk")) {
							try {
								JSONObject jsob = new JSONObject(responseInfo.result);
								boolean bo = jsob.getBoolean("success");
								if(bo) {
									Toast.makeText(getApplicationContext(), "车辆放行成功", Toast.LENGTH_SHORT).show();
									DealActivity.this.finish();
								}else {
									Toast.makeText(getApplicationContext(), "车辆放行失败", Toast.LENGTH_SHORT).show();
								}
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							
							if(mDialog != null) {
								dialogDismiss = 1;
								mDialog.dismiss();
							}
						}
						
						
					}

					@Override
					public void onFailure(HttpException error, String msg) {
						// TODO Auto-generated method stub
						if(curShowView.equals("doOk")) {
							showTipsDialog("车辆放行失败，请检查网络连接，稍后再试 ", DealActivity.this);
						}
						if(mDialog != null) {
							dialogDismiss = 1;
							mDialog.dismiss();
						}
					}
				});
	
	}

	@Override
	protected void onActivityResult(int arg0, int arg1, Intent arg2) {
		// TODO Auto-generated method stub
		if(arg1 == -2) {
			DealActivity.this.finish();
		}
		super.onActivityResult(arg0, arg1, arg2);
	}
    
    
}
