package com.sendi.lhparking.ui.baoan;

import java.util.List;

import android.app.Activity;
import android.content.Intent;

import com.google.gson.reflect.TypeToken;
import com.sendi.lhparking.adapter.InUseParkAdapter;
import com.sendi.lhparking.adapter.UnUseParkAdapter;
import com.sendi.lhparking.model.CompletedOrder;
import com.sendi.lhparking.model.ExecutingOrder;
import com.sendi.lhparking.model.InUsePark;
import com.sendi.lhparking.model.UnUsePark;
import com.sendi.lhparking.server.IServer;
import com.sendi.lhparking.ui.common.frag.RefreshListFragment;

public class UnUseParkListFragment extends RefreshListFragment<UnUsePark, BaoanMainActivity> {
	
	public static final int REQ_VIEW_ORDER = 1001;

	@Override
	protected void initListAdapter() {
		// TODO Auto-generated method stub
		mListAdapter = new UnUseParkAdapter(mOwner);
	}

	@Override
	protected String getRefreshURL() {
		// TODO Auto-generated method stub
		return mOwner.getServer().getURL(IServer.URL_FREE_PARK_INFO);
	}

	@Override
	protected CharSequence getEmptyText() {
		// TODO Auto-generated method stub
		return "在这里查看剩余车位的情况\n下拉可以刷新";
	}	

	@SuppressWarnings("rawtypes")
	@Override
	protected TypeToken getListModelTypeToken() {
		// TODO Auto-generated method stub
		return new TypeToken<List<UnUsePark>>(){};
	}
	
	@Override
	protected void handleModels(List<UnUsePark> models) {
		// TODO Auto-generated method stub
		for(UnUsePark order : models){
//			order.setOrderId(order.getId()+"_"+order.getType());
		}
	}
	
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		if(requestCode == REQ_VIEW_ORDER && resultCode == Activity.RESULT_OK){
			refreshListViewFromServer();
		}
	}

	@Override
	protected void viewModelByItemClick(UnUsePark m) {
		// TODO Auto-generated method stub
		
	}

}
