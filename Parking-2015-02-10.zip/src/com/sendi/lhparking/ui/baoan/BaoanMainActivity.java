package com.sendi.lhparking.ui.baoan;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;
import org.sendi.parking.ui.R;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnDismissListener;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.LinearLayout.LayoutParams;

import com.ab.view.sliding.AbSlidingTabView;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.sendi.lhparking.ctx.ParkingApp;
import com.sendi.lhparking.im.conn.XmppManager;
import com.sendi.lhparking.ui.common.AboutActivity;
import com.sendi.lhparking.ui.common.BaseActivity;
import com.sendi.lhparking.ui.common.ChangePswActivity;
import com.sendi.lhparking.ui.common.CheckVersionActivity;
import com.sendi.lhparking.ui.common.DefaultSettingActivity;
import com.sendi.lhparking.ui.common.FeedBackActivity;
import com.sendi.lhparking.ui.common.LoginActivity;
import com.sendi.lhparking.ui.common.PersonInfoActivity;
import com.sendi.lhparking.ui.common.SetSecretActivity;
import com.sendi.lhparking.ui.common.SettingActivity;
import com.sendi.lhparking.ui.common.base.BaseFragmentActivity;
import com.sendi.lhparking.ui.common.frag.CompletedOrderListFragment;
import com.sendi.lhparking.ui.common.frag.ExecutingOrderListFragment;
import com.sendi.lhparking.ui.wuye.AddParkingHistoryActivity;
import com.sendi.lhparking.util.MD5Crypter;
import com.sendi.lhparking.util.ParkingPrefs;

public class BaoanMainActivity extends BaseFragmentActivity implements OnTouchListener {

	private Button btnMenu;
	private LinearLayout llmenu;
	private LinearLayout llConetent;
	
	private LinearLayout.LayoutParams menuParams, contextParams;
	private int screenWidth;
	private boolean isShowMenu = false;
	private int rightEdge;
	private int leftEdge;
	
	private AbSlidingTabView vTapView;
	private List<Fragment> mFragments;
	private List<String> mTabTexts;
	
	private Button btnPersonalinfo;
	private Button btnChangepsw;
	private Button btnSecret;
	private Button btnFeedback;
	private Button btnAbout;
	private Button btnCheckVersion;
	private Button btnExit;
	
	private Dialog mDialog;
	private ProgressDialog proDialog;
	private String curShowView = "0";
	private int dialogDismiss = 0;
	private int mAppTypeCode = 0;
	private String ServerURL = "https://121.33.214.30:8443/lhparking/servlet/SysInterface";

	private TextView tvInUse, tvFree;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_baoanmain);
		ParkingApp.mAppCtx.setOrderTabHandler(orderTabHandler);
		init();
		initData();
		initViews();
		initView();
		getParkCountInfo();
	}
	
	private void initData() {
		mFragments = new ArrayList<Fragment>();
		mFragments.add(new InUseParkListFragment());   // 已用车位
		mFragments.add(new UnUseParkListFragment());   // 剩余车位
//		mFragments.add(new ExecutingOrderListFragment());   // 已用车位
//		mFragments.add(new CompletedOrderListFragment());   // 剩余车位
		
		mTabTexts = new ArrayList<String>();
		mTabTexts.add("已用车位");
		mTabTexts.add("剩余车位");
	}
	
	private void initViews() {
		//设置样式
		vTapView = (AbSlidingTabView) this.findViewById(R.id.order_list_tabview);
		
		vTapView.setTabTextColor(Color.BLACK);
		vTapView.setTabSelectColor(Color.rgb(30, 168, 131));
		vTapView.setTabBackgroundResource(R.drawable.tab_bg);
		vTapView.setTabLayoutBackgroundResource(R.drawable.slide_top);
		//演示增加一组
		vTapView.addItemViews(mTabTexts, mFragments);
		vTapView.setTabPadding(20, 8, 20, 8);
	}
	
	private void initView() {
		// 获取屏幕分辨率
		DisplayMetrics dm = new DisplayMetrics();
		WindowManager wm = (WindowManager)getApplicationContext().getSystemService(Context.WINDOW_SERVICE);
		wm.getDefaultDisplay().getMetrics(dm);
		screenWidth = dm.widthPixels;
		leftEdge = -(screenWidth/2);
		
		tvInUse = (TextView) this.findViewById(R.id.tv_in_use);
		tvFree = (TextView) this.findViewById(R.id.tv_free);
		btnMenu = (Button) this.findViewById(R.id.btn_menu);
		llmenu = (LinearLayout) this.findViewById(R.id.layout_menu);
		llConetent = (LinearLayout) this.findViewById(R.id.layout_content);
		
		contextParams = (LayoutParams) llConetent.getLayoutParams();
		menuParams = (LayoutParams) llmenu.getLayoutParams();
		
		menuParams.width = screenWidth/2;
		menuParams.rightMargin = -screenWidth;
		contextParams.width = screenWidth;
		
		btnMenu.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(isShowMenu) {
					new SlidingTask().execute(30);
				}else {
					new SlidingTask().execute(-30);
				}
			}
		});
		
		
	}

	@Override
	public boolean onTouch(View v, MotionEvent event) {
		// TODO Auto-generated method stub
		return false;
	}
	
	class SlidingTask extends AsyncTask<Integer, Integer, Integer> {

		@Override
		protected Integer doInBackground(Integer... params) {
			// TODO Auto-generated method stub
			int leftMargin = contextParams.leftMargin;
			while(true) {
				leftMargin = leftMargin + params[0];
				if(leftMargin > 0) {
					leftMargin = 0;
					break;
				}
				if(leftMargin < leftEdge) {
					leftMargin = leftEdge;
					break;
				}
				publishProgress(leftMargin);
				sleep(20);
			}
			if(params[0] >0) {
				isShowMenu = false;
			}else {
				isShowMenu = true;
			}
			return leftMargin;
		}

		@Override
		protected void onPostExecute(Integer result) {
			// TODO Auto-generated method stub
			contextParams.leftMargin = result;
			llConetent.setLayoutParams(contextParams);
		}

		@Override
		protected void onProgressUpdate(Integer... values) {
			// TODO Auto-generated method stub
			contextParams.leftMargin = values[0];
			llConetent.setLayoutParams(contextParams);
		}
	}
	
	private void sleep(long millis) {
		try {
			Thread.sleep(millis);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	Handler orderTabHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			setSelectItem(msg.what);
		}
		
	};
	
	private void setSelectItem(int item) {
		vTapView.setCurrentItem(item);
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		int index = vTapView.getViewPager().getCurrentItem();
		mFragments.get(index).onActivityResult(requestCode, resultCode, data);
	}
	
	private long exitTime = 0;
	
	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		if((System.currentTimeMillis()-exitTime) > 2000){  
            Toast.makeText(getApplicationContext(), "再按一次返回键退出程序", Toast.LENGTH_SHORT).show();                                
            exitTime = System.currentTimeMillis();   
        } else {
            finish();
            System.exit(0);
        }
	}
	
	private void init() {
		btnChangepsw = (Button) this.findViewById(R.id.btn_changepsw);
		btnSecret = (Button) this.findViewById(R.id.btn_secret);
		btnExit = (Button) this.findViewById(R.id.btn_exit);
		btnFeedback = (Button) this.findViewById(R.id.btn_feedback);
		btnAbout = (Button) this.findViewById(R.id.btn_about);
		btnPersonalinfo = (Button) this.findViewById(R.id.btn_personalinfo);
		btnCheckVersion = (Button) this.findViewById(R.id.btn_checkversion);
		
		btnChangepsw.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(BaoanMainActivity.this, ChangePswActivity.class);
				startActivity(intent);
			}
		});
		
		btnSecret.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(BaoanMainActivity.this, SetSecretActivity.class);
				startActivity(intent);
			}
		});
		
		btnFeedback.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(BaoanMainActivity.this, FeedBackActivity.class);
				startActivity(intent);
			}
		});
		
		btnAbout.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(BaoanMainActivity.this, AboutActivity.class);
				startActivity(intent);
			}
		});		
		
		btnCheckVersion.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(BaoanMainActivity.this, CheckVersionActivity.class);
				startActivity(intent);
			}
		});
		
		btnExit.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				showExitDialog();
			}
		});
		
		btnPersonalinfo.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(BaoanMainActivity.this, PersonInfoActivity.class);
				startActivity(intent);
			}
		});
	}
	
	/** 
	 * 是否退出提示框
	 * */
	private void showExitDialog() {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("提醒");
		builder.setMessage("是否确定退出？");
		builder.setCancelable(false);
		builder.setNegativeButton("取消",
				new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						return;
					}
				});
		builder.setPositiveButton("确定",
				new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub\
						ParkingPrefs.loginOut();
						XmppManager.getXmpp().disConn();
						Intent intentLogin = new Intent(BaoanMainActivity.this, LoginActivity.class);
						startActivity(intentLogin);
						ParkingApp.mAppCtx.finishMainActivity();
					}
				});	
		builder.create().show();
	}
	
	private void getParkCountInfo() {
		curShowView = "getParkCountInfo";
		RequestParams params = new RequestParams();
		params.addBodyParameter("method", "2010");
		params.addBodyParameter("uid", ParkingApp.mAppCtx.getUID());
		params.addBodyParameter("utype", ParkingApp.mAppCtx.getUType()+"");
		Log.i("TEST", "Utype : " + String.valueOf(ParkingApp.mAppCtx.getUType()));
		HttpUtils http = new HttpUtils(10000);
		
		Log.i("TEST", "POST URL : " + ServerURL+"?uid="+ParkingApp.mAppCtx.getUID()+"&utype="+ParkingApp.mAppCtx.getUType()
				+"&method=2010");
		
		showProgDialog("正在查询...", http);
		http.send(HttpMethod.POST, ServerURL, params,
				new RequestCallBack<String>() {

					@Override
					public void onSuccess(ResponseInfo<String> responseInfo) {
						// TODO Auto-generated method stub
						Log.i("TEST", "test" + responseInfo.result);
						if(curShowView.equals("getParkCountInfo")) {
							try {
								JSONObject jso = new JSONObject(responseInfo.result);
								int free = jso.getInt("free");
								int inuse = jso.getInt("in_use");
								tvInUse.setText("已用车位： "+String.valueOf(inuse));
								tvFree.setText("剩余车位： "+String.valueOf(free));
								
							} catch (Exception ex) {
								// TODO Auto-generated catch block
								ex.printStackTrace();
							}
							if (proDialog != null) {
								dialogDismiss = 1;
								proDialog.dismiss();
							}
						}
						}

					@Override
					public void onFailure(HttpException error, String msg) {
						// TODO Auto-generated method stub
						if(curShowView.equals("getParkCountInfo")) {
							Toast.makeText(BaoanMainActivity.this, "获取数据失败", Toast.LENGTH_LONG).show();
						}
						if (proDialog != null) {
							dialogDismiss = 1;
							proDialog.dismiss();
						}
					}
				});	
	}
	
	private void showProgDialog(final String msg, final HttpUtils httpUtils) {
		proDialog = new ProgressDialog(this);
		proDialog.setCanceledOnTouchOutside(false);
		proDialog.setOnDismissListener(new OnDismissListener() {
			
			@Override
			public void onDismiss(DialogInterface dialog) {
				// TODO Auto-generated method stub
				if(dialogDismiss == 0 ) {
					httpUtils.getHttpClient().getConnectionManager().closeExpiredConnections();
//					httpUtils.getHttpClient().getConnectionManager().shutdown();
				}
				dialogDismiss = 0;
				curShowView = "0";
				Log.i("TEST", "dialog dismiss : "+msg);
			}
		});
		proDialog.setMessage(msg);
		proDialog.show();
	}
}
