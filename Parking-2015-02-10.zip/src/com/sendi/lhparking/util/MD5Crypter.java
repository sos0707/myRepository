package com.sendi.lhparking.util;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * 
 * @author  
 * @version 1.0  
 */
public class MD5Crypter {

	private final static char HEX_DIGITS[] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd',
			'e', 'f' };

	private final static String UTF8 = "utf8";

	private final static String MD5 = "MD5";

	public static String MD5Encode(String originalString) {
		try {
			byte[] originalBytes = originalString.getBytes(UTF8);
			MessageDigest md = MessageDigest.getInstance(MD5);
			md.update(originalBytes);
			byte[] temps = md.digest();
			int j = temps.length;
			char[] str = new char[j * 2];
			int k = 0;
			for (int i = 0; i < j; i++) {
				byte tempByte = temps[i];
				str[k++] = HEX_DIGITS[tempByte >>> 4 & 0xf];
				str[k++] = HEX_DIGITS[tempByte & 0xf];
			}
			return new String(str).toUpperCase();

		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}
	public static void main(String[] args) {
		System.out.println(MD5Encode("a"));
	}
}
