package com.sendi.lhparking.util;

import android.util.Log;

/**
 * 
 * @author Administrator
 * 
 */
public class LogX {

	public static boolean isDeBug = true;
	public static String DEFAULT_TAG = "lh";

	public static void i(String msg) {
		if (isDeBug)
			Log.i(DEFAULT_TAG, msg);
	}

	public static void i(String tag, String msg) {
		// TODO Auto-generated method stub
		i(tag + " # " + msg);
	}

}
