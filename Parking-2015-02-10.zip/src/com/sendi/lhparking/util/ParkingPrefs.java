package com.sendi.lhparking.util;

import com.sendi.lhparking.ctx.ParkingApp;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

/**
 * APP 的prefs 数据
 * @author Administrator
 *
 */
public class ParkingPrefs {
	
	private static final String PREF_FILE_DEFAULT = "langhua";
	public static final String PREF_LANGHUA_UID = "langhua_uid";/*string*/
	public static final String PREF_LANGHUA_UTYPE = "langhua_utype";/*string*/
	private static final String AUTO_LOGIN = "auto_login";
	
	
	private static SharedPreferences getDefaultPreferences(){
		return ParkingApp.mAppCtx.getSharedPreferences(PREF_FILE_DEFAULT, Context.MODE_PRIVATE);
	}
	
	public ParkingPrefs(){
		
	}
	
	/**
	 * string value
	 * @param key
	 * @return
	 */
	public static String getStrValue(String key){
		return getDefaultPreferences().getString(key, null);
	}

	/**
	 * set value
	 */
	public static void setStrValue(String key, String value){
		SharedPreferences prefs = getDefaultPreferences();
		Editor edit = prefs.edit();
		edit.putString(key, value);
		boolean success = edit.commit();
//		LogX.i("设置 key : "+key+"; value : "+value+" 成功?"+success);
	}
	
	/**
	 * 
	 * @param key
	 * @return
	 */
	public static boolean getBoolValue(String key, boolean defvalue){
		return getDefaultPreferences().getBoolean(key, defvalue);
	}
	
	public static void setBoolValue(String key, boolean value){
		SharedPreferences prefs = getDefaultPreferences();
		Editor edit = prefs.edit();
		edit.putBoolean(key, value);
		boolean success = edit.commit();
//		LogX.i("设置 key : "+key+"; value : "+value+" 成功?"+success);
	}
	
	public static long getLongValue(String key, long defvalue){
		return getDefaultPreferences().getLong(key, defvalue);
	}
	
	public static void setLongValue(String key, long value){
		SharedPreferences prefs = getDefaultPreferences();
		Editor edit = prefs.edit();
		edit.putLong(key, value);
		boolean success = edit.commit();
//		LogX.i("设置 key : "+key+"; value : "+value+" 成功?"+success);
	}
	
	public static void setIntValue(String key, int value) {
		SharedPreferences prefs = getDefaultPreferences();
		Editor edit = prefs.edit();
		edit.putInt(key, value);
		boolean success = edit.commit();
	}
	
	public static int getIntValue(String key, int defvalue){
		return getDefaultPreferences().getInt(key, defvalue);
	}
	
	/**
	 * 退出登录
	 */
	public static boolean loginOut(){
		SharedPreferences prefs = getDefaultPreferences();
		Editor edit = prefs.edit();
		edit.putBoolean(AUTO_LOGIN, false);
		edit.remove(PREF_LANGHUA_UID);
		edit.remove(PREF_LANGHUA_UTYPE);
		return edit.commit();
	}
}
