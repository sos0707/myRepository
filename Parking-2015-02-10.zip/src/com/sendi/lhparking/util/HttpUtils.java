package com.sendi.lhparking.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.FileEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;
import org.sendi.parking.ui.wxapi.Util;

import android.util.Log;

public class HttpUtils {

	private static HttpClient httpclient;
	

	// 获得HttpClient对象，设置超时参数 (单例模式)
	public static final HttpClient getHttpClient() {
		BasicHttpParams httpParams = new BasicHttpParams();
		httpParams.setParameter("charset", "UTF-8");
		// 设置连接超时
		HttpConnectionParams.setConnectionTimeout(httpParams, 3000);
		HttpConnectionParams.setSoTimeout(httpParams, 5000);
//		httpclient = new DefaultHttpClient(httpParams);
		httpclient = Util.getNewHttpClient();
		return httpclient;
	}
	
	// 获得Get请求对象request
	public static HttpGet getHttpGet(String url) {
		HttpGet request = new HttpGet(url);
		return request;
	}

	// 获得Post请求对象request
	public static HttpPost getHttpPost(String url) {
		HttpPost request = new HttpPost(url);
		return request;
	}

	// 根据请求获得响应对象response
	public static HttpResponse getHttpResponse(HttpGet request) throws ClientProtocolException, IOException {
		
		HttpClient httpClient = getHttpClient();
		HttpResponse response = httpClient.execute(request);
		return response;
	}

	// 根据请求获得响应对象response
	public static HttpResponse getHttpResponse(HttpPost request) throws ClientProtocolException, IOException {
		if (null == request)
		{
			return null;
		}
		HttpClient httpClient = getHttpClient();
		HttpResponse response = httpClient.execute(request);
		return response;
	}

	// 根据请求获得响应对象response
	public static String execute(HttpGet request, HttpContext context) {
		String result = "OK";
		HttpClient httpClient = getHttpClient();
		try {
			if (context != null)
				httpClient.execute(request, context);
			else
				httpClient.execute(request);

		} catch (ClientProtocolException e) {
			e.printStackTrace();
			result = "网络异常！";
		} catch (IOException e) {
			e.printStackTrace();
			result = "IO异常";
		}
		return result;
	}

	// 发送Post请求，获得响应查询结果
	public static String queryStringForPost(String url) {
		// 根据url获得HttpPost对象
		HttpPost request = HttpUtils.getHttpPost(url);
		String result = null;
		try {
			// 获得响应对象
			HttpResponse response = HttpUtils.getHttpResponse(request);
			// 判断是否请求成功
			if (response.getStatusLine().getStatusCode() == 200) {
				// 获得响应
				InputStream is = response.getEntity().getContent();
				byte[] array = new byte[(int) response.getEntity().getContentLength()];
				is.read(array);
				is.close();
				return new String(array, "UTF-8");
			}
		} catch (ClientProtocolException e) {
			e.printStackTrace();
			result = "网络异常！";
			return result;
		} catch (IOException e) {
			e.printStackTrace();
			result = "IO异常";
			return result;
		}
		return null;
	}

	// 获得响应查询结果
	public static String queryStringForPost(HttpPost request) {
		if (null == request)
		{
			return null;
		}
		String result = null;
		try {
			// 获得响应对象
			/*HttpResponse response = HttpUtils.getHttpResponse(request);
			// 判断是否请求成功
			// 获得响应
			//注意 getEntity() 只能使用一次
			//result = EntityUtils.toString(response.getEntity());
			InputStream is = response.getEntity().getContent();
			long length = response.getEntity().getContentLength();
			if (length <= 0)
			{
				is.close();
				return null;
			}
			byte[] array = new byte[(int) response.getEntity().getContentLength()];
			is.read(array);
			is.close();
			return new String(array, "UTF-8");*/
			HttpResponse response = HttpUtils.getHttpResponse(request);
			HttpEntity entity = response.getEntity();  
	        StringBuffer sb = new StringBuffer();  
	        if (entity != null) {  
	            InputStream is = entity.getContent();  
	            if (null != is)
				{
	            	byte[] bytes = new byte[1024];  
	            	int size = 0;  
	            	while ((size = is.read(bytes)) > 0) {  
	            		String str = new String(bytes, 0, size, "UTF-8");  
	            		sb.append(str);  
	            	}  
	            	is.close();  
				}
	        }  
	        return sb.toString();  

		} catch (ClientProtocolException e) {
			e.printStackTrace();
			result = "网络异常！";
			return result;
		} catch (IOException e) {
			e.printStackTrace();
			result = "IO异常";
			return result;
		}
	}

	public static String queryStringForPost(String url, File file)
	{
		if (null == url || null == file || file.isDirectory())
		{
			return null;
		}
		String uploadResult = null;
		HttpPost request = HttpUtils.getHttpPost(url);
	//	FileEntity entity = new FileEntity(file, "binary/octet-stream");
		FileEntity entity = new FileEntity(file, "text/plain");
		request.setEntity(entity);
		//request.setHeader("Content-Type", "application/x-www-form-urlencoded; charset=utf-8");
		uploadResult = HttpUtils.queryStringForPost(request);
		return uploadResult;
	}

	// 发送Get请求，获得响应查询结果
	public static String queryStringForGet(String url) {
		// 获得HttpGet对象
		HttpGet request = HttpUtils.getHttpGet(url);
		String result = null;
		try {
			// 获得响应对象
			HttpResponse response = HttpUtils.getHttpResponse(request);
			// 判断是否请求成功
			if (response.getStatusLine().getStatusCode() == 200) {
				// 获得响应
				result = EntityUtils.toString(response.getEntity());
				return result;
			} else {
				// return response.getAllHeaders().toString();
				return response.getStatusLine().toString();
			}
		} catch (ClientProtocolException e) {
			e.printStackTrace();
			result = "网络异常！";
			return result;
		} catch (IOException e) {
			e.printStackTrace();
			result = "IO异常";
			return result;
		}
	}

	// 发送Get请求，获得响应查询结果
	public static String queryStringForGet2(String url) {
		// 获得HttpGet对象
		HttpGet request = HttpUtils.getHttpGet(url);
		String result = null;
		try {
			// 获得响应对象
			HttpResponse response = HttpUtils.getHttpResponse(request);
			// 判断是否请求成功
			if (response.getStatusLine().getStatusCode() == 200) {
				// 获得响应
				InputStream is = response.getEntity().getContent();
				byte[] array = new byte[(int) response.getEntity().getContentLength()];
				is.read(array);
				is.close();
				return new String(array, "UTF-8");
			} else {
				Log.d("wifi", "HttpUtils>>>" + response.getStatusLine().toString());
				return "false1";
			}
		} catch (ClientProtocolException e) {
			e.printStackTrace();
			result = "false2";
			return result;
		} catch (IOException e) {
			e.printStackTrace();
			result = "false3";
			return result;
		}
	}

	public static String Query_getURL(String url) {
		// 根据url获得HttpPost对象
		HttpGet request = HttpUtils.getHttpGet(url);
		String result = null;
		try {
			// 获得响应对象
			HttpResponse response = HttpUtils.getHttpResponse(request);
			// 判断是否请求成功
			if (response.getStatusLine().getStatusCode() == 200) {
				// 获得响应
				result = EntityUtils.toString(response.getEntity());
				return result;
			} else {
				// return response.getAllHeaders().toString();
				// return response.getStatusLine().toString();
				return "网络异常";
			}

		} catch (ClientProtocolException e) {
			e.printStackTrace();
			result = "网络异常";
			return result;
		} catch (IOException e) {
			e.printStackTrace();
			result = "IO异常";
			return result;
		}
	}

	public static String Httpconnection(String httpUrl)
	{
		try
		{
			URL url = new URL(httpUrl);
			HttpURLConnection conn=(HttpURLConnection)url.openConnection();  
			// 取得inputStream，并进行读取
			InputStream input = conn.getInputStream();
			BufferedReader in = new BufferedReader(new InputStreamReader(input));
			String line = null;
			StringBuffer sb = new StringBuffer();
			while ((line = in.readLine()) != null)
			{
				sb.append(line);
			}
			return sb.toString();
		} catch (MalformedURLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
       return null;
	}
}
