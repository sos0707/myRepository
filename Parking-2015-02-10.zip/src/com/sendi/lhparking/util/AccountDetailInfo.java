package com.sendi.lhparking.util;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class AccountDetailInfo implements Parcelable{
//	{user_name,time,task_name,task_id,money,flag} 
//	user_name：姓名  time：结算时间 money：金额（收入为正，支出为负） task_name：值为4种：收入，支出，充值，提现。 Flag：parkcar/money
//	当task_name为“充值”时，返回值 新增---pay_type_en：1支付宝 2微信支付   pay_type：pay_type_en的中文说明 amountId：交易流水号
//	  当task_name为“提现”时，返回值 新增 ---pay_type_en 1支付宝 2理财通 3：银行卡 pay_type：pay_type_en的中文说明  。
//	  account：账号。 bank：银行名称(当 pay_type=3的时候显示)
	private String userName;
	private String time;
	private String taskName;
	private String taskId;
	private double money;
	private String flag;
	private int payTypeEn;
	private String payType;
	private String amountId;
	private String account;
	private String bank;
	private String state;
	
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public int getPayTypeEn() {
		return payTypeEn;
	}
	public void setPayTypeEn(int payTypeEn) {
		this.payTypeEn = payTypeEn;
	}
	public String getPayType() {
		return payType;
	}
	public void setPayType(String payType) {
		this.payType = payType;
	}
	public String getAmountId() {
		return amountId;
	}
	public void setAmountId(String amountId) {
		this.amountId = amountId;
	}
	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	public String getBank() {
		return bank;
	}
	public void setBank(String bank) {
		this.bank = bank;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public String getTaskId() {
		return taskId;
	}
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	public double getMoney() {
		return money;
	}
	public void setMoney(double money) {
		this.money = money;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	@Override
	public int describeContents() {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public void writeToParcel(Parcel parcel, int flags) {
		// TODO Auto-generated method stub
		parcel.writeString(userName);
		parcel.writeString(time);
		parcel.writeString(taskName);
		parcel.writeString(taskId);
		parcel.writeDouble(money);
		parcel.writeString(flag);
		parcel.writeInt(payTypeEn);
		parcel.writeString(payType);
		parcel.writeString(amountId);
		parcel.writeString(account);
		parcel.writeString(bank);
		parcel.writeString(state);
	}
	
	public static final Parcelable.Creator<AccountDetailInfo> CREATOR = new Creator<AccountDetailInfo>() {

		@Override
		public AccountDetailInfo createFromParcel(Parcel arg0) {
			// TODO Auto-generated method stub
			AccountDetailInfo info = new AccountDetailInfo();
			info.userName = arg0.readString();
			info.time = arg0.readString();
			info.taskName = arg0.readString();
			info.taskId = arg0.readString();
			info.money = arg0.readDouble();
			info.flag = arg0.readString();
			info.payTypeEn = arg0.readInt();
			info.payType = arg0.readString();
			info.amountId = arg0.readString();
			info.account = arg0.readString();
			info.bank = arg0.readString();
			info.state = arg0.readString();
			return info;
		}

		@Override
		public AccountDetailInfo[] newArray(int arg0) {
			// TODO Auto-generated method stub
			return new AccountDetailInfo[arg0];
		}
	};
}
