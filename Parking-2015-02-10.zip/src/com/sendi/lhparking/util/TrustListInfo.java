package com.sendi.lhparking.util;

public class TrustListInfo {
	
	private String parkName;
	private String parkId;
	private String parkingNo;
	private String relateTime;
	
	public String getParkName() {
		return parkName;
	}
	public void setParkName(String parkName) {
		this.parkName = parkName;
	}
	public String getParkId() {
		return parkId;
	}
	public void setParkId(String parkId) {
		this.parkId = parkId;
	}
	public String getParkingNo() {
		return parkingNo;
	}
	public void setParkingNo(String parkingNo) {
		this.parkingNo = parkingNo;
	}
	public String getRelateTime() {
		return relateTime;
	}
	public void setRelateTime(String relateTime) {
		this.relateTime = relateTime;
	}
	
	
}
