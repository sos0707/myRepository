package com.sendi.lhparking.util;

import android.os.Parcel;
import android.os.Parcelable;

public class ParkingDetailInfo implements Parcelable{
//	"id":"218","time_hour":"08:50---21:50","price":"10元/小时","parking_no":"1" park_rate：好评率
	private String pid;
	private String timeHour;
	private String price;
	private String pno;
	private String pdate;
	private String prate;
	private String bossId;
	
	public String getBossId() {
		return bossId;
	}
	public void setBossId(String bossId) {
		this.bossId = bossId;
	}
	public String getPrate() {
		return prate;
	}
	public void setPrate(String prate) {
		this.prate = prate;
	}
	public String getPdate() {
		return pdate;
	}
	public void setPdate(String pdate) {
		this.pdate = pdate;
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getTimeHour() {
		return timeHour;
	}
	public void setTimeHour(String timeHour) {
		this.timeHour = timeHour;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getPno() {
		return pno;
	}
	public void setPno(String pno) {
		this.pno = pno;
	}
	
	public String getStrPrice() {
		String s[] = this.price.split("元");
		return s[0];
	}
	
	@Override
	public int describeContents() {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public void writeToParcel(Parcel parcel, int arg1) {
		// TODO Auto-generated method stub
		parcel.writeString(pid);
		parcel.writeString(pno);
		parcel.writeString(price);
		parcel.writeString(timeHour);
		parcel.writeString(pdate);
		parcel.writeString(prate);
		parcel.writeString(bossId);
	}
	
	public static final Parcelable.Creator<ParkingDetailInfo> CREATOR = new Creator<ParkingDetailInfo>() {

		@Override
		public ParkingDetailInfo createFromParcel(Parcel arg0) {
			// TODO Auto-generated method stub
			ParkingDetailInfo info = new ParkingDetailInfo();
			info.pid = arg0.readString();
			info.pno = arg0.readString();
			info.price = arg0.readString();
			info.timeHour = arg0.readString();
			info.pdate = arg0.readString();
			info.prate = arg0.readString();
			info.bossId = arg0.readString();
			return info;
		}

		@Override
		public ParkingDetailInfo[] newArray(int arg0) {
			// TODO Auto-generated method stub
			return new ParkingDetailInfo[arg0];
		}
	};
}
