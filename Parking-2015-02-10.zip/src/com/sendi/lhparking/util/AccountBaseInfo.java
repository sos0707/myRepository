package com.sendi.lhparking.util;

public class AccountBaseInfo {
	/*{balance,total_income,day_income,week_income,week_outcome,total_outcome} 
	分别代表 金额 ，总收益，昨日收益，一周收益，一周支出，总支出*/
	
	private String balance;
	private String totalIncome;
	private String dayIncome;
	private String weekIncome;
	private String weekOutcome;
	private String totalOutcome;
	private String ranking;
	
	
	public String getRanking() {
		return ranking;
	}
	public void setRanking(String ranking) {
		this.ranking = ranking;
	}
	public String getBalance() {
		return balance;
	}
	public void setBalance(String balance) {
		this.balance = balance;
	}
	public String getTotalIncome() {
		return totalIncome;
	}
	public void setTotalIncome(String totalIncome) {
		this.totalIncome = totalIncome;
	}
	public String getDayIncome() {
		return dayIncome;
	}
	public void setDayIncome(String dayIncome) {
		this.dayIncome = dayIncome;
	}
	public String getWeekIncome() {
		return weekIncome;
	}
	public void setWeekIncome(String weekIncome) {
		this.weekIncome = weekIncome;
	}
	public String getWeekOutcome() {
		return weekOutcome;
	}
	public void setWeekOutcome(String weekOutcome) {
		this.weekOutcome = weekOutcome;
	}
	public String getTotalOutcome() {
		return totalOutcome;
	}
	public void setTotalOutcome(String totalOutcome) {
		this.totalOutcome = totalOutcome;
	}
	
	
}
