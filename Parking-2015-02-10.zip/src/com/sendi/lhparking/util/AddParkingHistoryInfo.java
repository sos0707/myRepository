package com.sendi.lhparking.util;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class AddParkingHistoryInfo implements Parcelable{
	/*parkingName：小区名字  city //所属市  district：区 address：详细地址
	numberField：车位数 chargeUnit：物业公司  inchargeName：姓名  phoneNumber：联系电话 mobileNumber：手机*/
	private String parkingName;
	private String city;
	private String district;
	private String address;
	private String numberField;
	private String chargeUnit;
	private String inchargeName;
	private String phoneNumber;
	private String mobileNumber;
	private String state;
	
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getParkingName() {
		return parkingName;
	}
	public void setParkingName(String parkingName) {
		this.parkingName = parkingName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getNumberField() {
		return numberField;
	}
	public void setNumberField(String numberField) {
		this.numberField = numberField;
	}
	public String getChargeUnit() {
		return chargeUnit;
	}
	public void setChargeUnit(String chargeUnit) {
		this.chargeUnit = chargeUnit;
	}
	public String getInchargeName() {
		return inchargeName;
	}
	public void setInchargeName(String inchargeName) {
		this.inchargeName = inchargeName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	@Override
	public int describeContents() {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public void writeToParcel(Parcel parcel, int arg1) {
		// TODO Auto-generated method stub
		parcel.writeString(parkingName);
		parcel.writeString(city);
		parcel.writeString(district);
		parcel.writeString(address);
		parcel.writeString(numberField);
		parcel.writeString(chargeUnit);
		parcel.writeString(inchargeName);
		parcel.writeString(phoneNumber);
		parcel.writeString(mobileNumber);
		parcel.writeString(state);
	}
	
	public static final Parcelable.Creator<AddParkingHistoryInfo> CREATOR = new Creator<AddParkingHistoryInfo>() {

		@Override
		public AddParkingHistoryInfo createFromParcel(Parcel arg0) {
			// TODO Auto-generated method stub
			AddParkingHistoryInfo info = new AddParkingHistoryInfo();
			info.parkingName = arg0.readString();
			info.city = arg0.readString();
			info.district = arg0.readString();
			info.address = arg0.readString();
			info.numberField = arg0.readString();
			info.chargeUnit = arg0.readString();
			info.inchargeName = arg0.readString();
			info.phoneNumber = arg0.readString();
			info.mobileNumber = arg0.readString();
			info.state = arg0.readString();
			return info;
		}

		@Override
		public AddParkingHistoryInfo[] newArray(int arg0) {
			// TODO Auto-generated method stub
			return new AddParkingHistoryInfo[arg0];
		}
	};
}
