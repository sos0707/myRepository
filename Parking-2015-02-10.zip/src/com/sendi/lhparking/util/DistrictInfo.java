package com.sendi.lhparking.util;

public class DistrictInfo {
	private String districtName;
	private String districtEn;
	private String districtCode;
	
	public String getDistrictName() {
		return districtName;
	}
	public void setDistrictName(String districtName) {
		this.districtName = districtName;
	}
	public String getDistrictEn() {
		return districtEn;
	}
	public void setDistrictEn(String districtEn) {
		this.districtEn = districtEn;
	}
	public String getDistrictCode() {
		return districtCode;
	}
	public void setDistrictCode(String districtCode) {
		this.districtCode = districtCode;
	}

}
