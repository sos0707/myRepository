package com.sendi.lhparking.payutil;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.sql.Date;
import java.text.SimpleDateFormat;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.alipay.android.app.sdk.AliPay;

public class AliPayUtil {

	
	private String body = "浪花停车充值";
	private String totalfee = "0.1";
	private String outtradeno = "20140711123123123";
	private Activity mContext;
	private Handler mHandler;
	
	public AliPayUtil(Activity context, Handler handler) {
		this.mContext = context;
		this.mHandler = handler;
	}
	
	public void doAliPay(String body, String totalfee, String outTradeNo) {
		this.body = body;
		this.totalfee = totalfee;
		this.outtradeno = outTradeNo;
		
		String info = getNewOrderInfo();
		if( info == null || info == "" ) {
			return;
		}
		String sign = Rsa.sign(info, Keys.PRIVATE);
		try {
			sign = URLEncoder.encode(sign, "UTF-8");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		info += "&sign=\"" + sign + "\"&" + getSignType();

		final String orderInfo = info;
		Log.i("TEST AliPayUtil orderInfo : ", info);
		new Thread() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				AliPay alipay = new AliPay(mContext, mHandler);
				String result = alipay.pay(orderInfo);
				Message msg = new Message();
				msg.what = 1;
				msg.obj = result+","+AliPayUtil.this.outtradeno;
				mHandler.sendMessage(msg);
			}
		}.start();
	}
	
	private String getNewOrderInfo() {
		StringBuilder sb = new StringBuilder();
		try {
			sb.append("partner=\"");
			sb.append(Keys.DEFAULT_PARTNER);
			sb.append("\"&out_trade_no=\"");
			sb.append(this.outtradeno);

			sb.append("\"&subject=\"");
			sb.append(this.body);
			sb.append("\"&body=\"");
			sb.append("浪花停车充值");
			sb.append("\"&total_fee=\"");
			sb.append(this.totalfee);
			sb.append("\"&notify_url=\"");
//			// 网址需要做URL编码
			sb.append(URLEncoder.encode("http://lhhl.cc/lhparking/AliPayInterface", "UTF-8"));
			sb.append("\"&service=\"mobile.securitypay.pay");
			sb.append("\"&_input_charset=\"UTF-8");
			sb.append("\"&return_url=\"");
			sb.append(URLEncoder.encode("http://m.alipay.com", "UTF-8"));
			sb.append("\"&payment_type=\"1");
			sb.append("\"&seller_id=\"");
			sb.append(Keys.DEFAULT_SELLER);
			// 如果show_url值为空，可不传
			// sb.append("\"&show_url=\"");
			sb.append("\"&it_b_pay=\"1m");
			sb.append("\"");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		
		return new String(sb);
	}
	
	private String getSignType() {
		return "sign_type=\"RSA\"";
	}

}
