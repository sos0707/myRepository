package com.sendi.lhparking.server;

public interface IServer {
	
	//apk
	public static final int URL_FLAG_GET_APK = 1001;
	public static final int URL_FLAG_GET_APK_VERSION = 1002;
	public static final String V_SPLIT = "V#";//v文件的分隔符
	
	//发布
	
	public static final int URL_FLAG_GET_PUBLISH_VIEW = 1;
	//city list
	public static final int URL_FLAG_GET_CITIES = 2;
	//行政区
	public static final int URL_FLAG_GET_DISTRICT = 3;
	//居民小区
	public static final int URL_FLAG_GET_QUARTER = 4;
	//提交新建的停车任务
	public static final int URL_FLAG_POST_NEW_PUBLISH = 5;
	//业主  删除 或者 修改  或 暂停 已发布的车位 
	public static final int URL_FLAG_POST_USER_OPT_PUBLISH = 6;
	//物业 审核车位
	public static final int URL_FLAG_POST_GUARD_OPT_PUBLISH = 7;
	
	//订单
	public static final int URL_FLAG_GET_ORDER_LIST_EXECUTING = 10;
	public static final int URL_FLAG_GET_ORDER_LIST_COMPLETED = 11;
	//订单详情
	public static final int URL_FLAG_GET_ORDER_VIEW = 12;
	
	//业主确认车主的 请求
	public static final int URL_FLAG_POST_ANSWER_TO_PARKING_REQ = 13;
	//二维码扫描失败  联系物业
	public static final int URL_FLAG_POST_NEED_QUARTER_GUARD = 14;
	
	//扫描二维码
	public static final int URL_FLAG_POST_SCAN = 15;
	//物业 确认 
	public static final int URL_FLAG_POST_QUARTER_ANSWER = 16;
	//提交  车主对业主的评价
	public static final int URL_FLAG_POST_EVALUATION_TO_PARKING_OWNER = 17;
	//获取评价总信息
	public static final int URL_FLAG_GET_EVALUATION_TOTAL_INFO = 18;
	//获取评价条目
	public static final int URL_FLAG_GET_EVALUATION_ITEMS = 19;
	//获取个人信息
	public static final int URL_FLAG_GET_PERSON_INFO = 20;
	//
	public static final int URL_IN_USE_PARK_INFO = 21;
	//
	public static final int URL_FREE_PARK_INFO = 22;
	
	//============= 参数
	//业主 删除 或者 修改发布车位
	public static final int USER_OPT_STATE_DELETE = -1;//删除任务
	public static final int USER_OPT_STATE_UN_PAUSE = 1;//取消暂停 
	public static final int USER_OPT_STATE_PAUSE = 2;//暂停
	//物业 拒绝 或者 通过
	public static final int GUARD_OPT_STATE_REFUSE = -1;
	public static final int GUARD_OPT_STATE_OK = 1;
	
	//业主 通过或者拒绝 车位预定
	public static final int PARKING_OWNER_ACCEPT = 1;
	public static final int PARKING_OWNER_REFUSE = -1;
	//车位状态
	//0车位已腾空, 1任务已认领, 2车辆已进场, 3车辆已离场, 4任务已确认, 5任务已拒绝 , 6等待物业确认
	/**
	 * 车位已腾空
	 */
	public static final int PARKING_STATE_EMPTY = 0;
	/**
	 * 任务已认领
	 */
	public static final int PARKING_STATE_WAIT_CONFIRM = 1;
	/**
	 * 车辆已进场
	 */
	public static final int PARKING_STATE_CAR_IN = 2;
	/**
	 * 车辆已离场
	 */
	public static final int PARKING_STATE_CAR_OUT = 3;
	/**
	 * 任务已确认
	 */
	public static final int PARKING_STATE_CONFIRM = 4;
	/**
	 * 任务已拒绝
	 */
	public static final int PARKING_STATE_REFUSE = 5;
	/**
	 * 等待物业确认
	 */
	public static final int PARKING_STATE_WAIT_QUARTER = 6;
	/**
	 * 
	 * @param urltag
	 * @param params
	 * @return
	 */
	public String getURL(int urlflag, String... params);

}
