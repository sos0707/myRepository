package com.sendi.lhparking.server;

import com.sendi.lhparking.ctx.ParkingApp;

/**
 * 代表服务器 相关设置
 * @author Administrator
 *
 */
public class ParkingServer implements IServer{
	
	private String address;
	
	public ParkingServer(String host, String port){
		checkAddress(host, port);
	}

	private void checkAddress(String host, String port) {
		// TODO Auto-generated method stub
//		this.address = "http://" + host + ":" + port + "/lhparking";// http://127.0.0.1:8088
		this.address = "https://" + host + ":" + port + "/lhparking"; // "121.33.214.30", "8443"
	}

	@Override
	public String getURL(int urlflag, String... params) {
		// TODO Auto-generated method stub
		switch (urlflag) {
		case URL_FLAG_GET_PUBLISH_VIEW:
			return getPublishViewModels(params);
		case URL_FLAG_GET_CITIES:
			return getCities(params);
		case URL_FLAG_GET_DISTRICT:
			return getDistricts(params);
		case URL_FLAG_GET_QUARTER:
			return getQuarter(params);
		case URL_FLAG_POST_NEW_PUBLISH:
			return postNewPublish(params);
		case URL_FLAG_POST_USER_OPT_PUBLISH:
			return postUserOptOnPublish(params);
		case URL_FLAG_POST_GUARD_OPT_PUBLISH:
			return postGuardOptOnPublish(params);
		case URL_FLAG_GET_ORDER_LIST_EXECUTING:
			return getExecutingOrderList(params);
		case URL_FLAG_GET_ORDER_LIST_COMPLETED:
			return getCompletedOrderList(params);
		case URL_FLAG_GET_ORDER_VIEW:
			return getViewOrder(params);
		case URL_FLAG_POST_ANSWER_TO_PARKING_REQ:
			return postAnswerToParkingReq(params);
		case URL_FLAG_POST_NEED_QUARTER_GUARD:
			return postNeedGuard(params);
		case URL_FLAG_POST_SCAN:
			return postScan(params);
		case URL_FLAG_POST_QUARTER_ANSWER:
			return postGuardOk(params);
		case URL_FLAG_POST_EVALUATION_TO_PARKING_OWNER:
			return postEvaluationToParkingOwner(params);
		case URL_FLAG_GET_EVALUATION_TOTAL_INFO:
			return getEvaluationTotalInfo(params);
		case URL_FLAG_GET_EVALUATION_ITEMS:
			return getEvaluationItems(params);
		case URL_FLAG_GET_PERSON_INFO:
			return getPersonInfo(params);
		case URL_FLAG_GET_APK:
			return getAPKDownUrl();
		case URL_FLAG_GET_APK_VERSION:
			return getAPKVersion();
		case URL_IN_USE_PARK_INFO:
			return getInUseParkInfo();
		case URL_FREE_PARK_INFO:
			return getFreeParkInfo();
		default:
			return null;
		}
	}
	
	private String wapperWithUIDAndUType(String url){
		url = url + "&uid="+ParkingApp.mAppCtx.getUID()+"&utype="+ParkingApp.mAppCtx.getUType();
		return url;
	}

	//无参数
	private String getPublishViewModels(String...params){
		return wapperWithUIDAndUType(address + "/servlet/SysInterface?method=2009");
	}
	
	//无参数
	private String getCities(String... params){
		return wapperWithUIDAndUType(address + "/servlet/SysInterface?method=201301");
	}
	
	//city_code
	private String getDistricts(String... params){
		return wapperWithUIDAndUType(address + "/servlet/SysInterface?method=201302&city_code="+params[0]);
	}
	//city_code  district_en
	private String getQuarter(String... params){
		return wapperWithUIDAndUType(address + "/servlet/SysInterface?method=201303&city_code="+params[0] +"&district_en="+params[1]);
	}
	
	//area_id   price   parking_no    start_hour  end_hour   cycle   validitydate
	private String postNewPublish(String... params){
		StringBuilder builder = new StringBuilder();
		builder.append(address)
			.append("/servlet/SysInterface?method=2002")
			.append("&area_id=").append(params[0])
			.append("&price=").append(params[1])
			.append("&parking_no=").append(params[2])
			.append("&start_hour=").append(params[3])
			.append("&end_hour=").append(params[4])
			.append("&cycle=").append(params[5])
			.append("&validitydate=").append(params[6]);
		return wapperWithUIDAndUType(builder.toString());
	}
	
	//task_id   state
	private String postUserOptOnPublish(String[] params) {
		// TODO Auto-generated method stub
		return wapperWithUIDAndUType(address + "/servlet/SysInterface?method=2008&task_id="+params[0]+"&state="+params[1]);
	}
	//task_id state trust_host
	private String postGuardOptOnPublish(String[] params) {
		// TODO Auto-generated method stub
		return  wapperWithUIDAndUType(address + "/servlet/SysInterface?method=2006&task_id="+params[0]+"&state="+params[1]+"&trust_host="+params[2]);
	}
	
	//无参数
	private String getCompletedOrderList(String[] params){
		return wapperWithUIDAndUType(address + "/servlet/SysInterface?method=2004");
	}

	// 无参数
	private String getExecutingOrderList(String[] params) {
		return wapperWithUIDAndUType(address
				+ "/servlet/SysInterface?method=2003");
	}
	
	// 无参数
	private String getViewOrder(String[] params) {
		return wapperWithUIDAndUType(address
				+ "/servlet/SysInterface?method=2007&task_id="+params[0]);
	}
	
	//method 16 业主通过或者拒绝  车主的预定请求
	//task_id  state  trust_guest
	private String postAnswerToParkingReq(String[] params) {
		// TODO Auto-generated method stub
		return wapperWithUIDAndUType(address
				+ "/servlet/SysInterface?method=2016&task_id="+params[0]
						+"&state="+params[1]
								+"&trust_guest="+params[2]);
	}
	
	//method：2017 物业确认放行 task_id：任务id  numOfScan: 1 代表入场 2代表离场 
	private String postGuardOk(String[] params) {
		// TODO Auto-generated method stub
		return wapperWithUIDAndUType(address
				+ "/servlet/SysInterface?method=2017&task_id="+params[0]
						+ "&order_id="+params[1] +"&numOfScan="+params[2]);
	}
	
	//method 18 车主联系物业
	private String postNeedGuard(String[] params) {
		// TODO Auto-generated method stub
		return wapperWithUIDAndUType(address
				+ "/servlet/SysInterface?method=2018&task_id="+params[0]);
	}
	
	//method method：2020  task_id：任务id   numOfScan: 1 代表入场 2代表离场  nid：小区id
	private String postScan(String[] params){
		return wapperWithUIDAndUType(address
				+ "/servlet/SysInterface?method=2020&task_id="+params[0]
						+ "&numOfScan="+params[1]
						+ "&nid="+params[2]
					    + "&door="+params[3]);
	}
	
	//method：config_2022  task_id：交易号     master：评价者ID  guest：被评价者ID   point：评分 comment:评论
	//返回：返回值： {success:true,msg:’评论成功’}
	private String postEvaluationToParkingOwner(String[] params) {
		// TODO Auto-generated method stub
		return wapperWithUIDAndUType(address
				+ "/servlet/SysInterface?method=config_2022&task_id="+params[0]
						+ "&master="+ params[1]
						+ "&guest=" + params[2]
						+ "&point=" + params[3]
						+ "&comment=" + params[4]);
	}
	/**
	 * 
	 * @param params
	 * @return
	 */
	private String getEvaluationTotalInfo(String[] params) {
		// TODO Auto-generated method stub
		return wapperWithUIDAndUType(address
				+ "/servlet/SysInterface?method=config_2015&guestId="+params[0]);
	}
	//
	private String getEvaluationItems(String[] params) {
		// TODO Auto-generated method stub
		return wapperWithUIDAndUType(address
				+ "/servlet/SysInterface?method=config_2016&guestId="+params[0]
						+ "&limit=" + params[1]);
	}
	//获取个人信息
	//method=2001
	private String getPersonInfo(String[] params) {
		// TODO Auto-generated method stub
		return wapperWithUIDAndUType(address
				+ "/servlet/SysInterface?method=2001");
	}
	
	private String getAPKDownUrl(){
		return address+"/lhparking.apk";
	}
	
	private String getAPKVersion(){
		return address+"/v";
	}
	
	private String getInUseParkInfo() {
		return wapperWithUIDAndUType(address
				+ "/servlet/SysInterface?method=2003");
	}
	
	private String getFreeParkInfo() {
		return wapperWithUIDAndUType(address
				+ "/servlet/SysInterface?method=unuse_2003");
	}
}
